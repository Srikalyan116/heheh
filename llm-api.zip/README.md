## Table of Contents
- [Introduction](#introduction)
- [How to build](#how-to-build)
- [Pre Commit Hooks](#pre-commit-hooks)
- [Contribute](#contribute)

# Introduction
This project contains the API Implementation for the Gen AI SDLC use cases.

# How to build

This repository uses [PDM](https://pdm-project.org/en/latest/) as a package management tool. To set it up, create a virtual environment using the following command:

    python -m venv <env-name>

Install pdm in the virtual environment using,

    pip install pdm

Install the dependencies for the required group using,

    pdm install -dg <group-name>

Set the environment variables as mentioned in the .env file.

Run the api instance using,

    gunicorn src/main:app -p 8000:8000

# Pre Commit Hooks
This repository has pre-commit hooks set up for code formatting. You need to have pre-commit==2.20.0 installed (listed in the requirements.txt).\
Once pre-commit is installed, move to the source directory and run

    pre-commit install
You will only need to run this command once when you clone the repo initially. For the subsequent runs, it will automatically reuse the created environment.

# Contribute
- Use the azure devops template to raise a pull request.
- Add pylint score to the PR comments.
- Add code coverage to the PR comments.
- Test CI pipeline on your branch before pushing the code.
- Ensure to remove all sensitive information before raising a PR.
