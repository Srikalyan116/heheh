"""Test data file for test cases."""

import datetime


def get_test_task():
    """Yields a test task dictionary.

    Returns:
        dict: A test task dictionary.
    """
    temp = {
        "_id": "123456789",
        "project": "test_project",
        "email": "test@test.com",
        "filename": "test.csv",
        "task_name": "SEARCH",
        "status": "SUCCESS",
        "created_timestamp": datetime.datetime(2024, 7, 8, 9, 49, 30, 477000),
        "lastupdated_timestamp": datetime.datetime(2024, 7, 8, 9, 49, 30, 477000),
        "tracker": None,
        "description_col_name": "Description",
        "id_col_name": "ID",
        "search_type": "TEXT_SEARCH",
        "request_type": "MANUAL",
    }
    yield temp


def get_test_project():
    """Yields a test project dictionary.

    Returns:
        dict: A test project dictionary.
    """
    temp = {
        "_id": "66fb9c0e18ac6c9ae0eaa3eb",
        "project_name": "test_project",
        "admin": {"name": "test_user", "id": "123456"},
        "last_updated_by": {"name": "test_user", "id": "123456"},
        "create_timestamp": datetime.datetime(2024, 7, 30, 13, 52, 25, 370000),
        "update_timestamp": datetime.datetime(2024, 7, 30, 13, 52, 25, 370000),
        "files": [
            {
                "file_name": "test_file.pdf",
                "uploaded_by": {"name": "test_user", "id": "123456"},
                "project_name": "test_project",
                "last_update_timestamp": datetime.datetime(2024, 7, 30, 13, 52, 25, 370000),
                "location": "test/path",
                "download_link": "https://test_url/test/path/test.pdf",
            }
        ],
    }
    yield temp


SEARCH_RESPONSE = [
    {
        "hit_0_text": "test text",
        "hit_0_file_name": "test.pdf",
        "hit_1_text": "test text 1",
        "hit_1_file_name": "test1.pdf",
    }
]
