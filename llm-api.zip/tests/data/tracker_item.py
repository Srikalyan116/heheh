"""Data for unit tests."""

TRACKER_ITEMS = {
    "page": 1,
    "pageSize": 25,
    "total": 1,
    "items": [
        {
            "id": 4569,
            "name": "Final Test",
            "description": "New description",
            "descriptionFormat": "Wiki",
            "createdAt": "2024-03-13T08:43:13.511",
            "createdBy": {
                "id": 1718,
                "name": "testuser@zf.com",
                "type": "UserReference",
                "email": "testuser@zf.com",
            },
            "modifiedAt": "2024-03-19T09:02:13.484",
            "modifiedBy": {
                "id": 1682,
                "name": "test-account",
                "type": "UserReference",
                "email": "testuser@zf.com",
            },
            "owners": [],
            "version": 4,
            "tracker": {"id": 5572961, "name": "Design Specification", "type": "TrackerReference"},
            "children": [],
            "customFields": [
                {
                    "fieldId": 10014,
                    "name": "Parameter Value",
                    "value": "[{Table style='width:100%;'\r\n\r\n||__Name__\r\n||(width:20.0000%;)__Unit__\r\n||(width:20.0000%;)__Default Value__\r\n||__min__\r\n||__max__\r\n\r\n|(width:20.0000%;)\\\\\r\n|(width:20.0000%;)\\\\\r\n|(width:20.0000%;)\\\\\r\n|(width:20.0000%;)\\\\\r\n|(width:20.0000%;)\\\\}]",
                    "type": "WikiTextFieldValue",
                }
            ],
            "status": {"id": 1, "name": "In Progress", "type": "ChoiceOptionReference"},
            "categories": [],
            "subjects": [],
            "teams": [],
            "versions": [],
            "ordinal": 1,
            "typeName": "Requirement",
            "comments": [],
            "tags": [],
        }
    ],
}
