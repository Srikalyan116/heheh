"""Tests for codebeamer utilities."""

# import unittest
# import requests_mock
# import json

# from tests.data.tracker_item import TRACKER_ITEMS
# from src.utils.codebeamer_utils import get_items_by_project, update_item_by_id


# class TestCodebeamerUtils(unittest.TestCase):
#     """Class to test codebeamer utils."""

#     @classmethod
#     def setUpClass(cls) -> None:
#         """Setup class to test codebeamer utils."""
#         cls.codebeamer_base_url = "https://codebeamer-training.azure.zf-world.com/api"
#         cls.codebeamer_project = "GenAI"
#         cls.codebeamer_tracker = "GenAI Tracker"
#         cls.tracker_items = TRACKER_ITEMS

#     def test_get_items_by_project_success(self):
#         """Test successful execution of get_items_by_project method."""
#         with requests_mock.Mocker() as rm:
#             # Setup the api response
#             endpoint = "/v3/items/query"
#             rm.get(self.codebeamer_base_url + endpoint, json=self.tracker_items, status_code=200)

#             # Call the method
#             response = get_items_by_project(
#                 "XXXXXXXXXXXXXX",
#                 self.codebeamer_base_url,
#                 self.codebeamer_project,
#                 self.codebeamer_tracker,
#             )

#             # Assert
#             self.assertEqual(response.text, json.dumps(self.tracker_items))

#     def test_update_item_by_id_success(self):
#         """Test successful execution of update_item_by_id method."""
#         with requests_mock.Mocker() as rm:
#             # Setup the api response
#             id = self.tracker_items["items"][0]["id"]
#             payload = self.tracker_items["items"][0]
#             payload["name"] = "Test a model"
#             endpoint = f"/v3/items/{id}/"
#             rm.put(self.codebeamer_base_url + endpoint, json=self.tracker_items, status_code=200)

#             # Call the method
#             response = update_item_by_id("XXXXXXXXXX", self.codebeamer_base_url, payload)

#             resp_json = json.loads(response.text)
#             # Assert
#             self.assertEqual(resp_json["items"][0]["name"], payload["name"])
#             self.assertEqual(resp_json["items"][0]["id"], payload["id"])
