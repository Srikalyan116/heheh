import pytest
import asyncio
import sys
from unittest.mock import patch, MagicMock

# ---------------------------------------------------------------------
# REQUIRED mocks BEFORE importing utils
# ---------------------------------------------------------------------
sys.modules["pymongo"] = MagicMock()
sys.modules["pymongo.collection"] = MagicMock()
sys.modules["src.utils.mongo_db"] = MagicMock()

from src.utils.unit_test_generation_utils import (
    extract_repo_name,
    short_hash,
    normalize_commit_hash,
    extract_ado_repo_info,
    list_folders_ado,
    get_latest_commit_hash,
    RepoMetadataManager,
)

# ---------------------------------------------------------------------
# Pure helper function tests
# ---------------------------------------------------------------------

def test_extract_repo_name():
    assert extract_repo_name("https://dev.azure.com/org/proj/_git/my-repo") == "my-repo"
    assert extract_repo_name("https://github.com/user/repo.git") == "repo"


def test_short_hash():
    assert short_hash("abcdef1234567890") == "abcdef123456"
    assert short_hash("abc", length=2) == "ab"


def test_normalize_commit_hash():
    assert normalize_commit_hash("abcdef1234567890") == "abcdef123456"

# ---------------------------------------------------------------------
# extract_ado_repo_info
# ---------------------------------------------------------------------

def test_extract_ado_repo_info_success():
    url = "https://dev.azure.com/org/project/_git/repo"
    info = extract_ado_repo_info(url)

    assert info["org"] == "org"
    assert info["project"] == "project"
    assert info["repo_name"] == "repo"
    assert info["repo_url"] == url


def test_extract_ado_repo_info_invalid_domain():
    with pytest.raises(ValueError):
        extract_ado_repo_info("https://github.com/org/repo")


def test_extract_ado_repo_info_invalid_path():
    with pytest.raises(ValueError):
        extract_ado_repo_info("https://dev.azure.com/org/project/repo")

# ---------------------------------------------------------------------
# get_latest_commit_hash (ADO REST)
# ---------------------------------------------------------------------

@pytest.mark.asyncio
@patch("src.utils.unit_test_generation_utils.requests.get")
async def test_get_latest_commit_hash_success(mock_get):
    mock_get.return_value = MagicMock(
        status_code=200,
        json=lambda: {
            "value": [{"objectId": "abcdef1234567890"}]
        },
    )

    commit = await get_latest_commit_hash(
        repo_url="https://dev.azure.com/org/project/_git/repo",
        branch="main",
        token="PAT123",
    )

    assert commit == "abcdef1234567890"


@pytest.mark.asyncio
@patch("src.utils.unit_test_generation_utils.requests.get")
async def test_get_latest_commit_hash_http_error(mock_get):
    mock_get.return_value = MagicMock(
        status_code=500,
        text="Internal Server Error",
    )

    with pytest.raises(RuntimeError):
        await get_latest_commit_hash(
            repo_url="https://dev.azure.com/org/project/_git/repo",
            branch="main",
            token="PAT123",
        )

# ---------------------------------------------------------------------
# list_folders_ado
# ---------------------------------------------------------------------

@patch("src.utils.unit_test_generation_utils.requests.get")
def test_list_folders_ado_success(mock_get):
    mock_get.return_value = MagicMock(
        status_code=200,
        text="ok",
        json=lambda: {
            "value": [
                {"path": "/src/A", "isFolder": True},
                {"path": "/src/B", "isFolder": True},
                {"path": "/src/file.txt", "isFolder": False},
            ]
        },
    )

    folders = list_folders_ado(
        repo_url="https://dev.azure.com/org/project/_git/repo",
        branch="main",
        path="src",
        token="PAT",
    )

    assert folders == ["A", "B"]


@patch("src.utils.unit_test_generation_utils.requests.get")
def test_list_folders_ado_http_error(mock_get):
    mock_get.return_value = MagicMock(
        status_code=401,
        text="Unauthorized",
    )

    with pytest.raises(RuntimeError):
        list_folders_ado(
            repo_url="https://dev.azure.com/org/project/_git/repo",
            branch="main",
            path="src",
            token="PAT",
        )

# ---------------------------------------------------------------------
# RepoMetadataManager
# ---------------------------------------------------------------------

@pytest.fixture
def repo_manager():
    with patch("src.utils.unit_test_generation_utils.MongoDB.get_collection") as mock_get_collection:
        mock_collection = MagicMock()
        mock_get_collection.return_value = mock_collection
        yield RepoMetadataManager(), mock_collection


@pytest.mark.asyncio
@patch("src.utils.unit_test_generation_utils.get_latest_commit_hash")
async def test_get_record_not_found(mock_latest_commit, repo_manager):
    manager, collection = repo_manager
    mock_latest_commit.return_value = "abcdef1234567890"
    collection.find_one.return_value = None

    result = await manager.get_record(
        repo_url="https://dev.azure.com/org/project/_git/repo",
        branch="main",
        component_names=["A"],
        llm_refinement=1,
        token="PAT",
    )

    assert result["status"] == "NOT_FOUND"


@pytest.mark.asyncio
@patch("src.utils.unit_test_generation_utils.get_latest_commit_hash")
async def test_get_record_exists(mock_latest_commit, repo_manager):
    manager, collection = repo_manager
    mock_latest_commit.return_value = "abcdef1234567890"

    collection.find_one.return_value = {
        "repo_name": "repo",
        "branch": "main",
        "commit_hash": "abcdef123456",
        "component_names": {"A": [1]},
        "storage_path": "/tmp/results",
    }

    result = await manager.get_record(
        repo_url="https://dev.azure.com/org/project/_git/repo",
        branch="main",
        component_names=["A"],
        llm_refinement=1,
        token="PAT",
    )

    assert result["status"] == "EXISTS"
    assert result["storage_path"] == "/tmp/results"


@pytest.mark.asyncio
@patch("src.utils.unit_test_generation_utils.get_latest_commit_hash")
async def test_create_or_update_record_creates(mock_latest_commit, repo_manager):
    manager, collection = repo_manager
    mock_latest_commit.return_value = "abcdef1234567890"
    collection.find_one.return_value = None
    collection.insert_one.return_value = MagicMock(inserted_id="123")

    result = await manager.create_or_update_record(
        repo_url="https://dev.azure.com/org/project/_git/repo",
        branch="main",
        component_names=["A"],
        llm_refinement=1,
        storage_path="/tmp/results",
        token="PAT",
    )

    assert result["status"] == "CREATED"


@pytest.mark.asyncio
async def test_delete_record(repo_manager):
    manager, collection = repo_manager
    collection.delete_one.return_value = MagicMock(deleted_count=1)

    deleted = await manager.delete_record(
        repo_url="https://dev.azure.com/org/project/_git/repo",
        branch="main",
        commit_hash="abcdef123456",
    )

    assert deleted is True
