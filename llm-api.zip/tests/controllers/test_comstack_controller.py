import pytest
import sys
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi import FastAPI
from fastapi.testclient import TestClient

# ------------------------------------------------------------------
# Mock Azure imports (same as working test)
# ------------------------------------------------------------------
sys.modules["azure"] = MagicMock()
sys.modules["azure.identity"] = MagicMock()
sys.modules["azure.storage"] = MagicMock()
sys.modules["azure.storage.blob"] = MagicMock()
sys.modules["pymongo"] = MagicMock()
sys.modules["src.utils.mongo_db"] = MagicMock()
# ------------------------------------------------------------------
# Import router AFTER mocks
# ------------------------------------------------------------------
from src.controllers.comstack_controller import router
from src.utils.utils_enum import TaskStatus

# ------------------------------------------------------------------
# Build app + client (same pattern)
# ------------------------------------------------------------------
app = FastAPI()
app.include_router(router)
client = TestClient(app)

# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------
@pytest.fixture
def mock_task_data():
    return {
        "task_id": "123",
        "status": TaskStatus.SUCCESS.value,
        "output_filename": "result.zip",
        "created_timestamp": "2024-01-01T00:00:00Z",
    }

@pytest.fixture(autouse=True)
def mock_mongo_init():
    with patch("src.utils.mongo_db.MongoDB.initialize", return_value=None):
        yield

@pytest.fixture
def auth_headers():
    return {"Authorization": "Bearer dummy-token"}


def _patch_jwt_ok():
    """Patch JWT validation so AuthValidation always succeeds."""
    return patch.multiple(
        "src.utils.auth.jwt",
        get_unverified_header=lambda token: {"alg": "none"},
        decode=lambda token, algorithms=None, options=None: {
            "email": "tester@example.com",
            "exp": 4102444800,
        },
    )


def ensure_fake_rabbitmq():
    """Inject fake RabbitMQ into app.state (same as working tests)."""
    if not hasattr(client.app.state, "rabbitmq"):
        client.app.state.rabbitmq = MagicMock()
        client.app.state.rabbitmq.publish_task = AsyncMock(return_value=None)

# ------------------------------------------------------------------
# GET /status/{task_id}
# ------------------------------------------------------------------
@patch("src.controllers.comstack_controller.TaskManager")
def test_get_status_success(mock_task_manager, mock_task_data):
    mock_task_manager.return_value.get_task.return_value = mock_task_data

    resp = client.get("/api/comstack/status/123")

    assert resp.status_code == 200
    body = resp.json()

    assert body["Task ID"] == "123"
    assert body["Task Status"] == TaskStatus.SUCCESS.value


# ------------------------------------------------------------------
# GET /download/{task_id}
# ------------------------------------------------------------------
@patch("src.controllers.comstack_controller.BlobClientManager")
@patch("src.controllers.comstack_controller.TaskManager")
def test_download_success(mock_task_manager, mock_blob_mgr, mock_task_data):
    mock_task_manager.return_value.get_task.return_value = mock_task_data
    mock_blob_mgr.return_value.get_data_from_blob.return_value = b"zip-bytes"

    resp = client.get("/api/comstack/download/123")

    assert resp.status_code == 200
    assert resp.content == b"zip-bytes"
    assert "attachment;" in resp.headers["Content-Disposition"]


# ------------------------------------------------------------------
# POST /task – missing files
# ------------------------------------------------------------------
def test_task_missing_files(auth_headers):
    ensure_fake_rabbitmq()

    with _patch_jwt_ok():
        resp = client.post(
            "/api/comstack/task",
            headers=auth_headers,
            data={"ecu_name": "EPS_FD"},
        )

    assert resp.status_code == 422


# ------------------------------------------------------------------
# POST /task – invalid DBC extension
# ------------------------------------------------------------------
def test_task_invalid_dbc_extension(auth_headers):
    ensure_fake_rabbitmq()

    files = {
        "dbc_file": ("file.txt", b"x"),
        "can_base_arxml": ("can.arxml", b"x"),
        "canif_base_arxml": ("canif.arxml", b"x"),
        "com_base_arxml": ("com.arxml", b"x"),
        "ecuc_base_arxml": ("ecuc.arxml", b"x"),
        "pdur_base_arxml": ("pdur.arxml", b"x"),
    }

    with _patch_jwt_ok():
        resp = client.post(
            "/api/comstack/task",
            files=files,
            headers=auth_headers,
        )

    assert resp.status_code == 400
    assert "DBC file must have .dbc extension" in resp.text


# ------------------------------------------------------------------
# POST /task – invalid ARXML extension
# ------------------------------------------------------------------
def test_task_invalid_arxml_extension(auth_headers):
    ensure_fake_rabbitmq()

    files = {
        "dbc_file": ("file.dbc", b"x"),
        "can_base_arxml": ("can.txt", b"x"),
        "canif_base_arxml": ("canif.arxml", b"x"),
        "com_base_arxml": ("com.arxml", b"x"),
        "ecuc_base_arxml": ("ecuc.arxml", b"x"),
        "pdur_base_arxml": ("pdur.arxml", b"x"),
    }

    with _patch_jwt_ok():
        resp = client.post(
            "/api/comstack/task",
            files=files,
            headers=auth_headers,
        )

    assert resp.status_code == 400
    assert "Expecting an .arxml file" in resp.text


# ------------------------------------------------------------------
# POST /task – happy path
# ------------------------------------------------------------------
@patch("src.controllers.comstack_controller.BlobClientManager")
@patch("src.controllers.comstack_controller.TaskManager")
def test_task_happy_path(
    mock_task_manager,
    mock_blob_mgr,
    auth_headers,
):
    ensure_fake_rabbitmq()

    # TaskManager.create_task()
    mock_task_manager.create_task.return_value = MagicMock(inserted_id="999")

    tm_instance = mock_task_manager.return_value
    tm_instance.get_collection_name.return_value = "comstack_tasks"
    tm_instance.update_status.return_value = None

    # Blob upload
    mock_blob_mgr.return_value.upload_data_to_blob.return_value = None

    files = {
        "dbc_file": ("file.dbc", b"x"),
        "can_base_arxml": ("can.arxml", b"x"),
        "canif_base_arxml": ("canif.arxml", b"x"),
        "com_base_arxml": ("com.arxml", b"x"),
        "ecuc_base_arxml": ("ecuc.arxml", b"x"),
        "pdur_base_arxml": ("pdur.arxml", b"x"),
    }

    with _patch_jwt_ok():
        resp = client.post(
            "/api/comstack/task",
            files=files,
            headers=auth_headers,
        )

    assert resp.status_code == 200
    body = resp.json()

    assert body["task_id"] == "999"
    assert body["message"] == "Task submitted"

    client.app.state.rabbitmq.publish_task.assert_awaited_once()