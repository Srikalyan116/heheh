import pytest
import sys
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi import FastAPI
from fastapi.testclient import TestClient
from datetime import datetime, timezone

# ------------------------------------------------------------------
# Mock Azure + Mongo BEFORE imports
# ------------------------------------------------------------------
sys.modules["azure"] = MagicMock()
sys.modules["azure.identity"] = MagicMock()
sys.modules["azure.storage"] = MagicMock()
sys.modules["azure.storage.blob"] = MagicMock()
sys.modules["pymongo"] = MagicMock()
sys.modules["src.utils.mongo_db"] = MagicMock()
sys.modules["pymongo.collection"] = MagicMock()


# ------------------------------------------------------------------
# Import router AFTER mocks
# ------------------------------------------------------------------
from src.controllers.unit_test_generation_controller import router
from src.utils.utils_enum import TaskStatus
from src.utils.unit_test_generation_utils import Stage

# ------------------------------------------------------------------
# Build app + client
# ------------------------------------------------------------------
app = FastAPI()
app.include_router(router)
client = TestClient(app)

# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------
@pytest.fixture
def mock_task_data():
    return {
        "task_id": "123",
        "repo_url": "https://dev.azure.com/org/project/_git/repo",
        "branch": "main",
        "clone_dir": "/tmp/clone",
        "context_gen_output": "/tmp/context",
        "unit_test_output_dir": "/tmp/tests",
        "component_dir": "source/Components",
        "component_names": ["AkcInput", "AkcOutput"],
        "overall_status": TaskStatus.SUCCESS.value,
        "pipeline_stage": Stage.UNIT_TEST,
        "output_filename": "result.zip",
        "created_timestamp": datetime.now(timezone.utc),
    }


@pytest.fixture
def auth_headers():
    return {"Authorization": "Bearer dummy-token"}


def _patch_jwt_ok():
    """AuthValidation always succeeds."""
    return patch.multiple(
        "src.utils.auth.jwt",
        get_unverified_header=lambda token: {"alg": "none"},
        decode=lambda token, algorithms=None, options=None: {
            "email": "tester@example.com",
            "token": "PAT123",
            "exp": 4102444800,
        },
    )


def ensure_fake_rabbitmq():
    if not hasattr(client.app.state, "rabbitmq"):
        client.app.state.rabbitmq = MagicMock()
        client.app.state.rabbitmq.publish_task = AsyncMock(return_value=None)

# ------------------------------------------------------------------
# GET /status/{task_id}
# ------------------------------------------------------------------
@patch("src.controllers.unit_test_generation_controller.TaskManager")
def test_get_status(mock_task_manager, mock_task_data):
    mock_task_manager.return_value.get_task.return_value = mock_task_data

    resp = client.get("/unit-test-generation/status/123")

    assert resp.status_code == 200
    body = resp.json()

    assert body["Task ID"] == "123"
    assert body["Task Status"] == TaskStatus.SUCCESS.value
    assert body["result_dir"] == "/tmp/tests"

# ------------------------------------------------------------------
# DELETE /task/{task_id}
# ------------------------------------------------------------------
@patch("src.controllers.unit_test_generation_controller.TaskManager")
def test_delete_task(mock_task_manager, mock_task_data):
    mock_task_manager.return_value.get_task.return_value = mock_task_data
    mock_task_manager.return_value.delete_task.return_value = True

    resp = client.delete("/unit-test-generation/task/123")

    assert resp.status_code == 200
    assert resp.json()["message"] == "Task deleted. Cleanup scheduled."

# ------------------------------------------------------------------
# GET /download/{task_id}
# ------------------------------------------------------------------
@patch("src.controllers.unit_test_generation_controller.BlobClientManager")
@patch("src.controllers.unit_test_generation_controller.TaskManager")
def test_download_success(mock_task_manager, mock_blob_mgr, mock_task_data):
    mock_task_manager.return_value.get_task.return_value = mock_task_data
    mock_blob_mgr.return_value.get_data_from_blob.return_value = b"zip-bytes"

    resp = client.get("/unit-test-generation/download/123")

    assert resp.status_code == 200
    assert resp.content == b"zip-bytes"
    assert "attachment;" in resp.headers["Content-Disposition"]

# ------------------------------------------------------------------
# GET /list_components
# ------------------------------------------------------------------
@patch("src.controllers.unit_test_generation_controller.list_folders_ado")
def test_list_components_success(mock_list_folders):
    mock_list_folders.return_value = ["AkcInput", "AkcOutput"]

    with _patch_jwt_ok():
        resp = client.get(
            "/unit-test-generation/list_components",
            headers={"Authorization": "Bearer dummy-token"},
            params={
                "repo_url": "https://dev.azure.com/org/project/_git/repo",
                "branch": "main",
                "component_dir": "source/Components",
            },
        )

    assert resp.status_code == 200

# ------------------------------------------------------------------
# POST /clone
# ------------------------------------------------------------------
@patch("src.controllers.unit_test_generation_controller.validate_clone_request_inputs")
@patch("src.controllers.unit_test_generation_controller.bypass_unit_test_generation", return_value=None)
@patch("src.controllers.unit_test_generation_controller.TaskManager.create_task")
def test_clone_endpoint(
    mock_create_task,
    _bypass,
    _validate,
    auth_headers
):
    ensure_fake_rabbitmq()

    mock_create_task.return_value = MagicMock(inserted_id="666")

    payload = {
        "repo_url": "https://dev.azure.com/org/project/_git/repo",
        "branch": "main",
        "component_dir": "source/Components",
        "component_names": ["AkcInput", "AkcOutput"],
        "vector_cast_version": "24.sp7 (02/06/25)",
        "pipeline": True,
        "force_retry": False,
        "llm_refinements": 2,
    }

    with _patch_jwt_ok():
        resp = client.post(
            "/unit-test-generation/clone",
            data=payload,
            headers=auth_headers,
        )

    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert body["task_id"] == "666"

# ------------------------------------------------------------------
# POST /context
# ------------------------------------------------------------------
@patch("src.controllers.unit_test_generation_controller.TaskManager")
def test_context_endpoint(mock_task_manager, mock_task_data, auth_headers):
    ensure_fake_rabbitmq()

    mock_task_manager.return_value.get_task.return_value = mock_task_data

    payload = {
        "task_id": "123",
        "component_names": ["AkcInput", "AkcOutput"],
        "pipeline": True,
    }

    with _patch_jwt_ok():
        resp = client.post(
            "/unit-test-generation/context",
            data=payload,
            headers=auth_headers,
        )

    assert resp.status_code == 200
    assert resp.json()["success"] is True
    assert resp.json()["task_id"] == "123"

# ------------------------------------------------------------------
# POST /unit_test
# ------------------------------------------------------------------
@patch("src.controllers.unit_test_generation_controller.TaskManager")
def test_unit_test_endpoint(mock_task_manager, mock_task_data, auth_headers):
    ensure_fake_rabbitmq()

    mock_task_manager.return_value.get_task.return_value = mock_task_data

    payload = {
        "task_id": "123",
        "component_names": ["AkcInput", "AkcOutput"],
    }

    with _patch_jwt_ok():
        resp = client.post(
            "/unit-test-generation/unit_test",
            data=payload,
            headers=auth_headers,
        )

    assert resp.status_code == 200
    assert resp.json()["success"] is True
    assert resp.json()["task_id"] == "123"
