"""Test file for doc_retrieval_controller.py."""

import os
import sys
from unittest.mock import MagicMock, mock_open, patch

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

from src.utils.auth import jwt

sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", ".."))
from tests.data.doc_retriever.doc_retreiver_test_data import (
    SEARCH_RESPONSE,
    get_test_project,
    get_test_task,
)


@pytest.fixture(autouse=True)
def blobserviceclient(mocker):
    """Mocks the Azure Blob Service Client to return a mock client object.

    Args:
        mocker: A Pytest fixture for mocking objects.

    Returns:
        A mock Azure Blob Service Client object.
    """
    mock_blobservice_client = mocker.patch("azure.storage.blob.BlobServiceClient")
    mock_blobservice_client.from_connection_string.return_value = MagicMock()
    mock_blob_client = mock_blobservice_client.from_connection_string.return_value
    mock_blob_client.get_blob_client.return_value = MagicMock()
    mock_blob_client.get_container_client.return_value = MagicMock()
    mock_blob_client.get_container_client.return_value.list_blobs.return_value = ["blob1", "blob2"]
    mock_blob_client.get_blob_client.return_value.upload_blob.return_value = None
    mock_blob_client.get_blob_client.return_value.download_blob.return_value = MagicMock()
    mock_blob_client.get_blob_client.return_value.delete_blob.return_value = None
    mock_download_blob = mock_blob_client.get_blob_client.return_value.download_blob.return_value
    mock_download_blob.readall.return_value = "test"
    return mock_blob_client


@pytest.fixture()
def blob_sas_token(mocker):
    """Mocks the generation of a SAS token for Azure Blob Storage.

    Args:
        mocker: A Pytest fixture for mocking objects.

    Returns:
        A mock SAS token generator object.
    """
    mock_blob_sas_gen = mocker.patch("azure.storage.blob.generate_blob_sas")
    return mock_blob_sas_gen


@pytest.fixture(autouse=True)
def azure_identity_fixture(mocker):
    """Mocks the Azure Identity ClientSecretCredential to return a mock credential object.

    Args:
        mocker: A Pytest fixture for mocking objects.

    Returns:
        A mock Azure Identity ClientSecretCredential object.
    """
    mock_azure_identity = mocker.patch("azure.identity.ClientSecretCredential")
    mock_azure_identity.return_value = MagicMock()

    return mock_azure_identity


@pytest.fixture(autouse=True)
def azure_keyvault_fixutre(mocker):
    """Mocks the Azure Key Vault SecretClient to return a mock secret client object.

    Args:
        mocker: A Pytest fixture for mocking objects.

    Returns:
        A mock Azure Key Vault SecretClient object.
    """
    mock_azure_keyvault_secretclient = mocker.patch("azure.keyvault.secrets.SecretClient")
    mock_azure_keyvault_secretclient.return_value = MagicMock()
    mock_azure_keyvault_secretclient.return_value.get_secret.return_value.value = "test_secret"


@pytest.fixture(autouse=True)
def client(
    mocker, blobserviceclient, azure_identity_fixture, azure_keyvault_fixutre, blob_sas_token
):
    """Creates a TestClient instance for testing the document retriever controller.

    Args:
        mocker: A Pytest fixture for mocking objects.
        blobserviceclient: A mock Azure Blob Service Client object.
        azure_identity_fixture: A mock Azure Identity ClientSecretCredential object.
        azure_keyvault_fixture: A mock Azure Key Vault SecretClient object.
        blob_sas_token: A mock SAS token generator object.

    Returns:
        A TestClient instance for testing the document retriever controller.
    """
    from src.controllers.document_retriever_controller import router

    client = TestClient(router)
    return client


@pytest.fixture(autouse=True)
def setenvvar():
    """Set Environment variables."""
    with patch.dict(
        os.environ,
        {
            "BLOB_CONNECT_STR": "test_connection_string",
            "BLOB_CONTAINER_NAME": "test_container_name",
            "DOC_RETRIEVER_SERVICE_URL": "test_service_url",
        },
    ):
        yield  # This is the magical bit which restore the environment after


@pytest.fixture(autouse=True)
def backgroundtask(mocker, client):
    """Mocks the FastAPI BackgroundTasks to add a task.

    Args:
        mocker: A Pytest fixture for mocking objects.
        client: A TestClient instance for testing the document retriever controller.

    Returns:
        None
    """
    mock_backgroundtask = mocker.patch("fastapi.BackgroundTasks.add_task")
    mock_backgroundtask.return_value = None


@pytest.fixture()
def os_fixture(mocker, pandas_fixture):
    """Mocks the os module to control file system interactions.

    Args:
        mocker: A Pytest fixture for mocking objects.
        pandas_fixture: A Pandas fixture for testing data manipulation.

    Returns:
        A mock os module object.
    """
    mock_oc = mocker.patch("src.controllers.document_retriever_controller.os")
    mock_oc.makedirs.reutrn_value = None
    mock_oc.path.isfile.return_value = True
    mock_oc.path.exists.return_value = True
    mock_oc.remove.return_value = None
    import os

    mock_oc.path.join = os.path.join
    return mock_oc


@pytest.fixture()
def open_fixture(mocker, pandas_fixture):
    """Mocks the built-in open function to control file interactions.

    Args:
        mocker: A Pytest fixture for mocking objects.
        pandas_fixture: A Pandas fixture for testing data manipulation.

    Returns:
        A mock open function object.
    """
    return mocker.patch("builtins.open", mocker.mock_open(read_data="file content"))


@pytest.fixture(autouse=True)
def pandas_fixture(mocker):
    """Mocks the Pandas library to control data manipulation.

    Args:
        mocker: A Pytest fixture for mocking objects.

    Returns:
        None
    """
    import pandas

    file_path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), "..", "data", "doc_retriever", "test_search.csv"
    )
    test_data = pandas.read_csv(file_path)
    mock_read_csv = mocker.patch("pandas.read_csv")
    mock_read_csv.return_value = test_data

    mock_to_csv = mocker.patch("pandas.DataFrame.to_csv")
    mock_to_csv.return_value = None


@pytest.fixture(autouse=True)
def MongoDb(mocker, client):
    """Mocks the MongoDB database interactions.

    Args:
        mocker: A Pytest fixture for mocking objects.
        client: A TestClient instance for testing the document retriever controller.

    Returns:
        None
    """
    from src.controllers.document_retriever_controller import MongoDB

    mock_get_collection = mocker.patch.object(MongoDB, "get_collection")

    def get_collection_side_effect(database_name):
        mock_collection = mocker.Mock()
        if database_name == "task_metadata_collection":
            mock_collection.find.return_value.sort.return_value.skip.return_value.limit.return_value = (
                get_test_task()
            )
            mock_collection.find_one.return_value = next(get_test_task())

        elif database_name == "project_metadata_collection":
            mock_collection.find.return_value.sort.return_value.skip.return_value.limit.return_value = (
                get_test_project()
            )
            mock_collection.find_one.return_value = next(get_test_project())
            mock_collection.find.return_value = MagicMock(return_value=get_test_project())

        mock_collection.count_documents.return_value = 1
        mock_collection.insert_one.return_value = MagicMock()
        mock_collection.insert_one.return_value.inserted_id = "66fb9c0e18ac6c9ae0eaa3eb"
        mock_collection.update_one.return_value = None
        mock_collection.delete_one.return_value = None
        return mock_collection

    mock_get_collection.side_effect = get_collection_side_effect
    return mock_get_collection


@pytest.fixture(autouse=True)
def request_fixture(mocker):
    """Fixture to mock the requests library and simulate a successful API call.

    Args:
        mocker: pytest mocker object

    Returns:
        mock_request: Mocked requests object
    """
    import pandas as pd

    mock_request = mocker.patch("src.controllers.document_retriever_controller.requests")
    mock_request.post.return_value = MagicMock()
    post_response = mock_request.post.return_value
    post_response.status_code = 200
    post_response.json.return_value = pd.DataFrame(SEARCH_RESPONSE).to_json(orient="records")
    return mock_request


def test_get_all_tasks_success(client):
    """Test that the get all tasks endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    setattr(jwt, "get_unverified_header", MagicMock)
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    mock_op = patch("builtins.open", mock_open())
    params = [("page", 1), ("page_size", 10)]
    response = client.get(
        "/api/doc-finder/tasks", headers={"Authorization": "Bearer kglkgkjdklj"}, params=params
    )
    assert response.status_code == 200


def test_get_all_projects_success(client, MongoDb):
    """Tests that the get all projects endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.
        MongoDb: The MongoDB instance.

    Returns:
        None
    """
    params = [("page", 1), ("page_size", 10)]
    MongoDb.find.return_value.sort.return_value.skip.return_value.limit.return_value = (
        get_test_project()
    )

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}

    response = client.get("/api/doc-finder/projects", headers=headers, params=params)
    assert response.status_code == 200


def test_get_tasks_by_field_success(client):
    """Tests that the get tasks by field endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}
    params = [("field", "task_name"), ("value", "SEARCH"), ("page", 1), ("page_size", 10)]
    response = client.get("/api/doc-finder/tasks/task_name/SEARCH", params=params, headers=headers)
    assert response.status_code == 200


def test_get_tasks_by_field_invalid_field_failure(client):
    """Tests that the get tasks by field endpoint returns a 400 status code with an invalid field.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    params = [("field", "abc"), ("value", "SEARCH"), ("page", 1), ("page_size", 10)]

    with pytest.raises(HTTPException):
        response = client.get("/api/doc-finder/tasks/abc/SEARCH", params=params)
        assert response.status_code == 400


def test_task_upload_file_search_success(client):
    """Tests that the task upload file search endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    sample_input = {
        "user_id": "123456",
        "agent_id": "123456",
        "project_name": "test_project",
        # "email": "test@email.com",
        "description_col_name": "Description",
        "id_col_name": "ID",
    }

    file_path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        "..",
        "data",
        "doc_retriever",
        "test_search.xlsx",
    )

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}

    with open(file_path, "rb") as f:
        response = client.post(
            "api/doc-finder/task/search/upload_file",
            data=sample_input,
            files={"file": f},
            headers=headers,
        )
        assert response.status_code == 200


def test_create_task_for_text_success(client):
    """Tests that the create task for text endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    sample_input = {
        # "user_name": "test_user",
        # "user_id": "123456",
        "agent_id": "123456",
        "project_name": "test_project",
        "email": "test@email.com",
        "requirement": "this is test requirement",
    }

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}

    response = client.post("api/doc-finder/task/search/text", data=sample_input, headers=headers)
    assert response.status_code == 200


def test_search_data(mocker, os_fixture):
    """Tests that the search data function returns a successful response.

    Args:
        os_fixture: The OS fixture.

    Returns:
        None
    """
    import pandas as pd

    d = {"ID": [0], "Description": ["This is a test requirement"]}
    df = pd.DataFrame(data=d)
    sample_task_id = "669e437604dbe10bb2db4636"
    from src.controllers.document_retriever_controller import search_data

    mocker.patch(
        "src.controllers.document_retriever_controller.postprocess_result_file", return_value=df
    )
    mocker.patch("pandas.DataFrame.to_csv", return_value=None)

    with patch("builtins.open", mock_open(read_data="data")):
        output = search_data(sample_task_id)

        sample_response = {"status": "success", "message": "Task executed successfully."}

        assert output == sample_response


def test_task_create_project_success(client):
    """Tests that the task create project endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    sample_input = {
        "project_name": "test_project_1",
        "agent_id": "123456",
        # "user_name": "test_user",
        "user_id": "1234",
        # "email": "test@email.com",
    }

    files = ("test.pdf", b"test data", "application/pdf")

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}

    response = client.post(
        "api/doc-finder/task/project/create",
        data=sample_input,
        files={"files": files},
        headers=headers,
    )

    assert response.status_code == 200


def test_task_upload_project_success(client):
    """Tests that the task upload project endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    sample_input = {
        "project_name": "test_project",
        # "user_name": "test_user",
        "user_id": "1234",
        # "email": "test@email.com",
    }

    files = ("test.pdf", b"test data", "application/pdf")

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}

    response = client.post(
        "api/doc-finder/task/project/upload_file",
        data=sample_input,
        files={"files": files},
        headers=headers,
    )

    assert response.status_code == 200


def test_upload_files_success():
    """Tests that the upload files function returns a successful response.

    Args:
        None

    Returns:
        None
    """
    sample_input = {
        "task_id": "669e437604dbe10bb2db4636",
        "project_id": "669e437604dbe10bb2db4636",
        "files_name": ["testfile.pdf"],
    }

    sample_response = {"status": "success", "message": "Data uploaded successfully successfully."}
    from src.controllers.document_retriever_controller import upload_files

    output = upload_files(**sample_input)

    assert output == sample_response


def test_upload_files_request_failure(request_fixture):
    """Tests that the upload files function raises an HTTPException when a request failure occurs.

    Args:
        request_fixture: The request fixture.

    Returns:
        None
    """
    sample_input = {
        "task_id": "669e437604dbe10bb2db4636",
        "project_id": "669e437604dbe10bb2db4636",
        "files_name": ["test_file.pdf"],
    }
    request_fixture.post.side_effect = Exception()
    from src.controllers.document_retriever_controller import upload_files

    with pytest.raises(HTTPException):
        output = upload_files(**sample_input)


def test_task_delete_project_success(client):
    """Tests that the task delete project endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    sample_input = {
        "project_name": "test_project",
        "user_name": "test_user",
        "user_id": "123456",
        "email": "test@gmail.com",
    }

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}

    response = client.post("api/doc-finder/task/project/delete", data=sample_input, headers=headers)

    assert response.status_code == 200


def test_delete_project_success(request_fixture):
    """Tests that the delete project function returns a successful response.

    Args:
        request_fixture: The request fixture.

    Returns:
        None
    """
    sample_input = {"project_id": "66fb9c0e18ac6c9ae0eaa3eb", "task_id": "669e437604dbe10bb2db4636"}
    from src.controllers.document_retriever_controller import delete_project

    delete_project(**sample_input)

    request_fixture.post.assert_called_once()


def test_task_delete_project_file_success(client):
    """Tests that the task delete project file endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    sample_input = {
        "project_name": "test_project",
        "user_name": "test_user",
        "user_id": "123456",
        "file_name": "test_file.pdf",
        "email": "test@email.com",
    }

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}

    response = client.post(
        "api/doc-finder/task/project/file_delete", data=sample_input, headers=headers
    )

    assert response.status_code == 200


def test_delete_project_file_success(request_fixture):
    """Tests that the delete project file function returns a successful response.

    Args:
        request_fixture: The request fixture.

    Returns:
        None
    """
    sample_input = {
        "task_id": "669e437604dbe10bb2db4636",
        "project_id": "669e437604dbe10bb2db4636",
        "file_name": "test_file.pdf",
        "user_name": "test_user",
        "user_id": "123456",
    }
    from src.controllers.document_retriever_controller import delete_project_file

    delete_project_file(**sample_input)

    request_fixture.post.assert_called_once()


def test_task_update_project_file_success(client):
    """Tests that the task update project file endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.

    Returns:
        None
    """
    sample_input = {
        "project_name": "test_project",
        "user_name": "test_user",
        "user_id": "123456",
        "email": "test@email.com",
    }

    file = ("test_file.pdf", b"test data", "application/pdf")
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    headers = {"Authorization": "Bearer kglkgkjdklj"}
    response = client.post(
        "api/doc-finder/task/project/update_file",
        data=sample_input,
        files={"file": file},
        headers=headers,
    )

    assert response.status_code == 200


def test_update_file_success(request_fixture):
    """Tests that the update file function returns a successful response.

    Args:
        request_fixture: The request fixture.

    Returns:
        None
    """
    sample_input = {
        "task_id": "669e437604dbe10bb2db4636",
        "project_id": "669e437604dbe10bb2db4636",
        "file_name": "test_file.pdf",
        "user_name": "test_user",
        "user_id": "123456",
    }
    from src.controllers.document_retriever_controller import update_file

    update_file(**sample_input)

    request_fixture.post.assert_called_once()


def test_get_sas_token_success(client, blob_sas_token, azure_identity_fixture):
    """Tests that the get SAS token endpoint returns a 200 status code.

    Args:
        client (TestClient): The FastAPI test client.
        blob_sas_token: The blob SAS token.
        azure_identity_fixture: The Azure identity fixture.

    Returns:
        None
    """
    sample_input = (("project_name", "test_project"), ("file_name", "test_file.pdf"))
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    headers = {"Authorization": "Bearer kglkgkjdklj"}
    blob_sas_token.return_value = "test_token"
    response = client.get(
        "api/doc-finder/get_sas_token/test_project/test_file", params=sample_input, headers=headers
    )

    assert response.status_code == 200


def test_get_search_data(mocker):
    """Tests that the get search data function returns a successful response.

    Args:
        mocker: The mocker fixture.

    Returns:
        None
    """
    mockio = mocker.patch("io.BytesIO")
    mockio.return_value = None
    from src.controllers.document_retriever_controller import get_search_data

    sample_input = {"task_id": "669e437604dbe10bb2db4636", "page": 1, "page_size": 10}

    response = get_search_data(**sample_input)
    assert response.status_code == 200
