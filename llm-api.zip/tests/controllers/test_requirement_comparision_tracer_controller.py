"""Test route.py."""

import io
import json
import os
import sys
from datetime import datetime, timezone
from io import BytesIO
from unittest.mock import MagicMock, call, patch

import loguru
import pandas as pd
import pytest
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import BackgroundTasks, HTTPException, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.testclient import TestClient
from pymongo.collection import Collection

from src.models.requirement_comparision_tracer_feedbacktask import UpdateItem
from src.utils.auth import jwt
from src.utils.utils_enum import TaskStatus

sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", ".."))
# Load environment variables
load_dotenv("tests/.env.testing")

# Mock data
task_id = "669e437604dbe10bb2db4636"
task = {
    "_id": ObjectId(task_id),
    "status": TaskStatus.SUCCESS.value,
    # "output_filename": "output_file.txt",
    "output_filename": "output_file.xlsx",
    "user_id": "123",
}
task_data = {
    "_id": ObjectId(task_id),
    "user_id": None,
    "project": "testproject",
    "email": "test@example.com",
    "output_filename": None,
    "source_filename": "source.xlsx",
    "revision_filename": "revision.xlsx",
    "source_col_name": "source_description",
    "revision_col_name": "source_description",
    "source_id": "ID",
    "revision_id": "ID",
    "status": "CREATED",
    "created_timestamp": datetime.now(timezone.utc),
    "lastupdated_timestamp": datetime.now(timezone.utc),
}

create_task_list = {
    "_id": ObjectId(task_id),
    "source_filename": "source.xlsx",
    "revision_filename": "revision.xlsx",
    "source_id": "source_id",
    "revision_id": "revision_id",
    "source_col_name": "source_col",
    "revision_col_name": "revision_col",
}


@pytest.fixture(autouse=True)
def client(mocker, blobserviceclient):
    """Fixture to create a FastAPI TestClient for the application.

    This fixture sets up the FastAPI application with the necessary routes and
    provides a TestClient instance that can be used in tests.
    """
    from src.controllers.requirement_comparision_tracer_controller import routertracer

    # mock_blobservice_client.stop()
    with TestClient(routertracer) as client:
        yield client


@pytest.fixture(autouse=True)
def setenvvar(client):
    """Set Environment variables."""
    with patch.dict(
        os.environ,
        {
            "BLOB_CONNECT_STR": "test_connection_string",
            "BLOB_CONTAINER_NAME": "test_container_name",
        },
    ):
        yield  # This is the magical bit which restore the environment after


@pytest.fixture(autouse=True)
def mock_env(client, mocker):
    """Fixture to mock environment variables for testing.

    This fixture uses the mocker to mock the environment variables
    needed for the tests to ensure they run with the expected configuration.
    """
    mocker.patch.dict(os.environ, {"REQUIREMENT_COMP_TRACER_URL": "http://mockservice"})
    mocker.patch(
        "src.controllers.requirement_comparision_tracer_controller.requirement_comparison_tracer_config",
        {"collection_name": "mock_collection"},
    )


@pytest.fixture
def mock_db(mocker):
    """Fixture to mock the MongoDB collection for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    mock_collection = MagicMock(Collection)
    mock_collection.find_one.return_value = task_data
    mocker.patch("src.utils.mongo_db.MongoDB.get_collection", return_value=mock_collection)
    return mock_collection


@pytest.fixture
def mock_requests(client, mocker):
    """Fixture to mock the requests.post method for testing.

    This fixture uses the mocker to patch the requests.post method,
    providing a mock implementation to be used in tests.
    """
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = json.dumps([{"ID": 1, "Comparison": "match"}])
    return mocker.patch("requests.post", return_value=mock_response)


@pytest.fixture
def mock_os_operations(client, mocker):
    """Fixture to mock os operations for testing.

    This fixture uses the mocker to patch the os.remove and os.path.exists functions,
    providing mock implementations to be used in tests.
    """
    mocker.patch("os.path.exists", return_value=True)
    mocker.patch("os.remove")


@pytest.fixture
def mock_requests_post(client, mocker):
    """Fixture to mock the requests.post method for testing.

    This fixture uses the mocker to patch the requests.post method,
    providing a mock implementation to be used in tests.
    """
    return mocker.patch("requests.post")


@pytest.fixture
def mock_mongodb(client, mocker):
    """Fixture to mock the MongoDB get_collection method for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    mock_collection = get_collection_mock.return_value
    mock_collection.find_one.return_value = task
    # mock_collection.find_one_and_delete.return_value = {"_id": ObjectId(task_id)}
    return mock_collection


@pytest.fixture
def mock_mongo_collection():
    """Fixture to mock the MongoDB collection for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    with patch("src.utils.mongo_db.MongoDB.get_collection") as mock_get_collection:
        mock_collection = MagicMock()
        mock_get_collection.return_value = mock_collection
        yield mock_collection


@pytest.fixture
def mock_mongo(mocker):
    # Create a MagicMock for MongoDB collection
    mock_collection = MagicMock()

    # Mock the behavior of 'find' method to return a cursor-like object
    mock_cursor = MagicMock()
    mock_collection.find.return_value = mock_cursor  # Simulate find() returning a cursor

    # Return the mock collection
    mocker.patch("src.utils.mongo_db.MongoDB.get_collection", return_value=mock_collection)

    return mock_collection


@pytest.fixture
def mock_upload_file(client):
    """Fixture to mock the file upload function for testing.

    This fixture uses the mocker to patch the upload_file method,
    providing a mock implementation to be used in tests.
    """
    with patch("src.controllers.requirement_comparision_tracer_controller.UploadFile") as mock_file:
        yield mock_file


@pytest.fixture
def mock_read_excel():
    """Fixture to mock the pandas.read_excel function for testing.

    This fixture uses the mocker to patch the read_excel method from pandas,
    providing a mock implementation to be used in tests.
    """
    with patch("pandas.read_excel") as mock_read_excel:
        yield mock_read_excel


@pytest.fixture
def mock_read_csv():
    """Fixture to mock the pandas.read_csv function for testing.

    This fixture uses the mocker to patch the read_csv method from pandas,
    providing a mock implementation to be used in tests.
    """
    with patch("pandas.read_csv") as mock_read_csv:
        yield mock_read_csv


@pytest.fixture
def mock_background_tasks():
    """Fixture to mock the BackgroundTasks.add_task method for testing.

    This fixture uses the mocker to patch the add_task method of BackgroundTasks from FastAPI,
    providing a mock implementation to be used in tests.
    """
    return MagicMock(spec=BackgroundTasks)


@pytest.fixture()
def blobserviceclient(mocker):
    """Create and return a BlobServiceClient instance.

    This function initializes a BlobServiceClient, which can be used to interact
    with Azure Blob Storage. It handles authentication and sets up the necessary
    configurations for accessing the storage account.

    Returns:
        BlobServiceClient: An instance of BlobServiceClient configured for
        the specified storage account.
    """
    mock_blobservice_client = mocker.patch("azure.storage.blob.BlobServiceClient")
    mock_blobservice_client.from_connection_string.return_value = MagicMock()
    mock_blob_client = mock_blobservice_client.from_connection_string.return_value
    mock_blob_client.get_blob_client.return_value = MagicMock()
    # Prepare mock data
    df = pd.DataFrame(
        {
            "ID": [1, 2],
            "source_description": ["source1", "source2"],
            "revision_description": ["revision1", "revision2"],
            "changeType": ["type1", "type2"],
            "changes": ["change1", "change2"],
            "feedback": ["feedback1", "feedback2"],
        }
    )
    excel_buffer = io.BytesIO()
    df.to_excel(excel_buffer, index=False, engine="openpyxl")
    excel_buffer.seek(0)

    mock_blob_client.get_blob_client.return_value.download_blob.return_value.readall.return_value = (
        excel_buffer.read()
    )
    return mock_blob_client


def test_find_all_tasks_uninitialized_db(client):
    """_summary_."""
    # Missing Arrange setup is intentional
    # To trigger a 500 response

    # Assert
    with pytest.raises(HTTPException):
        response = client.get("/api/requirement-comp-tracer/", params={"page": 1, "page_size": 10})
        assert response.status_code == 500


tasks_list = [
    {
        "agent_id": "123",
        "_id": "668fdcb5d648cf8036423be2",
        "rule_id": "",
        "rule_name": "",
        "project": "Tracer",
        "source_tracker": "AI",
        "revision_tracker": "AI",
        "request_type": "Manual",
        "email": "sai@gmail.com",
        "output_filename": "output.xlsx",
        "source_filename": "Trace_rev3.xlsx",
        "revision_filename": "Trace_rev4.xlsx",
        "source_col_name": "Description",
        "revision_col_name": "Description",
        "source_id": "Cust Req ID",
        "revision_id": "Cust Req ID",
        "status": "SUCCESS",
        "created_timestamp": "2024-07-11T13:23:01.242+00:00",
        "lastupdated_timestamp": "2024-07-11T13:23:47.260+00:00",
        "status_error_message": "",
    }
]


def test_find_all_tasks_success(mock_env, client, mock_mongo_collection):
    """Test case for successfully retrieving a list of tasks with pagination.

    This test case mocks the MongoDB collection to return a predefined list of tasks
    and verifies that the endpoint returns the correct status code and response format.
    """
    mock_mongo_collection.find.return_value.sort.return_value.skip.return_value.limit.return_value = (
        tasks_list
    )
    mock_mongo_collection.count_documents.return_value = len(tasks_list)
    setattr(jwt, "get_unverified_header", MagicMock)
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    response = client.get(
        "/api/requirement-comp-tracer/",
        headers={"Authorization": "Bearer kglkgkjdklj"},
        params={"page": 1, "page_size": 2, "agent_id": "123"},
    )
    assert response.status_code == 200
    # Ensure the _id is serialized to string
    expected_tasks_list = [
        {
            "id": str(task["_id"]),
            "agent_id": "123",
            "rule_id": task["rule_id"],
            "rule_name": task["rule_name"],
            "project": task["project"],
            "email": task["email"],
            "request_type": task["request_type"],
            "source_tracker": task["source_tracker"],
            "revision_tracker": task["revision_tracker"],
            "output_filename": task["output_filename"],
            "source_filename": task["source_filename"],
            "revision_filename": task["revision_filename"],
            "source_col_name": task["source_col_name"],
            "revision_col_name": task["revision_col_name"],
            "source_id": task["source_id"],
            "revision_id": task["revision_id"],
            "status": task["status"],
            "created_timestamp": task["created_timestamp"],
            "lastupdated_timestamp": task["lastupdated_timestamp"],
            "status_error_message": task["status_error_message"],
        }
        for task in tasks_list
    ]
    assert response.json() == {"Tasks": expected_tasks_list, "total_count": len(tasks_list)}


def test_find_all_tasks_invalid_page(client):
    """_summary_."""

    with pytest.raises(RequestValidationError):
        response = client.get(
            "/api/requirement-comp-tracer/",
            headers={"Authorization": "Bearer kglkgkjdklj"},
            params={"page": -1, "page_size": 10},
        )
        assert response.status_code == 422


def test_find_all_tasks_invalid_page_size(client):
    """_summary_."""
    with pytest.raises(RequestValidationError):
        response = client.get(
            "/api/requirement-comp-tracer/",
            headers={"Authorization": "Bearer kglkgkjdklj"},
            params={"page": 1, "page_size": -1},
        )
        assert response.status_code == 422


def test_get_columns_excel_success(client, mock_upload_file, mock_read_excel):
    """Test case for successfully retrieving columns from an Excel file.

    This test case mocks the pandas.read_excel method to return a predefined DataFrame
    and verifies that the endpoint returns the correct status code and response format.
    """
    file = MagicMock(spec=UploadFile)
    file.filename = "test.xlsx"
    file.read.return_value = b"file_content"
    mock_upload_file.return_value = file
    # mock_read_excel.return_value = pd.DataFrame(columns=["col1", "col2", "col3"])
    mock_read_excel.return_value = pd.DataFrame(
        {"col1": [1], "col2": [2], "col3": [3]}  # At least one non-empty row
    )
    # response = client.post("/api/requirement-comp-tracer/filecolumns", files={"test.xlsx": ("filename", b"file_content", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})
    response = client.post(
        "/api/requirement-comp-tracer/filecolumns",
        files={
            "file": (
                "test.xlsx",
                b"file_content",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        },
    )
    loguru.logger.info(response.content)
    assert response.status_code == 200
    # assert response.json() == {"columns": ["col1", "col2", "col3"]}


# def test_get_columns_csv_success(client, mock_upload_file, mock_read_csv):
#     """Test case for successfully retrieving columns from an csv file.

#     This test case mocks the pandas.read_excel method to return a predefined DataFrame
#     and verifies that the endpoint returns the correct status code and response format.
#     """
#     file = MagicMock(spec=UploadFile)
#     file.filename = "test.csv"
#     file.read.return_value = b"file_content"
#     mock_upload_file.return_value = file
#     #mock_read_csv.return_value = pd.DataFrame(columns=["col1", "col2", "col3"])
#     mock_read_excel.return_value = pd.DataFrame({
#         "col1": [1],  # At least one non-empty row
#         "col2": [2],
#         "col3": [3]
#     })
#     response = client.post(
#         "/api/requirement-comp-tracer/filecolumns",
#         files={"file": ("test.csv", b"file_content", "text/csv")},
#     )
#     print(response.content)
#     assert response.status_code == 200
#     assert response.json() == {"columns": ["col1", "col2", "col3"]}


def test_get_columns_csv_success(client):
    """Test case for successfully retrieving columns from a CSV file."""
    # Create a mock UploadFile object
    file = MagicMock(spec=UploadFile)
    file.filename = "test.csv"
    file_content = b"column1,column2,column3\nvalue1,value2,value3"  # Ensure this is consistent with your CSV format
    file.read.return_value = file_content  # Mocking the file read operation

    # DataFrame that should be returned by pandas.read_csv
    df_mock = pd.DataFrame(
        {
            "column1": [
                "value1"
            ],  # Include actual data to prevent the 'empty rows below headers' error
            "column2": ["value2"],
            "column3": ["value3"],
        }
    )

    # Patch the pandas.read_csv method to return the mocked DataFrame
    with patch("pandas.read_csv", return_value=df_mock):
        response = client.post(
            "/api/requirement-comp-tracer/filecolumns",
            files={"file": ("test.csv", file_content, "text/csv")},
        )

        # Check the response status and data
        assert response.status_code == 200
        assert response.json() == {"columns": ["column1", "column2", "column3"]}


def test_create_task_success(
    mock_env,
    mocker,
    client,
    mock_mongodb,
    # mock_blob_service_client,
    mock_background_tasks,
    mock_upload_file,
):
    """Test case for successfully creating a task.

    This test case mocks the MongoDB collection, blob service client, background tasks,
    and file upload method to simulate the creation of a task. It verifies that the endpoint
    returns the correct status code and response format.
    """
    task = create_task_list
    valid_object_id = task["_id"]
    mock_mongodb.insert_one.return_value.inserted_id = valid_object_id
    mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    headers = {"Authorization": "Bearer kglkgkjdklj"}
    response = client.post(
        "/api/requirement-comp-tracer/task/",
        data={
            "rule_id": task_id,
            "agent_id": task_id,
            "source_col_name": "source_col",
            "revision_col_name": "revision_col",
            "project": "test_project",
            "source_id": "source_id",
            "revision_id": "revision_id",
        },
        files={
            "source_file": ("source.csv", b"source file content", "text/csv"),
            "revision_file": (
                "revision.xlsx",
                b"revision file content",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ),
        },
        headers=headers,
    )
    loguru.logger.info(response.content)  # Debugging
    assert response.status_code == 200


def test_execute_task_success(mock_env, mock_db, blobserviceclient, mock_requests, mocker):
    """Test case for successfully executing a task.

    This test case mocks the MongoDB collection, blob service client, requests.post method,
    os operations, and the open function to simulate the execution of a task. It verifies
    that the endpoint performs the expected operations and returns the correct status code
    and response format.
    """
    from src.controllers.requirement_comparision_tracer_controller import execute_task

    mock_os_remove = mocker.patch("os.remove")
    mock_os_path_exists = mocker.patch("os.path.exists", return_value=True)
    mock_os_makedirs = mocker.patch("os.makedirs")
    mock_os_path_isfile = mocker.patch("os.path.isfile", return_value=True)
    # mock_open = mocker.patch("builtins.open", mocker.mock_open())
    mock_pd_read_excel = mocker.patch(
        "pandas.read_excel",
        side_effect=lambda x: pd.DataFrame({"ID": [1], "source_description": ["desc"]}),
    )
    mock_to_excel = mocker.patch("pandas.DataFrame.to_excel", return_value=None)

    # Mock datetime.now to return a fixed datetime
    fixed_datetime = datetime(2023, 1, 1, tzinfo=timezone.utc)
    mock_datetime = mocker.patch(
        "src.controllers.requirement_comparision_tracer_controller.datetime"
    )
    mock_datetime.now.return_value = fixed_datetime
    blobserviceclient.get_blob_client.return_value.download_blob.return_value.readall.return_value = (
        "test"
    )
    blobserviceclient.get_blob_client.return_value.upload_blob.return_value = MagicMock()
    try:
        with patch("builtins.open", mocker.mock_open(read_data="data")):
            request_type = task.get("request_type")
            execute_task(task_id, None, request_type)
    except Exception as e:
        loguru.logger.info("Exception occurred:", e)

    # Assertions
    mock_db.update_one.assert_has_calls(
        [
            call(
                {"_id": ObjectId(task_id)},
                {"$set": {"status": "PROCESSING", "lastupdated_timestamp": fixed_datetime}},
            ),
            call(
                {"_id": ObjectId(task_id)},
                {
                    "$set": {
                        "status": "SUCCESS",
                        "output_filename": "output.xlsx",
                        "lastupdated_timestamp": fixed_datetime,
                    }
                },
            ),
        ]
    )


def test_retry_task_success(mock_env, client, mocker):
    """Test case for successfully retrying a task.

    This test case mocks the MongoDB collection and the BackgroundTasks.add_task method
    to simulate retrying a task. It verifies that the endpoint updates the task status
    and enqueues the task for execution in the background.
    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    get_collection_mock.return_value.find_one.return_value = {"id": 123}

    get_collection_mock.return_value.update_one.return_value = ""
    task_id = "55153a8014829a865bbf700d"

    mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")

    # Act
    response = client.post(
        "/api/requirement-comp-tracer/retry/55153a8014829a865bbf700d",
    )

    # Assert
    assert response.status_code == 200
    assert json.loads(response.text)["task_id"] == task_id


def test_download_task_success(mock_env, client, mock_mongodb, blobserviceclient):
    """Test case for successfully downloading a task result.

    This test case mocks the MongoDB collection and the blob service client
    to simulate the downloading of a task result. It verifies that the endpoint
    returns the correct status code and the expected file content.
    """
    blobserviceclient.get_blob_client.return_value.download_blob.return_value.readall.return_value = (
        "test"
    )
    response = client.get(f"/api/requirement-comp-tracer/download/{task_id}")
    assert response.status_code == 200


def test_delete_task_success(mock_env, client, mock_mongodb):
    """Test case for successfully deleting a task.

    This test case mocks the MongoDB collection to simulate the deletion of a task.
    It verifies that the endpoint returns the correct status code when a task is successfully deleted.
    """
    # Set up the mock to return a deleted task
    mock_mongodb.find_one_and_delete.return_value = {"_id": ObjectId(task_id)}
    response = client.delete(f"/api/requirement-comp-tracer/tasks/{task_id}")
    assert response.status_code == 200


def test_delete_task_exception(mock_env, client, mock_mongodb):
    """Test case for handling exceptions during task deletion.

    This test case mocks the MongoDB collection to simulate an exception
    when trying to delete a task. It verifies that the endpoint handles
    the exception correctly and returns the appropriate status code.
    """
    mock_mongodb.find_one_and_delete.side_effect = Exception("Mocked exception")
    with pytest.raises(HTTPException):
        response = client.delete(f"/api/requirement-comp-tracer/tasks/{task_id}")
        assert response.status_code == 500
        assert "Mocked exception" in response.json()["detail"]


def test_feedback_success_xlsx(mock_env, client, mock_mongodb, blobserviceclient):
    """Test case for successfully retrieving feedback from an Excel file.

    This test case mocks the MongoDB collection and the blob service client
    to simulate the retrieval of feedback from an Excel file. It verifies
    that the endpoint returns the correct status code and the expected feedback data.
    """
    # Prepare mock data
    df = pd.DataFrame(
        {
            "ID": [1, 2],  # Ensure IDs are strings
            "source_description": ["source1", "source2"],
            "revision_description": ["revision1", "revision2"],
            "changeType": ["type1", "type2"],
            "changes": ["change1", "change2"],
            "feedback": ["feedback1", "feedback2"],
        }
    )
    excel_buffer = io.BytesIO()
    df.to_excel(excel_buffer, index=False, engine="openpyxl")
    excel_buffer.seek(0)

    blobserviceclient.get_blob_client.return_value.download_blob.return_value.readall.return_value = (
        excel_buffer.read()
    )
    response = client.get(
        f"/api/requirement-comp-tracer/feedback/{task_id}", params={"page": 1, "page_size": 2}
    )
    assert response.status_code == 200
    blobserviceclient.get_blob_client.return_value.download_blob.return_value.readall.return_value = (
        "test"
    )


def test_feedback_task_not_found(mock_env, client, mock_mongodb):
    """Test case for handling the scenario where a task is not found during feedback retrieval.

    This test case mocks the MongoDB collection to simulate a scenario where the task
    is not found. It verifies that the endpoint correctly handles the missing task
    and returns the appropriate status code and error message.
    """
    mock_mongodb.find_one.return_value = None
    with pytest.raises(HTTPException):
        response = client.get(
            f"/api/requirement-comp-tracer/feedback/{task_id}", params={"page": 1, "page_size": 2}
        )
        assert response.status_code == 404
        assert response.json()["detail"] == "Task not found"


def test_feedback_filename_missing(mock_env, client, mock_mongodb):
    """Test case for handling the scenario where the filename is missing during feedback retrieval.

    This test case mocks the MongoDB collection to simulate a scenario where the task's
    filename is missing. It verifies that the endpoint correctly handles the missing filename
    and returns the appropriate status code and error message.
    """
    task_without_filename = task.copy()
    del task_without_filename["output_filename"]
    mock_mongodb.find_one.return_value = task_without_filename
    with pytest.raises(HTTPException):
        response = client.get(
            f"/api/requirement-comp-tracer/feedback/{task_id}", params={"page": 1, "page_size": 2}
        )
        assert response.status_code == 404
        assert response.json()["detail"] == "Filename missing in task"


def test_feedback_unsupported_file_format(mock_env, client, mock_mongodb):
    """Test case for handling the scenario where an unsupported file format is encountered during feedback retrieval.

    This test case mocks the MongoDB collection and the blob service client to simulate a scenario where the task's
    output file is in an unsupported format. It verifies that the endpoint correctly handles the unsupported format
    and returns the appropriate status code and error message.
    """
    task_with_invalid_file = task.copy()
    task_with_invalid_file["output_filename"] = "output_file.txt"
    mock_mongodb.find_one.return_value = task_with_invalid_file
    with pytest.raises(HTTPException):
        response = client.get(
            f"/api/requirement-comp-tracer/feedback/{task_id}", params={"page": 1, "page_size": 2}
        )
        assert response.status_code == 500
        assert "Unsupported file format" in response.json()["detail"]


def test_update_feedback_success(mock_env, client, mock_mongodb, blobserviceclient):
    """Test case for successfully updating feedback for a task.

    This test case mocks the MongoDB collection and the blob service client
    to simulate updating feedback for a task. It verifies that the endpoint
    correctly processes the feedback updates and returns the appropriate status code.
    """
    updates = [
        UpdateItem(
            ID="1",
            source="source1",
            revision="revision1",
            changeType="new_type1",
            changes="new_change1",
            feedback="new_feedback1",
        ),
        UpdateItem(
            ID="2",
            source="source2",
            revision="revision2",
            changeType="new_type2",
            changes="new_change2",
            feedback="new_feedback2",
        ),
    ]

    response = client.patch(
        f"/api/requirement-comp-tracer/update_feedback/{task_id}",
        json=[update.dict() for update in updates],
    )

    assert response.status_code == 200
    blobserviceclient.get_blob_client.return_value.download_blob.return_value.readall.return_value = (
        "test"
    )


def test_update_feedback_task_not_found(mock_env, client, mock_mongodb):
    """Test case for handling the scenario where a task is not found during feedback update.

    This test case mocks the MongoDB collection to simulate a scenario where the task
    is not found. It verifies that the endpoint correctly handles the missing task
    and returns the appropriate status code and error message.
    """
    mock_mongodb.find_one.return_value = None
    updates = [
        UpdateItem(
            ID="1",
            source="source1",
            revision="revision1",
            changeType="new_type1",
            changes="new_change1",
            feedback="new_feedback1",
        )
    ]
    with pytest.raises(HTTPException):
        response = client.patch(
            f"/api/requirement-comp-tracer/update_feedback/{task_id}",
            json=[update.dict() for update in updates],
        )
        assert response.status_code == 404
        assert response.json()["detail"] == "Task not found"


def test_update_feedback_filename_missing(mock_env, client, mock_mongodb):
    """Test case for handling the scenario where the filename is missing during feedback update.

    This test case mocks the MongoDB collection to simulate a scenario where the task's
    filename is missing. It verifies that the endpoint correctly handles the missing filename
    and returns the appropriate status code and error message.
    """
    task_without_filename = task.copy()
    del task_without_filename["output_filename"]
    mock_mongodb.find_one.return_value = task_without_filename
    updates = [
        UpdateItem(
            ID="1",
            source="source1",
            revision="revision1",
            changeType="new_type1",
            changes="new_change1",
            feedback="new_feedback1",
        )
    ]
    with pytest.raises(HTTPException):
        response = client.patch(
            f"/api/requirement-comp-tracer/update_feedback/{task_id}",
            json=[update.dict() for update in updates],
        )
        assert response.status_code == 404


def test_get_project_by_id_success(client, mocker, mock_mongodb):
    """

    Args:
        client (_type_): _description_
        mocker (_type_): _description_
    """
    mock_project_collection = MagicMock()

    # Mock the find_one method to return a sample project
    mock_project_collection.find_one.return_value = {
        "_id": ObjectId("60d5f479f4b2b59b0f0298d6"),
        "name": "Sample Project",
        "description": "This is a sample project.",
    }
    mocker.patch(
        "src.controllers.requirement_comparision_tracer_controller.get_project_by_id",
        return_value=mock_project_collection,
    )

    # Act

    response = client.get(
        "/api/requirement-comp-tracer/getProject/60d5f479f4b2b59b0f0298d6",
    )

    # Assert
    assert response.status_code == 200


@pytest.fixture(autouse=True)
def mock_blob_service_client(mocker):
    """Fixture that mocks the Azure BlobServiceClient for testing.

    This fixture mocks the `BlobServiceClient` class from `azure.storage.blob`
    and its methods, including `from_connection_string`, `get_blob_client`,
    `upload_blob`, and `download_blob`. It returns a mock blob client
    with predefined responses for testing purposes.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    Returns:
        MagicMock: A mocked instance of the blob client with preconfigured methods.
    """
    mock_blobservice_client = mocker.patch("azure.storage.blob.BlobServiceClient")
    mock_blobservice_client.from_connection_string.return_value = MagicMock()
    mock_blob_client = mock_blobservice_client.from_connection_string.return_value
    mock_blob_client.get_blob_client.return_value = MagicMock()
    mock_blob_client.get_blob_client.return_value.upload_blob.return_value = None
    mock_blob_client.get_blob_client.return_value.download_blob.return_value = MagicMock()
    mock_download_blob = mock_blob_client.get_blob_client.return_value.download_blob.return_value
    mock_download_blob.readall.return_value = json.dumps({"key": "value"}).encode("utf-8")
    return mock_blob_client


def test_create_codebeamer_task_success(client, mocker, mock_blob_service_client, mock_mongodb):
    """Test case for creating a CodeBeamer task successfully.

    Args:
        client: FastAPI test client.
        mocker: Mocking framework.
        mock_blob_service_client: Mocked Azure Blob Service client.
        mock_mongodb: Mocked MongoDB collection.

    Returns:
        None
    """
    # Arrange
    mock_os = mocker.patch("src.controllers.requirement_comparision_tracer_controller.os")
    mock_os.makedirs.return_value = None
    mock_os.path.isfile.return_value = True
    mock_os.path.exists.return_value = True
    mock_os.remove.return_value = None
    import os

    mock_os.path.join = os.path.join

    mock_execute_task = mocker.patch(
        "src.controllers.requirement_comparision_tracer_controller.execute_task"
    )
    mock_mongo_insert_one = mock_mongodb.insert_one
    mock_get_items_by_project = mocker.patch(
        "src.controllers.requirement_comparision_tracer_controller.get_items_by_project"
    )
    mocker.patch("pandas.DataFrame.to_excel", return_value=None)

    mock_mongo_insert_one.return_value.inserted_id = "mock_task_id"
    mock_get_items_by_project.return_value = [{"id": "1", "description": "Requirement 1"}]

    blob_client = MagicMock()
    mock_blob_service_client.return_value = blob_client
    blob_client.upload_blob.return_value = None

    # mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")

    # Act
    try:
        with patch("builtins.open", mocker.mock_open(read_data="data")):
            response = client.post(
                "api/requirement-comp-tracer/cb/task",
                headers={"Authorization": "Bearer mock_token"},
                data={
                    "rule_id": "abecdedfegege",
                    "agent_id": "test_agent_id",
                    "project": "ai",
                    "source_tracker": "test_project",
                    "revision_tracker": "test_tracker",
                },
            )

        # Assert
        assert response.status_code == 200
        assert response.json() == {"task_id": "mock_task_id"}
        mock_mongo_insert_one.assert_called_once()
        mock_execute_task.assert_called_once_with("mock_task_id", "mock_token")

    except Exception as e:
        print("Exception occurred:", e)


def test_delete_task_rules_success(mock_env, client, mock_mongodb):
    """Test case for successfully deleting a task.

    This test case mocks the MongoDB collection to simulate the deletion of a task.
    It verifies that the endpoint returns the correct status code when a task is successfully deleted.
    """
    # Set up the mock to return a deleted task
    mock_mongodb.find_one_and_delete.return_value.deleted_count = 1
    response = client.delete(
        "/api/requirement-comp-tracer/delete_task_rules/",
        params={"user_id": "user123", "project": "projectX"},
    )
    assert response.status_code == 200


def test_create_rule_success(client, mocker, mock_mongodb):
    """

    Args:
        client (_type_): _description_
        mocker (_type_): _description_
    """
    mock_mongodb.insert_one.return_value.inserted_id = "new_task_id"
    # mocker.patch("src.controllers.requirement_comparision_tracer_controller.create_rule")

    # Act
    payload = {
        "user_id": "user123",
        "project": "projectX",
        "rule_name": "rule1",
        "rules": {
            "major_rules": ["major_rule_1"],
            "minor_rules": ["minor_rule_1"],
            "no_change_rules": ["no_change_rule_1"],
        },
    }
    json_payload = json.dumps(payload)
    response = client.post("/api/requirement-comp-tracer/create_rule", json=json_payload)

    # Assert
    assert response.status_code == 200
    response_json = response.json()
    assert response_json["user_id"] == "user123"
    assert response_json["project"] == "projectX"
    assert response_json["rule_name"] == "rule1"


def test_get_rule_success(client, mock_mongodb, mock_mongo_collection):
    # Simulate a valid rule_id and successful fetch from DB
    mock_mongodb.find_one.return_value = {
        "_id": ObjectId("60b6a2d6b80b2c3e6c8d9f0a"),
        "rule_name": "Test Rule",
        "rules": {"major_rules": [], "minor_rules": []},
        "created_timestamp": datetime(2023, 1, 1),
        "lastupdated_timestamp": datetime(2023, 1, 2),
    }

    # Call the endpoint
    response = client.get("/api/requirement-comp-tracer/get_rule/60b6a2d6b80b2c3e6c8d9f0a")

    # Check the response status and body
    assert response.status_code == 200
