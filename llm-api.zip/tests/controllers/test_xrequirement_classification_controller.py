"""Test_requirement_classification_controller.py!"""

import json
import os
from datetime import datetime, timezone
from tempfile import NamedTemporaryFile
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest
from bson import ObjectId
from fastapi import BackgroundTasks, HTTPException, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.testclient import TestClient
from pymongo.collection import Collection

from src.models.requirement_classification_feedbacktask import UpdateItem
from src.utils.auth import jwt


@pytest.fixture(autouse=True)
def client(mocker, mock_blob_service_client):
    """Fixture that provides a TestClient instance for testing.

    This fixture automatically initializes a TestClient for the `router`
    imported from `src.controllers.requirement_classification_controller`
    and yields it for use in tests.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.
        mock_blob_service_client (MagicMock): A mocked instance of `BlobServiceClient`.

    Yields:
        TestClient: A TestClient instance to interact with the application router.
    """
    from src.controllers.requirement_classification_controller import router

    with TestClient(router) as client:
        yield client


# Mock the BlobServiceClient and Mongodb
@pytest.fixture(autouse=True)
def mock_blob_service_client(mocker):
    """Fixture that mocks the Azure BlobServiceClient for testing.

    This fixture mocks the `BlobServiceClient` class from `azure.storage.blob`
    and its methods, including `from_connection_string`, `get_blob_client`,
    `upload_blob`, and `download_blob`. It returns a mock blob client
    with predefined responses for testing purposes.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    Returns:
        MagicMock: A mocked instance of the blob client with preconfigured methods.
    """
    mock_blobservice_client = mocker.patch("azure.storage.blob.BlobServiceClient")
    mock_blobservice_client.from_connection_string.return_value = MagicMock()
    mock_blob_client = mock_blobservice_client.from_connection_string.return_value
    mock_blob_client.get_blob_client.return_value = MagicMock()
    mock_blob_client.get_blob_client.return_value.upload_blob.return_value = None
    mock_blob_client.get_blob_client.return_value.download_blob.return_value = MagicMock()
    mock_download_blob = mock_blob_client.get_blob_client.return_value.download_blob.return_value
    mock_download_blob.readall.return_value = json.dumps({"key": "value"}).encode("utf-8")
    return mock_blob_client


@pytest.fixture(autouse=True)
def setenvvar(client):
    """Set Environment variables."""
    with patch.dict(
        os.environ,
        {
            "BLOB_CONNECT_STR": "test_connection_string",
            "BLOB_CONTAINER_NAME": "test_container_name",
        },
    ):
        yield  # This is the magical bit which restore the environment variables to their original values after the test is done


@pytest.fixture()
def mock_requests_and_pandas(mocker):
    """Fixture that mocks `pandas` and `requests` for testing.

    This fixture mocks `pandas.read_excel` to return a predefined DataFrame,
    `pandas.DataFrame.to_excel` to do nothing, and `requests.post` to return
    a mock response with a status code of 200 and a JSON payload.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    Returns:
        MagicMock: A mocked response object for `requests.post` with predefined attributes.
    """
    # Mock pandas read_excel
    mock_df = pd.DataFrame({"text": ["Sample text"], "ID": ["123"]})
    mocker.patch(
        "src.controllers.requirement_classification_controller.pd.read_excel", return_value=mock_df
    )

    # Mock pandas to_excel
    mocker.patch(
        "src.controllers.requirement_classification_controller.pd.DataFrame.to_excel",
        return_value=None,
    )

    # Mock requests.post
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = '[{"text": "Information", "ID": "123"}]'
    # mock_response.json.return_value = ""
    mocker.patch(
        "src.controllers.requirement_classification_controller.requests.post",
        return_value=mock_response,
    )

    return mock_response


# Mock the MongoDB collection and return values
@pytest.fixture
def mock_mongodb(mocker):
    """Fixture that mocks MongoDB collection methods for testing.

    This fixture mocks the `MongoDB.get_collection` method and returns
    a mock collection with a predefined return value for the `find_one` method.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    Returns:
        MagicMock: A mocked MongoDB collection with a predefined `find_one` return value.
    """
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    mock_collection = get_collection_mock.return_value
    mock_collection.find_one.return_value = mock_task
    return mock_collection


#############
# Mock data #
#############

mock_task_id = "55153a8014829a865bbf700d"

mock_task = {
    "_id": ObjectId(mock_task_id),
    "project": "test_project",
    "filename": "test_file.xlsx",
    "status": "success",
    "created_timestamp": "01/01/2024",
    "lastupdated_timestamp": "01/01/2024",
    "prediction_col_name": "req",
    "request_type": "DOORS",
    "tracker": "",
    "status_error_message": "",
    "code_beamer_error_message": "",
    "code_beamer_status": "",
}


# Tests for the method find_all_tasks
def test_find_all_tasks_uninitialized_db(client):
    """Tests the behavior of the endpoint when the database is uninitialized.

    This test simulates a scenario where the database has not been set up,
    which should result in a 500 Internal Server Error response when
    attempting to fetch tasks.

    Args:
        client (TestClient): A test client instance for sending requests to the API.

    Raises:
        HTTPException: An exception is expected if the database is not initialized.
    """
    # Missing Arrange setup is intentional
    # To trigger a 500 response

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.get("/api/req-class/", params={"page": 1, "page_size": 10})

        # Assert
        assert response.status_code == 500


def test_find_all_tasks_success(client, mocker):
    """Tests the successful retrieval of tasks from the API.

    This test simulates a scenario where tasks are successfully retrieved from
    the database. It verifies that the API correctly returns the tasks and
    appropriate metadata such as total count.

    Args:
        client (TestClient): A test client instance for sending requests to the API.
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    tasks_list = [
        {
            "_id": 1,
            "project": "test_project",
            "filename": "test_file.xlsx",
            "status": "success",
            "created_timestamp": "01/01/2024",
            "lastupdated_timestamp": "01/01/2024",
            "prediction_col_name": "req",
            "prediction_id": "pred",
            "request_type": "DOORS",
            "tracker": "",
            "status_error_message": "",
        }
    ]
    get_collection_mock.return_value.find.return_value.sort.return_value.skip.return_value.limit.return_value = (
        tasks_list
    )

    get_collection_mock.return_value.count_documents.return_value = len(tasks_list)

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    # Act
    response = client.get(
        "/api/req-class/",
        headers={"Authorization": "Bearer kglkgkjdklj"},
        params={"page": 1, "page_size": 10},
    )

    # Assert
    assert response.status_code == 200
    assert response.json()["total_count"] == len(tasks_list)
    assert len(response.json()) == 2


def test_find_all_tasks_invalid_page(client):
    """Tests the behavior of the endpoint when an invalid page number is provided.

    This test verifies that the API responds with a 422 Unprocessable Entity
    status code when an invalid page number (e.g., negative number) is provided
    in the request parameters.

    """
    # Arrange
    page = -1
    page_size = 10

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    # Act & Assert
    with pytest.raises(RequestValidationError):
        response = client.get(
            "/api/req-class/",
            headers={"Authorization": "Bearer kglkgkjdklj"},
            params={"page": page, "page_size": page_size},
        )

        # Assert
        assert response.status_code == 422


def test_find_all_tasks_invalid_page_size(client):
    """Tests the behavior of the endpoint when an invalid page size is provided.

    This test verifies that the API responds with a 422 Unprocessable Entity
    status code when an invalid page size (e.g., negative number) is provided
    in the request parameters.

    """
    # Arrange
    page = 1
    page_size = -1

    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    # Act
    with pytest.raises(RequestValidationError):
        response = client.get(
            "/api/req-class/",
            headers={"Authorization": "Bearer kglkgkjdklj"},
            params={"page": page, "page_size": page_size},
        )

        # Assert
        assert response.status_code == 422


# Tests for the method get_columns


def test_get_columns_invalid_extension(client, mocker):
    """Tests the API response for an unsupported file extension.

    This test simulates a scenario where a file with an invalid extension
    (e.g., ".txt") is uploaded to the `/api/req-class/filecolumns` endpoint.
    It checks that the API responds with a 422 Unprocessable Entity status code.

    Args:
        client (TestClient): A test client instance for sending requests to the API.
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.
    """
    # Arrange
    # Load test client for FastAPI
    mocker.patch("os.path.splitext", [0, "txt"])

    # Act & Assert
    with pytest.raises(RequestValidationError):
        response = client.post(
            "/api/req-class/filecolumns", params={"file": {"file_name": "test.txt"}}
        )

        # Assert
        assert response.status_code == 422


def test_get_columns_excel(client, mocker):
    """Tests the API response for a valid Excel file upload.

    This test simulates uploading a file with a ".xlsx" extension to the
    `/api/req-class/filecolumns` endpoint. It mocks `pandas.read_excel` to
    return a predefined set of columns and checks that the response includes
    the expected column names and has a 200 OK status.

    Args:
        client (TestClient): A test client instance for sending requests to the API.
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.
    """
    # Arrange
    file_object = open("tests/data/test.xlsx", "rb")
    # mocker.patch("pandas.read_excel.return_value.dropna.return_value.empty", return_value=False)

    get_excel_mocker = mocker.patch("pandas.read_excel")
    get_excel_mocker.return_value = pd.DataFrame({"req": ["Sample text"], "id": ["123"]})
    get_excel_mocker.columns.return_value.tolist.return_value = ["req", "id"]
    get_excel_mocker.read_excel.return_value.dropna.return_value.empty.return_value = False
    # Act
    response = client.post(
        "/api/req-class/filecolumns",
        files={
            "file": (
                "test.xlsx",
                file_object,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        },
    )

    # Assert
    assert json.loads(response.text)["columns"] == ["req", "id"]
    assert response.status_code == 200


def test_get_columns_csv(client, mocker):
    """Tests the API response for a valid CSV file upload.

    This test simulates uploading a file with a ".csv" extension to the
    `/api/req-class/filecolumns` endpoint. It mocks `pandas.read_csv` to
    return a predefined set of columns and checks that the response includes
    the expected column names and has a 200 OK status.

    Args:
        client (TestClient): A test client instance for sending requests to the API.
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.
    """
    # Arrange
    file_object = open("tests/data/test.csv", "rb")

    get_excel_mocker = mocker.patch("pandas.read_csv")
    get_excel_mocker.columns.return_value.tolist.return_value = ["req", "id"]
    get_excel_mocker.return_value = pd.DataFrame({"req": ["Sample text"], "id": ["123"]})

    # Act
    response = client.post(
        "/api/req-class/filecolumns",
        files={
            "file": (
                "test.csv",
                file_object,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        },
    )

    # Assert
    assert json.loads(response.text)["columns"] == ["req", "id"]
    assert response.status_code == 200


###################################
# Tests for the method retry_task #
###################################


def test_retry_task_error(client, mocker):
    """Tests the API response when retrying a non-existent task.

    This test simulates a scenario where a retry request is made for a task
    that does not exist in the database. It checks that the API responds with
    a 404 Not Found status code, indicating that the task could not be found.

    Args:
        client (TestClient): A test client instance for sending requests to the API.
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    Raises:
        HTTPException: Expected exception due to task not being found.
    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    get_collection_mock.return_value.find_one.return_value = None

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.post(
            "/api/req-class/retry/55153a8014829a865bbf700d",
        )

        # Assert
        assert response.status_code == 404


def test_retry_task_success(client, mocker):
    """Tests the API response when retrying an existing task.

    This test simulates a scenario where a retry request is made for an existing
    task in the database. It verifies that the API responds with a 200 OK status
    code and returns the correct `task_id` in the response.

    Args:
        client (TestClient): A test client instance for sending requests to the API.
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    get_collection_mock.return_value.find_one.return_value = {"id": 123}

    get_collection_mock.return_value.update_one.return_value = ""
    task_id = "55153a8014829a865bbf700d"

    mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")

    # Act
    response = client.post(
        "/api/req-class/retry/55153a8014829a865bbf700d",
    )

    # Assert
    assert response.status_code == 200
    assert json.loads(response.text)["task_id"] == task_id


#####################################
# Tests for the method execute_task #
#####################################

# def test_execute_task_success(mocker, mock_requests_and_pandas):
#     """Tests the successful execution of a task.

#     This test verifies the behavior of the `execute_task` function when a task is executed successfully.
#     It mocks interactions with MongoDB, Azure Blob Storage, and file system operations. The test
#     checks that the function performs as expected, including updating the MongoDB record, uploading
#     the file to Azure Blob Storage, and handling file system operations.

#     Args:
#         mock_requests_and_pandas (MagicMock): A mocked instance of requests and pandas for simulating external dependencies.
#         mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

#     """
#     from src.controllers.requirement_classification_controller import execute_task

#     # Arrange
#     # Mock MongoDB collection
#     mock_collection = MagicMock()
#     mock_collection.find_one.return_value = {
#         "filename": "sample.xlsx",
#         "user_id": "user123",
#         # "prediction_col_name": "text",
#         "prediction_col_name": "prediction",
#         "request_type": "CODEBEAMER",
#     }
#     mock_collection.update_one = MagicMock()

#     mock_mongo = mocker.patch(
#         "src.controllers.requirement_classification_controller.MongoDB.get_collection",
#         return_value=mock_collection,
#     )
#     mocker.patch(
#         "src.controllers.requirement_classification_controller.os.path.isfile", return_value=True
#     )

#     # Mock os.remove and os.makedirs
#     mocker.patch(
#         "src.controllers.requirement_classification_controller.os.remove", return_value=None
#     )
#     mocker.patch(
#         "src.controllers.requirement_classification_controller.os.makedirs", return_value=None
#     )


#     # Mock datetime.now to return a fixed datetime
#     fixed_datetime = datetime(2023, 1, 1, tzinfo=timezone.utc)
#     mock_datetime = mocker.patch("src.controllers.requirement_classification_controller.datetime")
#     mock_datetime.now.return_value = fixed_datetime
#       # Mock request object
#     mock_request = MagicMock()
#     mock_request.headers = {"Authorization": "Bearer test_auth_token"}
#     # Define the task_id and auth_token
#     task_id = "605c72ef0c8c0a001f1b2c3d"  # Example ObjectId as a string
#     auth_token = "test_auth_token"
#     agent_name = "BMW"
#     user_details = {"email": "user@example.com"}
#     mocker.patch(
#         "src.controllers.requirement_classification_controller.AuthValidation.wrapper",
#         return_value=user_details
#     )
#     # Execute the task
#     # Act
#     with patch("builtins.open", mocker.mock_open(read_data="data")):
#             # breakpoint()
#         result = execute_task(mock_request,user_details,task_id,agent_name)


#     # Assertions
#     assert result == {"status": "success", "message": "Task executed successfully."}

#     # Verify MongoDB update call
#     mock_collection = mock_mongo.return_value
#     mock_collection.update_one.assert_called_with(
#         {"_id": ObjectId(task_id)},
#         {
#             "$set": {
#                 "code_beamer_status": "SUCCESS",
#                 "code_beamer_error_message":"",
#                 #"filename": "605c7_processed_sample.xlsx",
#                 "lastupdated_timestamp": fixed_datetime,
#             }
#         },
#     )

# Verify blob upload
# mock_blob_client = mock_mongo[1].return_value
# mock_blob_client.upload_blob.assert_called_once()

# Verify file removal
# mocker.patch('src.controllers.requirement_classification_controller.os.path.exists', return_value=True)
# mocker.patch('src.controllers.requirement_classification_controller.os.remove', return_value=None)
# os.remove.assert_called_with(os.path.join("data", "temp_sample.xlsx"))


def test_delete_task_success(client, mocker):
    """Test the successful deletion of a task from the API.

    This test verifies that the API endpoint `/api/req-class/tasks/{task_id}` correctly
    handles the deletion of a task when the task is found and successfully removed.
    The test mocks the `MongoDB.get_collection` method to simulate a successful deletion
    operation and checks that the response status code is 200, indicating a successful
    request.

    Args:
        client: The test client used to make requests to the API.
        mocker: The mocker fixture used to patch and mock dependencies.

    Act:
        The test sends a DELETE request to the `/api/req-class/tasks/55153a8014829a865bbf700d` endpoint.

    Assert:
        The test verifies that the response status code is 200, indicating that the task was successfully deleted.

    Note:
        This test is designed to check the successful execution of the deletion operation and assumes
        that the mocked `find_one_and_delete` method returns a successful result.
    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    get_collection_mock.return_value.find_one_and_delete.return_value = "1234"

    # Act
    response = client.delete(
        "/api/req-class/tasks/55153a8014829a865bbf700d",
    )

    # Assert
    assert response.status_code == 200


def test_download_task_not_found(client, mock_mongodb):
    """Test case for handling the scenario when a task is not found in the database.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.

    Raises:
        HTTPException: If the task is not found.

    Returns:
        None
    """
    mock_mongodb.find_one.return_value = None

    with pytest.raises(HTTPException):
        response = client.get(f"api/req-class/download/55153a8014829a865bbf700d")
        # assert response.status_code == 404
        assert response.json() == {"detail": "Task not found"}


def test_download_task_processing(client, mock_mongodb):
    """Test case for handling the scenario when a task is still processing.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.

    Returns:
        None
    """
    mock_mongodb.find_one.return_value = {"_id": mock_task_id, "status": "PROCESSING"}

    response = client.get(f"api/req-class/download/{mock_task_id}")
    assert response.text == "Task is still processing, please try again later."


def test_download_task_failure(client, mock_mongodb):
    """Test case for handling the scenario when a task has failed or is in an unrecognized state.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.

    Returns:
        None
    """
    mock_mongodb.find_one.return_value = {"_id": mock_task_id, "status": "FAILED"}
    response = client.get(f"api/req-class/download/{mock_task_id}")
    assert response.text == "Task has failed or is in an unrecognized state."


def test_download_task_missing_filename(client, mock_mongodb):
    """Test case for handling the scenario when the filename is missing for a successful task.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.

    Raises:
        HTTPException: If the filename is missing.

    Returns:
        None
    """
    mock_mongodb.find_one.return_value = {
        "_id": ObjectId(),
        "status": "SUCCESS",
        "user_id": "user1",
    }

    with pytest.raises(HTTPException):
        response = client.get(f"api/req-class/download/{ObjectId()}")
        assert response.status_code == 404
        assert response.json() == {"detail": "Filename is missing"}


def test_download_task_success(client, mock_mongodb):
    """Test case for handling successful task download.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.
        mock_blob_service_client: Mocked Azure Blob Service client.

    Returns:
        None
    """
    mock_mongodb.find_one.return_value = {
        "_id": ObjectId(),
        "status": "SUCCESS",
        "filename": "file.txt",
        "user_id": "user1",
    }

    # Act
    response = client.get(f"api/req-class/download/{ObjectId()}")
    assert response.status_code == 200
    assert response.headers["Content-Disposition"] == "attachment; filename=file.txt"


###############################################
# Tests for the method create_codebeamer_task #
###############################################

mock_cb_task_id = "55153a8014829a865bbf700e"

mock_cb_task = {
    "_id": ObjectId(mock_task_id),
    "rule_id": "123",
    "project": "test_project",
    "agent_id": "abcde",
    "filename": "test_file.xlsx",
    "status": "success",
    "created_timestamp": "01/01/2024",
    "lastupdated_timestamp": "01/01/2024",
    "prediction_col_name": "req",
    "request_type": "CODEBEAMER",
    "tracker": "",
    "status_error_message": "",
    "code_beamer_error_message": "",
    "code_beamer_status": "",
}


@pytest.fixture
def mock_db_cb(mocker):
    """Fixture to mock the MongoDB collection for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    mock_collection = MagicMock(Collection)
    mock_collection.find_one.return_value = mock_cb_task
    mocker.patch("src.utils.mongo_db.MongoDB.get_collection", return_value=mock_collection)
    return mock_collection


@pytest.fixture
def mock_background_tasks():
    """Fixture to mock the BackgroundTasks.add_task method for testing.

    This fixture uses the mocker to patch the add_task method of BackgroundTasks from FastAPI,
    providing a mock implementation to be used in tests.
    """
    return MagicMock(spec=BackgroundTasks)


@pytest.fixture
def mock_mongodb_cb(mocker):
    """Fixture that mocks MongoDB collection methods for testing.

    This fixture mocks the `MongoDB.get_collection` method and returns
    a mock collection with a predefined return value for the `find_one` method.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    Returns:
        MagicMock: A mocked MongoDB collection with a predefined `find_one` return value.
    """
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    mock_collection = get_collection_mock.return_value
    mock_collection.find_one.return_value = mock_cb_task
    return mock_collection


@pytest.fixture(autouse=True)
def mock_env(client, mocker):
    """Fixture to mock environment variables for testing.

    This fixture uses the mocker to mock the environment variables
    needed for the tests to ensure they run with the expected configuration.
    """
    mocker.patch.dict(os.environ, {"REQUIREMENT_CLASSIFICATION_URL": "http://mockservice"})
    mocker.patch(
        "src.controllers.requirement_classification_controller.requirement_classification_config",
        {"collection_name": "mock_collection"},
    )


def test_create_codebeamer_task_success(
    client, mocker, mock_background_tasks, mock_env, mock_mongodb_cb
):
    """Test case for creating a CodeBeamer task successfully.

    Args:
        client: FastAPI test client.
        mocker: Mocking framework.
        mock_blob_service_client: Mocked Azure Blob Service client.
        mock_mongodb: Mocked MongoDB collection.

    Returns:
        None
    """
    # Arrange
    cb_task = mock_cb_task
    valid_object_id = cb_task["_id"]
    mock_mongodb_cb.insert_one.return_value.inserted_id = valid_object_id
    mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")
    projects = [{"id": "123", "description": "Design"}]

    # Mocking the return value of get_items_by_project
    mocker.patch(
        "src.controllers.requirement_classification_controller.get_items_by_project",
        return_value=projects,
    )
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    headers = {"Authorization": "Bearer kglkgkjdklj"}

    # mock_get_items_by_project.return_value = [{"id": "1", "description": "Requirement 1"}]

    blob_client = MagicMock()
    mock_blob_service_client.return_value = blob_client
    blob_client.upload_blob.return_value = None

    # mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")

    # Act
    data = {
        "agent_id": "agent123",
        "agent_name": "Test Agent",
        "codebeamer_project": "test_project",
        "codebeamer_tracker": "test_tracker",
        "email": "test@example.com",
    }
    response = client.post("api/req-class/cb/task", headers=headers, data=data)

    # Assert
    assert response.status_code == 200


#################################
# Tests for the method feedback #
#################################
def test_feedback_task_not_found(client, mocker):
    """Test case for handling the scenario when a feedback task is not found in the database.

    Args:
        client: FastAPI test client.
        mocker: Mocking framework.

    Raises:
        HTTPException: If the task is not found.

    Returns:
        None
    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    task = None
    get_collection_mock.return_value.find_one.return_value = task

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.get(
            "/api/req-class/feedback/55153a8014829a865bbf700d", params={"page": 1, "page_size": 10}
        )

        # Assert
        assert response.status_code == 404


def test_feedback_missing_filename(client, mocker):
    """Test case for handling the scenario when the filename is missing for a feedback task.

    Args:
        client: FastAPI test client.
        mocker: Mocking framework.

    Raises:
        HTTPException: If the filename is missing.

    Returns:
        None
    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    task = {"user_id": 1234}
    get_collection_mock.return_value.find_one.return_value = task

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.get(
            "/api/req-class/feedback/55153a8014829a865bbf700d", params={"page": 1, "page_size": 10}
        )

        # Assert
        assert response.status_code == 404


def test_feedback_missing_pred_col_name(client, mocker):
    """Test case for handling the scenario when the prediction column name is missing for a feedback task.

    Args:
        client: FastAPI test client.
        mocker: Mocking framework.

    Raises:
        HTTPException: If the prediction column name is missing.

    Returns:
        None
    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    task = {"filename": "test.xlsx", "user_id": 1234}
    get_collection_mock.return_value.find_one.return_value = task

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.get(
            "/api/req-class/feedback/55153a8014829a865bbf700d", params={"page": 1, "page_size": 10}
        )

        # Assert
        assert response.status_code == 404


def test_feedback_blob_error(client, mocker):
    """Test case for handling the scenario when there is an error with the Azure Blob Service for a feedback task.

    Args:
        client: FastAPI test client.
        mocker: Mocking framework.

    Raises:
        HTTPException: If there is an error with the Azure Blob Service.

    Returns:
        None
    """
    # Arrange
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    task = {"filename": "test.xlsx", "user_id": 1234, "prediction_col_name": "req"}
    get_collection_mock.return_value.find_one.return_value = task

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.get(
            "/api/req-class/feedback/55153a8014829a865bbf700d", params={"page": 1, "page_size": 10}
        )

        # Assert
        assert response.status_code == 500


def test_feedback_pred_col_not_in_df(client, mocker, mock_mongodb):
    """Test case for handling the scenario when the prediction column is not in the DataFrame for a feedback task.

    Args:
        client: FastAPI test client.
        mocker: Mocking framework.
        mock_blob_service_client: Mocked Azure Blob Service client.
        mock_mongodb: Mocked MongoDB collection.

    Returns:
        None
    """
    # Arrange
    # get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    task = {"filename": "test.xlsx", "user_id": 1234, "prediction_col_name": "req"}
    dummy_df = pd.DataFrame(columns=["req"])
    mock_mongodb.get_collection.return_value.find_one.return_value = task
    mock_blob_client = MagicMock()

    pandas_mocker = mocker.patch("src.controllers.requirement_classification_controller.pd")
    pandas_mocker.return_value.read_excel.return_value = dummy_df

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.get(
            "/api/req-class/feedback/55153a8014829a865bbf700d", params={"page": 1, "page_size": 10}
        )
        assert response.detail == f"Column 'prediction' not found in file"
        assert response.status_code == 400


########################################
# Tests for the method update_feedback #
########################################


def test_update_feedback_task_not_found(client, mock_mongodb):
    """Test case for handling the scenario when a feedback task is not found in the database.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.

    Raises:
        HTTPException: If the task is not found.

    Returns:
        None
    """
    mock_mongodb.find_one.return_value = None
    updates = [
        UpdateItem(
            ID="1",
            requirement="requirement1",
            prediction="prediction",
            prediction_feedback="prediction_feedback",
        )
    ]

    with pytest.raises(HTTPException):
        response = client.patch(
            f"/api/req-class/update_feedback/{mock_task_id}",
            json=[update.dict() for update in updates],
        )
        assert response.status_code == 404
        assert response.json()["detail"] == "Task not found"


def test_update_feedback_missing_filename(client, mock_mongodb):
    """Test case for handling the scenario when the filename is missing for a feedback task.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.

    Raises:
        HTTPException: If the filename is missing.

    Returns:
        None
    """
    # Arrange
    task = {"user_id": 1234}
    updates = [
        UpdateItem(
            ID="1",
            requirement="requirement1",
            prediction="prediction",
            prediction_feedback="prediction_feedback",
        )
    ]

    mock_mongodb.find_one.return_value = task

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.patch(
            f"/api/req-class/update_feedback/{mock_task_id}",
            json=[update.dict() for update in updates],
        )
        assert response.status_code == 404
        assert response.json()["detail"] == "Filename missing in task"


def test_update_feedback_missing_pred_column_name(client, mock_mongodb):
    """Test case for handling the scenario when the prediction column name is missing for a feedback task.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.

    Raises:
        HTTPException: If the prediction column name is missing.

    Returns:
        None
    """
    # Arrange
    task = {"filename": "test.xlsx", "user_id": 1234}
    updates = [
        UpdateItem(
            ID="1",
            requirement="requirement1",
            prediction="prediction",
            prediction_feedback="prediction_feedback",
        )
    ]

    mock_mongodb.find_one.return_value = task

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.patch(
            f"/api/req-class/update_feedback/{mock_task_id}",
            json=[update.dict() for update in updates],
        )
        assert response.status_code == 404
        assert response.json()["detail"] == "Prediction column name missing in task"


def test_update_feedback_blob_error(client, mock_mongodb):
    """Test case for handling the scenario when there is an error with the Azure Blob Service for a feedback task.

    Args:
        client: FastAPI test client.
        mock_mongodb: Mocked MongoDB collection.

    Raises:
        HTTPException: If there is an error with the Azure Blob Service.

    Returns:
        None
    """
    # Arrange
    task = {"filename": "test.xlsx", "user_id": 1234, "prediction_col_name": "req"}
    mock_mongodb.find_one.return_value = task

    updates = [
        UpdateItem(
            ID="1",
            requirement="requirement1",
            prediction="prediction",
            prediction_feedback="prediction_feedback",
        )
    ]

    with pytest.raises(HTTPException):
        response = client.patch(
            f"/api/req-class/update_feedback/{mock_task_id}",
            json=[update.dict() for update in updates],
        )
        assert response.status_code == 500


def test_update_feedback_pred_col_not_in_df(client, mocker, mock_mongodb):
    """Test case for handling the scenario when the prediction column is not in the DataFrame for a feedback task.

    Args:
        client: FastAPI test client.
        mocker: Mocking framework.
        mock_blob_service_client: Mocked Azure Blob Service client.
        mock_mongodb: Mocked MongoDB collection.

    Returns:
        None
    """
    # Arrange
    task = {"filename": "test.xlsx", "user_id": 1234, "prediction_col_name": "req"}
    dummy_df = pd.DataFrame(columns=["req"])
    mock_mongodb.get_collection.return_value.find_one.return_value = task
    mock_blob_client = MagicMock()

    pandas_mocker = mocker.patch("src.controllers.requirement_classification_controller.pd")
    pandas_mocker.return_value.read_excel.return_value = dummy_df

    updates = [
        UpdateItem(
            ID="1",
            requirement="requirement1",
            prediction="prediction",
            prediction_feedback="prediction_feedback",
        )
    ]

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.patch(
            f"/api/req-class/update_feedback/55153a8014829a865bbf700d",
            json=[update.dict() for update in updates],
        )
        assert response.detail == f"Column 'prediction' not found in file"
        assert response.status_code == 400


def test_get_project_by_id_success(client, mocker, mock_mongodb):
    """

    Args:
        client (_type_): _description_
        mocker (_type_): _description_
    """
    mock_project_collection = MagicMock()

    # Mock the find_one method to return a sample project
    mock_project_collection.find_one.return_value = {
        "_id": ObjectId("60d5f479f4b2b59b0f0298d6"),
        "name": "Sample Project",
        "description": "This is a sample project.",
    }
    # mocker.patch("src.utils.mongo_db.MongoDB.get_collection", return_value=mock_project_collection)
    mocker.patch(
        "src.controllers.requirement_classification_controller.get_project_by_id",
        return_value=mock_project_collection,
    )

    # Act

    response = client.get(
        "/api/req-class/getProject/60d5f479f4b2b59b0f0298d6",
    )

    # Assert
    assert response.status_code == 200
