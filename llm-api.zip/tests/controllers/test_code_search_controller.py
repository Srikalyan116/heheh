"""Test route.py."""

import io
import json
import os
import sys
from datetime import datetime, timezone
from io import BytesIO
from unittest.mock import MagicMock, call, patch

import pandas as pd
import pytest
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import BackgroundTasks, HTTPException, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.testclient import TestClient
from pymongo.collection import Collection

from src.utils.auth import jwt
from src.utils.utils_enum import TaskStatus

sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", ".."))
# Load environment variables
load_dotenv("tests/.env.testing")

# Mock data
task_id = "669e437604dbe10bb2db4636"
task_data = {
    "_id": ObjectId(task_id),
    "project_name": "testproject",
    "email": "test@example.com",
    "repo_url": "https://abc.com",
    "branch": "main",
    "repo_type": "azure",
    "branch_name": "codesearch",
    "status": "PROCESSING",
    "created_timestamp": datetime.now(timezone.utc),
    "lastupdated_timestamp": datetime.now(timezone.utc),
}


@pytest.fixture(autouse=True)
def client(mocker):
    """Fixture that provides a TestClient instance for testing.

    This fixture automatically initializes a TestClient for the `router`
    imported from `src.controllers.requirement_classification_controller`
    and yields it for use in tests.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.
        mock_blob_service_client (MagicMock): A mocked instance of `BlobServiceClient`.

    Yields:
        TestClient: A TestClient instance to interact with the application router.
    """
    from src.controllers.code_search_controller import routercodesearch

    with TestClient(routercodesearch) as client:
        yield client


@pytest.fixture
def mock_db(mocker):
    """Fixture to mock the MongoDB collection for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    mock_collection = MagicMock(Collection)
    mock_collection.find_one.return_value = task_data
    mocker.patch("src.utils.mongo_db.MongoDB.get_collection", return_value=mock_collection)
    return mock_collection


# Mock the MongoDB collection and return values
@pytest.fixture()
def mock_mongodb(mocker):
    """Fixture that mocks MongoDB collection methods for testing.

    This fixture mocks the `MongoDB.get_collection` method and returns
    a mock collection with a predefined return value for the `find_one` method.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    Returns:
        MagicMock: A mocked MongoDB collection with a predefined `find_one` return value.
    """
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    mock_collection = get_collection_mock.return_value
    mock_collection.find_one.return_value = task_data
    return mock_collection


def test_create_task_success(
    mocker,
    client,
    mock_mongodb,
):
    """Test case for successfully creating a task.

    This test case mocks the MongoDB collection, blob service client, background tasks,
    and file upload method to simulate the creation of a task. It verifies that the endpoint
    returns the correct status code and response format.
    """
    task = task_data
    valid_object_id = task["_id"]
    mock_mongodb.insert_one.return_value.inserted_id = valid_object_id
    mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    headers = {"Authorization": "Bearer kglkgkjdklj"}
    response = client.post(
        "/api/code-search/task/",
        data={
            "repo_url": "https://abc.com",
            "branch_name": "codesearch",
            "project_name": "testproject",
            "source_id": "source_id",
            "revision_id": "revision_id",
        },
        headers=headers,
    )
    print(response.content)  # Debugging
    assert response.status_code == 200
