"""Test cases for the codebeamer controller module."""

import json
import os
from datetime import datetime, timezone
from tempfile import NamedTemporaryFile
from unittest.mock import MagicMock, patch

import loguru
import pandas as pd
import pytest
from bson import ObjectId
from fastapi import HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.testclient import TestClient

from src.models.requirement_classification_feedbacktask import UpdateItem
from src.utils.auth import jwt


@pytest.fixture(autouse=True)
def client(mocker, mock_blob_service_client):
    """Fixture that provides a TestClient instance for testing.

    This fixture automatically initializes a TestClient for the `router`
    imported from `src.controllers.requirement_classification_controller`
    and yields it for use in tests.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.
        mock_blob_service_client (MagicMock): A mocked instance of `BlobServiceClient`.

    Yields:
        TestClient: A TestClient instance to interact with the application router.
    """
    from src.controllers.code_beamer_controller import router_code_beamer

    with TestClient(router_code_beamer) as client:
        yield client


# Mock the BlobServiceClient and Mongodb
@pytest.fixture(autouse=True)
def mock_blob_service_client(mocker):
    """Fixture that mocks the Azure BlobServiceClient for testing.

    This fixture mocks the `BlobServiceClient` class from `azure.storage.blob`
    and its methods, including `from_connection_string`, `get_blob_client`,
    `upload_blob`, and `download_blob`. It returns a mock blob client
    with predefined responses for testing purposes.

    Args:
        mocker (mocker.MockerFixture): The `mocker` fixture provided by pytest-mock.

    Returns:
        MagicMock: A mocked instance of the blob client with preconfigured methods.
    """
    mock_blobservice_client = mocker.patch("azure.storage.blob.BlobServiceClient")
    mock_blobservice_client.from_connection_string.return_value = MagicMock()
    mock_blob_client = mock_blobservice_client.from_connection_string.return_value
    mock_blob_client.get_blob_client.return_value = MagicMock()
    mock_blob_client.get_blob_client.return_value.upload_blob.return_value = None
    mock_blob_client.get_blob_client.return_value.download_blob.return_value = MagicMock()
    mock_download_blob = mock_blob_client.get_blob_client.return_value.download_blob.return_value
    mock_download_blob.readall.return_value = json.dumps({"key": "value"}).encode("utf-8")
    return mock_blob_client


@pytest.fixture(autouse=True)
def setenvvar(client):
    """Set Environment variables."""
    with patch.dict(
        os.environ,
        {
            "BLOB_CONNECT_STR": "test_connection_string",
            "BLOB_CONTAINER_NAME": "test_container_name",
        },
    ):
        yield


def test_get_projects_success(client, mocker):
    """Test the successful retrieval of projects from the API.

    This test verifies that the API endpoint `/api/req-class/projects` correctly
    returns a list of projects when a valid authorization header is provided.
    It mocks the `get_all_projects` function to return a predefined list of projects
    and checks that the response contains the correct project details and a 200 status code.

    Args:
        client: The test client used to make requests to the API.
        mocker: The mocker fixture used to patch and mock dependencies.
    """
    # Arrange
    projects = [{"id": 123, "name": "GenAI project"}]
    cb_utils_mock = mocker.patch("src.controllers.code_beamer_controller.get_all_projects")
    cb_utils_mock.return_value = projects
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    # Act
    response = client.get(
        "/api/code-beamer/projects",
        headers={"Authorization": "Bearer 123"},
    )

    # Assert
    output = json.loads(response.text)
    assert len(output) == 1
    assert output["projects"][0]["id"] == 123
    assert output["projects"][0]["name"] == "GenAI project"
    assert response.status_code == 200


def test_get_projects_invalid_header(client, mocker):
    """Test the API's response to an invalid or missing authorization header.

    This test checks that the API endpoint `/api/req-class/cb/projects` returns a
    500 status code when no authorization header is provided. It mocks the
    `get_all_projects` function but does not set the headers, ensuring the
    system correctly handles the absence of expected headers.

    Args:
        client: The test client used to make requests to the API.
        mocker: The mocker fixture used to patch and mock dependencies.
    """
    # Arrange
    projects = [{"id": 123, "name": "GenAI project"}]
    cb_utils_mock = mocker.patch("src.controllers.code_beamer_controller.get_all_projects")
    cb_utils_mock.return_value = projects

    # Act &Assert
    with pytest.raises(HTTPException):
        response = client.get(
            "/api/code-beamer/projects",
            # Missing headers on purpose
        )

        # Assert
        assert response.status_code == 500


#####################################
# Tests for the method get_trackers #
#####################################


def test_get_trackers_success(client, mocker):
    """Test the successful retrieval of trackers from the API.

    This test verifies that the API endpoint `/api/req-class/cb/trackers` correctly
    returns a list of trackers for a given project when a valid authorization header
    and project ID are provided. It mocks the `get_trackers_by_project_id` function
    to return a predefined list of trackers and checks that the response contains the
    correct tracker details and a 200 status code.

    Args:
        client: The test client used to make requests to the API.
        mocker: The mocker fixture used to patch and mock dependencies.
    """
    # Arrange
    trackers = [{"id": 123, "name": "GenAI Tracker"}]
    cb_utils_mock = mocker.patch(
        "src.controllers.code_beamer_controller.get_trackers_by_project_id"
    )
    cb_utils_mock.return_value = trackers

    # Act
    response = client.get(
        "/api/code-beamer/trackers",
        headers={"Authorization": "Bearer 123"},
        params={"project_id": "123"},
    )

    # Assert
    output = json.loads(response.text)
    assert len(output) == 1
    assert output["trackers"][0]["id"] == 123
    assert output["trackers"][0]["name"] == "GenAI Tracker"
    assert response.status_code == 200


def test_get_trackers_invalid_header(client, mocker):
    """Test the API's response to an invalid or missing authorization header when retrieving trackers.

    This test checks that the API endpoint `/api/req-class/cb/trackers` returns a
    500 status code when no authorization header is provided. It mocks the
    `get_trackers_by_project_id` function but does not set the headers, ensuring the
    system correctly handles the absence of expected headers.

    Args:
        client: The test client used to make requests to the API.
        mocker: The mocker fixture used to patch and mock dependencies.
    """
    # Arrange
    trackers = [{"id": 123, "name": "GenAI Tracker"}]
    mocker.patch(
        "src.controllers.code_beamer_controller.get_trackers_by_project_id", return_value=trackers
    )

    # Act & Assert
    with pytest.raises(HTTPException):
        response = client.get("/api/code-beamer/trackers", params={"project_id": 123})

        # Assert
        assert response.status_code == 500


@pytest.fixture(autouse=True)
def mock_env(mocker):
    """Fixture to mock environment variables for testing."""
    mocker.patch.dict(os.environ, {"codebeamer_url": "https://mockservice"})


@pytest.fixture
def mock_requests_get(mocker):
    """Fixture to mock the requests.get method for testing."""
    return mocker.patch("requests.request")


@pytest.fixture
def mock_requests_put(mocker):
    # This fixture will mock requests.put to simulate the behavior of the PUT request
    return mocker.patch("requests.put")


def tests_get_all_projects_success(mocker, client, mock_requests_get, mock_env):
    from src.controllers.code_beamer_controller import get_all_projects

    auth_token = "abcdedf"
    codebeamer_url = "https://mockservice"
    mock_response = mock_requests_get.return_value
    mock_response.status_code = 200
    mock_response.text = json.dumps(
        [{"project_id": 1, "name": "Test Project", "type": "refer"}]
    )  # Mock data

    # Act
    try:
        with patch("builtins.open", mocker.mock_open(read_data="data")):
            projects = get_all_projects(auth_token, codebeamer_url)

        # Assert that the projects are returned correctly
        assert len(projects) == 1
        assert projects[0]["project_id"] == 1
        assert projects[0]["name"] == "Test Project"

    except Exception as e:
        loguru.logger.info("Exception occurred:", e)
        pytest.fail(f"Test failed with exception: {e}")


def tests_get_trackers_by_project_id_success(mocker, client, mock_requests_get, mock_env):
    from src.controllers.code_beamer_controller import get_trackers_by_project_id

    auth_token = "abcdedf"
    project_id = "123"
    codebeamer_url = "https://mockservice"
    mock_response = mock_requests_get.return_value
    mock_response.status_code = 200
    mock_response.text = json.dumps(
        [
            {"id": 449, "name": "Input Requirements", "type": "TrackerReference"},
            {"id": 4543, "name": "Documents", "type": "TrackerReference"},
        ]
    )  # Mock data
    try:
        with patch("builtins.open", mocker.mock_open(read_data="data")):
            projects = get_trackers_by_project_id(auth_token, codebeamer_url, project_id)

        # Assert that the projects are returned correctly
        assert len(projects) == 2
        assert projects[0]["id"] == 449
        assert projects[0]["name"] == "Input Requirements"

    except Exception as e:
        loguru.logger.info("Exception occurred:", e)
        pytest.fail(f"Test failed with exception: {e}")


def tests_get_items_success(client, mocker):
    projects = [{"id": "123", "Description": "Design"}]
    cb_utils_mock = mocker.patch("src.controllers.code_beamer_controller.get_items_by_project")
    cb_utils_mock.return_value = projects
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    # Act
    response = client.get(
        "/api/code-beamer/items_by_project",
        headers={"Authorization": "Bearer 123"},
        params={"codebeamer_project": "AI", "codebeamer_tracker": "Design"},
    )
    output = json.loads(response.text)
    loguru.logger.info(output)
    assert len(output) == 1
    assert output[0]["id"] == "123"
    assert output[0]["Description"] == "Design"
    assert response.status_code == 200


def tests_get_items_by_project_success(client, mocker, mock_requests_get, mock_env):
    from src.controllers.code_beamer_controller import get_items_by_project

    auth_token = "abcdedf"
    codebeamer_url = "https://mockservice"
    codebeamer_project = "ai"
    codebeamer_tracker = "genai"
    mock_response = mock_requests_get.return_value
    mock_response.status_code = 200
    mock_response_first_page = mock_requests_get.return_value
    mock_response_first_page.status_code = 200
    mock_response_first_page.text = json.dumps(
        {
            "items": [{"project": "ai", "tracker": "genai"}],
            "totalCount": 5,  # Assume there are more items in the pagination
        }
    )

    # Second response has no items, ending pagination
    mock_response_second_page = mocker.MagicMock()
    mock_response_second_page.status_code = 200
    mock_response_second_page.text = json.dumps({"items": [], "totalCount": 5})

    # Setup the mock requests to return the first page first, then the second page
    mock_requests_get.side_effect = [mock_response_first_page, mock_response_second_page]

    try:
        with patch("builtins.open", mocker.mock_open(read_data="data")):
            items = get_items_by_project(
                auth_token, codebeamer_url, codebeamer_project, codebeamer_tracker
            )

        assert len(items) == 1  # Check that 1 item is returned
        assert items[0]["project"] == "ai"  # Ensure the correct project is returned
        assert items[0]["tracker"] == "genai"  # Ensure the correct tracker is returned

    except Exception as e:
        print("Exception occurred:", e)
        pytest.fail(f"Test failed with exception: {e}")


@pytest.fixture
def mock_mongo_collection():
    """Fixture to mock the MongoDB collection for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    with patch("src.utils.mongo_db.MongoDB.get_collection") as mock_get_collection:
        mock_collection = MagicMock()
        mock_get_collection.return_value = mock_collection
        yield mock_collection


@pytest.fixture
def mock_mongo_db_initialization(mocker):
    """Mock the MongoDB initialization to prevent actual database connection during tests."""
    mock_initialize = mocker.patch.object(MongoDB, "initialize", return_value=None)
    return mock_initialize


@pytest.fixture
def mock_read_excel():
    """Fixture to mock the pandas.read_excel function for testing.

    This fixture uses the mocker to patch the read_excel method from pandas,
    providing a mock implementation to be used in tests.
    """
    with patch("pandas.read_excel") as mock_read_excel:
        yield mock_read_excel


task_id = "669e437604dbe10bb2db4636"
from src.utils.utils_enum import TaskStatus

task = {
    "_id": ObjectId(task_id),
    "status": TaskStatus.SUCCESS.value,
    # "output_filename": "output_file.txt",
    "filename": "output_file.xlsx",
    "user_id": "123",
}
task_data = {
    "_id": ObjectId(task_id),
    "user_id": "123",
    "project": "test_project",
    "filename": "test_file.xlsx",
    "status": "success",
    "created_timestamp": "01/01/2024",
    "lastupdated_timestamp": "01/01/2024",
    "prediction_col_name": "req",
    "request_type": "DOORS",
    "tracker": "",
    "status_error_message": "",
    "code_beamer_error_message": "",
    "code_beamer_status": "",
}

from pymongo.collection import Collection


@pytest.fixture
def mock_mongodb(client, mocker):
    """Fixture to mock the MongoDB get_collection method for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    mock_collection = get_collection_mock.return_value
    mock_collection.find_one.return_value = task
    # mock_collection.find_one_and_delete.return_value = {"_id": ObjectId(task_id)}
    return mock_collection


@pytest.fixture
def mock_db(mocker):
    """Fixture to mock the MongoDB collection for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    mock_collection = MagicMock(Collection)
    mock_collection.find_one.return_value = task_data
    mocker.patch("src.utils.mongo_db.MongoDB.get_collection", return_value=mock_collection)
    return mock_collection


def test_bulk_update_items_success(client, mocker):
    """Test the case where the bulk update operation succeeds."""
    mock_task_collection = MagicMock()
    mock_task_collection.find_one.return_value = {"_id": "", "filename": "test_file.xlsx"}

    # Mock the DataFrame to simulate the Excel content
    df = pd.DataFrame({"ID": [1, 2], "prediction": ["information", "requirement"]})

    # Mock MongoDB to return the mocked task collection
    mocker.patch(
        "src.controllers.code_beamer_controller.MongoDB.get_collection",
        return_value=mock_task_collection,
    )

    # Mock pandas read_excel to return the mocked DataFrame
    mocker.patch("pandas.read_excel", return_value=df)
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    # Mock the requests.request to simulate a successful PUT request
    mock_requests_put = mocker.patch("requests.request")
    mock_requests_put.return_value.status_code = 200
    mock_requests_put.return_value.json.return_value = {"successfulOperationsCount": 2}

    # Mocking JWT decode function
    # setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    # Call the PUT request via the FastAPI test client
    response = client.put(
        "/api/code-beamer/update_items",
        headers={"Authorization": "Bearer 123"},
        params={"task_id": task_id},
    )

    # Assertions to check the response
    assert response.status_code == 200
    response_json = response.json()
    assert response_json["status"] == "success"
    assert response_json["successfulOperationsCount"] == 2
