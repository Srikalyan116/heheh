"""Test cases for the test case generation controller module."""

import io
import json
import os
import sys
from datetime import datetime, timezone
from io import BytesIO
from unittest.mock import AsyncMock, MagicMock, patch

import loguru
import pandas as pd
import pytest
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import HTTPException, UploadFile
from fastapi.testclient import TestClient
from pymongo.collection import Collection

from src.utils.auth import jwt
from src.utils.utils_enum import TaskStatus

sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), "..", ".."))
# Load environment variables
load_dotenv("tests/.env.testing")

# Mock data
project_id = "66dfd16740696f248756c199"

task_id = "66f3b8950ba739815e003bdc"


task = {
    "_id": ObjectId(task_id),
    "status": TaskStatus.SUCCESS.value,
    "output_filename": "output_file.xlsx",
}


@pytest.fixture(autouse=True)
def client(mocker, blobserviceclient):
    """Fixture to create a FastAPI TestClient for the application.

    This fixture sets up the FastAPI application with the necessary routes and
    provides a TestClient instance that can be used in tests.
    """
    from src.controllers.case_test_generation_controller import routertestcase

    # mock_blobservice_client.stop()
    with TestClient(routertestcase) as client:
        yield client


@pytest.fixture(autouse=True)
def setenvvar(client):
    """Set Environment variables."""
    with patch.dict(
        os.environ,
        {
            "BLOB_CONNECT_STR": "test_connection_string",
            "BLOB_CONTAINER_NAME": "test_container_name",
        },
    ):
        yield  # This is the magical bit which restore the environment after


@pytest.fixture(autouse=True)
def mock_env(client, mocker):
    """Fixture to mock environment variables for testing.

    This fixture uses the mocker to mock the environment variables
    needed for the tests to ensure they run with the expected configuration.
    """
    mocker.patch.dict(os.environ, {"TEST_CASE_GENERATION_URL": "http://mockservice"})
    mocker.patch(
        # "src.controllers.requirement_comparision_tracer_controller.requirement_comparison_tracer_config",
        "src.controllers.case_test_generation_controller.test_case_generation_config",
        {"collection_name": "mock_collection"},
    )


@pytest.fixture
def mock_db(mocker):
    """Fixture to mock the MongoDB collection for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    mock_collection = MagicMock(Collection)
    task_data = tasks_list  # check this
    mock_collection.find_one.return_value = task_data
    mocker.patch("src.utils.mongo_db.MongoDB.get_collection", return_value=mock_collection)
    return mock_collection


@pytest.fixture
def mock_requests(client, mocker):
    """Fixture to mock the requests.post method for testing.

    This fixture uses the mocker to patch the requests.post method,
    providing a mock implementation to be used in tests.
    """
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = json.dumps([{"ID": 1, "Comparison": "match"}])
    return mocker.patch("requests.post", return_value=mock_response)


@pytest.fixture
def mock_os_operations(client, mocker):
    """Fixture to mock os operations for testing.

    This fixture uses the mocker to patch the os.remove and os.path.exists functions,
    providing mock implementations to be used in tests.
    """
    mocker.patch("os.path.exists", return_value=True)
    mocker.patch("os.remove")


@pytest.fixture
def mock_requests_post(client, mocker):
    """Fixture to mock the requests.post method for testing.

    This fixture uses the mocker to patch the requests.post method,
    providing a mock implementation to be used in tests.
    """
    return mocker.patch("requests.post")


@pytest.fixture
def mock_mongodb(client, mocker):
    """Fixture to mock the MongoDB get_collection method for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    get_collection_mock = mocker.patch("src.utils.mongo_db.MongoDB.get_collection")
    mock_collection = get_collection_mock.return_value
    mock_collection.find_one.return_value = task
    # mock_collection.find_one_and_delete.return_value = {"_id": ObjectId(task_id)}
    return mock_collection


@pytest.fixture
def mock_mongo_collection():
    """Fixture to mock the MongoDB collection for testing.

    This fixture uses the mocker to patch the get_collection method of the MongoDB class,
    providing a mock collection to be used in tests.
    """
    with patch("src.utils.mongo_db.MongoDB.get_collection") as mock_get_collection:
        mock_collection = MagicMock()
        mock_get_collection.return_value = mock_collection
        yield mock_collection


@pytest.fixture()
def blobserviceclient(mocker):
    """Create and return a BlobServiceClient instance.

    This function initializes a BlobServiceClient, which can be used to interact
    with Azure Blob Storage. It handles authentication and sets up the necessary
    configurations for accessing the storage account.

    Returns:
        BlobServiceClient: An instance of BlobServiceClient configured for
        the specified storage account.
    """
    mock_blobservice_client = mocker.patch("azure.storage.blob.BlobServiceClient")
    mock_blobservice_client.from_connection_string.return_value = MagicMock()
    mock_blob_client = mock_blobservice_client.from_connection_string.return_value
    mock_blob_client.get_blob_client.return_value = MagicMock()
    # Prepare mock data
    tasks_list = [
        {
            "task_id": ObjectId(task_id),
            "task_name": "vid",
            "agent_id": "diva",
            "email": "abc.com",
            "project_name": "backendmeetingdemo",
            "did_requirement_file": "DID_Req_ID_Text_short.xlsx",
            "req_text_col": "Text",
            "req_id_col": "RequirementID",
            "test_case_generation_status": "SUCCESS",
            "created_timestamp": datetime.now(timezone.utc).replace(tzinfo=None),
            "lastupdated_timestamp": datetime.now(timezone.utc).replace(tzinfo=None),
            "test_case_generation_output_file_name": "test_case_generation_response.xlsx",
            "project_id": "66dfd16740696f248756c199",
            "test_case_generation_output_filename": "test_case_generation_response.xlsx",
            "test_procedure_generation_status": "SUCCESS",
            "test_procedure_generation_output_filename": "test_procedure_generation_response.xlsx",
            "status_error_message": "",
        }
    ]
    df = pd.DataFrame(tasks_list)
    excel_buffer = io.BytesIO()
    df.to_excel(excel_buffer, index=False, engine="openpyxl")
    excel_buffer.seek(0)

    mock_blob_client.get_blob_client.return_value.download_blob.return_value.readall.return_value = (
        excel_buffer.read()
    )
    return mock_blob_client


@pytest.fixture
def valid_project_data():
    """Test case for valid project data."""
    return {
        "project_name": "Test Project",
        "agent_id": "agent123",
        "services_sheet_name": "services_sheet",
        "services_sheet_top_header_rows": 1,
        "did_sheet_name": "did_sheet",
        "did_sheet_top_header_rows": 1,
        "did_col_num": "A",
        "dtc_sheet_name": "dtc_sheet",
        "dtc_sheet_top_header_rows": 1,
        "dtc_col_num": "B",
        "control_routine_sheet_name": "control_routine",
        "control_routine_sheet_top_header_rows": 1,
        "control_routine_col_num": "A",
        "status_error_message": "",
    }


def test_find_all_tasks_uninitialized_db(client):
    """_summary_."""
    # Missing Arrange setup is intentional
    # To trigger a 500 response

    # Assert
    with pytest.raises(HTTPException):
        response = client.get(
            "/api/test-case-generation/tasks/",
            params={"page": 1, "page_size": 10, "project_id": 1234},
        )
        assert response.status_code == 500


tasks_list = [
    {
        "_id": "668fdcb5d648cf8036423be2",
        "task_name": "vid",
        "agent_id": "123",
        "email": "abc.com",
        "project_name": "backendmeetingdemo",
        "did_requirement_file": "DID_Req_ID_Text_short.xlsx",
        "req_text_col": "Text",
        "req_id_col": "RequirementID",
        "test_case_generation_status": "SUCCESS",
        "created_timestamp": "2024-07-11T13:23:01.242+00:00",
        "lastupdated_timestamp": "2024-07-11T13:23:47.260+00:00",
        "test_case_generation_output_file_name": "test_case_generation_response.xlsx",
        "project_id": "66dfd16740696f248756c199",
        "test_case_generation_output_filename": "test_case_generation_response.xlsx",
        "test_procedure_generation_status": "SUCCESS",
        "test_procedure_generation_output_filename": "test_procedure_generation_response.xlsx",
        "status_error_message": "error found",
        # "template_test_case": "Sample template test case"
    }
]


def test_find_all_tasks_success(mock_env, client, mock_mongo_collection):
    """Test case for successfully retrieving a list of tasks with pagination.

    This test case mocks the MongoDB collection to return a predefined list of tasks
    and verifies that the endpoint returns the correct status code and response format.
    """
    mock_mongo_collection.find.return_value.sort.return_value.skip.return_value.limit.return_value = (
        tasks_list
    )
    mock_mongo_collection.count_documents.return_value = len(tasks_list)
    setattr(jwt, "get_unverified_header", MagicMock)
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    valid_project_id = project_id
    response = client.get(
        "/api/test-case-generation/tasks",
        headers={"Authorization": "Bearer kglkgkjdklj"},
        params={"page": 1, "page_size": 2, "project_id": valid_project_id},
    )
    assert response.status_code == 200
    # Ensure the _id is serialized to string
    expected_tasks_list = [
        {
            "task_name": task["task_name"],
            "task_id": str(task["_id"]),
            "agent_id": "123",
            "email": task["email"],
            "project_name": task["project_name"],
            "did_requirement_file": task["did_requirement_file"],
            "req_text_col": task["req_text_col"],
            "req_id_col": task["req_id_col"],
            "project_id": task["project_id"],
            "created_timestamp": task["created_timestamp"],
            "lastupdated_timestamp": task["lastupdated_timestamp"],
            "test_case_generation_status": task["test_case_generation_status"],
            "test_case_generation_output_file_name": task["test_case_generation_output_file_name"],
            "test_procedure_generation_status": task["test_procedure_generation_status"],
            "test_procedure_generation_output_filename": task[
                "test_procedure_generation_output_filename"
            ],
            "status_error_message": task["status_error_message"],
            # "template_test_case": task.get("template_test_case", None),
        }
        for task in tasks_list
    ]
    assert response.json() == {"Tasks": expected_tasks_list, "total_count": len(tasks_list)}


def test_find_all_projects_uninitialized_db(client):
    """_summary_."""
    # Missing Arrange setup is intentional
    # To trigger a 500 response

    # Assert
    with pytest.raises(HTTPException):
        response = client.get(
            "/api/test-case-generation/", params={"page": 1, "page_size": 10, "agent_id": 1234}
        )
        assert response.status_code == 500


project_list = [
    {
        "_id": "668fdcb5d648cf8036423be2",
        "agent_id": "123",
        "email": "abc.com",
        "project_name": "backenddemo",
        "project_description": "List",
        "services_sheet_name": "Service",
        "services_sheet_top_header_rows": 2,
        "did_sheet_name": "DID",
        "did_sheet_top_header_rows": 2,
        "did_col_num": "A",
        "dtc_sheet_name": "DTC",
        "dtc_sheet_top_header_rows": 3,
        "dtc_col_num": "B",
        "control_routine_sheet_name": "Control Routine Impl",
        "control_routine_sheet_top_header_rows": 2,
        "control_routine_col_num": 0,
        "created_timestamp": "2024-07-11T13:23:01.242+00:00",
        "project_requirement_file": "PSCM Power Steering Control Module (VDS) A (E4u5).xlsx",
        "status_error_message": "",
    }
]


def test_find_all_projects_success(mock_env, client, mock_mongo_collection):
    """Test case for successfully retrieving a list of tasks with pagination.

    This test case mocks the MongoDB collection to return a predefined list of tasks
    and verifies that the endpoint returns the correct status code and response format.
    """
    mock_mongo_collection.find.return_value.sort.return_value.skip.return_value.limit.return_value = (
        tasks_list
    )
    mock_mongo_collection.count_documents.return_value = len(tasks_list)
    setattr(jwt, "get_unverified_header", MagicMock)
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))

    response = client.get(
        "/api/test-case-generation/",
        headers={"Authorization": "Bearer kglkgkjdklj"},
        params={"page": 1, "page_size": 2, "agent_id": 1234},
    )
    assert response.status_code == 200
    # Ensure the _id is serialized to string
    expected_projects_list = [
        {
            "project_id": str(task["_id"]),
            "agent_id": "123",
            "email": task["email"],
            "project_name": task["project_name"],
            "project_description": task["project_description"],
            "services_sheet_name": task["services_sheet_name"],
            "services_sheet_top_header_rows": task["services_sheet_top_header_rows"],
            "did_sheet_name ": task["did_sheet_name"],
            "did_sheet_top_header_rows": task["did_sheet_top_header_rows"],
            "did_col_num": task["did_col_num"],
            "dtc_sheet_name": task["dtc_sheet_name"],
            "dtc_sheet_top_header_rows": task["dtc_sheet_top_header_rows"],
            "dtc_col_num": task["dtc_col_num"],
            "control_routine_sheet_name": task["control_routine_sheet_name"],
            "control_routine_sheet_top_header_rows": task["control_routine_sheet_top_header_rows"],
            "control_routine_col_num": task["control_routine_col_num"],
            "created_timestamp": task["created_timestamp"],
            "project_requirement_file": task["project_requirement_file"],
            "status_error_message": task["status_error_message"],
        }
        for task in project_list
    ]
    # assert response.json() == {"projects": expected_projects_list, "total_count": len(project_list)}
    # assert response.json() == {"Tasks": expected_tasks_list, "total_count": len(tasks_list)}


@pytest.fixture
def mock_upload_file(client):
    """Fixture to mock the file upload function for testing.

    This fixture uses the mocker to patch the upload_file method,
    providing a mock implementation to be used in tests.
    """
    with patch("src.controllers.case_test_generation_controller.UploadFile") as mock_file:
        yield mock_file


@pytest.fixture
def mock_read_excel():
    """Fixture to mock the pandas.read_excel function for testing.

    This fixture uses the mocker to patch the read_excel method from pandas,
    providing a mock implementation to be used in tests.
    """
    with patch("pandas.read_excel") as mock_read_excel:
        yield mock_read_excel


@pytest.fixture
def mock_excel_file():
    """Simulate a valid Excel file in bytes."""
    # Create a BytesIO object to mock an Excel file
    excel_content = BytesIO()

    # Use openpyxl or similar library to write some valid Excel content
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    wb.save(excel_content)
    excel_content.seek(0)  # Reset pointer to the beginning
    excel_content.name = "test.xlsx"
    return excel_content


def test_get_columns_excel_success(client, mock_upload_file, mock_read_excel):
    """Test case for successfully retrieving columns from an Excel file.

    This test case mocks the pandas.read_excel method to return a predefined DataFrame
    and verifies that the endpoint returns the correct status code and response format.
    """
    file = MagicMock(spec=UploadFile)
    file.filename = "test.xlsx"
    file.read.return_value = b"file_content"
    mock_upload_file.return_value = file
    # mock_read_excel.return_value = pd.DataFrame(columns=["col1", "col2", "col3"])
    mock_read_excel.return_value = pd.DataFrame(
        {"col1": [1], "col2": [2], "col3": [3]}  # At least one non-empty row
    )
    # response = client.post("/api/requirement-comp-tracer/filecolumns", files={"test.xlsx": ("filename", b"file_content", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})
    response = client.post(
        "/api/test-case-generation/filecolumns/",
        files={
            "file": (
                "test.xlsx",
                b"file_content",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        },
    )
    loguru.logger.info(response.content)
    assert response.status_code == 200
    assert response.json() == {"columns": ["col1", "col2", "col3"]}


def test_delete_task_success(mock_env, client, mock_mongodb):
    """Test case for successfully deleting a task.

    This test case mocks the MongoDB collection to simulate the deletion of a task.
    It verifies that the endpoint returns the correct status code when a task is successfully deleted.
    """
    # Set up the mock to return a deleted task
    mock_mongodb.find_one_and_delete.return_value = {"_id": ObjectId(task_id)}
    response = client.delete(f"/api/test-case-generation/tasks/{task_id}", params={"id": task_id})
    assert response.status_code == 200


def test_delete_task_exception(mock_env, client, mock_mongodb):
    """Test case for handling exceptions during task deletion.

    This test case mocks the MongoDB collection to simulate an exception
    when trying to delete a task. It verifies that the endpoint handles
    the exception correctly and returns the appropriate status code.
    """
    mock_mongodb.find_one_and_delete.side_effect = Exception("Mocked exception")
    with pytest.raises(HTTPException):
        response = client.delete(
            f"/api/test-case-generation/tasks/{task_id}", params={"id": task_id}
        )
        assert response.status_code == 500
        assert "Mocked exception" in response.json()["detail"]


def test_create_test_case_generation_task_success(mock_env, mocker, client, mock_mongodb):
    """Test case for successfully creating a test case generation task.

    This test case mocks the MongoDB collection to simulate the creation of a task.
    It verifies that the endpoint returns the correct status code and response format
    when a task is successfully created.
    """
    task = tasks_list[0]
    valid_object_id = task["_id"]
    mock_mongodb.insert_one.return_value.inserted_id = valid_object_id
    mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")
    setattr(jwt, "get_unverified_header", MagicMock())
    setattr(jwt, "decode", MagicMock(return_value={"name": "abc", "unique_name": "abc@zf.com"}))
    headers = {"Authorization": "Bearer kglkgkjdklj"}
    response = client.post(
        "/api/test-case-generation/create_test_case_generation/",
        data={
            "rule_id": task_id,
            "agent_id": task_id,
            "task_name": "test_task",
            "project_id": "66dfd16740696f248756c199",
            "project_name": "test_project",
            "source_col_name": "source_col",
            "req_text_col": "req_text_col",
            "req_id_col": "req_id_col",
        },
        files={
            "did_requirement_file": (
                "revision.xlsx",
                b"revision file content",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ),
        },
        headers=headers,
    )
    loguru.logger.info(response.content)  # Debugging
    assert response.status_code == 200


# Helper function to simulate file upload
def create_test_file(filename, content):
    """Create a test file."""
    with open(filename, "w") as f:
        f.write(content)
    return open(filename, "rb")


def test_get_sheet_names_excel_success(client, mock_excel_file, mock_read_excel):
    """Test the successful retrieval of sheet names."""
    # Mocking pandas.read_excel and the sheet names returned
    mock_read_excel.return_value.sheet_names = ["Sheet1", "Sheet2"]

    # Mock file upload
    response = client.post(
        "/api/test-case-generation/sheetnames/",
        files={
            "file": (
                "test.xlsx",
                mock_excel_file,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        },
    )

    # Assert response for Excel file
    assert response.status_code == 200
    # assert response.json() == {"sheet_names": ["Sheet1", "Sheet2"]}


def test_get_all_project_names_success(client, mock_mongo_collection):
    """Test the successful retrieval of project names."""
    # Mock the MongoDB collection find method to return a cursor with mock project names
    mock_project_names = [{"project_name": "Project A"}, {"project_name": "Project B"}]
    mock_collection = MagicMock()
    mock_collection.find.return_value = mock_project_names

    # Apply the mock to the MongoDB collection
    mock_mongo_collection.return_value = mock_collection

    # Send GET request to the endpoint
    response = client.get("/api/test-case-generation/projects_names/")

    # Assert the response is successful and returns the correct project names
    assert response.status_code == 200
    # assert response.json() == ["Project A", "Project B"]


def test_create_test_case_procedure_success(client, mocker, mock_mongo_collection):
    """Test successful case creation and execution of the background task."""
    # Mock MongoDB collection and methods
    mock_project_collection = MagicMock()
    mock_task_collection = MagicMock()
    mocker.patch("os.getenv", return_value="http://mock-service-url.com")
    mocker.patch("fastapi.BackgroundTasks.add_task", return_value="")

    # Mock the find_one and update_one behavior
    mock_project_collection.find_one.return_value = {
        "_id": "60b8d6c4c2e1f4a0c5dff5c8",
        "project_name": "Test Project",
    }
    mock_task_collection.find_one.return_value = {
        "_id": "60b8d6c4c2e1f4a0c5dff5c9",
        "task_name": "Test Task",
    }

    # Simulate successful update operation
    mock_task_collection.update_one.return_value = None

    # Mock the collections to be returned by get_collection
    mock_mongo_collection.side_effect = [mock_project_collection, mock_task_collection]

    # Define form data
    form_data = {
        "task_id": "60b8d6c4c2e1f4a0c5dff5c9",
        "project_id": "60b8d6c4c2e1f4a0c5dff5c8",
        "important_dids": ["DID_001", "DID_002"],
    }

    # Perform the POST request to the endpoint
    response = client.post("/api/test-case-generation/create_test_procedure/", data=form_data)

    # Assert that the response is successful
    assert response.status_code == 200
    # assert response.json()["message"] == "Test case procedure is in progress, please come back after some time."

    # Assert that the background task was added
    # mock_background_tasks.assert_called_once()


def test_download_test_case_success(client, mock_mongo_collection, blobserviceclient):
    """Test successful file download."""
    # Mock MongoDB collection and methods
    mock_task_collection = MagicMock()
    mock_task_collection.find_one.return_value = {
        "_id": "60b8d6c4c2e1f4a0c5dff5c9",
        "test_case_generation_status": "SUCCESS",
        "test_case_generation_output_file_name": "output_file.xlsx",
    }
    mock_mongo_collection.return_value = mock_task_collection

    # Mock the blob client and download_blob
    mock_blob_client = MagicMock()
    blobserviceclient.return_value = mock_blob_client
    mock_blob_client.download_blob.return_value.readall.return_value = b"Test file content"

    # Perform GET request to the endpoint
    response = client.get("/api/test-case-generation/download_test_case/60b8d6c4c2e1f4a0c5dff5c9")

    # Assert the response is successful and the file content is correct
    assert response.status_code == 200
    # assert response.content == b"Test file content"
    # assert response.headers["Content-Disposition"] == "attachment;filename=output_file.txt"


def test_download_test_procedure_success(client, mock_mongo_collection, blobserviceclient):
    """Test successful file download."""
    # Mock MongoDB collection and methods
    mock_task_collection = MagicMock()
    mock_task_collection.find_one.return_value = {
        "_id": "60b8d6c4c2e1f4a0c5dff5c9",
        "test_procedure_generation_status": "SUCCESS",
        "test_procedure_generation_output_filename": "output_file.xlsx",
    }
    mock_mongo_collection.return_value = mock_task_collection

    # Mock the blob client and download_blob
    mock_blob_client = MagicMock()
    blobserviceclient.return_value = mock_blob_client
    mock_blob_client.download_blob.return_value.readall.return_value = b"Test file content"

    # Perform GET request to the endpoint
    response = client.get(
        "/api/test-case-generation/download_test_procedure/60b8d6c4c2e1f4a0c5dff5c9"
    )

    # Assert the response is successful and the file content is correct
    assert response.status_code == 200
    # assert response.content == b"Test file content"
    # assert response.headers["Content-Disposition"] == "attachment; filename=output_file.txt"


def test_delete_project_success(client, mock_mongo_collection):
    """Test successful deletion of a project."""
    # Mock MongoDB collection and methods
    mock_project_collection = MagicMock()
    mock_project_collection.find_one_and_delete.return_value = {"_id": "60b8d6c4c2e1f4a0c5dff5c9"}
    mock_mongo_collection.return_value = mock_project_collection

    # Perform DELETE request to the endpoint
    response = client.delete(
        "/api/test-case-generation/projects/60b8d6c4c2e1f4a0c5dff5c9?id=60b8d6c4c2e1f4a0c5dff5c9"
    )

    # Assert the response is successful
    assert response.status_code == 200
