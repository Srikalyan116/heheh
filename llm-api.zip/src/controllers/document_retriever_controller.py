"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import io
import json
import logging
import os
from datetime import datetime, timedelta, timezone
from io import BytesIO
from typing import List, Optional

import numpy as np
import pandas as pd
import requests
from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.blob import BlobSasPermissions, BlobServiceClient, generate_blob_sas
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
)
from fastapi.responses import JSONResponse
from pymongo import DESCENDING

from src.config.config import document_retriever_config
from src.utils.auth import AuthValidation
from src.utils.doc_retriever_helper import (
    get_project_by_user_id,
    postprocess_result_file,
    preprocess_input_file,
)
from src.utils.doc_retriever_schema import (
    list_serial_project,
    list_serial_task,
    transform_data,
)
from src.utils.mongo_db import MongoDB
from src.utils.utils_enum import (
    FileType,
    RequestType,
    SearchType,
    TaskStatus,
    TaskTypes,
)
from src.utils.common.azure_helper import blob_service_client
load_dotenv()

router = APIRouter(prefix="/api/doc-finder", dependencies=[Depends(AuthValidation().wrapper)], tags=["Document Finder"])


container_name = os.getenv("BLOB_CONTAINER_NAME")



#@router.get("/tasks")
async def get_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all the tasks submitted by all users.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    try:
        collection_name = document_retriever_config.get("task_collection_name")
        collection = MongoDB.get_collection(collection_name)
        query = {"user_id": email}
        if search:
            search_regex = {"$regex": search, "$options": "i"}  # Case-insensitive partial match
            query["$or"] = [
                {"project": search_regex},
                {"request_type": search_regex},
                {"filename": search_regex},
                {"status": search_regex},
            ]
        if agent_id:
            query["agent_id"] = agent_id  # Only add agent_id to query if it is provided
        skip = (page - 1) * page_size
        todos = list_serial_task(
            collection.find(query).sort("created_timestamp", DESCENDING).skip(skip).limit(page_size)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")
    # total_count = collection.count_documents({})
    total_count = collection.count_documents(query)
    return {"Tasks": todos, "total_count": total_count}


#@router.get("/projects")
async def get_all_projects(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    agent_id: Optional[str] = Query(
        None, description="Optional ID of the agent to filter projects"
    ),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all the projects created by all the users.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved project metadata and the total count of tasks.
            - projects (list): a list of all the projects.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]
    try:
        query = {"admin.id": email}
        if agent_id:
            query["agent_id"] = agent_id  # Filter by agent_id if it is provided
        collection_name = document_retriever_config.get("project_manage_collection_name")
        collection = MongoDB.get_collection(collection_name)
        skip = (page - 1) * page_size
        projects = list_serial_project(
            collection.find(query).sort("create_timestamp", DESCENDING).skip(skip).limit(page_size)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
    total_count = collection.count_documents(query)
    return {"Projects": projects, "total_count": total_count}


#@router.get("/tasks/{field}/{value}")
async def get_tasks_by_field(
    field: str,
    value: str,
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Fetches tasks by a specific field and value.

    Args:
        field (str): The field to filter by.
        value (str): The value to filter for in the specified field.
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0

    Raises:
        HTTPException: If the field is not valid or no tasks are found.

    Returns:
        dict: A dictionary of tasks that match the criteria.
    """
    email = user_details["email"]
    query = {"user_id": email}
    collection_name = document_retriever_config.get("task_collection_name")
    collection = MongoDB.get_collection(collection_name)
    query[field] = value
    if agent_id:
        query["agent_id"] = agent_id
    valid_fields = {
        "user_id",
        "agent_id",
        "status",
        "created_timestamp",
        "lastupdated_timestamp",
        "project",
        "tracker",
        "task_name",
        "id",
    }

    if field not in valid_fields:
        logging.error(f"Invalid field: {field}")
        raise HTTPException(status_code=400, detail="Field not found in the model")

    try:
        collection_name = document_retriever_config.get("task_collection_name")
        collection = MongoDB.get_collection(collection_name)
        skip = (page - 1) * page_size
        if field == "id":
            tasks = list_serial_task(
                collection.find({"_id": ObjectId(value)})
                .sort("created_timestamp", DESCENDING)
                .skip(skip)
                .limit(page_size)
            )
        else:
            tasks = list_serial_task(
                collection.find(query)
                .sort("created_timestamp", DESCENDING)
                .skip(skip)
                .limit(page_size)
            )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
    total_count = collection.count_documents(query)
    return {"Tasks": tasks, "total_count": total_count}


#@router.post("/filecolumns")
async def get_columns(file: UploadFile = File(...)):
    """Retrieves the column names from the uploaded file.

    Args:
        file (UploadFile): The file from which to extract column names.

    Raises:
        HTTPException: 400 Bad Request if the file is not a valid format.

    Returns:
        dict: A dictionary containing the column names.
            - columns (list): A list of column names.
    """
    file_extension = os.path.splitext(file.filename)[1]
    if file_extension == FileType.EXCEL.value:
        df = pd.read_excel(BytesIO(await file.read()))
    elif file_extension == FileType.CSV.value:
        df = pd.read_csv(BytesIO(await file.read()))
    else:
        raise HTTPException(status_code=400, detail="Unsupported file format")

    # Check if there are non-empty rows below the header
    if df.dropna(how="all", axis=0).empty:
        raise HTTPException(status_code=400, detail="The rows below the headers are empty.")

    # Drop columns that are completely empty
    df = df.dropna(how="all", axis=1)
    # id unamed 2
    columns = df.columns.tolist()
    # Check for 'Unnamed' columns that might be generated if headers are not properly provided
    if any("Unnamed" in col for col in columns):
        raise HTTPException(
            status_code=400,
            detail="Please review the headers and provide appropriate column names.",
        )

    return {"columns": columns}


#@router.post("/task/search/upload_file")
def task_upload_file_search(
    background_tasks: BackgroundTasks,
    user_details: dict = Depends(AuthValidation().wrapper),
    agent_id=Form(...),
    description_col_name: str = Form(...),
    id_col_name: str = Form(...),
    project_name: str = Form(),
    file: UploadFile = File(...),
):
    """Creates a new task for searching and uploads the file to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): Background tasks for processing after request return.
        prediction_col_name (str): The column name to be used for prediction.
        project (str): Project name associated with the task.
        email (str): Email address of the user.
        file (UploadFile): The file to be processed.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    file_extension = os.path.splitext(file.filename)[-1]
    if file_extension not in {file_type.value for file_type in FileType}:
        raise HTTPException(status_code=400, detail="Unsupported file type")

    task_data = {
        "user_id": user_details["email"],
        "agent_id": agent_id,
        "project": project_name,
        "filename": file.filename,  # None
        "task_name": TaskTypes.SEARCH.value,
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "tracker": None,
        "description_col_name": description_col_name,
        "id_col_name": id_col_name,
        "search_type": SearchType.FILE_UPLOAD.value,
        "request_type": RequestType.MANUAL.value,
    }
    collection_name = document_retriever_config.get("task_collection_name")
    collection = MongoDB.get_collection(collection_name)
    result = collection.insert_one(task_data)
    task_id = str(result.inserted_id)
    blob_path = f"doc_retriever/tasks/{user_details['email']}/{task_id}/{file.filename}"
    try:
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
        # file_contents = file.file.read()  # Read file asynchronously
        file_contents = preprocess_input_file(file, id_col_name)
        blob_client.upload_blob(
            file_contents.getvalue(), overwrite=True
        )  # Upload file asynchronously
    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "upload_status": "FAILED",
                    "status_error_message": "Failed to upload file",
                    "lastupdated_timestamp": datetime.now(timezone.utc),
                }
            },
        )
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

    background_tasks.add_task(search_data, task_id)
    return {"task_id": task_id}


#@router.post("/task/search/text")
def create_task_for_text(
    background_tasks: BackgroundTasks,
    user_details: dict = Depends(AuthValidation().wrapper),
    project_name: str = Form(),
    agent_id=Form(...),
    requirement: str = Form(),
):
    """Creates a new task for text search and uploads the data to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): Background tasks for processing after request return.
        prediction_col_name (str): The column name to be used for prediction.
        project (str): Project name associated with the task.
        email (str): Email address of the user.
        file (UploadFile): The file to be processed.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    task_data = {
        "user_id": user_details["email"],
        "project": project_name,
        "agent_id": agent_id,
        "filename": f"requirement.csv",  # None
        "task_name": TaskTypes.SEARCH.value,
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "tracker": None,
        "description_col_name": "description",
        "id_col_name": "ID",
        "search_type": SearchType.TEXT_SEARCH.value,
        "request_type": RequestType.MANUAL.value,
    }
    collection_name = document_retriever_config.get("task_collection_name")
    collection = MongoDB.get_collection(collection_name)
    result = collection.insert_one(task_data)
    task_id = str(result.inserted_id)
    blob_path = f"doc_retriever/tasks/{user_details['email']}/{task_id}/{task_data['filename']}"
    try:
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
        file_contents = pd.DataFrame([{"ID": 0, "description": requirement}])
        # local_temp_path = os.path.join("data", f"temp_{task_data['filename']}")
        csv_buffer = io.StringIO()
        file_contents.to_csv(csv_buffer, index=False)
        csv_string = csv_buffer.getvalue()
        blob_client.upload_blob(csv_string, overwrite=True)  # Upload file asynchronously
    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "upload_status": "FAILED",
                    "status_error_message": "Failed to upload file",
                    "lastupdated_timestamp": datetime.now(timezone.utc),
                }
            },
        )
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

    background_tasks.add_task(search_data, task_id)
    return {"task_id": task_id}


def search_data(task_id: str):
    """A Helper function for search, it submits the request to llm backend to get the results.\
    save results on azure blob and update the metadat on mongodb.

    Args:
        task_id (str): Id of submitted task

    Raises:
        HTTPException: If Task is not found on mongodb
        HTTPException: If a file is not found on blob
        HTTPException: If file is not downlaoded sucessfully form blob
        HTTPException: If Error comes while prediction
        HTTPException: If failed to upload file on azure blob
        HTTPException: If failed to update task on Mongodb

    Returns:
        dict: message for sucessfully completed task.
    """
    # codebeamer_url = os.getenv("CODEBEAMER_URL")
    service_url = os.getenv("DOC_RETRIEVER_SERVICE_URL")
    collection_name = document_retriever_config.get("task_collection_name")

    # Update collection to 'PROCESSING' state
    collection = MongoDB.get_collection(collection_name)
    collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.PROCESSING.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )
    task = collection.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    project_name = task.get("project")
    filename = task.get("filename")
    user_id = task.get("user_id")
    description_col_name = task.get("description_col_name")
    id_col_name = task.get("id_col_name")
    project_details = get_project_by_user_id(project_name, user_id)
    project_id = project_details["_id"]
    # request_type = task.get("request_type")
    blob_path = f"doc_retriever/tasks/{user_id}/{task_id}/{filename}"
    local_temp_path = os.path.join("data", f"temp_{filename}")
    os.makedirs(os.path.dirname(local_temp_path), exist_ok=True)

    # Download the requirements file
    try:
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
        with open(local_temp_path, "wb") as download_file:
            stream_downloader = blob_client.download_blob()
            data = stream_downloader.readall()
            download_file.write(data)
    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {"$set": {"status": TaskStatus.FAILED.value, "status_error_message": "Blob not found"}},
        )
        raise HTTPException(status_code=404, detail=f"Blob not found: {e}")

    if not os.path.isfile(local_temp_path):
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "File not downloaded successfully",
                }
            },
        )
        raise HTTPException(status_code=404, detail="File not downloaded successfully.")

    # Make the predictions
    try:
        # Read the file and convert it to a list of dictionaries
        if local_temp_path.split(".")[-1] == "csv":
            df = pd.read_csv(local_temp_path)
        else:
            df = pd.read_excel(local_temp_path)
        # df.rename(columns={prediction_col_name: "text"}, inplace=True)
        df[description_col_name] = df[description_col_name].astype(str)
        data = json.loads(df.to_json(orient="records"))

        try:
            # Get prediction from the model API
            response = requests.post(
                service_url + "/search_data",
                json={
                    "data": data,
                    "collection_name": f"doc_retriever_{project_id}",
                    "req_col": description_col_name,
                },
            )
            if response.status_code != 200:
                raise Exception(f"Model API returned status code {response.status_code}")
            results = json.loads(response.json())
            predictions_df = pd.DataFrame(results)
            # predictions_df.rename(columns={description_col_name: 'Description', id_col_name:"ID" }, inplace=True)
        except Exception as e:
            collection.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$set": {
                        "status": TaskStatus.FAILED.value,
                        "status_error_message": "Error during model prediction",
                    }
                },
            )
            raise HTTPException(status_code=500, detail=f"Error during model prediction: {e}")
    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "Failed to upload processed file",
                }
            },
        )
        raise HTTPException(status_code=500, detail=f"Failed to upload processed file: {e}")

    try:
        # Save the processed file
        processed_filename = f"{task_id[:5]}_processed_{filename}"
        processed_blob_path = f"doc_retriever/tasks/{user_id}/{task_id}/{processed_filename}"
        # Replace empty strings with NaN in the specified column
        final_data = pd.concat([df, predictions_df], axis=1)
        final_data[description_col_name] = final_data[description_col_name].replace(
            r"^\s*$", pd.NA, regex=True
        )

        # Drop rows with NaN values in the specified column
        final_data = final_data.dropna(subset=[description_col_name])
        final_data.rename(
            columns={description_col_name: "Description", id_col_name: "ID"}, inplace=True
        )
        final_data = postprocess_result_file(final_data, "ID", "Description")
        if local_temp_path.split(".")[-1] == "csv":
            final_data.to_csv(local_temp_path, index=False)
        else:
            final_data.to_excel(local_temp_path, index=False)

        try:
            # Upload the processed file to Azure Blob Storage
            with open(local_temp_path, "rb") as data:
                blob_client = blob_service_client.get_blob_client(
                    container=container_name, blob=processed_blob_path
                )
                blob_client.upload_blob(data, overwrite=True)
        except Exception as e:
            collection.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$set": {
                        "status": TaskStatus.FAILED.value,
                        "status_error_message": "Failed to upload processed file",
                    }
                },
            )
            raise HTTPException(status_code=500, detail=f"Failed to upload processed file: {e}")

        # Remove the local temporary file
        if os.path.exists(local_temp_path):
            os.remove(local_temp_path)

        try:
            # Update the task status to success
            collection.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$set": {
                        "status": TaskStatus.SUCCESS.value,
                        "filename": processed_filename,
                        "lastupdated_timestamp": datetime.now(timezone.utc),
                    }
                },
            )
        except Exception as e:
            collection.update_one(
                {"_id": ObjectId(task_id)},
                {"$set": {"status_error_message": "Failed to update task after processing"}},
            )
            raise HTTPException(
                status_code=500, detail=f"Failed to update task status after processing: {e}"
            )

        return {"status": "success", "message": "Task executed successfully."}
    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "Failed to process file",
                }
            },
        )
        raise HTTPException(status_code=500, detail=f"Failed to process file: {e}")


#@router.post("/task/project/create")
def task_create_project(
    background_tasks: BackgroundTasks,
    project_name: str = Form(),
    agent_id: str = Form(...),
    user_details: dict = Depends(AuthValidation().wrapper),
    files: List[UploadFile] = File(...),
):
    """To create a New project.

    Args:
        background_tasks (BackgroundTasks): to process the data in background.
        project_name (str, optional): Name of the new project. Defaults to Form().
        user_name (str, optional): Name of user name. Defaults to Form().
        user_id (str, optional): Unique user id of the user. Defaults to Form().
        email (str, optional): Email Id of the user. Defaults to Form().
        files (List[UploadFile], optional): List of all the files uploaded by the user. Defaults to File(...).

    Raises:
        HTTPException: If failed to upload file on blob.

    Returns:
        dict: Task Id
    """
    # create a Task
    task_data = {
        "agent_id": agent_id,
        "user_id": user_details["email"],
        "project": project_name,
        "filename": None,  # None
        "task_name": TaskTypes.CREATE_PROJECT.value,
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "tracker": None,
        "description_col_name": None,
        "id_col_name": None,
        "search_type": None,
        "request_type": None,
    }

    task_collection_name = document_retriever_config.get("task_collection_name")
    task_collection = MongoDB.get_collection(task_collection_name)
    task_result = task_collection.insert_one(task_data)
    task_id = str(task_result.inserted_id)

    project_collection_name = document_retriever_config.get("project_manage_collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)

    # check if project is already present
    user_projects = [p for p in project_collection.find({"admin.id": user_details["email"]})]
    if project_name in [user_projects[i]["project_name"] for i in range(len(user_projects))]:
        raise HTTPException(status_code=500, detail=f"{project_name} is already exists.")

    # create project on MongoDB
    project_data = {
        "project_name": project_name,
        "agent_id": agent_id,
        "admin": {"id": user_details["email"]},
        "last_updated_by": {"id": user_details["email"]},
        "create_timestamp": datetime.now(timezone.utc),
        "update_timestamp": datetime.now(timezone.utc),
        # "files": [getfilesSchema(file) for file in files],
    }

    project_collection_name = document_retriever_config.get("project_manage_collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)
    result = project_collection.insert_one(project_data)
    project_id = str(result.inserted_id)

    def getfilesSchema(file):
        file_meta = {
            "file_name": file.filename,
            "uploaded_by": {"id": user_details["email"]},
            "project_name": project_name,
            "last_update_timestamp": datetime.now(timezone.utc),
            "location": f"doc_retriever/projects/{project_id}",
            "download_link": f"{os.getenv('AZURE_BLOB_URL')}/{os.getenv('BLOB_CONTAINER_NAME')}/doc_retriever/projects/{project_id}/{file.filename}",
        }
        return file_meta

    project_collection.update_one(
        {"_id": ObjectId(project_id)}, {"$set": {"files": [getfilesSchema(file) for file in files]}}
    )

    # task_collection.update_one(
    #         {"_id": ObjectId(task_id)}, {"$set": {"project_id": project_id}}
    #     )
    # upload files on blob
    file_path = f"doc_retriever/projects/{project_id}"
    files_name = [file.filename for file in files]

    for file in files:
        try:
            blob_client = blob_service_client.get_blob_client(
                container=container_name, blob=os.path.join(file_path, file.filename)
            )
            file_contents = file.file.read()
            blob_client.upload_blob(file_contents, overwrite=False)  # Upload file asynchronously
        except Exception as e:
            project_collection.delete_one({"_id": project_id})
            raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

    # upload files on weaviateDB
    background_tasks.add_task(upload_files, task_id, project_id, files_name)
    return {"task_id": task_id}


#@router.post("/task/project/upload_file")
def task_upload_project_file(
    background_tasks: BackgroundTasks,
    project_name: str = Form(),
    user_details: dict = Depends(AuthValidation().wrapper),
    # user_name: str = Form(),
    # email: str = Form(),
    files: List[UploadFile] = File(...),
):
    """To upload a new file in already created project.

    Raises:
        FileExistsError: If file is already exist on blob then use different service-> update file.
        HTTPException: For file exist error.
        HTTPException: if project is not found on Mongo db.

    Returns:
        dict: task_id
    """
    # create Task
    task_data = {
        "user_id": user_details["email"],
        "project": project_name,
        "filename": f"req_{datetime.now(timezone.utc)}",  # None
        "task_name": TaskTypes.UPLOAD_FILE.value,
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "tracker": None,
        "description_col_name": None,
        "id_col_name": None,
        "search_type": None,
        "request_type": None,
    }

    task_collection_name = document_retriever_config.get("task_collection_name")
    task_collection = MongoDB.get_collection(task_collection_name)
    result = task_collection.insert_one(task_data)
    task_id = str(result.inserted_id)
    project_collection_name = document_retriever_config.get("project_manage_collection_name")

    project_collection = MongoDB.get_collection(project_collection_name)
    files_name = [file.filename for file in files]
    project_details = get_project_by_user_id(project_name, user_details["email"])
    project_id = project_details["_id"]
    # check if project is there or not
    try:
        project_metadata = project_collection.find_one({"_id": ObjectId(project_id)})
        # project_id = project_metadata["_id"]

        # if file name is same or not
        for file in project_metadata["files"]:
            if file["file_name"] in files_name:
                raise FileExistsError("File already exist in DB")
    except:
        task_collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "project not found or file already exist in db",
                }
            },
        )
        raise HTTPException(status_code=404, detail="project not found or file already exist in db")

    # upload data on blob
    file_path = f"doc_retriever/projects/{project_id}"
    # files_name = [file.filename]
    for file in files:
        try:
            blob_client = blob_service_client.get_blob_client(
                container=container_name, blob=os.path.join(file_path, file.filename)
            )
            file_contents = file.file.read()
            blob_client.upload_blob(file_contents, overwrite=False)  # Upload file asynchronously
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")
    # task_collection_name = document_retriever_config.get("task_collection_name")
    # task_collection = MongoDB.get_collection(task_collection_name)
    # task_result = task_collection.insert_one(task_data)
    # task_id = str(task_result.inserted_id)

    background_tasks.add_task(upload_files, task_id, project_id, files_name)
    project_name = project_metadata["project_name"]

    def getfilesSchema(file):
        file_meta = {
            "file_name": file.filename,
            "uploaded_by": {"id": user_details["email"]},
            "project_name": project_name,
            "last_update_timestamp": datetime.now(timezone.utc),
            "location": f"doc_retriever/projects/{project_id}",
            "download_link": f"{os.getenv('AZURE_BLOB_URL')}/{os.getenv('BLOB_CONTAINER_NAME')}/doc_retriever/projects/{project_id}/{file.filename}",
        }
        return file_meta

    project_collection.update_one(
        {"_id": ObjectId(project_id)},
        {"$push": {"files": {"$each": [getfilesSchema(file) for file in files]}}},
    )
    project_collection.update_one(
        {"_id": ObjectId(project_id)},
        {"$set": {"last_updated_by": {"id": user_details["email"]}}},
    )

    return {"task_id": task_id}


def upload_files(task_id: str, project_id: str, files_name: List[str]):
    """Helper function to upload file on weavite db.

    Args:
        task_id (str): Associated task id for the task
        project_id (str): Project id for the selected project
        files_name (List[str]): Name of all the files uploaded by the user.

    Raises:
        Exception: If there is an error while uploading file on weaviate.
        HTTPException: for error while uploading data on weaviate.

    Returns:
        dict: success message.
    """
    # codebeamer_url = os.getenv("CODEBEAMER_URL")
    service_url = os.getenv("DOC_RETRIEVER_SERVICE_URL")
    project_collection_name = document_retriever_config.get("project_manage_collection_name")
    task_collection_name = document_retriever_config.get("task_collection_name")

    # Update task to 'PROCESSING' state
    task_collection = MongoDB.get_collection(task_collection_name)
    task_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.PROCESSING.value,
            }
        },
    )

    # get the files from project collection
    project_collection = MongoDB.get_collection(project_collection_name)
    project = project_collection.find_one({"_id": ObjectId(project_id)})

    # project_name = project.get("project_name")
    file_path = project["files"][0]["location"]

    request_data = {
        "collection_name": f"doc_retriever_{project_id}",
        "files_name": files_name,
        "file_path": file_path,
        "blob_url": os.getenv("AZURE_BLOB_URL"),
        "container_name": os.getenv("BLOB_CONTAINER_NAME"),
    }

    # send the request to upload the data
    try:
        # Get prediction from the model API
        response = requests.post(
            service_url + "/upload_data",
            json=request_data,
        )
        if response.status_code != 200:
            raise Exception(f"Model API returned status code {response.status_code}")

    except Exception as e:
        for file_name in files_name:
            # delete data from blob
            blob_client = blob_service_client.get_blob_client(
                container=container_name, blob=os.path.join(file_path, file_name)
            )
            blob_client.delete_blob()

            # delete from mongo
            project_collection.update_one(
                {"_id": ObjectId(project_id)},
                {"$pull": {"files": {"file_name": file_name}}},
            )
        project = project_collection.find_one({"_id": ObjectId(project_id)})
        if len(project["files"]) == 0:
            project_collection.delete_one({"_id": project_id})

        task_collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "Error during model prediction",
                }
            },
        )

        # if all files deleted delete project on mongo

        raise HTTPException(status_code=500, detail=f"Error during model prediction: {e}")

    task_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.SUCCESS.value,
            }
        },
    )

    return {"status": "success", "message": "Data uploaded successfully successfully."}


#@router.post("/task/project/delete")
def task_delete_project(
    background_task: BackgroundTasks,
    project_name: str = Form(),  # should be project ID
    # user_name: str = Form(),
    user_details: dict = Depends(AuthValidation().wrapper),
    # email: str = Form(),
):
    """To Dalete the project.

    Args:
        background_task (BackgroundTasks): To do the backgound task for deleting project on weaviate.
        project_name (str, optional): Name of the project to delete. Defaults to Form().
        user_name (str, optional): User Name. Defaults to Form().
        user_id (str, optional): Id of the User. Defaults to Form().
        email (str, optional): Email Id of the user. Defaults to Form().

    Raises:
        HTTPException: if there is an error while deleting data on blob.

    Returns:
        dict: task id.
    """
    # create Task
    task_data = {
        "user_id": user_details["email"],
        "project": project_name,
        "filename": None,  # None
        "task_name": TaskTypes.DELETE_PROJECT.value,
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "tracker": None,
        "description_col_name": None,
        "id_col_name": None,
        "search_type": None,
        "request_type": None,
    }

    task_collection_name = document_retriever_config.get("task_collection_name")
    task_collection = MongoDB.get_collection(task_collection_name)
    result = task_collection.insert_one(task_data)
    task_id = str(result.inserted_id)
    project_id = get_project_by_user_id(project_name, user_details["email"])["_id"]
    project_collection_name = document_retriever_config.get("project_manage_collection_name")

    project_collection = MongoDB.get_collection(project_collection_name)

    # delete data on blob container.
    try:
        project_path = f"doc_retriever/projects/{project_id}"
        container_client = blob_service_client.get_container_client(container=container_name)
        blobs = container_client.list_blobs(name_starts_with=project_path)
        for blob in blobs:
            blob_client = container_client.get_blob_client(blob)
            blob_client.delete_blob()
    except:
        task_collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "error while deleting data on blob",
                    "lastupdated_timestamp": datetime.now(timezone.utc),
                }
            },
        )
        raise HTTPException(status_code=500, detail="error while deleting data on blob")

    # delete collection on weaviate
    background_task.add_task(delete_project, project_id, task_id)

    # on successful deletion update mongodb
    project_collection = MongoDB.get_collection(project_collection_name)
    # project_collection.delete_one({"project_name": project_name})
    project_collection.delete_one({"_id": ObjectId(project_id)})

    return {"task_id": task_id}


def delete_project(project_id: str, task_id):
    """Helper function to delete project on weaviate DB.

    Args:
        project_name (str): Name of the project to delete.
        task_id (_type_): associated task id for that task.

    Raises:
        Exception: if there is an error while deleting data on weaviate.
        HTTPException: for the error while deleting data on weaviate.
    """
    task_col_name = document_retriever_config.get("task_collection_name")
    task_collection = MongoDB.get_collection(task_col_name)

    task_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.PROCESSING.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )

    service_url = os.getenv("DOC_RETRIEVER_SERVICE_URL")
    try:
        request_data = {"collection_name": f"doc_retriever_{project_id}"}
        headers = {"Content-Type": "application/json"}

        response = requests.post(
            service_url + "/delete_collection", json=request_data, headers=headers
        )
        if response.status_code != 200:
            raise Exception(f"Model API returned status code {response.status_code}")
    except:
        task_collection.update_one(
            {"_id": ObjectId(task_id)},
            {"$set": {"status_error_message": "error while requesting to delete collection"}},
        )
        raise HTTPException(status_code=500, detail="error while requesting to delete collection")

    task_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.SUCCESS.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )


#@router.post("/task/project/file_delete")
def task_delete_project_file(
    background_task: BackgroundTasks,
    project_name: str = Form(),
    # user_name: str = Form(),
    user_details: dict = Depends(AuthValidation().wrapper),
    file_name: str = Form(),
):
    """To delete a project file.

    Args:
        background_task (BackgroundTasks): Background task to delete the file on weaviate db.
        project_name (str, optional): Name of the project. Defaults to Form().
        user_name (str, optional): User Name. Defaults to Form().
        user_id (str, optional): Id of the user. Defaults to Form().
        file_name (str, optional): Name of the file to delete. Defaults to Form().
        email (str, optional): Email id of the user. Defaults to Form().

    Raises:
        HTTPException: Project not found.
        FileExistsError: File does not exist.
        HTTPException: File does not exist.

    Returns:
        dict: task_id
    """
    # create Task
    task_data = {
        "user_id": user_details["email"],
        "project": project_name,
        "filename": f"req_{datetime.now(timezone.utc)}",  # None
        "task_name": TaskTypes.DELETE_FILE.value,
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "tracker": None,
        "description_col_name": None,
        "id_col_name": None,
        "search_type": None,
        "request_type": None,
    }

    task_collection_name = document_retriever_config.get("task_collection_name")
    task_collection = MongoDB.get_collection(task_collection_name)
    result = task_collection.insert_one(task_data)
    task_id = str(result.inserted_id)
    project_collection_name = document_retriever_config.get("project_manage_collection_name")

    project_collection = MongoDB.get_collection(project_collection_name)
    project_id = get_project_by_user_id(project_name, user_details["email"])["_id"]
    try:
        # check if project is there or not
        try:
            project_metadata = project_collection.find_one({"_id": ObjectId(project_id)})
            # project_id = project_metadata["_id"]
        except:
            task_collection.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$set": {
                        "status": TaskStatus.FAILED.value,
                        "status_error_message": "project not found",
                    }
                },
            )
            raise HTTPException(status_code=404, detail="project not found")

        # check if file is there or not
        if file_name not in [
            project_metadata["files"][i]["file_name"] for i in range(len(project_metadata["files"]))
        ]:
            # if not project_metadata.find_one({"files.file_name": file_name}):
            raise FileExistsError("File does not exist")
    except:
        task_collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "Unable to delete file; File doesn't exist.",
                }
            },
        )
        raise HTTPException(
            status_code=404, detail=f"Unable to delete file. {file_name} does not exist"
        )

    # DELETE FILE ON WEAVAITE
    background_task.add_task(
        delete_project_file,
        task_id,
        project_id,
        file_name,
        user_details["email"],
    )
    return {"task_id": task_id}


def delete_project_file(task_id, project_id, file_name, user_id):
    """Helper Function to delete a project file.

    Args:
        task_id (_type_): Id of the Task
        project_id (_type_): Id of the project.
        file_name (_type_): Name of the file to delete.
        user_name (_type_): User name.
        user_id (_type_): User Id.

    Raises:
        Exception: if response to delete file request is not 200.
        HTTPException: if unable to delete file on weaviate.
    """
    project_collection_name = document_retriever_config.get("project_manage_collection_name")
    task_col_name = document_retriever_config.get("task_collection_name")
    service_url = os.getenv("DOC_RETRIEVER_SERVICE_URL")

    # task = task_col_name.find_one({"_id": ObjectId(task_id)})
    task_collection = MongoDB.get_collection(task_col_name)

    task_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.PROCESSING.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )

    project_collection = MongoDB.get_collection(project_collection_name)
    project = project_collection.find_one({"_id": ObjectId(project_id)})

    # project_name = project.get("project_name")
    # send the request to delete file from VDB
    try:
        request_data = {
            "collection_name": f"doc_retriever_{project_id}",
            "property_name": "file_name",
            "property_value": file_name,
        }

        response = requests.post(
            service_url + "/delete_data",
            json=request_data,
        )
        if response.status_code != 200:
            raise Exception(f"Model API returned status code {response.status_code}")

    except Exception as e:

        task_collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "Error during model prediction",
                }
            },
        )
        raise HTTPException(status_code=500, detail=f"Error during model prediction: {e}")

    # delete data from blob
    file_path = project["files"][0]["location"]
    blob_client = blob_service_client.get_blob_client(
        container=container_name, blob=os.path.join(file_path, file_name)
    )
    blob_client.delete_blob()

    # on successful deletion update mongodb
    project_collection = MongoDB.get_collection(project_collection_name)
    project_collection.update_one(
        {"_id": ObjectId(project_id)},
        {
            "$pull": {"files": {"file_name": file_name}},
            "$set": {
                "update_timestamp": datetime.now(timezone.utc),
                "last_updated_by": {"name": user_name, "id": user_id},
            },
        },
    )

    task_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.SUCCESS.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )


#@router.post("/task/project/update_file")
def task_update_project_file(
    background_tasks: BackgroundTasks,
    project_name: str = Form(),
    # user_name: str = Form(),
    user_details: dict = Depends(AuthValidation().wrapper),
    # email: str = Form(),
    file: UploadFile = File(...),
):
    """To update a file project file.

    Args:
        background_tasks (BackgroundTasks): Background task to update file on weaviate.
        project_name (str, optional): Name of the project. Defaults to Form().
        user_name (str, optional): Name of the user. Defaults to Form().
        user_id (str, optional): Id of the user. Defaults to Form().
        email (str, optional): email id of the user. Defaults to Form().
        file (UploadFile, optional): A new version of the previously existed file. Defaults to File(...).

    Raises:
        HTTPException: Project not found.
        HTTPException: upload file is not same.
        HTTPException: failed to upload file on blob.

    Returns:
        dict: task_id.
    """
    collection_name = document_retriever_config.get("project_manage_collection_name")

    project_collection = MongoDB.get_collection(collection_name)
    project_id = get_project_by_user_id(project_name, user_details["email"])["_id"]
    # check if project is there or not
    try:
        project_metadata = project_collection.find_one({"_id": ObjectId(project_id)})
        # project_id = project_metadata["_id"]
    except:
        raise HTTPException(status_code=404, detail="project not found")

    # check if file is there or not
    if file.filename not in [
        project_metadata["files"][i]["file_name"] for i in range(len(project_metadata["files"]))
    ]:
        # if not project_metadata.find_one({"files.file_name": file.filename}):
        raise HTTPException(
            status_code=404,
            detail=f"Unable to update file. {file.filename} must be same as previous file",
        )

    # create Task
    task_data = {
        "user_id": user_details["email"],
        "project": project_name,
        "filename": f"req_{datetime.now(timezone.utc)}",  # None
        "task_name": TaskTypes.UPDATE_FILE.value,
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "tracker": None,
        "description_col_name": None,
        "id_col_name": None,
        "search_type": None,
        "request_type": None,
    }

    task_collection_name = document_retriever_config.get("task_collection_name")
    task_collection = MongoDB.get_collection(task_collection_name)
    result = task_collection.insert_one(task_data)
    task_id = str(result.inserted_id)

    # upload file to blob
    file_path = f"doc_retriever/projects/{project_id}"

    try:
        blob_client = blob_service_client.get_blob_client(
            container=container_name, blob=os.path.join(file_path, file.filename)
        )
        file_contents = file.file.read()
        blob_client.upload_blob(file_contents, overwrite=True)  # Upload file asynchronously
    except Exception as e:
        task_collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "failed to upload file",
                }
            },
        )
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

    # upload data on weaviate
    background_tasks.add_task(
        update_file,
        task_id,
        project_id,
        file.filename,
        user_details["email"],
    )

    return {"task_id": task_id}


def update_file(task_id, project_id, file_name, user_id):
    """Helper funtion to update the file on weaviate.

    Args:
        task_id (_type_): related task id.
        project_id (_type_): project id.
        file_name (_type_): name of the file to be updated.
        user_name (_type_): user name.
        user_id (_type_): id of the user.

    Raises:
        Exception: if update request response is not 200.
        HTTPException: Error while updating file on weaviate.
    """
    project_collection_name = document_retriever_config.get("project_manage_collection_name")
    task_col_name = document_retriever_config.get("task_collection_name")
    service_url = os.getenv("DOC_RETRIEVER_SERVICE_URL")

    task_collection = MongoDB.get_collection(task_col_name)

    task_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.PROCESSING.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )

    project_collection = MongoDB.get_collection(project_collection_name)
    project = project_collection.find_one({"_id": ObjectId(project_id)})
    # project_name = project.get("project_name")
    file_path = project["files"][0]["location"]
    # send the request to update file from VDB
    try:
        request_data = {
            "collection_name": f"doc_retriever_{project_id}",
            "property_name": "file_name",
            "property_value": file_name,
            "file_path": file_path,
            "blob_url": os.getenv("AZURE_BLOB_URL"),
            "container_name": os.getenv("BLOB_CONTAINER_NAME"),
        }

        response = requests.post(
            service_url + "/update_data",
            json=request_data,
        )
        if response.status_code != 200:
            raise Exception(f"Model API returned status code {response.status_code}")

    except Exception as e:

        task_collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.FAILED.value,
                    "status_error_message": "Error while updating file on weaviate",
                }
            },
        )
        raise HTTPException(status_code=500, detail=f"Error while updating file on weaviate: {e}")

    # on successfull deletion update mongodb
    project_collection = MongoDB.get_collection(project_collection_name)
    project_collection.update_one(
        {
            "_id": ObjectId(project_id),
        },
        {
            "$set": {
                "update_timestamp": datetime.now(timezone.utc),
                "last_updated_by": {"id": user_id},
            }
        },
    )

    query = {"_id": ObjectId(project_id), "files.file_name": file_name}
    update_operation = {
        "$set": {
            "files.$[elem].last_update_timestamp": datetime.now(timezone.utc),
            "files.$[elem].uploaded_by": {"name": user_name, "id": user_id},
        }
    }
    array_filters = [{"elem.file_name": file_name}]
    project_collection.update_one(query, update_operation, array_filters=array_filters)

    task_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.SUCCESS.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )


#@router.get("/get_sas_token/{project_name}/{file_name}")
async def get_sas_token(
    project_name: str, file_name: str, user_details: dict = Depends(AuthValidation().wrapper)
):
    """Generate SAS token for a file on blob.

    Args:
        project_name (str): Project Name
        file_name (str): File Name

    Returns:
        str: SAS token for the file.
    """
    project_id = get_project_by_user_id(project_name, user_details["email"])["_id"]

    client_id = os.environ["AZURE_CLIENT_ID"]
    tenant_id = os.environ["AZURE_TENANT_ID"]
    client_secret = os.environ["AZURE_CLIENT_SECRET"]
    vault_url = os.environ["AZURE_VAULT_URL"]

    # create a credential
    credentials = ClientSecretCredential(
        client_id=client_id, client_secret=client_secret, tenant_id=tenant_id
    )

    directory_path = (
        f'doc_retriever/{os.environ["BLOB_PROJECT_FOLDER_NAME"]}/{project_id}/{file_name}'
    )
    # create a secret client object
    secret_client = SecretClient(vault_url=vault_url, credential=credentials)

    STORAGE_KEY = secret_client.get_secret("STORAGE-KEY").value
    STORAGE_ACCOUNT = secret_client.get_secret("STORAGE-ACCOUNT-NAME").value

    sas_token = generate_blob_sas(
        account_name=STORAGE_ACCOUNT,
        container_name=container_name,
        blob_name=directory_path,
        account_key=STORAGE_KEY,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.utcnow() + timedelta(minutes=10),
    )
    return sas_token


#@router.get("/get_task_history/{task_id}")
def get_search_data(task_id: str, page: int = 1, page_size: int = 10):
    """Retrieve paginated feedback data for a given task.

    Args:
        task_id (str): The ID of the task.
        page (int): The page number for pagination. Defaults to 1.
        page_size (int): The number of items per page for pagination. Defaults to 10.

    Returns:
        JSONResponse: A JSON response containing paginated feedback data and total count.

    Raises:
        HTTPException: If the task is not found, if filename or prediction column name is missing,
                       if the prediction column is not found in the file, or if there is any other error.
    """
    collection_name = document_retriever_config.get("task_collection_name")
    collection = MongoDB.get_collection(collection_name)
    task = collection.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    filename = task.get("filename")
    user_id = task.get("user_id")
    if not filename:
        raise HTTPException(status_code=404, detail="Filename missing in task")

    # prediction_col_name = task.get("prediction_col_name")
    # if not prediction_col_name:
    #     raise HTTPException(status_code=404, detail="Prediction column name missing in task")

    blob_path = f"doc_retriever/tasks/{user_id}/{task_id}/{filename}"
    try:
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
        stream_downloader = blob_client.download_blob()
        file_data = stream_downloader.readall()

        # Load file data into a DataFrame
        if filename.split(".")[-1] == "csv":
            df = pd.read_csv(io.BytesIO(file_data))
        else:
            df = pd.read_excel(io.BytesIO(file_data))

        # if prediction_col_name not in df.columns:
        #     raise HTTPException(
        #         status_code=400, detail=f"Column '{prediction_col_name}' not found in file"
        #     )

        # Total count of rows
        total_count = len(df)

        # Pagination logic
        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        paginated_df = df.iloc[start_index:end_index]

        # Replace NaN and infinity values
        paginated_df.replace([np.inf, -np.inf], np.nan, inplace=True)
        paginated_df.fillna("", inplace=True)

        formated_data = transform_data(json.loads(paginated_df.to_json(orient="records")))
        return JSONResponse(content={"data": formated_data, "total_count": total_count})

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


#@router.get("/getProject/{project_id}")
async def get_project_by_id(project_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    project_collection_name = document_retriever_config.get("project_manage_collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)

    try:
        # Fetch the project from the collection using the project_id
        project = project_collection.find_one({"_id": ObjectId(project_id)})

        if project is None:
            raise HTTPException(status_code=404, detail="Project not found")
        # Convert ObjectId to string for serialization
        project["_id"] = str(project["_id"])

        return project

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e
