"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import io
import json
import os
from datetime import datetime, timezone
from io import BytesIO
from typing import List, Optional


import numpy as np
import pandas as pd
import requests
from src.utils.common.azure_helper import blob_service_client
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from fastapi.responses import JSONResponse

from src.config.config import (
    incose_config
)
from src.controllers.code_beamer_controller import (
    bulk_update_items,
    get_items_by_project,
)
from src.controllers.requirement_comparision_tracer_controller import get_rabbitmq
from src.exceptions.azure_exceptions import AzureBlobUploadFailedError
from src.exceptions.common_exceptions import ColumnNotFoundError
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.common.logger import log as logging
from src.utils.common.logger import set_job_context,trace_id_ctx,span_id_ctx
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import (
    TaskManager,
    get_agent_mappings,
    get_tasks_from_db,
    validate_agent,
)
from src.utils.common.helper import (
    check_column_name_in_columns,
    clean_local_file,
    fetch_dataframe_from_file,
    get_blob_segment,
    get_columns_from_file,
    write_dataframe_to_file,
)
from src.utils.feature.api_helper import (
    delete_blob_data,
    get_downloadable_data,
    get_task_by_id,
)
from src.utils.mongo_db import MongoDB
from src.utils.utility import validate_json_input
from src.utils.utils_enum import FileType, RequestType, TaskStatus
from src.utils.utility import get_status_message


load_dotenv()
router = APIRouter(prefix="/api/quality-checker", dependencies=[Depends(AuthValidation().wrapper)], tags=["Incose Quality Checker"])


container_name = os.getenv("BLOB_CONTAINER_NAME")
from src.utils.requirement_comparision_tracer_schema import get_task_data_xmc
from src.utils.utils_enum import APIMessages, RequestType, TaskStatus


@router.post("/task/")
async def create_task(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
    prediction_col_name: str = Query(...),
    data_file: UploadFile = File(...)
    # <-- second file (optional)
):  
    """
    Create a new Incose.

    This endpoint allows users to upload a data file and initiate
    a classification task. The file is uploaded to Azure Blob Storage,
    task metadata is stored in MongoDB, and the task is queued for
    processing via RabbitMQ.

    Args:
        request (Request): The incoming HTTP request object.
        user_details (dict, optional): User details obtained from the authentication wrapper.
        rabbitmq (RabbitMQManager): RabbitMQ manager instance used for publishing the task.
        prediction_col_name (str, Required): The column name to be used for predictions.
        data_file (UploadFile): The uploaded file containing input data.

    Returns:
        dict: A JSON response containing a success message and the created task ID.

    Raises:
        HTTPException (400): If input validation fails (e.g., missing prediction column).
        AzureBlobUploadFailedError: If uploading the input file to Azure Blob fails.
        HTTPException (500): For unexpected server-side errors.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/quality-checker/task/",  # API endpoint
    }
    # Extract email from user_details
    email = user_details["email"]

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "prediction_col_name": prediction_col_name,
        "data_file_name": data_file.filename
    }
    logging.info("Creating Quality Checker Task", service=service, api_request=api_request, task_data=api_request_data)


    exception = await validate_json_input(data_file, prediction_col_name)
    if exception:
        logging.error(f"Validation failed: {exception}")
        raise HTTPException(
            status_code=400,
            detail=exception,
        )


    task_data = get_task_data_xmc(
        user_details, data_file, prediction_col_name
    )
    logging.debug("Generated task data for MongoDB insertion.")

    request_type = task_data.get("request_type")
    try:
        result = TaskManager.create_task(incose_config, task_data)
        logging.info("Inserted Meta Data into Database")
    except Exception as e:
        logging.exception(
            f"Error while storing metadata The error is {e}."
        )
        raise HTTPException(status_code=500, detail="Failed to insert task data into MongoDB.")

    task_id = str(result.inserted_id)
    set_job_context(task_id)
    logging.debug(f"Created task with ID: {task_id}")

    source_blob_path = get_blob_segment(
        task_id,
        incose_config["feature_name"],
        str(task_data["created_timestamp"]),
    )

    task_manager = TaskManager(incose_config, task_id)
    try:
        blob_manager = BlobClientManager()
        blob_manager.upload_data_to_blob(
            f"{source_blob_path}/{data_file.filename}",
            data_file.file.read(),
        )
        logging.info(f"Uploaded file to File storage {source_blob_path}/{data_file.filename}")
    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value, error_message="Failed to upload the sources"
        )
        logging.exception(f"Failed to upload file to storage: {e}")
        raise AzureBlobUploadFailedError()

    data_rabbit_mq = {
        "trace_id": trace_id_ctx.get(),
        "parent_span_id": span_id_ctx.get(),
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": incose_config["collection_name"],
        "request_type": request_type,
    }
    await rabbitmq.publish_task(
        incose_config["queue_name"],
        data_rabbit_mq,
    )
    logging.debug("Published task to RabbitMQ.")

    task_manager.update_status_directly(TaskStatus.QUEUED.value)
    logging.info("Published task, Current status: Task is in QUEUE.")

    return {"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id}


# except Exception as e:
#     raise HTTPException(status_code=500, detail=str(e))


@router.get("/status/{task_id}")
def download_task(task_id: str):
    """
    Get the status or result of an Incose task.

    This endpoint retrieves the status of a task by its ID. If the task
    has successfully completed, it downloads and returns the result JSON
    file from Azure Blob Storage. If the task is still processing or
    failed, an appropriate status message is returned.

    Args:
        task_id (str): The unique identifier of the task.

    Returns:
        Response: JSON file as a downloadable response if completed.
        JSONResponse: A status message with code 202 if still in progress or failed.

    Raises:
        HTTPException: If the task ID is invalid or an internal error occurs.
    """
    # Download the content and respond with the data
    set_job_context(task_id)
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/quality-checker/status/{task_id}",  # API endpoint
    }
    logging.info("Getting Quality Checker status", service=service, api_request=api_request)
    try:
        logging.debug("Fetching task data from MongoDB.")
        # Validate the task data from DB
        task_manager = TaskManager(incose_config, task_id)
        task_data = task_manager.get_task()
        if not task_data:
            message = "Please check the mentioed task id. Given task id is invalid"
            logging.error("Invalid task ID provided.")
            return JSONResponse(content={"message": message, "task_status": "NOT_FOUND"}, status_code=404)
        task_status = task_data.get("status")
        logging.info(f"Task status fetched: {task_status}")
        if task_status == TaskStatus.SUCCESS.value:
            blob_manager = BlobClientManager()
            blob_path = get_blob_segment(
                task_id,
                incose_config["feature_name"],
                str(task_data["created_timestamp"]),
            )
            logging.debug(f"Attempting to download output.json from blob path: {blob_path}")
            try:
                file_data = blob_manager.get_data_from_blob(
                    f"{blob_path}/output.json", processed=True
                )
                logging.debug("Successfully downloaded output.json from blob.")
                return Response(
                    content=file_data,  # raw bytes from blob
                    media_type="application/json",
                    headers={
                        "Content-Disposition": 'attachment; filename="output.json"',
                        "Access-Control-Expose-Headers": "Content-Disposition",
                    },
                )
            except Exception as e:
                message = "error in download data from blob"
                logging.error(f"Error downloading output.json from blob: {e}")
                raise HTTPException(status_code=500, detail=str(message))
        else:
            message, task_status = get_status_message(task_status)
            logging.info(f"Task not completed. Status: {task_status}, Message: {message}")
        return JSONResponse(content={"message": message, "task_status": task_status}, status_code=202)

    except Exception as e:
        logging.error(f"Exception occurred while fetching task status: {e}")
        raise HTTPException(status_code=500, detail=str(e))
