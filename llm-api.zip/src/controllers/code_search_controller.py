"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import os
from datetime import datetime, timezone
from typing import List, Optional
from urllib.parse import urlparse

import requests
from bson import ObjectId

from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Body,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from pydantic import BaseModel

from src.config.config import code_search_config
from src.utils.auth import AuthValidation
from src.utils.mongo_db import MongoDB
from src.utils.requirement_classification_schema import list_serial
from src.utils.utils_enum import TaskStatus

load_dotenv()
routercodesearch = APIRouter(prefix="/api/code-search", dependencies=[Depends(AuthValidation().wrapper)], tags=["Code Search"])


class ProjectUpdateModel(BaseModel):
    """Project details updating model."""

    repo_type: Optional[str] = None
    repo_url: Optional[str] = None
    project_name: Optional[str] = None
    branch: Optional[str] = None
    production_lines: Optional[str] = None


@routercodesearch.post("/task/")
def create_task(
    request: Request,
    background_tasks: BackgroundTasks,
    user_details: dict = Depends(AuthValidation().wrapper),
    repo_type: str = Form(...),
    repo_url: str = Form(...),
    project_name: Optional[str] = Form(...),
    branch: str = Form(...),
    production_lines: str = Form(...),
):
    """Creates a new task with the fields below.

    Args:
        background_tasks (BackgroundTasks): FastAPI's BackgroundTasks instance for running background tasks.
        repo_url (str): URL of the repo associated with the task.
        branch_name(str): The name of the branch associated with the task.
        project_name(str): The project name to which task belongs.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    task_data = {
        "email": user_details["email"],
        "repo_url": repo_url,
        "repo_type": repo_type,
        "branch": branch,
        "project_name": project_name,
        "production_lines": production_lines,
        "timestamp": datetime.now(timezone.utc),
        "status": "",
        "status_code": "",
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): "Task is being processed."
        },
    }
    token = request.headers.get("Authorization")
    if token is None:
        raise HTTPException(
            status_code=500,
            detail="Invalid header. Could not find Authorization token.",
        )
    token = token.replace("Bearer ", "")

    collection_name = code_search_config.get("collection_name")
    task_collection = MongoDB.get_collection(collection_name)
    result = task_collection.insert_one(task_data)
    task_id = str(result.inserted_id)
    background_tasks.add_task(execute_task, repo_url, branch, token, task_id)
    return {"task_id": task_id}


async def execute_task(repo_url: str, branch: str, token: str, task_id: str):
    """This function will be run as a background task.

    It fetches or processes data from an external service,
    and then updates the MongoDB record based on the response.

    Parameters
    ----------
    repo_url: str
        url for the repo.
    branch: str
        branch name.
    token: str
        token for validation
    task_id: str
        for taking task details
    """
    collection_name = code_search_config.get("collection_name")

    # Update collection to 'PROCESSING' state
    collection = MongoDB.get_collection(collection_name)
    collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.PROCESSING.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )
    task = collection.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    payload = {
        "repo_url": repo_url,
        "branch": branch,
        "token": token,
        "task_id": task_id,
    }

    try:
        service_url = os.getenv("CODE_SEARCH_URL")
        if not service_url:
            raise ValueError("SERVICE_URL not set in environment variables.")
        response = requests.post(service_url, json=payload)

    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status_code": response.status_code,
                    "status_update_message": "Failed during task execution",
                    "status": TaskStatus.FAILED.value,
                }
            },
        )


@routercodesearch.post("/retry/{task_id}")
async def retry_task(request: Request, task_id: str, background_tasks: BackgroundTasks):
    """Retry a specific task by task_id.

     The task status will be updated to 'PROCESSING',and the task will be added to the background task queue for execution.
    Args:
        task_id (str): The ID of the task to be retried.
        background_tasks (BackgroundTasks): BackgroundTasks instance for adding tasks to the background execution queue.

    Returns:
        dict: A message confirming the task is being retried and the task_id.

    Raises:
        HTTPException: If the task with the specified task_id is not found.
    """
    collection_name = code_search_config.get("collection_name")
    collection = MongoDB.get_collection(collection_name)
    task = collection.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    repo_url = task.get("repo_url")
    branch = task.get("branch")
    token = request.headers.get("Authorization")
    if token is None:
        raise HTTPException(
            status_code=500,
            detail="Invalid header. Could not find Authorization token.",
        )
    token = token.replace("Bearer ", "")
    if task.get("status_code") == 500:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "status": TaskStatus.PROCESSING.value,
                    "lastupdated_timestamp": datetime.now(timezone.utc),
                }
            },
        )
        background_tasks.add_task(execute_task, repo_url, branch, token, task_id)
    else:
        raise HTTPException(status_code=404, detail="Retry Not allowed")
    return {"task_id": task_id}


@routercodesearch.get("/ProjectURL/")
async def get_project_by_url(
    repo_url: str = Query(...),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Fetch a particular project from MongoDB using its URL.

    Args:
        url (str): The URL of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    collection_name = code_search_config.get("collection_name")
    task_collection = MongoDB.get_collection(collection_name)
    try:
        # Fetch all projects from the collection with the same repo_url and email
        projects = list(
            task_collection.find({"repo_url": repo_url, "email": user_details["email"]})
        )

        if not projects:
            raise HTTPException(status_code=404, detail="No projects found with this URL.")

        # Convert ObjectId to string for serialization
        for project in projects:
            project["_id"] = str(project["_id"])

        return projects

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch projects: {str(e)}") from e


@routercodesearch.get("/projects")
async def get_all_projects(user_details: dict = Depends(AuthValidation().wrapper)):
    """Fetch all projects from the MongoDB collection.

    Returns:
        List[Dict]: A list of dictionaries where each dictionary represents a project.
    """
    project_collection_name = code_search_config.get("collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)
    email = user_details["email"]
    try:
        # Build the query filter
        query_filter = {}
        if email:
            query_filter["email"] = email
        # Fetch all documents from the collection
        projects = list(project_collection.find(query_filter).sort("timestamp", -1))
        project_dict = {}

        # Convert ObjectId to string for serialization
        for project in projects:
            project["_id"] = str(project["_id"])
            project_name = project.get("project_name")
            if project_name not in project_dict:
                # Initialize the group if the project_name does not exist
                project_dict[project_name] = {
                    "project_name": project_name,
                    "repo_url": project.get("repo_url"),
                    "repo_type": project.get("repo_type"),
                    "production_lines": project.get("production_lines"),
                    "branches": set(),  # Use set to avoid duplicate branch names
                    "completed_branches_count": 0,
                }

            project_dict[project_name]["branches"].add(project.get("branch"))

            # Increase counts based on branch status
            if project.get("status") == "SUCCESS":
                project_dict[project_name]["completed_branches_count"] += 1
        # for project_name, data in project_dict.items():
        #     data["total_branches_count"] = len(data["branches"])

        # Convert the dictionary to a list to return the projects
        return list(project_dict.values())

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch projects: {str(e)}") from e


@routercodesearch.get("/task/check/")
def check_task_exists_by_url(
    user_details: dict = Depends(AuthValidation().wrapper),
    repo_url: str = Query(...),
):
    """Checks if a task already exists based on the repo URL.

    Args:
        user_details (dict): The authenticated user's details.
        repo_url (str): The repo URL to check.

    Returns:
        dict: A response indicating if the task exists or not.
    """
    collection_name = code_search_config.get("collection_name")
    task_collection = MongoDB.get_collection(collection_name)

    # Query to check if a task with the same repo_url exists for the authenticated user
    existing_task = task_collection.find_one({"repo_url": repo_url, "email": user_details["email"]})
    if existing_task:
        project_name = existing_task.get("project_name")
        branches = task_collection.find(
            {"repo_url": repo_url, "email": user_details["email"]}
        ).distinct("branch")
        branches_list = ", ".join(branches) if branches else "No branches found"
        raise HTTPException(
            status_code=400,
            detail={
                "task_exists": True,
                "message": f"Project with this repository URL already exists.",
                "branches": branches_list,
                "project_name": project_name,
            },
        )
    else:
        project_name = urlparse(repo_url).path.split("/")[-1]
        return {
            "task_exists": False,
            "message": "No task exists with this repo_url",
            "project_name": project_name,
        }


@routercodesearch.put("/updateProject/{project_id}")
async def update_project_details(project_id: str, project_details: ProjectUpdateModel):
    """Update the details of a particular project in MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to update.
        project_details (ProjectUpdateModel): The updated project details.

    Returns:
        Dict: The updated project if successful, otherwise raises an error.
    """
    project_collection_name = code_search_config.get("collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)

    try:
        # Convert the project_id to ObjectId for querying MongoDB
        project_object_id = ObjectId(project_id)

        # Prepare the update document, only including fields that are provided
        update_data = project_details.dict(exclude_unset=True)

        # Check if there are no update fields
        if not update_data:
            raise HTTPException(status_code=400, detail="No fields to update")

        # Update the project in MongoDB
        result = project_collection.update_one({"_id": project_object_id}, {"$set": update_data})

        # Check if the update operation was successful
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Project not found")
        if result.modified_count == 0:
            raise HTTPException(status_code=400, detail="No changes made to the project")

        # Retrieve the updated project details
        updated_project = project_collection.find_one({"_id": project_object_id})

        # Convert ObjectId to string for serialization
        updated_project["_id"] = str(updated_project["_id"])

        return updated_project

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update project: {str(e)}")


@routercodesearch.get("/getProject/{project_id}")
async def get_project_by_id(project_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    project_collection_name = code_search_config.get("collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)

    try:
        # Fetch the project from the collection using the project_id
        project = project_collection.find_one({"_id": ObjectId(project_id)})

        if project is None:
            raise HTTPException(status_code=404, detail="Project not found")
        # Convert ObjectId to string for serialization
        project["_id"] = str(project["_id"])

        return project

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e
