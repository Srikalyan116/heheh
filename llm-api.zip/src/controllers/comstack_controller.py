# src/api.py
from __future__ import annotations

import os
import re
import shutil
import asyncio
import aiofiles
import platform
import uuid
from datetime import datetime, timezone
from pathlib import Path
from io import BytesIO

import httpx
from fastapi import (
    APIRouter, 
    BackgroundTasks,
    Depends, 
    File, 
    Form, 
    HTTPException, 
    Request,
    Response,
    UploadFile, 
)
from fastapi.responses import StreamingResponse
from dotenv import load_dotenv

from src.config.config import comstack_config
from src.utils.auth import AuthValidation
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import TaskManager
from src.utils.common.helper import (
    get_blob_segment,
    sanitize_filename,
)
from src.utils.mongo_db import MongoDB
from src.utils.utils_enum import RequestType, TaskError, TaskStatus
from src.utils.common.logger import set_job_context,trace_id_ctx, span_id_ctx, parent_span_id_ctx
from src.utils.common.logger import log as logger

load_dotenv()

DEFAULT_ECU_NAME = "EPS_FD"

router = APIRouter(prefix='/api/comstack', dependencies=[Depends(AuthValidation().wrapper)], tags=["comstack"])

# ----------------------- Utils ------------------------

def get_rabbitmq(request: Request):
    """Get RabbitMQ Client."""
    return request.app.state.rabbitmq

# ------------------------------- Endpoints ---------------------------------
    
@router.get("/status/{task_id}")
async def get_task_status(
    task_id: str
):
    """
    Get status of the task
    
    Args:
        task_id (str): Task ID

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.
    
    Returns:
        JSONResponse: The status of the task with the given task_id
    """
    service = {
        "name": "llm-api",
        "type": "backend",
        "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/comstack/status",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
    }
    logger.info("Received GET request on /api/comstack/status. Fetching task status", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(comstack_config, task_id)
    task = task_manager.get_task()
    if not task:
        logger.error(f"Failed fetching task details.")
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    task_status = task.get("status", None)
    return {"Task Status": task_status,
            "Task ID": task_id,
            "message": "Successfully fetched status of the task"}

@router.get('/download/{task_id}')
def download_task(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/comstack/download",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
    }
    logger.info("Received GET request on /api/comstack/download. Fetching task results", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(comstack_config, task_id)
    task = task_manager.get_task()
    blob_manager_client = BlobClientManager()
    if not task:
        logger.error(f"Failed fetching task details.")
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)
    
    # Check the task status
    overall_task_status = task.get("status")
    output_filename = task.get("output_filename")

    if overall_task_status == TaskStatus.PROCESSING.value:
        logger.info(f"Task under processing. Please, try again later")
        return Response(content="Comstack is still processing, please try again later.")
    elif overall_task_status == TaskStatus.FAILED.value:
        logger.error(f"Comstack file generation has failed or is in an unrecognized state.")
        return Response(content="Comstack file generation has failed or is in an unrecognized state.")
    elif overall_task_status == TaskStatus.SUCCESS.value:
        # if task status is success
        results_path = task.get("output_filename")
        created_timestamp = task.get("created_timestamp", None)
        try:
            logger.info(f"Fetching results {results_path}")
            if (not results_path) or (not created_timestamp):
                raise HTTPException(status_code=404, detail="ZIP file or task creation datetime data not found")
            base_blob_path = get_blob_segment(
                task_id=task_id,
                feature_name=comstack_config["feature_name"],
                date_string=str(created_timestamp),
            )
            blob_path_construct = f"{base_blob_path}/{output_filename}"
            file_data = blob_manager_client.get_data_from_blob(
                blob_path_construct,
                True
            )
            return Response(
                content=file_data,
                media_type="application/octet-stream",
                headers={
                    "Content-Disposition": f"attachment; filename={output_filename}",
                    "Access-Control-Expose-Headers": "Content-Disposition",
                },
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    else:
        raise HTTPException(status_code=500, detail="Internal Error")

@router.get("/download_url/{task_id}")
def temporary_download_url(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        Response: The URL of the file to be downloaded.
    """
    service = {
        "name": "llm-api",
        "type": "backend",
        "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/comstack/download_url",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id
    }
    logger.info("Received GET request on /api/comstack/download_url. Downloading task results", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(comstack_config, task_id)
    blob_manager_client = BlobClientManager()
    task = task_manager.get_task()
    if not task:
        logger.error(f"Failed fetching task details")
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    overall_status = task.get("overall_status")

    zip_blob_name = task.get("output_filename")

    if not zip_blob_name:
        logger.error(f"Missing zip file details from the task details")
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    if overall_status == TaskStatus.PROCESSING.value:
        logger.error(f"Unit Test generation is in progress. Please, try again later")
        return Response(content="Unit Test is in progress, please try again later.")
    elif overall_status == TaskStatus.FAILED.value:
        # Additional failure modes can be handled here
        logger.error(f"Unit Test generation has failed or is in an unrecognized state.")
        return Response(content="Unit Test has failed or is in an unrecognized state.")
    
    created_timestamp = task.get("created_timestamp", None)
    base_blob_path = get_blob_segment(
        task_id=task_id,
        feature_name=comstack_config["feature_name"],
        date_string=str(created_timestamp),
    )
    blob_path = f"{base_blob_path}/{zip_blob_name}"
    try:
        logger.info(f"Fetching download URL from blob {blob_path}")
        return blob_manager_client.get_downlod_url(blob_path=blob_path, processed=True)
    except Exception as e:
        raise HTTPException(status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e))


@router.post("/task")
async def comstack_pipeline(
    background_tasks: BackgroundTasks,
    dbc_file: UploadFile = File(..., description="DBC file to process"),
    can_base_arxml: UploadFile = File(..., description="Can SIP *.arxml file"),
    canif_base_arxml: UploadFile = File(..., description="CanIf SIP *.arxml file"),
    com_base_arxml: UploadFile = File(..., description="Com SIP *.arxml file"),
    ecuc_base_arxml: UploadFile = File(..., description="Ecuc SIP *.arxml file"),
    pdur_base_arxml: UploadFile = File(..., description="Pdur SIP *.arxml file"),
    ecu_name: str = Form(..., description="ECU node name (e.g., EPS_FD, BCM, GW)"),
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq)
):
    """
    ---Comstack Controller---
    1. Accept dbc + arxml files
    2. Upload to blob
    3. Publish task to queue
    
    The endpoint is to execute the complete COM-STACK pipeline to generate AUTOSAR ARXML files.
    
    Orchestrates the generation of all communication stack modules:
    1. Hardware mappings (CAN controller assignments)
    2. EcuC (ECU Configuration)
    3. PduR (PDU Router)
    4. Can (CAN Driver)
    5. Com (Communication Manager)
    6. CanIf (CAN Interface)
    
    Returns:
        JSON Object with task details
    
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/comstack/task",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "dbc_file": dbc_file.filename,
        "can_base_arxml": can_base_arxml.filename,
        "canif_base_arxml": canif_base_arxml.filename,
        "com_base_arxml": com_base_arxml.filename,
        "ecuc_base_arxml": ecuc_base_arxml.filename,
        "pdur_base_arxml": pdur_base_arxml.filename,
        "ecu_name": ecu_name
    }
    logger.info("Received POST request on /api/comstack/task.", service=service, api_request=api_request, task_data=api_request_data)

    # tracing context variables for logging
    trace_id = trace_id_ctx.get() or str(uuid.uuid4())
    parent_span_id = parent_span_id_ctx.get() or str(uuid.uuid4())
    span_id = span_id_ctx.get() or str(uuid.uuid4())

    try:
        email = user_details["email"]

        files = {
            "dbc_file": dbc_file,
            "can_base_arxml": can_base_arxml,
            "canif_base_arxml": canif_base_arxml,
            "com_base_arxml": com_base_arxml,
            "ecuc_base_arxml": ecuc_base_arxml,
            "pdur_base_arxml": pdur_base_arxml,
        }

        if not all(files.values()):
            raise HTTPException(status_code=400, detail="One or more required files missing")

        logger.info(
            "Received comstack task request",
            extra={
                "email": email,
                "ecu_name": ecu_name,
                "files": {k: v.filename for k, v in files.items()},
            },
        )

        # Validate extensions
        if not dbc_file.filename.lower().endswith(".dbc"):
            raise HTTPException(status_code=400, detail="DBC file must have .dbc extension")

        for key, arxml_file in files.items():
            if key == "dbc_file":
                continue
            if not arxml_file.filename.lower().endswith(".arxml"):
                raise HTTPException(
                    status_code=400,
                    detail=f"Expecting an .arxml file instead of {arxml_file.filename}",
                )
        
        if not ecu_name:
            raise HTTPException(status_code=400, detail="Invalid ECU name. Please, provide a valid ECU name")
            
        # generate a unique id
        unique_id = uuid.uuid4().hex

        # Save files locally
        data_dir = Path(f"data/{unique_id}")
        data_dir.mkdir(parents=True, exist_ok=True)

        local_paths: dict[str, Path] = {}
        
        try:
            for key, upload_file in files.items():
                safe_name = sanitize_filename(os.path.basename(upload_file.filename))
                local_path = data_dir / safe_name

                with open(local_path, "wb") as f:
                    shutil.copyfileobj(upload_file.file, f)

                upload_file.file.seek(0)
                local_paths[key] = local_path
        except Exception as e:
            raise HTTPException(status_code=500, detail="Failed saving files to local directory")

        # Create task entry
        task_data = {
            "email": email,
            "ecu_name": ecu_name,
            "status": TaskStatus.CREATED.value,
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
            "input_files": {k: p.name for k, p in local_paths.items()},
        }

        try:
            result = TaskManager.create_task(comstack_config, task_data)
            task_id = str(result.inserted_id)
            logger.info("Inserted data to DB.")
            task_manager = TaskManager(comstack_config, task_id)
        except Exception as e:
            raise HTTPException(status_code=500, detail="Failed inserting data to DB")

        set_job_context(task_id)

        # Upload source files to blob
        logger.info("Uploading files to blob")
        blob_manager = BlobClientManager()

        source_blob_path = get_blob_segment(
            task_id=task_id,
            feature_name=comstack_config["feature_name"],
            date_string=str(task_data["created_timestamp"]),
        )

        try:
            for key, local_path in local_paths.items():
                with open(local_path, "rb") as f:
                    blob_manager.upload_data_to_blob(
                        blob_path=f"{source_blob_path}/{local_path.name}",
                        data=BytesIO(f.read()),
                    )
        except Exception as e:
            task_manager.update_status(TaskStatus.FAILED.value, error_message=str(e))
            raise HTTPException(status_code=500, detail="Blob upload failed")

        finally:
            for p in local_paths.values():
                if p.exists():
                    p.unlink()

        # Publish to RabbitMQ
        rabbit_payload = {
            "task_id": task_id,
            "email": email,
            "ecu_name": ecu_name,
            "input_files": {
                k: f"{source_blob_path}/{p.name}" for k, p in local_paths.items()
            },
            "collection_name": task_manager.get_collection_name(),
            "trace_id": trace_id,
            "span_id": span_id,
        }

        await rabbitmq.publish_task(
            comstack_config["queue_name"],
            rabbit_payload,
        )
        logger.info("Publishing task to queue", rabbit_payload)

        task_manager.update_status(TaskStatus.PROCESSING.value)

        
        # cleaning up resources on successful completion
        background_tasks.add_task(shutil.rmtree, str(data_dir), ignore_errors=True)
        logger.info(f"Comstack task submitted: {task_id}")

        return {"message": "Task submitted", "task_id": task_id}

    except HTTPException:
        raise

    except Exception as ex:
        logger.exception("Comstack task failed")
        return {"message": str(ex), "status": "FAILED"}
