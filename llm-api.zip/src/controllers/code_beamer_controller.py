"""Module to handle all the functions of codebeamer which are required."""

import json
import logging
import os

import pandas as pd
import requests
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response

from src.config.config import (
    requirement_classification_config,
    requirement_comparison_tracer_config,
)
from src.models.code_beamer_task import UpdateResponse
from src.utils.auth import AuthValidation
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import TaskManager, get_agent_mappings
from src.utils.common.helper import get_blob_segment
from src.utils.utils_enum import CodebeamerTaskType

router_code_beamer = APIRouter(prefix="/api/code-beamer", dependencies=[Depends(AuthValidation().wrapper)], tags=["Codebeamer Apis"])


container_name = os.getenv("BLOB_CONTAINER_NAME")

def code_beamer_bulk_update(auth_token: str, updated_items: dict, task_manager: TaskManager):
    endpoint = "/v3/items/fields"
    codebeamer_url = os.getenv("CODEBEAMER_URL")
    codebeamer_url += endpoint

    # Set header for token based auth
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {auth_token}",
    }
    try:
        response = requests.request(
            "PUT",
            codebeamer_url,
            headers=headers,
            data=json.dumps(updated_items),
            timeout=60,
            verify=False,
        )
        response_data = response.json()
        if response.status_code == 200:
            response_data = response.json()
            task_manager.update_record(
                {
                    "code_beamer_status": "SUCCESS",
                    "successfulOperationsCount": response_data.get("successfulOperationsCount", 0),
                }
            )

            return {
                "code_beamer_status": "SUCCESS",
                "successfulOperationsCount": response_data.get("successfulOperationsCount", 0),
            }
        else:
            logging.error(
                f"Issue fetching data from codebeamer, response code {response.status_code}"
            )
            task_manager.update_record(
                {
                    "code_beamer_status": "FAILED",
                    "code_beamer_error_message": response.text,
                }
            )

            raise HTTPException(status_code=response.status_code, detail=response.text)
    except Exception as e:
        task_manager.update_record(
            {
                "code_beamer_status": "FAILED",
                "code_beamer_error_message": e,
            }
        )
        raise Exception(f"Issue updating codebeamer,  {str(e)}") from e


@router_code_beamer.get("/projects")
def get_projects(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """API to get all codebeamer projects for a user."""
    auth_token = request.headers.get("Authorization")
    if auth_token is None:
        raise HTTPException(
            status_code=500,
            detail="Invalid header. Could not find Authorization token.",
        )
    auth_token = auth_token.replace("Bearer ", "")
    codebeamer_url = os.getenv("CODEBEAMER_URL")
    projects = get_all_projects(auth_token, codebeamer_url)
    return {"projects": projects}


@router_code_beamer.get("/trackers")
def get_trackers(
    request: Request,
    project_id: str,
):
    """API to get all codebeamer trackers for a project id.

    Args:
        request (Request): Request object.
        project_id (str, optional): ID of the codebeamer project.
    """
    auth_token = request.headers.get("Authorization")
    if auth_token is None:
        raise HTTPException(
            status_code=500,
            detail="Invalid header. Could not find Authorization token.",
        )
    auth_token = auth_token.replace("Bearer ", "")
    codebeamer_url = os.getenv("CODEBEAMER_URL")
    trackers = get_trackers_by_project_id(auth_token, codebeamer_url, project_id)
    return {"trackers": trackers}


@router_code_beamer.get("/items_by_project")
async def get_items(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    codebeamer_project: str = Query(...),
    codebeamer_tracker: str = Query(...),
):
    """Asynchronously retrieves tracker items from a Codebeamer project based on the specified project and tracker names.

    Args:
        request (Request): Request object.
        user_details (dict, optional): Defaults to Depends(AuthValidation().wrapper).
        codebeamer_project (str, optional): Name of codebeamer_project
        codebeamer_tracker (str, optional):  Name of codebeamer tracker
    """
    auth_token = request.headers.get("Authorization")
    if auth_token is None:
        raise HTTPException(
            status_code=500,
            detail="Invalid header. Could not find Authorization token.",
        )
    auth_token = auth_token.replace("Bearer ", "")
    codebeamer_url = os.getenv("CODEBEAMER_URL")
    req_objects = get_items_by_project(
        auth_token, codebeamer_url, codebeamer_project, codebeamer_tracker
    )

    if req_objects and len(req_objects) > 0:
        pass
    else:

        logging.error(f"No tracker items available:")
        raise HTTPException(status_code=500, detail=f"No available tracker items:")
    return req_objects


@router_code_beamer.put("/update_items", response_model=UpdateResponse)
async def bulk_update_items(
    request: Request,
    task_id: str,
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Asynchronously updates multiple tracker items in Codebeamer based on a task's prediction values.

    Args:
        request (Request): Request object
        task_id (str): Id of the task
        user_details (dict, optional):Defaults to Depends(AuthValidation().wrapper).
    """
    auth_token = request.headers.get("Authorization")
    if auth_token is None:
        raise HTTPException(
            status_code=500,
            detail="Invalid header. Could not find Authorization token.",
        )
    auth_token = auth_token.replace("Bearer ", "")
    task_manager = TaskManager(requirement_classification_config, task_id)

    if not task_manager.get_collection_name():
        raise HTTPException(status_code=500, detail="Collection name not configured")

    task = task_manager.get_task()
    task_manager.update_record({"code_beamer_status": "STARTED"})

    processed_filename = task.get("filename")
    blob_path = get_blob_segment(
        task_id,
        requirement_classification_config["feature_name"],
        str(task["created_timestamp"]),
    )
    processed_blob_path = f"{blob_path}/{processed_filename}"

    local_temp_path = os.path.join("data", processed_filename)
    os.makedirs(os.path.dirname(local_temp_path), exist_ok=True)

    blob_manager = BlobClientManager()

    with open(local_temp_path, "wb") as download_file:
        data = blob_manager.get_data_from_blob(processed_blob_path, processed=True)
        download_file.write(data)

    df = pd.read_excel(local_temp_path, engine="openpyxl")
    prediction_column_name = "itemType_pred"
    if prediction_column_name in list(df.columns):
        predictions_df = df[["ID", prediction_column_name]]
        task_manager.update_record({"code_beamer_status": "PROCESSING"})

        updated_items = []

        for _, row in predictions_df.iterrows():
            pred_value = row[prediction_column_name]
            pred_id = row["ID"]
            if pred_value == "information":
                pred_value_id = CodebeamerTaskType.INFORMATION.value["id"]
            else:
                pred_value_id = CodebeamerTaskType.REQUIREMENT.value["id"]
            items_db = [
                {
                    "itemId": pred_id,
                    "fieldValues": [
                        {
                            "fieldId": 13,
                            "type": "ChoiceFieldValue",
                            "values": [{"id": pred_value_id, "type": "ChoiceOptionReference"}],
                        }
                    ],
                }
            ]
            updated_items.extend(items_db)
        code_beamer_bulk_update(auth_token, updated_items, task_manager)
    elif "assignedSubsysDis_pred" in list(df.columns):
        prediction_column_name_1 = "responsibleFunctionalArea_pred"
        prediction_column_name_2 = "assignedSubsysDis_pred"
        updated_items = []
        predictions_df = df[["ID", prediction_column_name_1, prediction_column_name_2]]
        task_manager.update_record({"code_beamer_status": "PROCESSING"})

        responsible_functional_area_options = {
            "aftermarket": {
                "id": 2537043,
                "type": "TrackerItemReference",
            },
            "cost engineering": {
                "id": 2537045,
                "type": "TrackerItemReference",
            },
            "finance": {
                "id": 2537047,
                "type": "TrackerItemReference",
            },
            "operations": {
                "id": 2537049,
                "type": "TrackerItemReference",
            },
            "product engineering": {
                "id": 2537051,
                "type": "TrackerItemReference",
            },
            "product planning": {
                "id": 2537053,
                "type": "TrackerItemReference",
            },
            "project management": {
                "id": 2537055,
                "type": "TrackerItemReference",
            },
            "purchasing": {
                "id": 2537057,
                "type": "TrackerItemReference",
            },
            "quality": {
                "id": 2537059,
                "type": "TrackerItemReference",
            },
            "sales": {
                "id": 2537061,
                "type": "TrackerItemReference",
            },
            "supply chain management": {
                "id": 2537063,
                "type": "TrackerItemReference",
            },
            "sustainability": {
                "id": 2537065,
                "type": "TrackerItemReference",
            },
        }

        subsystem_discipline_options = {
            "hardware (_eehw)": {
                "id": 2537135,
                "type": "TrackerItemReference",
            },
            "_eeme": {
                "id": 2537137,
                "type": "TrackerItemReference",
            },
            "_hydr": {
                "id": 2537143,
                "type": "TrackerItemReference",
            },
            "_me": {
                "id": 2537139,
                "type": "TrackerItemReference",
            },
            "_metr": {
                "id": 2537141,
                "type": "TrackerItemReference",
            },
            "_pneu": {
                "id": 2537145,
                "type": "TrackerItemReference",
            },
            "software (_sw)": {
                "id": 2537133,
                "type": "TrackerItemReference",
            },
            "system (_sy)": {
                "id": 2537127,
                "type": "TrackerItemReference",
            },
            "_syar": {
                "id": 2537129,
                "type": "TrackerItemReference",
            },
            "_sydes": {
                "id": 2537131,
                "type": "TrackerItemReference",
            },
        }

        for _, row in predictions_df.iterrows():
            pred_value_1 = row[prediction_column_name_1]
            pred_value_2 = row[prediction_column_name_2]
            pred_id = row["ID"]

            items_for_field = [{"itemId": pred_id, "fieldValues": []}]
            if pred_value_1 in responsible_functional_area_options:

                items_for_field[0]["fieldValues"].append(
                    {
                        "fieldId": 1013,
                        "type": "ChoiceFieldValue",
                        "values": [responsible_functional_area_options[pred_value_1]],
                    }
                )
            if pred_value_2 in subsystem_discipline_options:
                items_for_field[0]["fieldValues"].append(
                    {
                        "fieldId": 1004,
                        "type": "ChoiceFieldValue",
                        "values": [subsystem_discipline_options[pred_value_2]],
                    }
                )
            if (pred_value_1 in responsible_functional_area_options) or (
                pred_value_2 in subsystem_discipline_options
            ):
                updated_items.extend(items_for_field)

        code_beamer_bulk_update(auth_token, updated_items, task_manager)
    else:
        task_manager.update_record(
            {
                "code_beamer_status": "FAILED",
            }
        )
        return {"message": f"Prediction {prediction_column_name} not available"}


@router_code_beamer.put("/change_tracer_trigger")
async def change_tracer_update(
    request: Request,
    task_id: str,
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Asynchronously updates multiple tracker items in Codebeamer based on a task's prediction values.

    Args:
        request (Request): Request object
        task_id (str): Id of the task
        user_details (dict, optional):Defaults to Depends(AuthValidation().wrapper).
    """
    auth_token = request.headers.get("Authorization")
    if auth_token is None:
        raise HTTPException(
            status_code=500,
            detail="Invalid header. Could not find Authorization token.",
        )
    auth_token = auth_token.replace("Bearer ", "")
    codebeamer_url = os.getenv("CODEBEAMER_URL")
    task_manager = TaskManager(requirement_comparison_tracer_config, task_id)

    if not task_manager.get_collection_name():
        raise HTTPException(status_code=500, detail="Collection name not configured")

    task = task_manager.get_task()
    task_manager.update_record({"code_beamer_status": "STARTED"})

    processed_filename = task.get("output_filename")
    rule_name = task.get("rule_name")

    blob_path = get_blob_segment(
        task_id,
        requirement_comparison_tracer_config["feature_name"],
        str(task["created_timestamp"]),
    )
    processed_blob_path = f"{blob_path}/{processed_filename}"

    local_temp_path = os.path.join("data", processed_filename)
    os.makedirs(os.path.dirname(local_temp_path), exist_ok=True)

    blob_manager = BlobClientManager()

    with open(local_temp_path, "wb") as download_file:
        data = blob_manager.get_data_from_blob(processed_blob_path, processed=True)
        download_file.write(data)

    df = pd.read_excel(local_temp_path, engine="openpyxl")
    change_type_df = df[["ID", "changeType"]]
    task_manager.update_record({"code_beamer_status": "PROCESSING"})
    constants = {
        "No Changes": {"id": 0, "name": "Unset", "type": "ChoiceOptionReference"},
        "Major": {"id": 1, "name": "New", "type": "ChoiceOptionReference"},
        "Minor": {"id": 2, "name": "Updated", "type": "ChoiceOptionReference"},
        "Deleted": {"id": 3, "name": "Deleted", "type": "ChoiceOptionReference"},
    }

    jlr_change_options = {
        "No Changes": {"id": 4, "name": "Feature Dependent", "type": "ChoiceOptionReference"},
        "Major": {"id": 2, "name": "Medium", "type": "ChoiceOptionReference"},
        "Minor": {"id": 1, "name": "Low", "type": "ChoiceOptionReference"},
        "Critical": {"id": 3, "name": "High", "type": "ChoiceOptionReference"},
    }

    updated_items = []
    updated_items_for_jlr = []

    for _, row in change_type_df.iterrows():
        change_type = row["changeType"]
        id = row["ID"]
        if id > 0:
            pred_value_id = constants[change_type]["id"] if change_type in constants else ""

            if pred_value_id:
                updated_items.append(
                    {
                        "itemId": id,
                        "fieldValues": [
                            {
                                "fieldId": 1016,
                                "type": "ChoiceFieldValue",
                                "values": [{"id": pred_value_id, "type": "ChoiceOptionReference"}],
                            }
                        ],
                    }
                )

    for _, row in change_type_df.iterrows():
        change_type = row["changeType"]
        id = row["ID"]
        value = jlr_change_options[change_type]["id"] if change_type in jlr_change_options else ""
        if value:
            updated_items_for_jlr.append(
                {
                    "itemId": id,
                    "fieldValues": [
                        {
                            "fieldId": 1017,
                            "type": "FieldReference",
                            "values": [{"id": pred_value_id, "type": "ChoiceOptionReference"}],
                        }
                    ],
                }
            )
    endpoint = "/v3/items/fields"
    codebeamer_url += endpoint

    # Set header for token based auth
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {auth_token}",
    }

    try:
        response = requests.request(
            "PUT",
            codebeamer_url,
            headers=headers,
            data=json.dumps(updated_items),
            timeout=60,
            verify=False,
        )
        response_data = response.json()
        if response.status_code == 200:
            response_data = response.json()
            task_manager.update_record(
                {
                    "code_beamer_status": "SUCCESS",
                    "successfulOperationsCount": response_data.get("successfulOperationsCount", 0),
                }
            )

        else:
            logging.error(
                f"Issue fetching data from codebeamer, response code {response.status_code}"
            )
            task_manager.update_record(
                {
                    "code_beamer_status": "FAILED",
                    "code_beamer_error_message": response.text,
                }
            )

            raise HTTPException(status_code=response.status_code, detail=response.text)

        if rule_name == "U-Div_JLR":
            response = requests.request(
                "PUT",
                codebeamer_url,
                headers=headers,
                data=json.dumps(updated_items_for_jlr),
                timeout=60,
                verify=False,
            )
            response_data = response.json()
            if response.status_code == 200:
                response_data = response.json()
                task_manager.update_record(
                    {
                        "code_beamer_status": "SUCCESS",
                        "successfulOperationsCount": response_data.get(
                            "successfulOperationsCount", 0
                        ),
                    }
                )

            else:
                logging.error(
                    f"Issue fetching data from codebeamer, response code {response.status_code}"
                )
                task_manager.update_record(
                    {
                        "code_beamer_status": "FAILED",
                        "code_beamer_error_message": response.text,
                    }
                )

                raise HTTPException(status_code=response.status_code, detail=response.text)

        return {
            "code_beamer_status": "SUCCESS",
            "successfulOperationsCount": response_data.get("successfulOperationsCount", 0),
        }
    except Exception as e:
        raise Exception(f"Issue updating codebeamer,  {str(e)}") from e


def get_all_projects(
    auth_token: str,
    codebeamer_url: str,
):
    """Method to get all projects from codebeamer.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer project api.
    """
    endpoint = "/v3/projects"
    codebeamer_url += endpoint
    projects = []
    # Set header for token based auth
    headers = {"Authorization": f"Bearer {auth_token}"}
    try:
        response = requests.request(
            "GET", codebeamer_url, headers=headers, timeout=60, verify=False
        )
        if response.status_code == 200:
            response = json.loads(response.text)
            if len(response) == 0:
                raise HTTPException(status_code=404, detail="No projects available.")
            projects.extend(response)
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Issue fetching data from codebeamer {response.text}",
            )
    except Exception as e:
        logging.error(f"Failed to send request to codebeamer: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to send request to codebeamer: {e}")
    return projects


def get_trackers_by_project_id(auth_token: str, codebeamer_url: str, project_id: int):
    """Get tracker by project id.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer instance.
        project_id (int): Project ID to get trackers for.
    """
    endpoint = f"/v3/projects/{project_id}/trackers"
    codebeamer_url += endpoint
    trackers = []
    # Set header for token based auth
    headers = {"Authorization": f"Bearer {auth_token}"}
    try:
        response = requests.request(
            "GET", codebeamer_url, headers=headers, timeout=60, verify=False
        )
        if response.status_code == 200:
            res = json.loads(response.text)
            if len(res) == 0:
                raise HTTPException(status_code=404, detail="No trackers available.")
            trackers.extend(res)
    except Exception as e:
        logging.error(f"Failed to send request to codebeamer: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to send request to codebeamer: {e}")
    return trackers


def get_items_by_project(
    auth_token: str,
    codebeamer_url: str,
    codebeamer_project: str,
    codebeamer_tracker: str,
) -> Response:
    """Method to fetch tracker items from codebeamer based on project name.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer project api.
        codebeamer_project (str): Name of the codebeamer project.

    Returns:
        Response: Object of paginated tracker items from codebeamer.
    """
    endpoint = "/v3/items/query"
    codebeamer_url += endpoint
    tracker_items = []
    page_number = 1

    while True:
        # Query param containing comma seperated project names
        params = {
            "queryString": f"project.name IN ('{codebeamer_project}') and \
                tracker.name IN ('{codebeamer_tracker}')",
            "page": page_number,
            "pageSize": 500,
        }

        # Set header for token based auth
        headers = {"Authorization": f"Bearer {auth_token}"}

        response = requests.request(
            "GET",
            codebeamer_url,
            headers=headers,
            data={},
            params=params,
            timeout=60,
            verify=False,
        )
        if response.status_code != 200:
            logging.error(
                f"Issue fetching items from codebeamer, response code {response.status_code} {response.text}"
            )
            raise HTTPException(
                status_code=500,
                detail=f"Issue fetching data from codebeamer, response code {response.status_code}",
            )

        res = json.loads(response.text)
        items = res.get("items", "")
        if items and len(items) > 0:
            tracker_items.extend(items)
            page_number += 1
        else:
            break
    return tracker_items
