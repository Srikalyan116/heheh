"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import io
import json
import logging
import os
from datetime import datetime, timezone
from io import BytesIO
from typing import List, Optional

import loguru
import numpy as np
import pandas as pd
import requests
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from fastapi.responses import JSONResponse

from src.config.config import (
    requirement_classification_config,
    requirement_classification_xmc_config,
)
from src.controllers.code_beamer_controller import (
    bulk_update_items,
    get_items_by_project,
)
from src.controllers.requirement_comparision_tracer_controller import get_rabbitmq
from src.exceptions.azure_exceptions import AzureBlobUploadFailedError
from src.exceptions.common_exceptions import ColumnNotFoundError
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import (
    TaskManager,
    get_agent_mappings,
    get_tasks_from_db,
    validate_agent,
)
from src.utils.common.helper import (
    check_column_name_in_columns,
    clean_local_file,
    fetch_dataframe_from_file,
    get_blob_segment,
    get_columns_from_file,
    write_dataframe_to_file,
)
from src.utils.feature.api_helper import (
    delete_blob_data,
    get_downloadable_data,
    get_task_by_id,
)
from src.utils.mongo_db import MongoDB
from src.utils.utility import validate_xmc_input
from src.utils.utils_enum import FileType, RequestType, TaskStatus
from src.utils.utility import get_status_message

load_dotenv()
router = APIRouter(prefix="/api/req-xmc", dependencies=[Depends(AuthValidation().wrapper)], tags=["Requirement Classification xmc"])

container_name = os.getenv("BLOB_CONTAINER_NAME")
from src.utils.requirement_comparision_tracer_schema import get_task_data_xmc
from src.utils.utils_enum import APIMessages, RequestType, TaskStatus


@router.post("/task/")
async def create_task(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
    prediction_col_name: str = Form(""),
    data_file: UploadFile = File(...)
    # <-- second file (optional)
):  
    """
    Create a new requirement classification XMC task.

    This endpoint allows users to upload a data file and initiate
    a classification task. The file is uploaded to Azure Blob Storage,
    task metadata is stored in MongoDB, and the task is queued for
    processing via RabbitMQ.

    Args:
        request (Request): The incoming HTTP request object.
        user_details (dict, optional): User details obtained from the authentication wrapper.
        rabbitmq (RabbitMQManager): RabbitMQ manager instance used for publishing the task.
        prediction_col_name (str, optional): The column name to be used for predictions. Defaults to "text".
        data_file (UploadFile): The uploaded file containing input data.

    Returns:
        dict: A JSON response containing a success message and the created task ID.

    Raises:
        HTTPException (400): If input validation fails (e.g., missing prediction column).
        AzureBlobUploadFailedError: If uploading the input file to Azure Blob fails.
        HTTPException (500): For unexpected server-side errors.
    """

    # try:
    if prediction_col_name == "" or prediction_col_name == None:
        prediction_col_name = "text"
    exception = await validate_xmc_input(data_file, prediction_col_name)
    if exception:
        raise HTTPException(
            status_code=400,
            detail=exception,
        )

    task_data = get_task_data_xmc(
        user_details, data_file, prediction_col_name
    )

    request_type = task_data.get("request_type")
    try:
        result = TaskManager.create_task(requirement_classification_xmc_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    source_blob_path = get_blob_segment(
        task_id,
        requirement_classification_xmc_config["feature_name"],
        str(task_data["created_timestamp"]),
    )

    task_manager = TaskManager(requirement_classification_xmc_config, task_id)
    try:
        blob_manager = BlobClientManager()
        blob_manager.upload_data_to_blob(
            f"{source_blob_path}/{data_file.filename}",
            data_file.file.read(),
        )

    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value, error_message="Failed to upload the sources"
        )
        raise AzureBlobUploadFailedError()

    data_rabbit_mq = {
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": requirement_classification_xmc_config["collection_name"],
        "request_type": request_type,
    }
    await rabbitmq.publish_task(
        requirement_classification_xmc_config["queue_name"],
        data_rabbit_mq,
    )
    task_manager.update_status_directly(TaskStatus.QUEUED.value)

    loguru.logger.info({"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id})
    return {"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id}


# except Exception as e:
#     raise HTTPException(status_code=500, detail=str(e))





@router.get("/status/{task_id}")
def download_task(task_id: str):
    """
    Get the status or result of a requirement classification XMC task.

    This endpoint retrieves the status of a task by its ID. If the task
    has successfully completed, it downloads and returns the result JSON
    file from Azure Blob Storage. If the task is still processing or
    failed, an appropriate status message is returned.

    Args:
        task_id (str): The unique identifier of the task.

    Returns:
        JSONResponse: The result JSON when the task has completed successfully.
        Response: A status message when the task is still in progress or has failed.

    Raises:
        HTTPException (404): If the task is not found.
        HTTPException (500): If downloading the result from blob fails or an unexpected error occurs.
    """
    # Download the content and respond with the data
    try:
        # Validate the task data from DB
        task_manager = TaskManager(requirement_classification_xmc_config, task_id)
        task_data = task_manager.get_task()
        if not task_data:
            message = "Please check the mentioed task id. Given task id is invalid"
            return  JSONResponse(content={"message": message,"task_status":"NOT_FOUND"}, status_code=404)
        task_status = task_data.get("status")
        if task_status == TaskStatus.SUCCESS.value:
            blob_manager = BlobClientManager()
            blob_path = get_blob_segment(
                task_id,
                requirement_classification_xmc_config["feature_name"],
                str(task_data["created_timestamp"]),
            )
            try:
                file_data = blob_manager.get_data_from_blob(
                    f"{blob_path}/result_xmc.json", processed=True
                )
                return Response(
                    content=file_data,  # raw bytes from blob
                    media_type="application/json",
                    headers={
                        "Content-Disposition": 'attachment; filename="output.json"',
                        "Access-Control-Expose-Headers": "Content-Disposition",
                    },
                )
            except Exception as e:
                print(e)
                message = "error in download data from blob"
                raise HTTPException(status_code=500, detail=str(message))
        
        else:
            message,task_status = get_status_message(task_status)
        return  JSONResponse(content={"message": message,"task_status":task_status}, status_code=202)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
