"""This module contains the routes and associated logic for the FastAPI application handling project items."""

# Standard library imports
import io
import logging
import os
import re
from datetime import datetime, timezone
from io import BytesIO

# Third party imports
from typing import List, Optional

import loguru
import pandas as pd
import requests
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Response,
    UploadFile,
)
from pydantic import BaseModel
from pymongo import DESCENDING

from src.config.config import (
    test_case_generation_config,
    test_case_generation_task_config,
)
from src.utils.auth import AuthValidation
from src.utils.common.azure_helper import BlobClientManager, blob_service_client
from src.utils.common.db_helper import TaskManager
from src.utils.common.helper import get_blob_segment

# Local application imports
from src.utils.mongo_db import MongoDB
from src.utils.test_case_generation_schema import list_serial_project
from src.utils.test_case_generation_task_schema import list_serial
from src.utils.utils_enum import FileType, TaskError, TaskStatus

load_dotenv()
routertestcase = APIRouter(prefix="/api/test-case-generation", dependencies=[Depends(AuthValidation().wrapper)], tags=["Test Case Generation"])

container_name = os.getenv("BLOB_CONTAINER_NAME")


@routertestcase.get("/tasks")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    project_id: str = Query(..., description="Id of the project"),
):
    """Retrieves a paginated list of all tasks.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.
        project_id (str): Id of the project.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    try:
        task_collection_name = test_case_generation_task_config.get("collection_name")
        task_collection = MongoDB.get_collection(task_collection_name)
        # task = task_collection.find_one({"_id": ObjectId(project_id)})
        # Ensure the project_id is a valid ObjectId
        if not ObjectId.is_valid(project_id):
            raise HTTPException(status_code=400, detail="Invalid project_id format")

        # Filter tasks by project_id
        # Build the query to filter tasks
        query = {"project_id": project_id}
        if search:
            search_regex = {
                "$regex": search,
                "$options": "i",
            }  # Case-insensitive partial match
            query["$or"] = [
                {"task_name": search_regex},
                {"test_case_generation_output_file_name": search_regex},
                {"req_id_col": search_regex},
                {"req_text_col": search_regex},
                {"test_case_generation_status": search_regex},
                {"test_procedure_generation_status": search_regex},
            ]

        skip = (page - 1) * page_size

        # Fetch tasks and total count
        todos = list_serial(
            task_collection.find(query)
            .sort("created_timestamp", DESCENDING)
            .skip(skip)
            .limit(page_size)
        )
        total_count = task_collection.count_documents(query)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve tasks: {str(e)}") from e

    return {"Tasks": todos, "total_count": total_count}


def column_letter_to_index(column_letter: str) -> int:
    """Convert a single column letter (A-Z) to its corresponding zero-based index.

    Args:
        column_letter (str): A single uppercase or lowercase letter representing a column.
                             For example, 'A', 'B', 'C', etc.

    Returns:
        int: The zero-based index of the column letter.
        For example, 'A' returns 0, 'B' returns 1, etc.

    Raises:
        ValueError: If the input is not a single letter or if it's not an alphabetic character.
    """
    column_letter = column_letter.upper()
    if len(column_letter) != 1 or not column_letter.isalpha():
        raise ValueError("Invalid column letter")
    return ord(column_letter) - ord("A")


@routertestcase.post("/create_project/")
def create_project(
    background_tasks: BackgroundTasks,
    project_name: str = Form(...),
    agent_id: str = Form(...),
    user_details: dict = Depends(AuthValidation().wrapper),
    # email: str = Form(...),
    project_description: Optional[str] = Form(None),
    services_sheet_name: str = Form(...),
    services_sheet_top_header_rows: int = Form(),
    did_sheet_name: str = Form(),
    did_sheet_top_header_rows: int = Form(),
    did_col_num: str = Form(),
    dtc_sheet_name: str = Form(),
    dtc_sheet_top_header_rows: int = Form(),
    dtc_col_num: str = Form(),
    control_routine_sheet_name: str = Form(...),
    control_routine_sheet_top_header_rows: int = Form(),
    control_routine_col_num: str = Form(),
    project_requirement_file: UploadFile = File(...),
):
    """Creates a new project task and uploads the associated requirement file to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): FastAPI's BackgroundTasks instance for running tasks
                                            in the background.
        project_name (str): Name of the project.
        project_description: Optional[str] : Description of the project.
        services_sheet_name (str): Name of the services sheet.
        services_sheet_top_header_rows (int): Number of top header rows in the services sheet.
        did_sheet_name (str, optional): Name of the DID sheet.
        did_sheet_top_header_rows (int, optional): Number of top header rows in the DID sheet.
        did_col_num (int, optional): Column number for DID data.
        dtc_sheet_name (str, optional): Name of the DTC sheet.
        dtc_sheet_top_header_rows (int, optional): Number of top header rows in the DTC sheet.
        dtc_col_num (int, optional): Column number for DTC data.
        control_routine_sheet_name (str): Name of the control routine sheet.
        control_routine_sheet_top_header_rows (int): Number of top header rows
                                                     in the control routine sheet.
        control_routine_col_num (int): Column number for control routine data.
        project_requirement_file (UploadFile): The file containing project requirements.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    # Validate file extensions
    project_file_extension = os.path.splitext(project_requirement_file.filename)[1]
    # Validate that there are no double extensions
    base_filename = os.path.splitext(project_requirement_file.filename)[0]
    if re.search(r"\.[^.]+$", base_filename):
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only CSV and Excel files are allowed without double extensions.",
        )

    # Define supported file extensions
    supported_extensions = [".csv", ".xlsx"]
    if project_file_extension not in supported_extensions:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only CSV and Excel files are allowed.",
        )
    try:
        did_col_num = column_letter_to_index(did_col_num)
        dtc_col_num = column_letter_to_index(dtc_col_num)
        control_routine_col_num = column_letter_to_index(control_routine_col_num)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    task_data = {
        "project_name": project_name,
        "agent_id": agent_id,
        "email": user_details["email"],
        "project_description": project_description,
        "services_sheet_name": services_sheet_name,
        "services_sheet_top_header_rows": services_sheet_top_header_rows,
        "did_sheet_name": did_sheet_name,
        "did_sheet_top_header_rows": did_sheet_top_header_rows,
        "did_col_num": did_col_num,
        "dtc_sheet_name": dtc_sheet_name,
        "dtc_sheet_top_header_rows": dtc_sheet_top_header_rows,
        "dtc_col_num": dtc_col_num,
        "control_routine_sheet_name": control_routine_sheet_name,
        "control_routine_sheet_top_header_rows": control_routine_sheet_top_header_rows,
        "control_routine_col_num": control_routine_col_num,
        "created_timestamp": datetime.now(timezone.utc),
        "project_requirement_file": project_requirement_file.filename,
    }
    result = TaskManager.create_task(test_case_generation_config, task_data)
    task_id = str(result.inserted_id)
    task_manager = TaskManager(test_case_generation_config, task_id)
    logging.debug("Using collection name: %s", task_manager.get_collection_name())
    source_blob_path = get_blob_segment(
        task_id,
        test_case_generation_config["feature_name"],
        str(task_data["created_timestamp"]),
    )
    try:
        blob_manager = BlobClientManager()

        # upload source file
        blob_manager.upload_data_to_blob(
            blob_path=f"{source_blob_path}/{project_requirement_file.filename}",
            data=project_requirement_file.file.read(),
        )

    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Failed to upload file")
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}") from e
    return {"task_id": task_id}


@routertestcase.post("/filecolumns")
async def get_columns(file: UploadFile = File(...)):
    """Retrieves the column names from the uploaded file.

    Args:
        file (UploadFile): The file from which to extract column names.

    Raises:
        HTTPException: 400 Bad Request if the file is not a valid format.
        HTTPException: 500 Internal Server Error if there is an error processing the file.

    Returns:
        dict: A dictionary containing the column names.
            - columns (list): A list of column names.
    """
    file_extension = os.path.splitext(file.filename)[1].lower()
    try:
        file_bytes = await file.read()
        file_like = BytesIO(file_bytes)

        if file_extension in [".xlsx", ".xls"]:
            df = pd.read_excel(file_like)
        # elif file_extension == ".csv":
        #   file_like.seek(0)  # Reset cursor on the file-like object
        #  df = pd.read_csv(file_like)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")
        if df.dropna(how="all", axis=0).empty:
            raise HTTPException(status_code=400, detail="The rows below the headers are empty.")
        df = df.dropna(how="all", axis=1)
        columns = df.columns.tolist()
        # Check for 'Unnamed' columns that might be generated if headers are not properly provided
        if any("Unnamed" in col for col in columns):
            raise HTTPException(
                status_code=400,
                detail="Please review the headers and provide appropriate column names.",
            )

        return {"columns": columns}

    except ValueError as ve:
        raise HTTPException(status_code=400, detail=f"Value error: {str(ve)}")
    except pd.errors.EmptyDataError:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")
    except pd.errors.ParserError:
        raise HTTPException(
            status_code=400,
            detail="Error parsing the file. Please check the file content.",
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing the file: {str(e)}",
        )


@routertestcase.post("/sheetnames/")
async def get_sheet_names(file: UploadFile = File(...)):
    """Extracts and returns sheet names from an uploaded Excel or CSV file.

    Args:
        file (UploadFile): File to be uploaded must be an Excel or csv

    Raises:
        HTTPException: 400 Bad Request if the file is not a valid format.
        HTTPException: 500 Internal server error if there is an error processing the file.

    Returns:
      dict : A dictionary containing the sheet names.
    """
    file_extension = os.path.splitext(file.filename)[1]
    file_content = await file.read()
    try:
        if file_extension == FileType.EXCEL.value:
            df = pd.ExcelFile(io.BytesIO(file_content))
        # elif file_extension == FileType.CSV.value:
        #   df = pd.read_csv(file_content())
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")

        sheet_names = df.sheet_names
        return {"sheet_names": sheet_names}
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=f"Value error: {str(ve)}") from ve
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing the file: {str(e)}",
        ) from e


'''
@routertestcase.get("/projects")
async def get_all_projects():
    """Fetch all projects from the MongoDB collection.

    Returns:
        List[Dict]: A list of dictionaries where each dictionary represents a project.
    """
    project_collection_name = test_case_generation_config.get("collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)
    try:
        # Fetch all documents from the collection
        projects = list(project_collection.find({}))

        # Convert ObjectId to string for serialization
        for project in projects:
            project["_id"] = str(project["_id"])

        return projects
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch projects: {str(e)}") from e'''


@routertestcase.get("/projects_names/")
async def get_all_project_names():
    """Fetch all project names from the MongoDB collection.

    Returns:
        List[str]: A list of project names.
    """
    project_collection_name = test_case_generation_config.get("collection_name")
    collection = MongoDB.get_collection(project_collection_name)
    try:
        # Fetch only the 'project_name' field from all documents
        projects_cursor = collection.find({}, {"_id": 0, "project_name": 1})

        # Extract the 'project_name' field from each document
        project_names = [project["project_name"] for project in projects_cursor]

        return project_names
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch project names: {str(e)}"
        ) from e


@routertestcase.get("/")
async def find_all_projects_data(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of projects per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(
        None, description="Optional ID of the agent to filter projects"
    ),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all projects.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of projects per page, must be greater than 0.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict or list: A dictionary containing the retrieved projects and the total count if paginated,
                       or a list of all projects if not paginated.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    project_collection_name = test_case_generation_config.get("collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)
    task_collection_name = test_case_generation_task_config.get("collection_name")
    task_collection = MongoDB.get_collection(task_collection_name)

    try:
        query = {"email": email}
        if search:
            search_regex = {
                "$regex": search,
                "$options": "i",
            }  # Case-insensitive partial match
            query["$or"] = [
                {"project_name": search_regex},
                {"project_description": search_regex},
                {"project_requirement_file": search_regex},
            ]
        if agent_id:
            query["agent_id"] = agent_id  # Filter by agent_id if it is provided
        if page is not None and page_size is not None:
            # Pagination logic
            skip = (page - 1) * page_size
            projects = list_serial_project(
                project_collection.find(query)
                .sort("created_timestamp", DESCENDING)
                .skip(skip)
                .limit(page_size)
            )
            total_count = project_collection.count_documents(query)
        for project in projects:
            project_id = project.get("project_id")
            task_count = task_collection.count_documents({"project_id": project_id})
            project["task_count"] = task_count  # adding task count for each project
        return {"projects": projects, "total_count": total_count}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch projects: {str(e)}") from e


@routertestcase.post("/create_test_case_generation/")
async def create_test_case_generation(
    background_tasks: BackgroundTasks,
    agent_id: str = Form(...),
    task_name: str = Form(...),
    project_id: str = Form(...),
    did_requirement_file: UploadFile = File(...),  # comment project_related_document
    project_name: str = Form(...),
    req_text_col: str = Form(...),
    req_id_col: str = Form(...),
    # template_test_case: Optional[str] = Form(None)
):
    """Asynchronously creates a task for processing a requirement file and triggers execution of task test case generation, task test procedure generation.

    Args:
        background_tasks (BackgroundTasks): The background tasks instance for scheduling tasks.
        task_name (str, optional): Name of the task.
        project_id (str, optional): ID of the project associated with the task.
        did_requirement_file (UploadFile, optional): The file containing requirements,
                                                        which must be either a CSV or Excel file.
        req_text_col (str, optional): The name of the column in the requirement file
                                      that contains text.
        req_id_col (str, optional): The name of the column in the requirement file
                                      that contains IDs.

    Raises:
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
       dict: A dictionary containing:
                - `task_id`(str): the unique ID assigned to the created task.
                - 'result' (dict): task execution result i.e., result of test case generation.
                - `test_procedure_result` (dict): The result of the test procedure execution.

    Raises:
    - HTTPException : If the uploaded file is not supported or
                        if an error occurs during file upload.
    """
    template_test_case = None
    did_file_extension = os.path.splitext(did_requirement_file.filename)[1]
    base_filename = os.path.splitext(did_requirement_file.filename)[0]
    if re.search(r"\.[^.]+$", base_filename):
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only CSV and Excel files are allowed without double extensions.",
        )
    # Define supported file extensions
    supported_extensions = [".csv", ".xlsx"]
    if did_file_extension not in supported_extensions:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only CSV and Excel files are allowed.",
        )
    task_data = {
        "task_name": task_name,
        "agent_id": agent_id,
        "project_name": project_name,
        "did_requirement_file": did_requirement_file.filename,
        "req_text_col": req_text_col,
        "req_id_col": req_id_col,
        "test_case_generation_status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        # "output_file_name":"req_test_case_did_dtc_control_routine.xlsx",
        "test_case_generation_output_file_name": "test_case_generation_response.xlsx",
        "project_id": project_id,
        # "template_test_case": template_test_case
    }
    project_task_manager = TaskManager(test_case_generation_config, project_id)
    create_project_id = project_task_manager.get_task()

    result = TaskManager.create_task(test_case_generation_task_config, task_data)
    task_id = str(result.inserted_id)
    task_manager = TaskManager(test_case_generation_task_config, task_id)
    logging.debug("Using collection name: %s", task_manager.get_collection_name())

    did_blob_path = get_blob_segment(
        task_id,
        test_case_generation_config["feature_name"],
        str(task_data["created_timestamp"]),
    )

    try:
        blob_manager = BlobClientManager()

        # upload source file
        blob_manager.upload_data_to_blob(
            blob_path=f"{did_blob_path}/{did_requirement_file.filename}",
            data=did_requirement_file.file.read(),
        )

    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Failed to upload file")
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}") from e
    background_tasks.add_task(
        execute_task_test_case_generation,
        task_id,
        create_project_id,
        template_test_case,
    )
    return {"task_id": task_id}


def execute_task_test_case_generation(task_id: str, project_data: dict, template_test_case: str):
    """Processes a task by executing a test case generation function, handling file storage, and updating task status.

    Args:
        task_id (str): The unique identifier of the task to be executed.
        project_data (str): The unique identifier of the project related to the task.

    Returns:
        dict: A dictionary indicating the execution status.
            - status (str): "success" if execution is successful.
            - data (str): JSON string of the processed data if successful.

    Raises:
        HTTPException: 404 Not Found if the task is not found
                        or the downloaded/processed file is missing.
        HTTPException: 500 Internal Server Error if an error occurs
                        during the processing or uploading the processed file.
    """
    try:
        service_url = os.getenv("TEST_CASE_GENERATION_URL")
        loguru.logger.info("service_url", service_url)
        if not service_url:
            raise HTTPException(status_code=500, detail="Service URL not configured")

        project_task_manager = TaskManager(test_case_generation_config, project_data["_id"])
        task_manager = TaskManager(test_case_generation_task_config, task_id)

        task_manager.update_status(status=TaskStatus.PROCESSING.value)

        task = task_manager.get_task()
        project_task = project_task_manager.get_task()

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to update execute task: {str(e)}"
        ) from e

    requirement_filename = task.get("did_requirement_file")
    project_filename = project_data.get("project_requirement_file")
    requirement_filename = task.get("did_requirement_file")
    req_text_col = task.get("req_text_col", None)
    req_id_col = task.get("req_id_col", None)
    ##metadata##
    services_sheet_name = project_data.get("services_sheet_name", None)
    # project_description = project_data.get("project_description",None)
    services_sheet_top_header_rows = project_data.get("services_sheet_top_header_rows", None)

    test_case_data = {
        "req_id_col": req_id_col,
        "req_text_col": req_text_col,
        "services_sheet_name": services_sheet_name,
        "services_sheet_top_header_rows": services_sheet_top_header_rows,
        "template_test_case": template_test_case,
    }
    blob_req_path = get_blob_segment(
        task_id,
        test_case_generation_task_config["feature_name"],
        str(task["created_timestamp"]),
    )
    blob_project_path = get_blob_segment(
        project_data["_id"],
        test_case_generation_config["feature_name"],
        str(project_task["created_timestamp"]),
    )

    blob_project_path = f"{blob_project_path}/{project_filename}"
    blob_requirement_path = f"{blob_req_path}/{requirement_filename}"
    local_project_path = os.path.join("data", f"temp_{project_filename}")
    local_requirement_path = os.path.join("data", f"temp_{requirement_filename}")
    os.makedirs(os.path.dirname(local_project_path), exist_ok=True)
    os.makedirs(os.path.dirname(local_requirement_path), exist_ok=True)

    try:
        blob_manager = BlobClientManager()

        with open(local_project_path, "wb") as download_file:
            data = blob_manager.get_data_from_blob(blob_path=blob_project_path)
            download_file.write(data)

        with open(local_requirement_path, "wb") as download_file:
            data = blob_manager.get_data_from_blob(blob_path=blob_requirement_path)
            download_file.write(data)
    except Exception as e:
        task_manager.update_status(status=TaskStatus.FAILED.value, error_message="Blob not found")
        raise HTTPException(status_code=404, detail=f"Blob not found: {e}") from e

    if not os.path.isfile(local_project_path) or not os.path.isfile(local_requirement_path):
        task_manager.update_status(
            status=TaskStatus.FAILED.value, error_message="Files not downloaded successfully"
        )
        raise HTTPException(status_code=404, detail="Files not downloaded successfully.")

    headers = {
        "accept": "application/json",
    }
    files = {
        "req_file": (
            "DID_Req_ID_Text_short.xlsx",
            open(local_requirement_path, "rb"),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ),
        "project_data_file": (
            "PSCM Power Steering Control Module (VDS) A (E4u5).xlsx",
            open(local_project_path, "rb"),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ),
    }
    try:
        # Get prediction from the model API
        loguru.logger.info(f"URL: {service_url}")
        response = requests.post(url=service_url, headers=headers, files=files, data=test_case_data)
        # response.raise_for_status()  # Raises an error for HTTP error responses
        if response.status_code != 200:
            raise Exception(f"Model API returned status code {response.status_code}")
        content_type = response.headers.get("Content-Type", "")
        if "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" in content_type:
            # Save the response content to a file
            with open("data//test_case_generation_response.xlsx", "wb") as f:
                f.write(response.content)
        loguru.logger.info("Excel file saved as 'response.xlsx'")
    except Exception as e:
        task_manager.update_status(
            status=TaskStatus.FAILED.value, error_message="Error during model prediction"
        )
        raise HTTPException(status_code=500, detail=f"Error during model prediction: {e}") from e

    processed_filename = "test_case_generation_response.xlsx"
    local_processed_path = os.path.join("data", processed_filename)

    processed_blob_path = f"{blob_req_path}/{processed_filename}"

    try:
        # upload the excel and upload to blob storage
        with open(local_processed_path, "rb") as data:
            blob_manager.upload_data_to_blob(
                blob_path=processed_blob_path, data=data, processed=True
            )

    except Exception as e:
        task_manager.update_status(
            status=TaskStatus.FAILED.value, error_message="Failed to upload processed file"
        )
        raise HTTPException(status_code=500, detail=f"Failed to upload processed file: {e}") from e

    # Update the task status to success
    task_manager.update_status(status=TaskStatus.SUCCESS.value)

    try:
        file_data = blob_manager.get_data_from_blob(blob_path=processed_blob_path, processed=True)
        df = pd.read_excel(io.BytesIO(file_data), engine="openpyxl")  # for xlsx files

        # Convert DataFrame to JSON
        json_data = df.to_json(orient="records")
        return {"status": "success", "data": json_data}

    except Exception as e:
        task_manager.update_status(
            status=TaskStatus.FAILED.value, error_message="failed test case generation"
        )
        raise HTTPException(status_code=500, detail=str(e)) from e


class TestProcedureData(BaseModel):
    """Test the procedure data."""

    task_id: str
    project_id: str
    important_dids: Optional[List[str]] = None  # Optional list, defaults to None

    @classmethod
    def as_form(
        cls,
        task_id: str = Form(...),
        project_id: str = Form(...),
        important_dids: Optional[str] = Form(
            None
        ),  # Accept as a comma-separated string in the form
    ) -> "TestProcedureData":
        """Split comma-separated string into a list if provided, otherwise default to empty list."""
        return cls(
            task_id=task_id,
            project_id=project_id,
            important_dids=important_dids.split(",") if important_dids else [],
        )


@routertestcase.post("/create_test_procedure/")
async def create_test_case_procedure(
    background_tasks: BackgroundTasks,
    data: TestProcedureData = Depends(
        TestProcedureData.as_form
    ),  # Use dependency for parsing form data
):
    """Calls a background task by managing file downloads, and handling file uploads.

    Args:
        data (TestProcedureData): Parsed form data, including task ID, project ID, and important DIDs.

    Returns:
        dict: A dictionary indicating the execution status.
            - status (str): "success" if execution is successful.
            - message (str): A message describing the outcome.

    Raises:
        HTTPException: 404 Not Found if the task is not found or
                        the downloaded/processed file is missing.
        HTTPException: 500 Internal Server Error if an error occurs during the processing or
                        uploading the processed file or updating task status.
    """
    try:
        service_url = os.getenv("TEST_PROCEDURE_GENERATION_URL")
        if not service_url:
            raise HTTPException(status_code=500, detail="Service URL not configured")

        project_task_manager = TaskManager(test_case_generation_config, data.project_id)
        task_manager = TaskManager(test_case_generation_task_config, data.task_id)

        # Update task status in MongoDB
        task_manager.update_status(TaskStatus.PROCESSING.value)

        # Retrieve project and task details
        project = project_task_manager.get_task()
        task = task_manager.get_task()
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")

    except Exception as e:
        # Handle exception and update error status in MongoDB
        task_manager.update_status(
            status=TaskStatus.FAILED.value, error_message="Failed to execute task"
        )
        raise HTTPException(status_code=500, detail=f"Failed to execute task: {str(e)}") from e

    # Add background task for test procedure generation
    background_tasks.add_task(
        execute_task_test_procedure_generation,
        task_manager,
        task,
        project,
        service_url,
        data.task_id,
        data.important_dids,
    )
    return {"message": "Test case procedure is in progress, please come back after some time."}


def execute_task_test_procedure_generation(
    task_manager: TaskManager, task, project_id, service_url, task_id: str, important_dids
):
    """Executes the test procedure generation task by downloading necessary files, invoking a model API for prediction, and uploading results to blob storage.

    Args:
        task_collection: The MongoDB collection where task information is stored.
        task: A dictionary containing task-specific data, including metadata for files.
        project_id: A dictionary containing project-specific configuration and identifiers.
        service_url: The URL of the model API to invoke for test procedure generation.
        task_id: A string identifier for the current task.
        important_dids: A list of important Document IDs (DIDs) relevant to the task.

    Raises:
        HTTPException: Raises an HTTPException with status code 404 if blob files are not found,
                       and status code 500 for other errors during processing or API calls.

    Returns:
        A dictionary containing the status of the test procedure generation and the generated data in JSON format.
    """
    req_text_col = task.get("req_text_col", None)
    req_id_col = task.get("req_id_col", None)
    ##metadata##
    services_sheet_name = project_id.get("services_sheet_name", None)

    services_sheet_top_header_rows = project_id.get("services_sheet_top_header_rows", None)
    did_sheet_name = project_id.get("did_sheet_name", None)
    did_sheet_top_header_rows = project_id.get("did_sheet_top_header_rows", None)
    did_col_num = project_id.get("did_col_num", None)
    dtc_sheet_name = project_id.get("dtc_sheet_name", None)
    dtc_sheet_top_header_rows = project_id.get("dtc_sheet_top_header_rows", None)
    dtc_col_num = project_id.get("dtc_col_num", None)
    control_routine_sheet_name = project_id.get("control_routine_sheet_name", None)
    control_routine_sheet_top_header_rows = project_id.get(
        "control_routine_sheet_top_header_rows", None
    )
    control_routine_col_num = project_id.get("control_routine_col_num")
    project_task_id = str(project_id.get("_id"))

    test_procedure_data = {
        "req_text_col": req_text_col,
        "req_id_col": req_id_col,
        "services_sheet_name": services_sheet_name,
        "services_sheet_top_header_rows": services_sheet_top_header_rows,
        "did_sheet_name": did_sheet_name,
        "did_sheet_top_header_rows": did_sheet_top_header_rows,
        "did_col_num": did_col_num,
        "dtc_sheet_name": dtc_sheet_name,
        "dtc_sheet_top_header_rows": dtc_sheet_top_header_rows,
        "dtc_col_num": dtc_col_num,
        "control_routine_sheet_name": control_routine_sheet_name,
        "control_routine_sheet_top_header_rows": control_routine_sheet_top_header_rows,
        "control_routine_col_num": control_routine_col_num,
        "important_dids": important_dids,
    }
    # processed_filename = "test_case_generation_response.xlsx"
    project_filename = project_id.get("project_requirement_file")
    test_case_generation_output = task.get("test_case_generation_output_file_name")

    blob_manager = BlobClientManager()
    blob_project_path = get_blob_segment(
        project_id,
        test_case_generation_config["feature_name"],
        str(project_id["created_timestamp"]),
    )

    blob_req_path = get_blob_segment(
        task_id,
        test_case_generation_task_config["feature_name"],
        str(task["created_timestamp"]),
    )

    blob_project_path = f"{blob_project_path}/{project_filename}"
    local_processed_path = os.path.join("data", f"temp_{test_case_generation_output}")
    local_project_path = os.path.join("data", f"temp_{project_filename}")
    os.makedirs(os.path.dirname(local_project_path), exist_ok=True)
    os.makedirs(os.path.dirname(local_processed_path), exist_ok=True)

    processed_blob_path = f"{blob_req_path}/{test_case_generation_output}"

    try:
        with open(local_project_path, "wb") as download_file:
            data = blob_manager.get_data_from_blob(blob_path=blob_project_path)
            download_file.write(data)

        blob_client = blob_service_client.get_blob_client(
            container=container_name, blob=processed_blob_path
        )
        with open(local_processed_path, "wb") as download_file:
            data = blob_manager.get_data_from_blob(processed_blob_path, True)
            download_file.write(data)

    except Exception as e:
        task_manager.update_status(status=TaskStatus.FAILED.value, error_message="Blob not found")
        raise HTTPException(status_code=404, detail=f"Blob not found: {e}") from e

    if not os.path.isfile(local_project_path) or not os.path.isfile(local_processed_path):
        task_manager.update_status(
            status=TaskStatus.FAILED.value, error_message="Files not downloaded successfully."
        )
        raise HTTPException(status_code=404, detail="Files not downloaded successfully.")

    headers = {
        "accept": "application/json",
    }
    files = {
        "test_case_did_dtc_routine_file": (
            "test_case_generation_response.xlsx",
            open(local_processed_path, "rb"),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ),
        "project_data_file": (
            "PSCM Power Steering Control Module (VDS) A (E4u5).xlsx",
            open(local_project_path, "rb"),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ),
    }
    try:
        # Get prediction from the model API
        loguru.logger.info(f"URL: {service_url}")
        response = requests.post(
            url=service_url,
            headers=headers,
            files=files,
            data=test_procedure_data,
        )
        # response.raise_for_status()  # Raises an error for HTTP error responses
        if response.status_code != 200:
            raise Exception(f"Model API returned status code {response.status_code}")
        content_type = response.headers.get("Content-Type", "")
        if "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" in content_type:
            # Save the response content to a file
            with open("data//test_case_procedure_response.xlsx", "wb") as f:
                f.write(response.content)
        loguru.logger.info("Excel file saved as 'response.xlsx'")
    except Exception as e:
        task_manager.update_status(
            status=TaskStatus.FAILED.value, error_message="Error during model prediction"
        )
        raise HTTPException(status_code=500, detail=f"Error during model prediction: {e}") from e

    processed_procedure_filename = "test_case_procedure_response.xlsx"
    local_processed_procedure_path = os.path.join("data", processed_procedure_filename)
    processed_blob_path = f"{blob_req_path}/{processed_procedure_filename}"
    try:
        # upload the excel and upload to blob storage
        with open(local_processed_procedure_path, "rb") as data:
            blob_manager.upload_data_to_blob(
                blob_path=processed_blob_path, data=data, processed=True
            )

    except Exception as e:
        task_manager.update_status(
            status=TaskStatus.FAILED.value, error_message="Failed to upload processed file"
        )
        raise HTTPException(status_code=500, detail=f"Failed to upload processed file: {e}") from e
    try:
        # Update the task status to success
        task_manager.update_status(
            status=TaskStatus.SUCCESS.value, filename=processed_procedure_filename
        )
    except Exception as e:
        task_manager.update_status(
            status=TaskStatus.FAILED.value,
            error_message="Failed to update task status after processing",
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to update task status after processing: {e}",
        ) from e
    try:
        file_data = blob_manager.get_data_from_blob(processed_blob_path, True)
        df = pd.read_excel(io.BytesIO(file_data), engine="openpyxl")  # for xlsx files

        # Convert DataFrame to JSON
        json_data = df.to_json(orient="records")
        return {"status": "test_procedure_generation_success", "data": json_data}

    except Exception as e:
        task_manager.update_status(
            status=TaskStatus.FAILED.value,
            error_message="Failed to update task status after processing",
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to update task status after processing: {e}",
        ) from e


@routertestcase.get("/download_test_case/{task_id}")
def download_test_case_generation(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    task_collection_name = test_case_generation_task_config.get("collection_name")
    task_collection = MongoDB.get_collection(task_collection_name)
    task = task_collection.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    task_status = task.get("test_case_generation_status")
    if task_status == TaskStatus.PROCESSING.value:
        return Response(content="Task is still processing, please try again later.")
    elif task_status != TaskStatus.SUCCESS.value:
        # Additional failure modes can be handled here
        return Response(content="Task has failed or is in an unrecognized state.")
    test_case_generation_output_file_name = task.get("test_case_generation_output_file_name")
    # user_id = task.get("user_id")
    if not test_case_generation_output_file_name:
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    blob_path = f"{task_id}/{test_case_generation_output_file_name}"
    try:
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
        stream_downloader = blob_client.download_blob()
        file_data = stream_downloader.readall()
        return Response(
            content=file_data,
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": f"attachment;filename={test_case_generation_output_file_name}",
                "Access-Control-Expose-Headers": "Content-Disposition",
            },
        )
    except Exception as e:
        task_collection.update_one({"$set": {"status_error_message": "Blob download failed"}})
        raise HTTPException(
            status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e)
        ) from e


@routertestcase.get("/download_test_procedure/{task_id}")
def download_test_procedure_generation(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    task_collection_name = test_case_generation_task_config.get("collection_name")
    task_collection = MongoDB.get_collection(task_collection_name)
    task = task_collection.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    task_status = task.get("test_procedure_generation_status")
    if task_status == TaskStatus.PROCESSING.value:
        return Response(content="Task is still processing, please try again later.")
    elif task_status != TaskStatus.SUCCESS.value:
        # Additional failure modes can be handled here
        return Response(content="Task has failed or is in an unrecognized state.")

    test_procedure_generation_output_filename = task.get(
        "test_procedure_generation_output_filename"
    )  # test_procedure_generation
    if not test_procedure_generation_output_filename:
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    blob_path = f"{task_id}/{test_procedure_generation_output_filename}"
    try:
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
        stream_downloader = blob_client.download_blob()
        file_data = stream_downloader.readall()
        return Response(
            content=file_data,
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": f"attachment; filename={test_procedure_generation_output_filename}",
                "Access-Control-Expose-Headers": "Content-Disposition",
            },
        )
    except Exception as e:
        task_collection.update_one({"$set": {"status_error_message": "Blob download failed"}})
        raise HTTPException(
            status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e)
        ) from e


@routertestcase.delete("/tasks/{task_id}")
async def delete_task(id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    try:
        # collection = MongoDB.get_collection()
        task_collection_name = test_case_generation_task_config.get("collection_name")
        collection = MongoDB.get_collection(task_collection_name)
        result = collection.find_one_and_delete({"_id": ObjectId(id)})
    except Exception as e:
        collection.update_one({"$set": {"status_error_message": "Error deleting task in mongodb"}})
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@routertestcase.delete("/projects/{project_id}")
async def delete_project(id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    try:
        # collection = MongoDB.get_collection()
        project_collection_name = test_case_generation_config.get("collection_name")
        collection = MongoDB.get_collection(project_collection_name)
        result = collection.find_one_and_delete({"_id": ObjectId(id)})
    except Exception as e:
        collection.update_one({"$set": {"status_error_message": "Error deleting task in mongodb"}})
        logging.error(f"Error deleting project in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@routertestcase.get("/getProject/{project_id}")
async def get_project_by_id(project_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    project_collection_name = test_case_generation_config.get("collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)

    try:
        # Fetch the project from the collection using the project_id
        project = project_collection.find_one({"_id": ObjectId(project_id)})

        if project is None:
            raise HTTPException(status_code=404, detail="Project not found")
        # Convert ObjectId to string for serialization
        project["_id"] = str(project["_id"])

        return project

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e
