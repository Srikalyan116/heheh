"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import uuid
from zipfile import ZipFile
from pathlib import Path

import loguru
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from pymongo import DESCENDING

from src.config.config import design_requirement_config
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import TaskManager, get_tasks_from_db
from src.utils.common.helper import (
    get_blob_segment,
    sanitize_filename,
    validate_input_file_type_for_design_requirement,
)
from src.utils.design_requirement_schema import list_serial, list_serial_projects
from src.utils.mongo_db import MongoDB
from src.utils.utils_enum import RequestType, TaskError, TaskStatus
from src.utils.common.logger import set_job_context,trace_id_ctx, span_id_ctx, parent_span_id_ctx
from src.utils.common.logger import log as logging

load_dotenv()
design_requirement_router = APIRouter(
    prefix="/api/design-requirement",
    dependencies=[Depends(AuthValidation().wrapper)],
    tags=["Design Requirement"],
)


def get_rabbitmq(request: Request):
    """Get RabbitMQ Client."""
    return request.app.state.rabbitmq


@design_requirement_router.get("/")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks for authenticated user.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.
        user_details (dict): User details extracted from the validated token.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/design-requirement/",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "page": page,
        "page_size": page_size,
        "search": search,
        "agent_id": agent_id,
    }
    logging.info("Received request on /api/design-requirement/. Fetching all tasks", service=service, api_request=api_request, task_data=api_request_data)

    try:
        return get_tasks_from_db(
            design_requirement_config,
            email,
            page=page,
            page_size=page_size,
            search=search,
            agent_id=agent_id,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch data from collection: {str(e)}"
        )


@design_requirement_router.get("/tasks")
async def find_all_tasks_by_project(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    project: Optional[str] = Query(None, description="Project Name"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks in the project for authenticated user.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.
        project (str): Name of the project
        user_details (dict): User details extracted from the validated token.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/design-requirement/tasks",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "page": page,
        "page_size": page_size,
        "project": project,
    }
    logging.info("Received request on /api/design-requirement/tasks. Fetching all tasks in the project", service=service, api_request=api_request, task_data=api_request_data)

    try:
        collection_name = design_requirement_config.get("collection_name")
        collection = MongoDB.get_collection(collection_name)
        query = {"email": email, "project": project}
        skip = (page - 1) * page_size
        todos = list_serial(
            collection.find(query).sort("created_timestamp", DESCENDING).skip(skip).limit(page_size)
        )
        total_count = collection.count_documents(query)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve tasks: {str(e)}")
    return {"Tasks": todos, "total_count": total_count}


@design_requirement_router.get("/projects")
async def find_all_projects(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search_string: Optional[str] = Query(None, description="Search keyword for filtering projects"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks for authenticated user.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.
        user_details (dict): User details extracted from the validated token.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/design-requirement/projects",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "page": page,
        "page_size": page_size,
        "search_string": search_string
    }
    logging.info("Received request on /api/design-requirement/projects. Fetching all projects", service=service, api_request=api_request, task_data=api_request_data)

    try:
        collection_name = design_requirement_config.get("collection_name")
        collection = MongoDB.get_collection(collection_name)
        query = [
            {
                "$match": {
                    "email": email,
                    "project": {
                        "$regex": search_string if search_string else "",
                        "$options": "i",
                    },
                },
            },
            {
                "$group": {
                    "_id": "$project",
                    "total_count": {"$sum": 1},
                    "success_count": {
                        "$sum": {
                            "$cond": [
                                {"$eq": ["$status", TaskStatus.SUCCESS.value]},
                                1,
                                0,
                            ]
                        }
                    },
                    "failed_count": {
                        "$sum": {
                            "$cond": [
                                {"$eq": ["$status", TaskStatus.FAILED.value]},
                                1,
                                0,
                            ]
                        }
                    },
                    "processing_count": {
                        "$sum": {
                            "$cond": [
                                {"$eq": ["$status", TaskStatus.PROCESSING.value]},
                                1,
                                0,
                            ]
                        }
                    },
                    "created_timestamp": {"$min": "$created_timestamp"},
                }
            },
            {
                "$project": {
                    "project": "$_id",
                    "_id": 0,
                    "total_count": 1,
                    "success_count": 1,
                    "failed_count": 1,
                    "processing_count": 1,
                    "created_timestamp": 1,
                }
            },
            {"$sort": {"created_timestamp": -1}},
        ]
        results = collection.aggregate(query)
        projects_with_details = list_serial_projects(results)

        # Adding Filter
        records_to_skip = (page - 1) * page_size
        filtered_details = projects_with_details[records_to_skip : (records_to_skip + page_size)]

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve tasks: {str(e)}")
    return {
        "projects": filtered_details,
        "total_count": len(filtered_details),
    }


@design_requirement_router.post("/task/")
async def create_task(
    user_details: dict = Depends(AuthValidation().wrapper),
    project: str = Form(...),
    task_name: str = Form(...),
    generate_test_case: bool = False,
    input_file: UploadFile | None = File(None),
    files_to_skip: str = "",
    repo_url: str | None = Form(None),
    base_commit: str | None = Form(None),
    latest_commit: str | None = Form(None),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Creates a new task and uploads the file to Azure Blob Storage.

    Args:
        email (str): The email address of the user creating the task.
        project (str): The name of the project.
        task (str): The name of the task.
        input_file (UploadFile): The input file uploaded by the user.
        repo_url (str): The URL of the azure repos
        base_commit (str): The base commit for comparison
        latest_commit (str): The latest commit for comparison

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.


    Returns:
        dict: A dictionary containing the created task ID.
    """
    if isinstance(input_file, str):
        input_file = None
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/design-requirement/task",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "project": project,
        "input_file": input_file.filename if input_file else None,
        "task_name": task_name,
        "generate_test_case": generate_test_case,
        "files_to_skip": files_to_skip,
        "repo_url": repo_url,
        "base_commit": base_commit,
        "latest_commit": latest_commit,
    }
    logging.info("Received POST request on /api/design-requirement/task. Creating a request to generate design document", service=service, api_request=api_request, task_data=api_request_data)
    
    # tracing context variables for logging
    trace_id = trace_id_ctx.get() or str(uuid.uuid4())
    parent_span_id = parent_span_id_ctx.get() or str(uuid.uuid4())
    span_id = span_id_ctx.get() or str(uuid.uuid4())

    # determine the mode
    is_delta_task = (
        input_file is None
        and repo_url
        and base_commit
        and latest_commit
    )

    is_normal_task = input_file is not None

    if not is_delta_task and not is_normal_task:
        raise HTTPException(
            status_code=400,
            detail="Invalid request: Provide either input_file OR original_commit & latest_commit"
        )

    if is_delta_task and is_normal_task:
        raise HTTPException(
            status_code=400,
            detail="Invalid request: Cannot provide both input_file and delta commit inputs"
        )

    blob_manager = BlobClientManager()

    if is_delta_task:
        if repo_url and base_commit and latest_commit:
            repo_url = repo_url.strip()
            base_commit = base_commit.strip()
            latest_commit = latest_commit.strip()

        task_data = {
            "email": email,
            "status": TaskStatus.CREATED.value,
            "status_code": 102,
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
            "request_type": RequestType.MANUAL.value,
            "base_commit": base_commit,
            "latest_commit": latest_commit,
            "repo_url": repo_url,
            "project": project,
            "task_name": task_name,
            "delta_comparison": True,
            "generate_test_case": generate_test_case,
            "generate_design_doc": True,
            "input_filename": None,
            "number_of_files": None,
            "output_filename": None,
            "testcase_output_filename": None,
            "design_doc_status": TaskStatus.CREATED.value,
            "testcases_status": (TaskStatus.TASK_NOT_STARTED.value if generate_test_case else None),
            "files_to_skip": [],
        }

        result = TaskManager.create_task(design_requirement_config, task_data)
        task_id = str(result.inserted_id)

        task_manager = TaskManager(design_requirement_config, task_id)

        source_blob_path = get_blob_segment(
            task_id,
            design_requirement_config["feature_name"],
            str(task_data["created_timestamp"]),
            module_name="design_doc"
        )
            
        data_rabbit_mq = {
            "task_id": task_id,
            "repo_url": repo_url,
            "base_commit": base_commit,
            "latest_commit": latest_commit,
            "token": user_details.get("token", None),
            "generate_test_case": generate_test_case,
            "generate_design_doc": True,
            "blob_path": source_blob_path,
            "delta_comparison": True,
            "collection_name": task_manager.get_collection_name(),
            "design_doc_source_file": None,
            "design_doc_output_file": None,
            "testcase_output_file": None,
            "number_of_files": None,
            "filenames_to_consider": None,
            "files_to_skip": None,
            "trace_id": trace_id,
            "span_id": span_id
        }

        await rabbitmq.publish_task(
            design_requirement_config["queue_name"],
            data_rabbit_mq
        )

        task_manager.update_status(TaskStatus.PROCESSING.value)

        return {
            "message": "Delta task submitted",
            "task_id": task_id
        }

    # Normal flow
    # Validate file extensions
    if not validate_input_file_type_for_design_requirement(input_file.filename):
        logging.error(f"Unsupported file type. Only C, CPP and ZIP files are allowed.")
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only C, CPP and ZIP files are allowed.",
        )

    # Securely sanitize filename to prevent directory traversal
    original_filename = os.path.basename(input_file.filename) if input_file.filename else "unnamed_file"
    safe_filename = sanitize_filename(original_filename)
    # Use a secure method to create paths within a designated directory
    data_dir = Path("data")
    data_dir.mkdir(exist_ok=True)
    local_temp_path = data_dir / f"temp_{safe_filename}"

    # Write file content
    content = input_file.file.read()
    with open(local_temp_path, "wb") as f:
        f.write(content)

    # Reset file pointer for potential later use
    input_file.file.seek(0)

    if safe_filename.endswith(".zip"):
        output_filename = Path(safe_filename).stem + ".zip"
        testcase_output_filename = Path(safe_filename).stem + "_testcases.zip"
    else:
        output_filename = Path(safe_filename).stem + ".csv"
        testcase_output_filename = Path(safe_filename).stem + "_testcases.csv"

    # Getting number of files
    if output_filename.endswith(".zip"):
        # Create a new ZipFile object since we already read the file
        with ZipFile(local_temp_path) as zip_file:
            only_files = [
                file_name for file_name in zip_file.filelist if not file_name.filename.endswith("/")
            ]
            number_of_files = len(only_files)
            logging.info(f"Found {number_of_files} valid files for processing in the zip archive")
    else:
        number_of_files = 1

    # Create task data
    task_data = {
        "project": project,
        "email": user_details["email"],
        "input_filename": safe_filename,
        "status": TaskStatus.CREATED.value,
        "status_update_message": None,
        "status_code": None,
        "number_of_files": number_of_files,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
        "output_filename": output_filename,
        "task_name": task_name,
        "testcase_output_filename": testcase_output_filename,
        "design_doc_status": TaskStatus.CREATED.value,
        "files_to_skip": files_to_skip.split(",") if files_to_skip else [],
        "testcases_status": (TaskStatus.TASK_NOT_STARTED.value if generate_test_case else None),
        "generate_test_case": generate_test_case,
        "generate_design_doc": True,
    }

    try:
        logging.info(f"Creating task data")
        result = TaskManager.create_task(design_requirement_config, task_data)
    except Exception as e:
        logging.error(f"Failed writing data to MongoDB. {str(e)}")
        # loguru.logger.info(
        #     f"There is an error with inserting the data in MongoDB. The error is {str(e)}."
        # )
        raise HTTPException(status_code=500, detail="Failed to create task")

    task_id = str(result.inserted_id)
    set_job_context(task_id)
    task_manager = TaskManager(design_requirement_config, task_id)
    source_blob_path = get_blob_segment(
        task_id,
        design_requirement_config["feature_name"],
        str(task_data["created_timestamp"]),
        module_name="design_doc",
    )

    try:
        # Read file content again
        with open(local_temp_path, "rb") as f:
            data = f.read()

        logging.info(f"Writing source files to blob {source_blob_path}/{safe_filename}")
        # Upload source file
        blob_manager.upload_data_to_blob(
            blob_path=f"{source_blob_path}/{safe_filename}",
            data=data,
        )

    except Exception as e:
        logging.error(f"Failed uploading source files to blob. {str(e)}")
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Failed to upload file")
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")
    finally:
        # Always clean up temporary files regardless of success or failure
        if local_temp_path.exists():
            local_temp_path.unlink()

    data_rabbit_mq = {
        "design_doc_source_file": f"{source_blob_path}/{safe_filename}",
        "task_id": task_id,
        "design_doc_output_file": f"{source_blob_path}/{output_filename}",
        "generate_test_case": generate_test_case,
        "generate_design_doc": True,
        "testcase_output_file": (
            get_blob_segment(
                task_id,
                design_requirement_config["feature_name"],
                str(task_data["created_timestamp"]),
                module_name="testcases",
            )
            + "/"
            + testcase_output_filename
        ),
        "collection_name": task_manager.get_collection_name(),
        "file_count": number_of_files,
        "files_to_skip": task_data["files_to_skip"],
        "trace_id": trace_id,
        "span_id": span_id
    }
    logging.info(f"Publishing task to Queue {design_requirement_config['queue_name']}")
    await rabbitmq.publish_task(design_requirement_config["queue_name"], data_rabbit_mq)

    task_manager.update_status(TaskStatus.PROCESSING.value)

    # loguru.logger.info({"message": "Task submitted", "task_id": task_id})
    logging.info(f"Task submitted: {task_id}")
    return {"message": "Task submitted", "task_id": task_id}

@design_requirement_router.get("/add_testcases/{task_id}")
async def add_testcases(
    task_id: str,
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Retry failed files from the task_id

    Args:
        task_id (str): The unique identifier of the task to retry.

    Returns:
        String: success or failed state
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/design-requirement/add_testcases",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id
    }
    logging.info("Received POST request on /api/design-requirement/add_testcases. Creating a request to generate test cases", service=service, api_request=api_request, task_data=api_request_data)

    # tracing context variables for logging
    trace_id = trace_id_ctx.get() or str(uuid.uuid4())
    parent_span_id = parent_span_id_ctx.get() or str(uuid.uuid4())
    span_id = span_id_ctx.get() or str(uuid.uuid4())

    # Setting up the task manager
    task_manager = TaskManager(design_requirement_config, task_id)

    task_manager.update_record({"generate_test_case": True})

    # Fetch task details
    logging.debug(f"Fetching task details for task: {task_id}")
    task_data = task_manager.get_task()
    input_filename = task_data["input_filename"]
    output_filename = task_data["output_filename"]
    testcase_output_filename = task_data["testcase_output_filename"]
    generate_test_case = True
    delta_comparison = task_data.get("delta_comparison", False)
    source_blob_path = get_blob_segment(
        task_id,
        design_requirement_config["feature_name"],
        str(task_data["created_timestamp"]),
        module_name="design_doc",
    )
    if delta_comparison:
        data_rabbit_mq = {
            "design_doc_source_file": None,
            "task_id": task_id,
            "design_doc_output_file": None,
            "generate_test_case": generate_test_case,
            "generate_design_doc": False,
            "delta_comparison": delta_comparison,
            "blob_path": source_blob_path,
            "testcase_output_file": None,
            "collection_name": task_manager.get_collection_name(),
            "files_to_skip": None,
            "trace_id": trace_id,
            "span_id": span_id
        }
    else:
        data_rabbit_mq = {
            "design_doc_source_file": f"{source_blob_path}/{input_filename}",
            "task_id": task_id,
            "design_doc_output_file": f"{source_blob_path}/{output_filename}",
            "generate_test_case": generate_test_case,
            "generate_design_doc": False,
            "testcase_output_file": (
                get_blob_segment(
                    task_id,
                    design_requirement_config["feature_name"],
                    str(task_data["created_timestamp"]),
                    module_name="testcases",
                )
                + "/"
                + testcase_output_filename
            ),
            "collection_name": task_manager.get_collection_name(),
            "files_to_skip": task_data["files_to_skip"],
            "trace_id": trace_id,
            "span_id": span_id
        }
    logging.info(f"Publishing task to queue {design_requirement_config['queue_name']}")
    await rabbitmq.publish_task(design_requirement_config["queue_name"], data_rabbit_mq)

    task_manager.update_status(TaskStatus.PROCESSING.value)

    return {"message": "Task submitted", "task_id": task_id}


@design_requirement_router.get("/retry/{task_id}")
async def retry_task(task_id: str, 
                     rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
                     user_details: dict = Depends(AuthValidation().wrapper)):
    """Retry failed files from the task_id

    Args:
        task_id (str): The unique identifier of the task to retry.

    Returns:
        String: success or failed state
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/design-requirement/retry",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id
    }
    logging.info("Received GET request on /api/design-requirement/retry. Creating a request to retry", service=service, api_request=api_request, task_data=api_request_data)

    # tracing context variables for logging
    trace_id = trace_id_ctx.get() or str(uuid.uuid4())
    parent_span_id = parent_span_id_ctx.get() or str(uuid.uuid4())
    span_id = span_id_ctx.get() or str(uuid.uuid4())

    # Setting up the task manager
    task_manager = TaskManager(design_requirement_config, task_id)

    # Fetch task details
    logging.info(f"Fetching task details for task: {task_id}")
    task_data = task_manager.get_task()
    input_file = task_data["input_filename"]
    output_file = task_data["output_filename"]
    generate_test_case = task_data["generate_test_case"]
    generate_design_doc = task_data["generate_design_doc"]
    testcase_output_filename = task_data.get("testcase_output_filename", None)
    delta_comparison = task_data.get("delta_comparison", False)
    repo_url = task_data.get("repo_url")
    base_commit = task_data.get("base_commit")
    latest_commit = task_data.get("latest_commit")
    source_blob_path = get_blob_segment(
        task_id,
        design_requirement_config["feature_name"],
        str(task_data["created_timestamp"]),
        module_name="design_doc",
    )
    if delta_comparison:
        data_rabbit_mq = {
            "task_id": task_id,
            "repo_url": repo_url,
            "base_commit": base_commit,
            "latest_commit": latest_commit,
            "token": user_details.get("token", None),
            "generate_test_case": generate_test_case,
            "generate_design_doc": generate_design_doc,
            "delta_comparison": delta_comparison,
            "blob_path": source_blob_path,
            "collection_name": task_manager.get_collection_name(),
            "design_doc_source_file": None,
            "design_doc_output_file": None,
            "testcase_output_file": None,
            "files_to_skip": None,
            "trace_id": trace_id,
            "span_id": span_id
        }
    else:

        data_rabbit_mq = {
            "design_doc_source_file": f"{source_blob_path}/{input_file}",
            "task_id": task_id,
            "design_doc_output_file": f"{source_blob_path}/{output_file}",
            "generate_test_case": generate_test_case,
            "generate_design_doc": generate_design_doc,
            "filenames_to_consider": task_data.get("failed_filenames", []),
            "testcase_output_file": (
                get_blob_segment(
                    task_id,
                    design_requirement_config["feature_name"],
                    str(task_data["created_timestamp"]),
                    module_name="testcases",
                )
                + "/"
                + testcase_output_filename
            ),
            "collection_name": task_manager.get_collection_name(),
            "file_count": task_data["number_of_files"],
            "files_to_skip": task_data["files_to_skip"],
            "trace_id": trace_id,
            "span_id": span_id
        }

    # send the rabbitmq message
    logging.info(f"Publishing task data to queue {design_requirement_config['queue_name']}")
    await rabbitmq.publish_task(design_requirement_config["queue_name"], data_rabbit_mq)

    task_manager.update_status(TaskStatus.PROCESSING.value)

    return {"message": "Task submitted", "task_id": task_id}


@design_requirement_router.get("/download/{task_id}")
def download_task(task_id: str, testcases_doc: bool = False):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/design-requirement/download",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
        "testcases_doc": testcases_doc
    }
    logging.info("Received GET request on /api/design-requirement/download. Fetching task results", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(design_requirement_config, task_id)
    blob_manager_client = BlobClientManager()

    try:
        task = task_manager.get_task()
    except Exception as e:
        logging.error(f"Failed fetching task details for {task_id}. {str(e)}")
        raise HTTPException(status_code=500, detail=f"{TaskError.NOT_FOUND.value}: {str(e)}")

    if not task:
        logging.error(f"Failed fetching task details for {task_id}. Task not found in DB (might have been deleted).")
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)
    
    # Check the task status
    task_status = task.get("status")
    design_doc_process_status = task.get("design_doc_status")
    testcase_process_status = task.get("testcases_status")
    testcases_flag = task.get("generate_test_case")

    output_filename = task.get("output_filename")
    testcases_output_filename = task.get("testcase_output_filename")

    if not output_filename:
        logging.error(f"Missing output filename in task details")
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    if not testcases_doc:
        if design_doc_process_status == TaskStatus.PROCESSING.value:
            logging.info(f"Task under processing. Please, try again later")
            return Response(content="Design Doc is still processing, please try again later.")
        elif design_doc_process_status == TaskStatus.FAILED.value:
            # Additional failure modes can be handled here
            logging.error(f"Design Doc generation has failed or is in an unrecognized state.")
            return Response(content="Design Doc has failed or is in an unrecognized state.")
        blob_path = get_blob_segment(
            task_id,
            design_requirement_config["feature_name"],
            str(task.get("created_timestamp")),
            module_name="design_doc",
        )

        blob_path = f"{blob_path}/{output_filename}"
        try:
            logging.info(f"Fetching results from blob {blob_path}")
            file_data = blob_manager_client.get_data_from_blob(blob_path=blob_path, processed=True)
            return Response(
                content=file_data,
                media_type="application/octet-stream",
                headers={
                    "Content-Disposition": f"attachment; filename={output_filename}",
                    "Access-Control-Expose-Headers": "Content-Disposition",
                },
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e))
    else:
        if testcases_flag:
            if testcase_process_status == TaskStatus.PROCESSING.value:
                logging.info(f"Testcase doc generation under processing. Please, try again later")
                return Response(content="Testcase Doc is still processing, please try again later.")
            elif design_doc_process_status == TaskStatus.FAILED.value:
                # Additional failure modes can be handled here
                logging.error(f"Testcase Doc generation has failed or is in an unrecognized state.")
                return Response(content="Testcase Doc has failed or is in an unrecognized state.")
            else:
                pass
            if output_filename and (testcases_output_filename is None) and (testcase_process_status == TaskStatus.SUCCESS.value):
                blob_path = get_blob_segment(
                    task_id,
                    design_requirement_config["feature_name"],
                    str(task.get("created_timestamp")),
                    module_name="design_doc",
                )
                blob_path = f"{blob_path}/{output_filename}"
                testcases_output_filename = output_filename
            else:
                blob_path = get_blob_segment(
                    task_id,
                    design_requirement_config["feature_name"],
                    str(task.get("created_timestamp")),
                    module_name="testcases",
                )
                blob_path = f"{blob_path}/{testcases_output_filename}"
            try:
                logging.info(f"Fetching testcase doc from blob {blob_path}")
                file_data = blob_manager_client.get_data_from_blob(
                    blob_path=blob_path, processed=True
                )
                return Response(
                    content=file_data,
                    media_type="application/octet-stream",
                    headers={
                        "Content-Disposition": f"attachment; filename={testcases_output_filename}",
                        "Access-Control-Expose-Headers": "Content-Disposition",
                    },
                )
            except Exception as e:
                logging.error(f"Failed downloading files from blob. {str(e)} ")
                raise HTTPException(
                    status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e)
                )
        else:
            logging.error(f"Testcases not generated yet")
            raise HTTPException(status_code=404, detail="Testcases not generated yet")


@design_requirement_router.delete("/tasks/{id}")
async def delete_task(id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "DELETE",  # HTTP method
        "endpoint": f"/api/design-requirement/tasks",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "id": id,
    }
    logging.info("Received DELETE request on /api/design-requirement/tasks. Fetching and deleting task", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(design_requirement_config, id)
    try:
        logging.info(f"Deleting task details from DB")
        result = task_manager.hard_delete_task()
    except Exception as e:
        logging.error(f"Failed deleting tasks from MongoDB. {str(e)}")
        task_manager.update_status(
            TaskStatus.FAILED.value, error_message="Error deleting task in mongodb"
        )
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    if result:
        return {"message": "Task deleted"}
    return {"error": "Task not found"}


@design_requirement_router.get("/getProject/{task_id}")
async def get_project_by_id(task_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/design-requirement/getProject",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
    }
    logging.info("Received GET request on /api/design-requirement/getProject. Fetching project details", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(design_requirement_config, task_id)

    try:
        # Fetch the project from the collection using the project_id
        logging.info(f"Fetching project details from DB")
        task_data = task_manager.get_task()

        if task_data is None:
            logging.error(f"Failed finding Project with id {task_id}")
            raise HTTPException(status_code=404, detail="Project not found")

        # Convert ObjectId to string for serialization
        task_data["_id"] = str(task_data["_id"])

        return task_data

    except Exception as e:
        logging.error(f"Failed to fetch project: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e


@design_requirement_router.get("/download_url/{task_id}")
def temporary_download_url(task_id: str, testcases_doc: bool = False):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    service = {
        "name": "llm-api",
        "type": "backend",
        "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/design-requirement/download_url",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
        "testcases_doc": testcases_doc
    }
    logging.info("Received GET request on /api/design-requirement/download_url. Downloading task results", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(design_requirement_config, task_id)
    blob_manager_client = BlobClientManager()

    try:
        task = task_manager.get_task()
    except Exception as e:
        logging.error(f"Failed fetching task details for {task_id}. {str(e)}")
        raise HTTPException(status_code=500, detail=f"{TaskError.NOT_FOUND.value}: {str(e)}")

    if not task:
        logging.error(f"Failed fetching task details for {task_id}. Task not found in DB (might have been deleted).")
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    task_status = task.get("status")
    design_doc_process_status = task.get("design_doc_status")
    testcase_process_status = task.get("testcases_status")
    testcases_flag = task.get("generate_test_case")

    output_filename = task.get("output_filename")
    testcases_output_filename = task.get("testcase_output_filename")

    if not output_filename:
        logging.error(f"Missing filename from the task details")
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    if not testcases_doc:
        if design_doc_process_status == TaskStatus.PROCESSING.value:
            logging.error(f"Design Doc generation is in progress. Please, try again later")
            return Response(content="Design Doc is still processing, please try again later.")
        elif design_doc_process_status == TaskStatus.FAILED.value:
            # Additional failure modes can be handled here
            logging.error(f"Design Doc generation has failed or is in an unrecognized state.")
            return Response(content="Design Doc has failed or is in an unrecognized state.")
        blob_path = get_blob_segment(
            task_id,
            design_requirement_config["feature_name"],
            str(task.get("created_timestamp")),
            module_name="design_doc",
        )

        blob_path = f"{blob_path}/{output_filename}"
        blob_manager_client.get_downlod_url(blob_path=blob_path, processed=True)
        try:
            logging.info(f"Fetching download URL from blob {blob_path}")
            return blob_manager_client.get_downlod_url(blob_path=blob_path, processed=True)
        except Exception as e:
            raise HTTPException(status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e))
    else:
        if testcases_flag:
            if testcase_process_status == TaskStatus.PROCESSING.value:
                logging.info(f"Testcase Doc generation is under processing. Please, try again later.")
                return Response(content="Testcase Doc is still processing, please try again later.")
            elif design_doc_process_status == TaskStatus.FAILED.value:
                # Additional failure modes can be handled here
                logging.error(f"Testcase Doc has failed or is in an unrecognized state.")
                return Response(content="Testcase Doc has failed or is in an unrecognized state.")
            if output_filename and (testcases_output_filename is None) and (testcase_process_status == TaskStatus.SUCCESS.value):
                blob_path = get_blob_segment(
                    task_id,
                    design_requirement_config["feature_name"],
                    str(task.get("created_timestamp")),
                    module_name="design_doc",
                )
                blob_path = f"{blob_path}/{output_filename}"
            else:
                blob_path = get_blob_segment(
                    task_id,
                    design_requirement_config["feature_name"],
                    str(task.get("created_timestamp")),
                    module_name="testcases",
                )
                blob_path = f"{blob_path}/{testcases_output_filename}"
            try:
                logging.info("Successfully generated download URL")
                return blob_manager_client.get_downlod_url(blob_path=blob_path, processed=True)
            except Exception as e:
                logging.error(f"Failed generating URL from blob")
                raise HTTPException(
                    status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e)
                )
        else:
            logging.error("Testcases not generated yet")
            raise HTTPException(status_code=404, detail="Testcases not generated yet")
