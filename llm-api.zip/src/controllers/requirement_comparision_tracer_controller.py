"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import asyncio
import io
import json
import os
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from src.config.config import (
    requirement_comparison_tracer_config,
    requirement_comparison_tracer_prompt_config,
)
from src.controllers.code_beamer_controller import change_tracer_update
from src.exceptions.azure_exceptions import AzureBlobUploadFailedError
from src.exceptions.db_exceptions import RecordInsertionFailed
from src.models.change_tracer_model import ChangeTracerForm
from src.models.requirement_comparision_tracer_feedbacktask import UpdateItem
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.codebeamer_utils import save_tracker_items_as_excel
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import (
    TaskManager,
    get_collection_using_config,
    get_tasks_from_db,
)
from src.utils.common.helper import (
    clean_local_file,
    fetch_dataframe_from_file,
    get_blob_segment,
    get_collection_using_config,
    get_columns_from_file,
    get_queue_name_from_config,
)
from src.utils.constant import ID_TYPE, MENDATORY_KEYS_FOR_FEEDBACK, NON_ID_TYPE
from src.utils.feature.api_helper import (
    delete_blob_data,
    get_auth_token_from_headers,
    get_downloadable_data,
    get_task_by_id,
)
from src.utils.requirement_comparision_tracer_schema import get_task_data
from src.utils.utility import validate_input
from src.utils.utils_enum import APIMessages, RequestType, TaskStatus
from src.utils.common.logger import log as logging
from src.utils.common.logger import set_job_context,trace_id_ctx,span_id_ctx
load_dotenv()
routertracer = APIRouter(
    prefix="/api/requirement-comp-tracer", dependencies=[Depends(AuthValidation().wrapper)], tags=["Requirement Comparision tracer"]
)

container_name = os.getenv("BLOB_CONTAINER_NAME_RAW")
processed_container_name = os.getenv("BLOB_CONTAINER_NAME_PROCESS")



def get_rabbitmq(request: Request):
    """Get rabbitmq client based on the request.

    Parameters
    ----------
    request: Request
        request object to get the client.
    """
    return request.app.state.rabbitmq


@routertracer.get("/")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks for authenticated user.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.
        user_details (dict): User details extracted from the validated token.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    logging.info(f"Fetching tasks for user: {email}, page: {page}, page_size: {page_size}, search: {search}, agent_id: {agent_id}")
    try:
        tasks = get_tasks_from_db(
            requirement_comparison_tracer_config,
            email,
            page=page,
            page_size=page_size,
            search=search,
            agent_id=agent_id,
        )
        logging.info(f"Successfully retrieved tasks for user: {email}")
        return tasks
    except Exception as e:
        logging.error(f"Failed to retrieve tasks for user: {email}. Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve tasks: {str(e)}")


@routertracer.post("/filecolumns")
async def get_columns(file: UploadFile = File(...)):
    """Retrieves the column names from the uploaded file.

    Args:
        file (UploadFile): The file from which to extract column names.

    Raises:
        HTTPException: 400 Bad Request if the file is not a valid format.
        HTTPException: 500 Internal Server Error if there is an error processing the file.

    Returns:
        dict: A dictionary containing the column names.
            - columns (list): A list of column names.
    """
    logging.debug(f"Received request to extract columns from file: {file.filename}")
    try:
        content = await file.read()
        columns = get_columns_from_file(BytesIO(content), file.filename)
        logging.info(f"Successfully extracted columns from file: {file.filename}")
        return {"columns": columns}
    except ValueError as ve:
        logging.error(f"Value error while processing file {file.filename}: {str(ve)}")
        raise HTTPException(status_code=400, detail=f"Value error: {str(ve)}")
    except Exception as e:
        logging.error(f"An error occurred while processing file {file.filename}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing the file: {str(e)}",
        )


class RulesSchema(BaseModel):
    """Represents the rules structure for a task.

    Attributes:
        major (Optional[str]): Describes significant changes or additions that affect the task.
        minor (Optional[str]): Describes minor changes or adjustments that do not significantly alter the task.
        no_change (Optional[str]): Describes cosmetic or non-functional changes that do not affect the task outcome.
    """

    major_rules: List[str] = Field(...)
    minor_rules: List[str] = Field(...)
    no_change_rules: List[str] = Field(...)


class UpdateRuleRequest(BaseModel):
    """updates the rules structure for a task.

    Attributes:
        major (Optional[str]): Describes significant changes or additions that affect the task.
        minor (Optional[str]): Describes minor changes or adjustments that do not significantly alter the task.
        no_change (Optional[str]): Describes cosmetic or non-functional changes that do not affect the task outcome.
    """

    major: Optional[str]
    minor: Optional[str]
    no_change: Optional[str]


@routertracer.post("/create_rule/")
async def create_rule(request: Request):
    """Creates a new rule document in the MongoDB collection.

    Args:
        request (Request): The incoming HTTP request containing the JSON payload.

    Returns:
        dict: The inserted document without the MongoDB object ID.

    Raises:
        HTTPException: If the JSON format is invalid or if the task creation fails.
    """
    logging.info("Received request to create a new rule.")
    try:
        data = await request.json()
        logging.debug(f"Request data: {data}")
        data: dict = json.loads(data)

        # Parse the modified string to a dictionary
        try:
            rules_dict = data["rules"]
            logging.debug(f"Parsed rules: {rules_dict}")
        except json.JSONDecodeError:
            logging.error("Invalid JSON format for rules.")
            raise HTTPException(status_code=400, detail="Invalid JSON format for rules")

        task_data = {
            "user_id": data["user_id"],
            "project": data["project"],
            "rule_name": data["rule_name"],
            "rules": {
                "major_rules": rules_dict.get("major_rules", []),
                "minor_rules": rules_dict.get("minor_rules", []),
                "no_change_rules": rules_dict.get("no_change_rules", []),
            },
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
        }

        logging.debug(f"Task data to be inserted: {task_data}")
        result = TaskManager.create_task(requirement_comparison_tracer_prompt_config, task_data)

        if not result.inserted_id:
            logging.error("Failed to insert the rule into the database.")
            raise RecordInsertionFailed()

        logging.info(f"Rule created successfully with ID: {result.inserted_id}")
        rule_db_manager = TaskManager(
            requirement_comparison_tracer_prompt_config, result.inserted_id
        )
        return rule_db_manager.get_task()

    except Exception as e:
        logging.error(f"Error adding the rule: {str(e)}")
        raise HTTPException(status_code=500, detail="An error occurred while inserting the rule.")


@routertracer.get("/get_rule/{rule_id}", response_model=Dict[str, object])
async def get_rule(rule_id: str):
    """Fetch a specific rule document by rule_id from MongoDB."""
    logging.info(f"Received request to fetch rule with ID: {rule_id}")
    try:
        rule_db_manager = TaskManager(requirement_comparison_tracer_prompt_config, rule_id)

        # Query the rule in the database
        logging.debug(f"Querying database for rule with ID: {rule_id}")
        rule = rule_db_manager.get_task()
        rule["rule_id"] = str(rule["_id"])

        logging.info(f"Successfully retrieved rule with ID: {rule_id}")
        return rule

    except Exception as e:
        logging.error(f"Error retrieving rule with ID {rule_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="An error occurred while fetching the rule.")


@routertracer.put("/update_rule/")
async def update_rule(task_id: str, user_id: str, project: str, update_data: UpdateRuleRequest):
    """Updates an existing rule document in the MongoDB collection.

    Args:
        task_id (str): The unique identifier for the task to be updated.
        user_id (str): The user ID associated with the task.
        project (str): The project name associated with the task.
        update_data (UpdateRuleRequest): The data containing new values for `major`, `minor`, and `no_change` rules.

    Returns:
        dict: A message indicating the success of the update operation.

    Raises:
        HTTPException: If the task is not found in the collection or if no modifications were made.
    """
    logging.info(f"Received request to update rule with task_id: {task_id}, user_id: {user_id}, project: {project}")
    rule_manager = TaskManager(requirement_comparison_tracer_prompt_config, task_id)

    # Construct the update query
    update_fields = {}
    if update_data.major is not None:
        update_fields["rules.major"] = update_data.major
        logging.debug(f"Updating 'major' rules to: {update_data.major}")
    if update_data.minor is not None:
        update_fields["rules.minor"] = update_data.minor
        logging.debug(f"Updating 'minor' rules to: {update_data.minor}")
    if update_data.no_change is not None:
        update_fields["rules.no_change"] = update_data.no_change
        logging.debug(f"Updating 'no_change' rules to: {update_data.no_change}")

    # Add updated timestamp
    update_fields["lastupdated_timestamp"] = datetime.now(timezone.utc).isoformat()
    logging.debug(f"Setting 'lastupdated_timestamp' to: {update_fields['lastupdated_timestamp']}")

    # Perform the update
    try:
        logging.info(f"Attempting to update rule with task_id: {task_id}")
        result = rule_manager.update_record(update_fields)

        if result.matched_count == 0:
            logging.error(f"No document found with user_id: {user_id} and project_name: {project}")
            raise HTTPException(status_code=404, detail="Task not found")

        if result.modified_count == 0:
            logging.info(f"No changes made for task_id: {task_id}, fields may be the same as existing data")
            return {"message": "No changes made, fields may be the same as existing data"}

        logging.info(f"Successfully updated rule with task_id: {task_id}")
        return {"message": "Task updated successfully"}
    except Exception as e:
        logging.error(f"Error occurred while updating rule with task_id: {task_id}. Error: {str(e)}")
        raise HTTPException(status_code=500, detail="An error occurred while updating the rule.")


@routertracer.get("/list_all_tasks/", response_model=Dict[str, object])
async def list_all_tasks_rules(page: int = Query(1, ge=1), page_size: int = Query(10, ge=1)):
    """Retrieves a paginated list of all tasks from the MongoDB collection.

    Args:
        page (int): The page number to retrieve, with a default value of 1. Must be 1 or greater.
        page_size (int): The number of tasks to retrieve per page, with a default value of 10. Must be 1 or greater.

    Returns:
        Dict[str, object]: A dictionary containing the list of tasks and the total count of tasks.

    Raises:
        HTTPException: If no tasks are found in the specified page.
    """
    logging.info(f"Fetching tasks with page: {page}, page_size: {page_size}")
    collection = get_collection_using_config(requirement_comparison_tracer_prompt_config)

    # Calculate the number of documents to skip
    skip = (page - 1) * page_size
    logging.debug(f"Calculated skip value: {skip}")

    try:
        # Retrieve tasks with pagination
        tasks = list(collection.find().skip(skip).limit(page_size))
        logging.debug(f"Retrieved tasks: {tasks}")

        # Count the total number of tasks
        total_count = collection.count_documents({})
        logging.info(f"Total tasks count: {total_count}")

        if not tasks:
            logging.warning("No tasks found for the specified page and page size")
            raise HTTPException(status_code=404, detail="No tasks found")

        # Convert ObjectId to string for JSON serialization
        for task in tasks:
            task["_id"] = str(task["_id"])
            logging.debug(f"Converted ObjectId to string for task: {task}")

        logging.info("Successfully retrieved tasks")
        return {"tasks": tasks, "total_count": total_count}

    except Exception as e:
        logging.error(f"Error occurred while fetching tasks: {str(e)}")
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")


@routertracer.delete("/delete_task_rules/")
async def delete_task_rules(user_id: str, project: str):
    """Delete an existing rule document in the MongoDB collection.

    Args:
        task_id (str): The unique identifier for the task to be updated.
        user_id (str): The user ID associated with the task.
        project (str): The project name associated with the task.
        update_data (UpdateRuleRequest): The data containing new values for `major`, `minor`, and `no_change` rules.

    Returns:
        dict: A message indicating the success of the update operation.

    Raises:
        HTTPException: If the task is not found in the collection or if no modifications were made.
    """
    logging.info(f"Received request to delete task rules for user_id: {user_id}, project: {project}")
    collection = get_collection_using_config(requirement_comparison_tracer_prompt_config)

    try:
        # Perform the delete operation
        logging.debug(f"Attempting to delete task rules for user_id: {user_id}, project: {project}")
        result = collection.delete_one({"user_id": user_id, "project": project})

        if result.deleted_count == 0:
            logging.warning(f"No task rule found for user_id: {user_id}, project: {project}")
            raise HTTPException(status_code=404, detail="Task rule not found")

        logging.info(f"Successfully deleted task rules for user_id: {user_id}, project: {project}")
        return {"message": "Task rule and associated rules deleted successfully"}
    except Exception as e:
        logging.error(f"Error occurred while deleting task rules for user_id: {user_id}, project: {project}. Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")


@routertracer.post("/task/")
async def create_task(
    user_details: dict = Depends(AuthValidation().wrapper),
    form_data: ChangeTracerForm = Depends(),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Creates a new task and uploads the file to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): FastAPI's BackgroundTasks instance for running background tasks.
        email (str): The email address of the user creating the task.
        source_col_name (str): The name of the source column.
        revision_col_name (str): The name of the revision column.
        project (str): The name of the project.
        source_id (str): The ID of the source.
        revision_id (str): The ID of the revision.
        source_file (UploadFile): The source file uploaded by the user.
        target_file (UploadFile): The target file uploaded by the user.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    logging.info("Received request to create a new task.")
    logging.debug(f"Form data received: agent_id={form_data.agent_id}, rule_id={form_data.rule_id}, project={form_data.project}, "
                  f"source_file={form_data.source_file.filename}, revision_file={form_data.revision_file.filename}, "
                  f"isIdSelected={form_data.isIdSelected}, source_id={form_data.source_id}, source_col_name={form_data.source_col_name}, "
                  f"revision_id={form_data.revision_id}, revision_col_name={form_data.revision_col_name}")
    try:
        exception, exception_message, id_type, pdf_params = validate_input(form_data)
        logging.debug(f"Validation results: exception={exception}, message={exception_message}, id_type={id_type}, pdf_params={pdf_params}")

        if exception:
            logging.error(f"Validation failed: {exception_message}")
            raise HTTPException(
                status_code=400,
                detail=exception_message,
            )

        rule_manager = TaskManager(requirement_comparison_tracer_prompt_config, form_data.rule_id)
        rule_task = rule_manager.get_task()
        logging.debug(f"Retrieved rule task: {rule_task}")

        task_data = get_task_data(
            user_details,
            form_data,
            rule_task,
            id_type,
            pdf_params,
        )
        logging.debug(f"Generated task data: {task_data}")

        request_type = task_data.get("request_type")
        rules = rule_task.get("rules", None)
        try:
            result = TaskManager.create_task(requirement_comparison_tracer_config, task_data)
            logging.info(f"Task created successfully in MongoDB with ID: {result.inserted_id}")
        except Exception as e:
            logging.error(f"Error inserting data into MongoDB: {e}")
            raise

        task_id = str(result.inserted_id)
        set_job_context(task_id)
        source_blob_path = get_blob_segment(
            task_id,
            requirement_comparison_tracer_config["feature_name"],
            str(task_data["created_timestamp"]),
        )
        logging.debug(f"Generated source blob path: {source_blob_path}")

        task_manager = TaskManager(requirement_comparison_tracer_config, task_id)
        try:
            blob_manager = BlobClientManager()
            logging.debug(f"Uploading source file: {form_data.source_file.filename}")
            blob_manager.upload_data_to_blob(
                f"{source_blob_path}/{form_data.source_file.filename}",
                form_data.source_file.file.read(),
            )
            logging.debug(f"Uploading revision file: {form_data.revision_file.filename}")
            blob_manager.upload_data_to_blob(
                f"{source_blob_path}/{form_data.revision_file.filename}",
                form_data.revision_file.file.read(),
            )
            logging.info("Files uploaded successfully to Azure Blob Storage.")
        except Exception as e:
            logging.error(f"Failed to upload files to Azure Blob Storage: {e}")
            task_manager.update_status(
                TaskStatus.FAILED.value, error_message="Failed to upload the sources"
            )
            raise AzureBlobUploadFailedError()

        data_rabbit_mq = {
            "task_id": task_id,
            "trace_id": trace_id_ctx.get(),
            "parent_span_id": span_id_ctx.get(),
            "task_details": task_data,
            "collection_name": requirement_comparison_tracer_config["collection_name"],
            "rules": rules,
            "request_type": request_type,
        }
        logging.debug(f"Publishing task to RabbitMQ: {data_rabbit_mq}")
        await rabbitmq.publish_task(
            get_queue_name_from_config(requirement_comparison_tracer_config),
            data_rabbit_mq,
        )
        task_manager.update_status(TaskStatus.PROCESSING.value)
        logging.info(f"Task submitted successfully with ID: {task_id}")

        logging.info({"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id})
        return {"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id}
    except Exception as e:
        logging.error(f"An error occurred while creating the task: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@routertracer.post("/retry/{task_id}")
async def retry_task(
    task_id: str,
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Retry a specific task by task_id.

    The task status will be updated to 'PROCESSING',and the task will be added to the background task queue for execution.
    Args:
        task_id (str): The ID of the task to be retried.
        background_tasks (BackgroundTasks): BackgroundTasks instance for adding tasks to the background execution queue.

    Returns:
        dict: A message confirming the task is being retried and the task_id.

    Raises:
        HTTPException: If the task with the specified task_id is not found.
    """
    logging.info(f"Received request to retry task with ID: {task_id}")
    task_manager = TaskManager(requirement_comparison_tracer_config, task_id)
    task = task_manager.get_task()
    if not task:
        logging.error(f"Task with ID {task_id} not found.")
        raise HTTPException(status_code=404, detail="Task not found.")

    logging.info(f"Updating task status to PROCESSING for task ID: {task_id}")
    task_manager.update_status(TaskStatus.PROCESSING.value)

    rule_id = task.get("rule_id", None)
    request_type = task.get("request_type", None)
    logging.debug(f"Rule ID: {rule_id}, Request Type: {request_type}")

    # Update status fields in the task
    task["status"] = TaskStatus.CREATED.value
    task["created_timestamp"] = datetime.utcnow()
    task["lastupdated_timestamp"] = datetime.utcnow()
    new_msg_dict = {
        datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_RESTARTED.value
    }
    task["status_code"] = None
    new_update_msg = task.get("status_update_message")
    new_update_msg.update(new_msg_dict)
    logging.debug(f"Updated status message: {new_update_msg}")

    logging.info(f"Updating task status to TASK_RESTARTED for task ID: {task_id}")
    task_manager.update_status(TaskStatus.TASK_RESTARTED.value, status_update_message=new_update_msg)

    rule_manager = TaskManager(requirement_comparison_tracer_prompt_config, rule_id)
    rule_task = rule_manager.get_task()
    rules = rule_task.get("rules", None)
    logging.debug(f"Retrieved rules for task ID {task_id}: {rules}")

    data_rabbit_mq = {
        "task_id": task_id,
        "trace_id": trace_id_ctx.get(),
        "parent_span_id": span_id_ctx.get(),
        "task_details": task,
        "collection_name": task_manager.get_collection_name(),
        "rules": rules,
        "request_type": request_type,
        "id_type": task.get("id_type", None)
    }
    logging.info(f"Publishing task to RabbitMQ for task ID: {task_id}")
    await rabbitmq.publish_task(
        get_queue_name_from_config(requirement_comparison_tracer_config),
        data_rabbit_mq,
    )
    logging.info(f"Task successfully submitted to RabbitMQ with ID: {task_id}")
    return {"message": "Task submitted", "task_id": task_id}


@routertracer.delete("/tasks/{id}")
async def delete_task(id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    try:
        delete_blob_data(requirement_comparison_tracer_config, id)
        logging.info(f"Blob data deleted successfully for task ID: {id}")
    except Exception as e:
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    return {"message": "Task deleted"}


@routertracer.get("/download/{task_id}")
def download_task(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    logging.info(f"Received request to download task with ID: {task_id}")
    try:
        # Validate the task data from DB
        logging.debug(f"Validating task data for task ID: {task_id}")
        task_validation, message, filename, file_data = get_downloadable_data(
            requirement_comparison_tracer_config, task_id
        )

        # If the validation failed respond with the proper message
        if not task_validation:
            logging.warning(f"Task validation failed for task ID: {task_id}. Message: {message}")
            return Response(content=message)
        else:
            logging.info(f"Task validation successful for task ID: {task_id}. Preparing file for download.")
            return Response(
                content=file_data,
                media_type="application/octet-stream",
                headers={
                    "Content-Disposition": f"attachment; filename={filename}",
                    "Access-Control-Expose-Headers": "Content-Disposition",
                },
            )
    except Exception as e:
        logging.error(f"An error occurred while downloading task with ID: {task_id}. Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@routertracer.get("/feedback/{task_id}")
def feedback(task_id: str, page: int = 1, page_size: int = 10, prediction: Optional[str] = None):
    """Retrieve paginated feedback data for a given task.

    Args:
        task_id (str): The ID of the task.
        page (int): The page number for pagination. Defaults to 1.
        page_size (int): The number of items per page for pagination. Defaults to 10.

    Returns:
        JSONResponse: A JSON response containing paginated feedback data and total count.

    Raises:
        HTTPException: If the task is not found, if filename or prediction column name is missing,
                       if the prediction column is not found in the file, or if there is any other error.
    """
    logging.info(f"Received request to retrieve feedback for task ID: {task_id}, page: {page}, page_size: {page_size}, prediction: {prediction}")
    try:
        task_manager = TaskManager(requirement_comparison_tracer_config, task_id)
        task = task_manager.get_task()
        if not task:
            logging.error(f"Task with ID {task_id} not found.")
            raise HTTPException(status_code=404, detail="Task not found")

        filename = task.get("output_filename")
        if not filename:
            logging.error(f"Filename missing in task with ID {task_id}.")
            raise HTTPException(status_code=404, detail="Filename missing in task")

        temp = get_blob_segment(
            task_id,
            requirement_comparison_tracer_config["feature_name"],
            str(task["created_timestamp"]),
        )
        blob_path = f"{temp}/{filename}"
        logging.debug(f"Blob path for task ID {task_id}: {blob_path}")

        blob_manager = BlobClientManager()
        file_data = blob_manager.get_data_from_blob(blob_path, processed=True)
        file_name = Path(filename)
        df = fetch_dataframe_from_file(file_data, file_name.suffix)
        logging.info(f"Successfully fetched and processed file data for task ID {task_id}.")

        # Determine the file type and choose the appropriate method to load the data
        file_extension = os.path.splitext(filename)[1].lower()
        if file_extension == ".xlsx":
            df = pd.read_excel(io.BytesIO(file_data), engine="openpyxl")  # for xlsx files
        elif file_extension == ".csv":
            df = pd.read_csv(io.BytesIO(file_data), encoding="utf-8")  # for csv files
        else:
            logging.error(f"Unsupported file format for task ID {task_id}: {file_extension}")
            raise ValueError("Unsupported file format")

        if not prediction:
            prediction_list = list(set(df["changeType"]))
        else:
            prediction_list = prediction.strip().split("|")
        logging.debug(f"Prediction list for task ID {task_id}: {prediction_list}")

        filtered = df.loc[df["changeType"].str.strip().isin(prediction_list)]
        if filtered.shape[0]:
            filtered = filtered.rename(
                columns={
                    "source_description": "source",
                    "revision_description": "revision",
                }
            )

        filtered.replace([np.inf, -np.inf], np.nan, inplace=True)
        filtered.fillna("", inplace=True)

        records = filtered.to_dict(orient="records")
        logging.debug(f"Filtered records for task ID {task_id}: {records}")

        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        records = records[start_index : end_index + 1]
        change_counts = df["changeType"].str.strip().value_counts().to_dict()
        logging.debug(f"Change counts for task ID {task_id}: {change_counts}")

        mendatory_keys = MENDATORY_KEYS_FOR_FEEDBACK
        for key in mendatory_keys:
            if key not in change_counts.keys():
                change_counts[key] = 0

        logging.info(f"Successfully retrieved feedback data for task ID {task_id}.")
        return JSONResponse(
            content={
                "data": records,
                "total_count": df.shape[0],  # total number of filtered rows
                **change_counts,
            }
        )

    except Exception as e:
        logging.error(f"An error occurred while retrieving feedback for task ID {task_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@routertracer.patch("/update_feedback/{task_id}")
async def update_feedback(task_id: str, updates: List[UpdateItem]):
    """Update feedback data for a given task.

    Args:
        task_id (str): The ID of the task.
        updates (List[UpdateItem]): A list of updates to be applied to the task.

    Returns:
        JSONResponse: A JSON response indicating the success of the operation.

    Raises:
        HTTPException: If the task is not found, if filename or prediction column name is missing,
                       if the prediction column is not found in the file, or if there is any other error.
    """
    logging.info(f"Received request to update feedback for task ID: {task_id}")
    try:
        task_manager = TaskManager(requirement_comparison_tracer_config, task_id)
        task = task_manager.get_task()

        if not task:
            logging.error(f"Task with ID {task_id} not found.")
            raise HTTPException(status_code=404, detail="Task not found")

        filename = task.get("output_filename")
        if not filename:
            logging.error(f"Filename missing in task with ID {task_id}.")
            raise HTTPException(status_code=404, detail="Filename missing in task")

        logging.debug(f"Fetching blob segment for task ID: {task_id}")
        source_col_name = "source_description"
        revision_col_name = "revision_description"
        temp = get_blob_segment(
            task_id,
            requirement_comparison_tracer_config["feature_name"],
            str(task["created_timestamp"]),
        )
        blob_path = f"{temp}/{filename}"

        logging.debug(f"Blob path for task ID {task_id}: {blob_path}")
        blob_manager = BlobClientManager()
        filename = Path(filename)
        file_data = blob_manager.get_data_from_blob(blob_path, processed=True)

        logging.debug(f"Fetching DataFrame from file for task ID: {task_id}")
        df = fetch_dataframe_from_file(file_data, filename.suffix)

        if "feedback" not in df.columns:
            logging.debug("Adding 'feedback' column to DataFrame.")
            df["feedback"] = None
        if "changeType" not in df.columns:
            logging.debug("Adding 'changeType' column to DataFrame.")
            df["changeType"] = None

        if source_col_name not in df.columns:
            logging.error(f"Column '{source_col_name}' not found in file for task ID: {task_id}.")
            raise HTTPException(
                status_code=400, detail=f"Column '{source_col_name}' not found in file"
            )
        if revision_col_name not in df.columns:
            logging.error(f"Column '{revision_col_name}' not found in file for task ID: {task_id}.")
            raise HTTPException(
                status_code=400,
                detail=f"Column '{revision_col_name}' not found in file",
            )

        logging.debug("Filling NaN values in DataFrame.")
        df = df.fillna("")
        columns = list(df.columns)
        if "ID" in columns:
            logging.debug("Converting 'ID' column to string.")
            df["ID"] = df["ID"].astype(str)

        for update_data in updates:
            update = update_data.dict()
            logging.debug(f"Processing update: {update}")
            if "ID" in columns:
                if "ID" not in update.keys():
                    logging.error("ID column missing from input.")
                    raise HTTPException(status_code=400, detail=f"ID column missing from input")
                mask = df["ID"] == update["ID"]
            else:
                mask = (df["source_description"] == update["source"]) & (
                    df["revision_description"] == update["revision"]
                )
            df.loc[mask, "changeType"] = update["changeType"]
            if "feedback" in update.keys():
                if "feedback" not in columns:
                    logging.debug("Adding 'feedback' column to DataFrame.")
                    df["feedback"] = ""
                df.loc[mask, "feedback"] = update["feedback"]

        logging.debug("Saving updated DataFrame to BytesIO object.")
        output = io.BytesIO()
        if filename.suffix == ".xlsx":
            df.to_excel(output, index=False)  # for xlsx files
        elif filename.suffix == ".csv":
            df.to_csv(output, index=False)  # for csv files
        output.seek(0)

        logging.info(f"Uploading updated file back to Azure Blob Storage for task ID: {task_id}.")
        blob_manager.upload_data_to_blob(blob_path, output, processed=True)
        logging.info(f"Feedback updated successfully for task ID: {task_id}.")
        return {"message": "data updated", "task_id": task_id}

    except Exception as e:
        logging.error(f"An error occurred while updating feedback for task ID {task_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@routertracer.post("/cb/task")
async def create_task_codebeamer(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    rule_id: str = Form(...),
    agent_id: str = Form(...),
    project: str = Form(...),
    source_tracker: str = Form(...),
    revision_tracker: str = Form(...),
    source_uid: str = Form(...),
    revision_uid: str = Form(...),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Method to create a codebeamer Tracer task.

    Args:
        request (Request): Request object.
        background_tasks (BackgroundTasks): Background tasks object.
        user_details (dict, optional):  Defaults to Depends(AuthValidation().wrapper).
        rule_id: States the rules to be applied for classifying the changes.
        agent_id (str): Id of the agent.
        project(str) : Name of the Project from which Requirements are gathered.
        source_tracker (str,optional): Name of the source codebeamer tracker.
        revision_tracker (str,optional): Name of the revision codebeamer tracker.
        source_uid (str): Unique identifier for the source tracker.
        revision_uid (str): Unique identifier for the revision tracker
        rabbitmq: Manager for Notification.
    """
    logging.info("Received request to create a codebeamer Tracer task.")
    try:
        auth_token = get_auth_token_from_headers(request)
        logging.debug(f"Auth token retrieved: {auth_token}")

        rule_manager = TaskManager(requirement_comparison_tracer_prompt_config, rule_id)
        rule_task = rule_manager.get_task()
        logging.debug(f"Rule task retrieved: {rule_task}")

        task_data = {
            "rule_id": rule_id,
            "rule_name": rule_task.get("rule_name"),
            "agent_id": agent_id,
            "project": project,
            "email": user_details["email"],
            "status": TaskStatus.CREATED.value,
            "status_update_message": {
                datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
            },
            "status_code": None,
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
            "source_tracker": source_tracker,
            "revision_tracker": revision_tracker,
            "source_uid": source_uid,
            "revision_uid": revision_uid,
            "request_type": RequestType.CODEBEAMER.value,
            "output_filename": "output.xlsx",
        }
        logging.debug(f"Task data prepared: {task_data}")

        codebeamer_url = os.getenv("CODEBEAMER_URL")
        logging.debug(f"Codebeamer URL: {codebeamer_url}")

        source_task = asyncio.to_thread(
            save_tracker_items_as_excel,
            auth_token,
            codebeamer_url,
            project,
            source_tracker,
            source_uid,
        )
        revision_task = asyncio.to_thread(
            save_tracker_items_as_excel,
            auth_token,
            codebeamer_url,
            project,
            revision_tracker,
            revision_uid,
        )
        logging.info("Fetching source and revision tracker data.")
        source_temp_file_path, revision_temp_file_path = await asyncio.gather(
            source_task, revision_task
        )
        logging.debug(f"Source temp file path: {source_temp_file_path}, Revision temp file path: {revision_temp_file_path}")

        result = TaskManager.create_task(requirement_comparison_tracer_config, task_data)
        task_id = str(result.inserted_id)
        logging.info(f"Task created successfully in MongoDB with ID: {task_id}")

        task_manager = TaskManager(requirement_comparison_tracer_config, task_id)
        task = task_manager.get_task()
        logging.debug(f"Task retrieved: {task}")

        source_tracker = task.get("source_tracker")
        revision_tracker = task.get("revision_tracker")
        source_uid = task.get("source_uid")
        revision_uid = task.get("revision_uid")
        request_type = task.get("request_type")
        rules = rule_task.get("rules", None)
        logging.debug(f"Task details: source_tracker={source_tracker}, revision_tracker={revision_tracker}, rules={rules}")

        if not task:
            logging.error("Task not found after creation.")
            raise HTTPException(status_code=404, detail="Task not found")

        source_file = os.path.basename(source_temp_file_path)
        revision_file = os.path.basename(revision_temp_file_path)
        logging.debug(f"Source file: {source_file}, Revision file: {revision_file}")

        temp = get_blob_segment(
            task_id,
            requirement_comparison_tracer_config["feature_name"],
            str(task["created_timestamp"]),
        )
        logging.debug(f"Blob segment path: {temp}")

        try:
            blob_manager = BlobClientManager()
            logging.info("Uploading source and revision files to Azure Blob Storage.")
            with open(source_temp_file_path, "rb") as data:
                blob_manager.upload_data_to_blob(f"{temp}/{source_file}", data)
            with open(revision_temp_file_path, "rb") as data:
                blob_manager.upload_data_to_blob(f"{temp}/{revision_file}", data)
            logging.info("Files uploaded successfully to Azure Blob Storage.")
        except Exception as e:
            logging.error(f"Failed to upload files to Azure Blob Storage: {e}")
            task_manager.update_status(
                error_message="Blob not found", status=TaskStatus.FAILED.value
            )
            raise HTTPException(status_code=404, detail=f"Blob not found: {e}")

        clean_local_file(source_temp_file_path)
        clean_local_file(revision_temp_file_path)
        logging.debug("Temporary files cleaned up.")

        source_uid = None if source_uid == "undefined" else source_uid
        revision_uid = None if revision_uid == "undefined" else revision_uid

        data_rabbit_mq = {
            "task_id": task_id,
            "task_details": task_data,
            "collection_name": task_manager.get_collection_name(),
            "rules": rules,
            "request_type": request_type,
            "id_type": ID_TYPE if (revision_uid and source_uid) else NON_ID_TYPE,
        }
        logging.debug(f"Data prepared for RabbitMQ: {data_rabbit_mq}")

        await rabbitmq.publish_task(
            get_queue_name_from_config(requirement_comparison_tracer_config),
            data_rabbit_mq,
        )
        logging.info(f"Task published to RabbitMQ successfully with ID: {task_id}")

        task_manager.update_status(TaskStatus.PROCESSING.value)
        logging.info(f"Task status updated to PROCESSING for task ID: {task_id}")

        return {"message": "Task submitted", "task_id": task_id}
    except Exception as e:
        logging.error(f"Issue publishing task to RabbitMQ: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Issue publishing task to RabbitMQ: {str(e)}",
        )


@routertracer.get("/getProject/{project_id}")
async def get_project_by_id(project_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    logging.info(f"Received request to fetch project with ID: {project_id}")
    try:
        project = get_task_by_id(requirement_comparison_tracer_config, project_id)
        logging.info(f"Successfully retrieved project with ID: {project_id}")
        return project

    except Exception as e:
        logging.error(f"Failed to fetch project with ID {project_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e


@routertracer.get("/update/codebeamer/{task_id}")
async def update_codebeamer(
    request: Request,
    task_id: str,
    user_details: dict = Depends(AuthValidation().wrapper),
):
    logging.info(f"Received request to update codebeamer task with ID: {task_id}")
    try:
        logging.debug(f"Request details: {request}, User details: {user_details}")
        await change_tracer_update(request, task_id, user_details)
        logging.info(f"Successfully updated codebeamer task with ID: {task_id}")
        return {"message": "success"}
    except Exception as e:
        logging.error(f"Failed to process request for task ID {task_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process request : {e}")
