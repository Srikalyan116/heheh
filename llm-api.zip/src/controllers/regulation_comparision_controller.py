"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import json
import logging
import os
from datetime import datetime, timezone
from io import BytesIO
from typing import Optional

import loguru
import pandas as pd
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from pymongo import DESCENDING

from src.config.config import regulation_comparision_config
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.mongo_db import MongoDB
from src.utils.regulation_comparision_schema import list_serial
from src.utils.utils_enum import TaskError, TaskStatus
from src.utils.common.azure_helper import blob_service_client

# from src.main import rabbitmq


# rabbitmq = RabbitMQManager("localhost")
# rabbitmq.initialize()
load_dotenv()
routerreg = APIRouter(prefix="/api/regulation-comp", dependencies=[Depends(AuthValidation().wrapper)], tags=["Regulation Comparision"])

container_name = os.getenv("BLOB_CONTAINER_NAME_RAW")
processed_container_name = os.getenv("BLOB_CONTAINER_NAME_PROCESS")



def get_rabbitmq(request: Request):
    """Get Rabbit MQ client.

    Parameters
    ----------
    request: Request
        request for the client
    """
    return request.app.state.rabbitmq


@routerreg.get("/")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all users.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    try:
        collection_name = regulation_comparision_config.get("collection_name")
        collection = MongoDB.get_collection(collection_name)
        query = {"email": email}
        if search:
            search_regex = {
                "$regex": search,
                "$options": "i",
            }  # Case-insensitive partial match
            query["$or"] = [
                {"status": search_regex},
            ]
        if agent_id:
            query["agent_id"] = agent_id  # Only add agent_id to query if it is provided
        skip = (page - 1) * page_size
        todos = list_serial(
            collection.find(query).sort("created_timestamp", DESCENDING).skip(skip).limit(page_size)
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")
    # total_count = collection.count_documents({})
    total_count = collection.count_documents(query)
    return {"Tasks": todos, "total_count": total_count}


@routerreg.post("/filecolumns")
async def get_columns(file: UploadFile = File(...)):
    """Retrieves the column names from the uploaded file.

    Args:
        file (UploadFile): The file from which to extract column names.

    Raises:
        HTTPException: 400 Bad Request if the file is not a valid format.
        HTTPException: 500 Internal Server Error if there is an error processing the file.

    Returns:
        dict: A dictionary containing the column names.
            - columns (list): A list of column names.
    """
    file_extension = os.path.splitext(file.filename)[1].lower()
    try:
        file_bytes = await file.read()
        file_like = BytesIO(file_bytes)

        if file_extension in [".xlsx", ".xls"]:
            df = pd.read_excel(file_like)
        elif file_extension == ".csv":
            file_like.seek(0)  # Reset cursor on the file-like object
            df = pd.read_csv(file_like)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")

        if df.dropna(how="all", axis=0).empty:
            raise HTTPException(status_code=400, detail="The rows below the headers are empty.")

        # Drop columns that are completely empty
        df = df.dropna(how="all", axis=1)
        # Check for 'Unnamed' columns that might be generated if headers are not properly provided
        columns = df.columns.tolist()
        if any("Unnamed" in col for col in columns):
            raise HTTPException(
                status_code=400,
                detail="Please review the headers and provide appropriate column names.",
            )

        # columns = df.columns.tolist()
        return {"columns": columns}

    except ValueError as ve:
        raise HTTPException(status_code=400, detail=f"Value error: {str(ve)}")
    except pd.errors.EmptyDataError:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")
    except pd.errors.ParserError:
        raise HTTPException(
            status_code=400,
            detail="Error parsing the file. Please check the file content.",
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing the file: {str(e)}",
        )


@routerreg.post("/task/")
async def create_task(
    background_tasks: BackgroundTasks,
    user_details: dict = Depends(AuthValidation().wrapper),
    agent_id=Form(...),
    source_extract_col_name: str = Form(default=None),
    target_extract_col_name: str = Form(default=None),
    source_file: UploadFile = File(...),
    target_file: UploadFile = File(...),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Creates a new task and uploads the file to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): FastAPI's BackgroundTasks instance for running background tasks.
        email (str): The email address of the user creating the task.
        source_file (UploadFile): The source file uploaded by the user.
        target_file (UploadFile): The target file uploaded by the user.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    # Validate file extensions
    allowed_extensions = [".pdf", ".xlsx", ".xls"]
    source_file_extension = os.path.splitext(source_file.filename)[1]
    target_file_extension = os.path.splitext(target_file.filename)[1]
    if (
        source_file_extension not in allowed_extensions
        or target_file_extension not in allowed_extensions
    ):
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only PDF and Excel files are allowed.",
        )

    task_data = {
        "user_id": None,
        "email": user_details["email"],
        "agent_id": agent_id,
        "output_filename": None,
        "match_json_file": None,
        "source_filename": source_file.filename,
        "target_filename": target_file.filename,
        "source_extract_col_name": source_extract_col_name,
        "target_extract_col_name": target_extract_col_name,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.utcnow(),
        "lastupdated_timestamp": datetime.utcnow(),
    }
    collection_name = regulation_comparision_config.get("collection_name")
    logging.debug("Using collection name: %s", collection_name)
    collection = MongoDB.get_collection(collection_name)
    try:
        result = collection.insert_one(task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    source_blob_path = f"{task_id}/{source_file.filename}"
    target_blob_path = f"{task_id}/{target_file.filename}"
    try:
        file_urls = {}
        # upload source file
        source_blob_client = blob_service_client.get_blob_client(
            container=container_name, blob=source_blob_path
        )
        source_file_contents = source_file.file.read()  # Read file asynchronously
        source_blob_client.upload_blob(
            source_file_contents, overwrite=True
        )  # Upload file asynchronously
        file_urls["source_file_url"] = source_blob_client.url
        # Upload target file
        target_blob_client = blob_service_client.get_blob_client(
            container=container_name, blob=target_blob_path
        )
        target_file_contents = target_file.file.read()  # Read file asynchronously
        target_blob_client.upload_blob(
            target_file_contents, overwrite=True
        )  # Upload file asynchronously
        file_urls["target_file_url"] = target_blob_client.url
    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {
                "$set": {
                    "upload_status": "FAILED",
                    "status_error_message": f"Failed to upload file: {str(e)}",
                    "lastupdated_timestamp": datetime.now(timezone.utc),
                }
            },
        )
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")
    # background_tasks.add_task(execute_task, task_id)
    data_rabbit_mq = {
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": collection_name,
    }
    await rabbitmq.publish_task("regulation_comparison", data_rabbit_mq)
    collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.PROCESSING.value,
                "lastupdated_timestamp": datetime.utcnow(),
            }
        },
    )
    loguru.logger.info({"message": "Task submitted", "task_id": task_id})
    return {"message": "Task submitted", "task_id": task_id}


@routerreg.post("/retry/{task_id}")
async def retry_task(
    task_id: str,
    background_tasks: BackgroundTasks,
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Retry a specific task by task_id.

    The task status will be updated to 'PROCESSING',and the task will be added to the background task queue for execution.
    Args:
        task_id (str): The ID of the task to be retried.
        background_tasks (BackgroundTasks): BackgroundTasks instance for adding tasks to the background execution queue.

    Returns:
        dict: A message confirming the task is being retried and the task_id.

    Raises:
        HTTPException: If the task with the specified task_id is not found.
    """
    collection_name = regulation_comparision_config.get("collection_name")
    collection = MongoDB.get_collection(collection_name)
    task = collection.find_one({"_id": ObjectId(task_id)})

    if not task:
        raise HTTPException(status_code=404, detail="Task not found.")

    collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": TaskStatus.PROCESSING.value,
                "status_update_message": {
                    datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
                },
                "status_code": None,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            }
        },
    )
    # background_tasks.add_task(execute_task, task_id)
    source_filename = task.get("source_filename")
    target_filename = task.get("target_filename")
    source_extract_col_name = task.get("source_extract_col_name")
    target_extract_col_name = task.get("target_extract_col_name")

    task_data = {
        "source_filename": source_filename,
        "target_filename": target_filename,
        "source_extract_col_name": source_extract_col_name,
        "target_extract_col_name": target_extract_col_name,
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.utcnow(),
        "lastupdated_timestamp": datetime.utcnow(),
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
    }
    data_rabbit_mq = {
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": collection_name,
    }
    await rabbitmq.publish_task("regulation_comparison", data_rabbit_mq)
    loguru.logger.info({"message": "Task submitted", "task_id": task_id})
    return {"message": "Task submitted", "task_id": task_id}


@routerreg.delete("/tasks/{id}")
async def delete_task(id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    try:
        collection_name = regulation_comparision_config.get("collection_name")
        collection = MongoDB.get_collection(collection_name)

        result = collection.find_one_and_delete({"_id": ObjectId(id)})
    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(id)},
            {"$set": {"status_error_message": "Error deleting task in mongodb"}},
        )
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@routerreg.get("/download/{task_id}")
def download_task(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    collection_name = regulation_comparision_config.get("collection_name")
    collection = MongoDB.get_collection(collection_name)
    task = collection.find_one({"_id": ObjectId(task_id)})
    if not task:
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    task_status = task.get("status")
    if task_status == TaskStatus.PROCESSING.value:
        return Response(content="Task is still processing, please try again later.")
    elif task_status != TaskStatus.SUCCESS.value:
        # Additional failure modes can be handled here
        return Response(content="Task has failed or is in an unrecognized state.")

    filename = task.get("output_filename")
    if not filename:
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    blob_path = f"{task_id}/{filename}"
    try:
        blob_client = blob_service_client.get_blob_client(
            container=processed_container_name, blob=blob_path
        )
        stream_downloader = blob_client.download_blob()
        file_data = stream_downloader.readall()
        return Response(
            content=file_data,
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "Access-Control-Expose-Headers": "Content-Disposition",
            },
        )
    except Exception as e:
        collection.update_one(
            {"_id": ObjectId(task_id)},
            {"$set": {"status_error_message": "Blob download failed"}},
        )
        raise HTTPException(status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e))


@routerreg.get("/regulation_matching/{task_id}/download")
async def download_json(task_id: str):
    """Fetches the final JSON file for a given task.

    Returns:
        JSON: The contents of the downloaded JSON file.

    Raises:
        HTTPException: If the task is not found (404).
        HTTPException: If the filename is missing (404).
        HTTPException: If there is an error downloading the blob (500).
        HTTPException: If there is a general error (500).
    """
    try:
        collection_name = regulation_comparision_config.get("collection_name")
        collection = MongoDB.get_collection(collection_name)
        task = collection.find_one({"_id": ObjectId(task_id)})
        if not task:
            raise HTTPException(status_code=404, detail="Task not found.")

        filename = task.get("match_json_file")
        if not filename:
            raise HTTPException(status_code=404, detail="Filename is missing.")

        blob_path = f"{task_id}/{filename}"
        try:
            blob_client = blob_service_client.get_blob_client(
                container=processed_container_name, blob=blob_path
            )
            stream_downloader = blob_client.download_blob()
            file_data = stream_downloader.readall()
            file_json = json.loads(file_data)
            return file_json
        except Exception as e:
            collection.update_one(
                {"_id": ObjectId(task_id)},
                {"$set": {"status_error_message": "Blob download failed"}},
            )
            raise HTTPException(status_code=500, detail=f"Blob download failed: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")


@routerreg.get("/getProject/{project_id}")
async def get_project_by_id(project_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    project_collection_name = regulation_comparision_config.get("collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)

    try:
        # Fetch the project from the collection using the project_id
        project = project_collection.find_one({"_id": ObjectId(project_id)})

        if project is None:
            raise HTTPException(status_code=404, detail="Project not found")
        # Convert ObjectId to string for serialization
        project["_id"] = str(project["_id"])

        return project

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e
