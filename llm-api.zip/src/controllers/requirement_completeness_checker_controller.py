"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import asyncio
import io
import json
import logging
import os
from datetime import datetime, timezone
import tempfile
from typing import Optional

import loguru
import numpy as np
import pandas as pd
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    Body,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from fastapi.responses import JSONResponse
from pymongo import DESCENDING

from src.config.config import requirement_completeness_checker_config
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import TaskManager
from src.utils.common.helper import (
    clean_local_file,
    fetch_dataframe_with_sheets,
    get_blob_segment,
    validate_input_file_type, validate_object_id, sanitize_filename,
)
from src.utils.mongo_db import MongoDB
from src.utils.requirement_completeness_checker_schema import list_serial
from src.utils.utils_enum import RequestType, TaskError, TaskStatus

load_dotenv()
req_completeness_router = APIRouter(
    prefix="/api/requirement-completeness-checker",
    dependencies=[Depends(AuthValidation().wrapper)],
    tags=["Requirement Completeness Checker"],
)


def get_rabbitmq(request: Request):
    """Get RabbitMQ Client."""
    return request.app.state.rabbitmq


@req_completeness_router.get("/")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks for authenticated user.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.
        user_details (dict): User details extracted from the validated token.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    try:
        collection_name = requirement_completeness_checker_config.get("collection_name")
        collection = MongoDB.get_collection(collection_name)
        query = {"email": email}
        if search:
            search_regex = {
                "$regex": search,
                "$options": "i",
            }  # Case-insensitive partial match
            query["$or"] = [
                {"project": search_regex},
                {"input_filename": search_regex},
                {"status": search_regex},
            ]

        if agent_id:
            query["agent_id"] = agent_id  # Only add agent_id to query if it is provided
        skip = (page - 1) * page_size
        todos = list_serial(
            collection.find(query).sort("created_timestamp", DESCENDING).skip(skip).limit(page_size)
        )
        total_count = collection.count_documents(query)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve tasks: {str(e)}")
    return {"Tasks": todos, "total_count": total_count}


@req_completeness_router.post("/task/")
async def create_task(
    user_details: dict = Depends(AuthValidation().wrapper),
    agent_id=Form(...),
    project: Optional[str] = Form(""),
    input_file: UploadFile = File(...),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Creates a new task and uploads the file to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): FastAPI's BackgroundTasks instance for running background tasks.
        email (str): The email address of the user creating the task.
        source_col_name (str): The name of the source column.
        revision_col_name (str): The name of the revision column.
        project (str): The name of the project.
        source_id (str): The ID of the source.
        revision_id (str): The ID of the revision.
        source_file (UploadFile): The source file uploaded by the user.
        target_file (UploadFile): The target file uploaded by the user.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    blob_manager = BlobClientManager()

    # Validate file extensions
    if not validate_input_file_type(input_file.filename):
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only CSV, Excel and Json files are allowed.",
        )

    # Create task data
    task_data = {
        "project": project,
        "email": user_details["email"],
        "agent_id": agent_id,
        "output_filename": (
            "output.json" if input_file.filename.endswith(".json") else "output.xlsx"
        ),
        "input_filename": input_file.filename,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
    }

    try:
        result = TaskManager.create_task(requirement_completeness_checker_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    task_manager = TaskManager(requirement_completeness_checker_config, task_id)
    source_blob_path = f"{task_id}/{input_file.filename}"
    try:
        # upload source file
        blob_manager.upload_data_to_blob(
            blob_path=source_blob_path, data=input_file.file.read(), processed=False
        )

    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Failed to upload file")
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

    data_rabbit_mq = {
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": task_manager.get_collection_name(),
    }

    await rabbitmq.publish_task("req_complete_checker", data_rabbit_mq)
    task_manager.update_status(TaskStatus.PROCESSING.value)

    loguru.logger.info({"message": "Task submitted", "task_id": task_id})
    return {"message": "Task submitted", "task_id": task_id}


@req_completeness_router.get("/download/{task_id}")
def download_task(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    task_manager = TaskManager(requirement_completeness_checker_config, task_id)
    blob_manager_client = BlobClientManager()
    task = task_manager.get_task()
    if not task:
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    task_status = task.get("status")
    if task_status == TaskStatus.PROCESSING.value:
        return Response(content="Task is still processing, please try again later.")
    elif task_status != TaskStatus.SUCCESS.value:
        # Additional failure modes can be handled here
        return Response(content="Task has failed or is in an unrecognized state.")

    output_filename = task.get("output_filename")
    media_type = "json" if output_filename.endswith(".json") else "octet-stream"

    if not output_filename:
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    blob_path = f"{task_id}/{output_filename}"
    try:
        file_data = blob_manager_client.get_data_from_blob(blob_path=blob_path, processed=True)
        return Response(
            content=file_data,
            media_type=f"application/{media_type}",
            headers={
                "Content-Disposition": f"attachment; filename={output_filename}",
                "Access-Control-Expose-Headers": "Content-Disposition",
            },
        )
    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Blob download failed")
        raise HTTPException(status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e))


@req_completeness_router.delete("/tasks/{id}")
async def delete_task(id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    task_manager = TaskManager(requirement_completeness_checker_config, id)
    try:
        result = task_manager.delete_task()
    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value, error_message="Error deleting task in mongodb"
        )
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    if result:
        return {"message": "Task deleted"}
    return {"error": "Task not found"}


@req_completeness_router.get("/feedback/{task_id}")
def feedback(
    task_id: str,
    criticality: int = -1,
    module_name: str = "",
    page: int = 1,
    page_size: int | None = None,
):
    """Retrieve paginated feedback data for a given task.

    Args:
        task_id (str): The ID of the task.
        criticality (int): The criticality of the task in each sheet. Defaults to -1. Allowed range [0, 5]
        module_name (int): The module_name page whose data is needed. Defaults to "".
            (Allowed values ["Contradictions Report", "Missing Conditions Report", "Raw Report"])

    Returns:
        JSONResponse: A JSON response containing paginated feedback data and total count.

    Raises:
        HTTPException: If the task is not found, if filename or prediction column name is missing,
                       if the prediction column is not found in the file, or if there is any other error.
    """
    # Initialize the variables
    sheets = ["Contradictions Report", "Missing Conditions Report", "Raw Report"]
    feedback_sheets = ["Contradictions Report", "Missing Conditions Report"]
    sheets_data: dict[str, pd.DataFrame] = {}

    # Standard Result format
    feedback_data = {}

    level_name = "Criticality Score"

    # Validate filter if given
    if module_name and module_name not in sheets:
        raise HTTPException(status_code=404, detail="Module not found")

    # # Validating criticality filter
    if criticality > 5 or criticality < -1:
        raise HTTPException(status_code=422, detail="Invalid criticality level")

    task_manager = TaskManager(requirement_completeness_checker_config, task_id)
    task_data = task_manager.get_task()

    # Checking for task status
    if task_data["status"] == TaskStatus.PROCESSING.value:
        raise HTTPException(
            status_code=404,
            detail="Document is in processing state output file not generated",
        )
    elif task_data["status"] == TaskStatus.FAILED.value:
        raise HTTPException(status_code=404, detail="Model Failed output file not generated")

    blob_manager = BlobClientManager()

    if not task_data:
        raise HTTPException(status_code=404, detail="Task not found")

    filename = task_data.get("input_filename")
    output_filename = task_data.get("output_filename")

    if not filename:
        raise HTTPException(status_code=404, detail="Filename missing in task")

    blob_path = f"{task_id}/{output_filename}"

    try:
        file_data = blob_manager.get_data_from_blob(blob_path, processed=True)

        for sheet in sheets:
            sheets_data[sheet] = fetch_dataframe_with_sheets(io.BytesIO(file_data), sheet)

        # Get len of the records in each sheet
        for sheet, sheet_data in sheets_data.items():

            if "Criticality Sore" in sheet_data.columns:
                sheet_data.rename(columns={"Criticality Sore": level_name}, inplace=True)

            criticality_count = []
            for criticality_level in range(0, 6):
                if level_name in list(sheet_data.columns):
                    criticality_count.append(
                        len(sheet_data.loc[sheet_data[level_name] == criticality_level])
                    )
                else:
                    criticality_count.append(0)

            feedback_data[sheet] = {
                "total": len(sheet_data),
                level_name: criticality_count,
            }

        # Prepare the result with required fields using apply
        def get_row_data(row):
            result = {}

            for column_name in row.index:
                result[column_name] = row[column_name]

            # If old format exists go with "All Conditions Criticality" else use the updated column names
            if level_name not in list(row.index):
                result[level_name] = 0

            return result

        for sheet, sheet_data in sheets_data.items():

            if "feedback_status" not in sheet_data.columns:
                sheet_data["feedback_status"] = ""

            if "feedback_comment" not in sheet_data.columns:
                sheet_data["feedback_comment"] = ""

            # Only fetch the data required module and ignore the rest
            if module_name:
                if sheet != module_name:
                    feedback_data[sheet]["data"] = []
                    continue

            if len(sheet_data) > 0:
                sheet_data.replace([np.inf, -np.inf], np.nan, inplace=True)
                sheet_data.fillna("", inplace=True)

                # Criticality filter
                if criticality >= 0:
                    sheet_data = sheet_data.loc[sheet_data[level_name] == criticality]

                # Pagination
                if page_size is not None:
                    start_index = (page - 1) * page_size
                    end_index = start_index + page_size
                    sheet_data = sheet_data.iloc[start_index:end_index]

                feedback_data[sheet]["data"] = sheet_data.apply(get_row_data, axis=1).tolist()
            else:
                feedback_data[sheet]["data"] = []
        return JSONResponse(content=feedback_data)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@req_completeness_router.patch("/feedback/{task_id}")
def update_feedback(
    task_id: str,
    updates: list[dict] = [],
    module_name: str = "Contradictions Report",
):
    """Retrieve paginated feedback data for a given task.

    Args:
        task_id (str): The ID of the task.
        updates (list[dict]): The rows along with feedback
        module_name (int): The module_name page whose data is needed. Defaults to "".
            (Allowed values ["Contradictions Report", "Missing Conditions Report"])

    Returns:
        JSONResponse: A JSON response containing paginated feedback data and total count.

    Raises:
        HTTPException: If the task is not found, if filename or prediction column name is missing,
                       if the prediction column is not found in the file, or if there is any other error.
    """

    if not validate_object_id(task_id):
        raise HTTPException(status_code=400, detail="Invalid task ID format")

    sheets = ["Contradictions Report", "Missing Conditions Report", "Raw Report"]
    feedback_sheets = ["Contradictions Report", "Missing Conditions Report"]
    columns_to_verify = ["Outlinks", "Module ID", "Outlinks Text", "Object Text"]
    sheets_data: dict[str, pd.DataFrame] = {}

    task_manager = TaskManager(requirement_completeness_checker_config, task_id)
    task_data = task_manager.get_task()

    if module_name not in feedback_sheets:
        raise HTTPException(
            status_code=404,
            detail="module name not found",
        )

    # Checking for task status
    if task_data["status"] == TaskStatus.PROCESSING.value:
        raise HTTPException(
            status_code=404,
            detail="Document is in processing state output file not generated",
        )
    elif task_data["status"] == TaskStatus.FAILED.value:
        raise HTTPException(status_code=404, detail="Model Failed output file not generated")

    blob_manager = BlobClientManager()

    if not task_data:
        raise HTTPException(status_code=404, detail="Task not found")

    filename = task_data.get("input_filename")
    output_filename = task_data.get("output_filename")

    if not filename:
        raise HTTPException(status_code=404, detail="Filename missing in task")

    safe_output_filename = sanitize_filename(output_filename)
    blob_path = f"{task_id}/{safe_output_filename}"

    try:
        file_data = blob_manager.get_data_from_blob(blob_path, processed=True)

        for sheet in sheets:
            sheets_data[sheet] = fetch_dataframe_with_sheets(io.BytesIO(file_data), sheet)

        df = sheets_data[module_name]
        if "Criticality Sore" in df.columns:
            df.rename(columns={"Criticality Sore": "Criticality Score"}, inplace=True)
        df.replace([np.inf, -np.inf], np.nan, inplace=True)
        df.fillna("", inplace=True)

        if "feedback_comment" not in df.columns:
            df["feedback_comment"] = ""

        if "feedback_status" not in df.columns:
            df["feedback_status"] = ""

        updates_df = pd.DataFrame(updates)

        def update_row(row, updates_df):
            feedback_filtered = updates_df
            feedback_status = ""
            feedback_comment = ""
            for column_name in columns_to_verify:
                feedback_filtered = updates_df.loc[updates_df[column_name] == row[column_name]]
                if len(feedback_filtered) > 1:
                    continue
                elif len(feedback_filtered) == 1:
                    feedback_status = feedback_filtered["feedback_status"].iloc[0]
                    feedback_comment = feedback_filtered["feedback_comment"].iloc[0]
                    break

            row["feedback_status"] = feedback_status
            row["feedback_comment"] = feedback_comment

            return row

        df = df.apply(update_row, axis=1, updates_df=updates_df)
        sheets_data[module_name] = df

         # Securely create a temporary file
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
            temp_file_path = temp_file.name

        with pd.ExcelWriter(temp_file_path, engine="openpyxl") as writer:
            for sheet, sheet_data in sheets_data.items():
                sheet_data.to_excel(writer, sheet_name=sheet, index=False)

        with open(temp_file_path, "rb") as data:
            # Upload the updated file back to Azure Blob Storage
            blob_manager.upload_data_to_blob(blob_path=blob_path, data=data.read(), processed=True)

        return {"status": "update success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if temp_file_path and os.path.exists(temp_file_path):
            os.remove(temp_file_path)


@req_completeness_router.get("/getProject/{task_id}")
async def get_project_by_id(task_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    task_manager = TaskManager(requirement_completeness_checker_config, task_id)

    try:
        # Fetch the project from the collection using the project_id
        project = task_manager.get_task()

        if project is None:
            raise HTTPException(status_code=404, detail="Project not found")

        # Convert ObjectId to string for serialization
        project["_id"] = str(project["_id"])

        return project

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e


@req_completeness_router.post("/check/completeness")
async def check_completeness(
    user_details: dict = Depends(AuthValidation().wrapper),
    agent_id: str = Form(...),
    project: Optional[str] = Form(""),
    input_file: UploadFile = File(...),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """API to check completeness of the customer and system requirement pairs uploaded by user.

    Args:
        user_details (dict, optional):  Defaults to Depends(AuthValidation().wrapper).
        agent_id (str): Id of the agent.
        project (str): Name of the project for which reuirements are analyzed.
        input_file (UploadFile): JSON file uploaded by the user.
        rabbitmq (RabbitMQManager): Manager for Notification.
    """
    # Create azure blob client
    blob_manager = BlobClientManager()

    # Validate file extensions
    if not validate_input_file_type(input_file.filename):
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only Json files are allowed.",
        )

    # Create task data
    task_data = {
        "project": project,
        "email": user_details["email"],
        "agent_id": agent_id,
        "output_filename": "output.json",
        "input_filename": input_file.filename,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
    }

    # Create task in the database.
    try:
        result = TaskManager.create_task(requirement_completeness_checker_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    # Get the task id and create a task manager object.
    task_id = str(result.inserted_id)
    task_manager = TaskManager(requirement_completeness_checker_config, task_id)

    # Upload the input file in blob.
    source_blob_path = f"{task_id}/{input_file.filename}"
    try:
        # upload source file
        blob_manager.upload_data_to_blob(
            blob_path=source_blob_path, data=input_file.file.read(), processed=False
        )
    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Failed to upload file")
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

    # Publish task in rabbitmq.
    data_rabbit_mq = {
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": task_manager.get_collection_name(),
    }
    await rabbitmq.publish_task("req_complete_checker", data_rabbit_mq)
    task_manager.update_status(TaskStatus.PROCESSING.value)

    loguru.logger.info({"message": "Task submitted", "task_id": task_id})

    # Setup polling for fetching the result.
    elapsed = 0
    poll_interval = 2
    timeout = 60

    # start polling with an interval of 2 secs.
    while elapsed < timeout:
        # Get the task status
        task = task_manager.get_task()
        task_status = task.get("status")

        if task_status == TaskStatus.PROCESSING.value:
            loguru.logger.info(f"Task status - {task_status}")
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval
            continue

        elif task_status != TaskStatus.SUCCESS.value:
            loguru.logger.info(f"Task status - {task_status}")
            return Response(content="Task has failed or is in an unrecognized state.")

        loguru.logger.info(f"Task completed.")
        output_filename = task.get("output_filename")

        if not output_filename:
            raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

        loguru.logger.info("Dowloading the output file.")
        blob_path = f"{task_id}/{output_filename}"
        try:
            file_data = blob_manager.get_data_from_blob(blob_path=blob_path, processed=True)
            return Response(
                content=file_data,
                media_type="application/json",
                headers={
                    "Content-Disposition": f"attachment; filename={output_filename}",
                    "Access-Control-Expose-Headers": "Content-Disposition",
                },
            )
        except Exception as e:
            task_manager.update_status(
                TaskStatus.FAILED.value, error_message="Blob download failed"
            )
            raise HTTPException(status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e))

    # Raise error in case there is a timeout.
    loguru.logger.error("Task timed out.")
    raise HTTPException(status_code=408, detail="Task timed out. Try again.")


@req_completeness_router.post("/json/task/")
async def create_task(
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
    data: dict = Body(...),  # Accepts any JSON object
):
    """Creates a new task and uploads the file to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): FastAPI's BackgroundTasks instance for running background tasks.
        email (str): The email address of the user creating the task.
        source_col_name (str): The name of the source column.
        revision_col_name (str): The name of the revision column.
        project (str): The name of the project.
        source_id (str): The ID of the source.
        revision_id (str): The ID of the revision.
        source_file (UploadFile): The source file uploaded by the user.
        target_file (UploadFile): The target file uploaded by the user.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    blob_manager = BlobClientManager()
    result = {}
    if data:
        for item in data["data"]:
            for key in list(item.keys()):
                val = item[key]
                if isinstance(val, dict) and "ID" in val and "text" in val:
                    item[key] = {val["ID"]: val["text"]}

    json_data = json.dumps(data)
    json_bytes = json_data.encode("utf-8")
    # Create task data
    task_data = {
        "email": user_details["email"],
        "output_filename": "output.json",
        "input_filename": "data.json",
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
    }
    #
    try:
        result = TaskManager.create_task(requirement_completeness_checker_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    task_manager = TaskManager(requirement_completeness_checker_config, task_id)
    source_blob_path = f"{task_id}/" + "data.json"
    try:
        # upload source file
        blob_manager.upload_data_to_blob(
            blob_path=source_blob_path, data=json_bytes, processed=False
        )
    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Failed to upload file")
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

    data_rabbit_mq = {
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": task_manager.get_collection_name(),
    }

    await rabbitmq.publish_task("req_complete_checker", data_rabbit_mq)
    task_manager.update_status(TaskStatus.PROCESSING.value)

    loguru.logger.info({"message": "Task submitted", "task_id": task_id})
    return {"message": "Task submitted", "task_id": task_id}


@req_completeness_router.get("/check/status/{task_id}")
def download_task(task_id: str):
    """check status and download  of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    task_manager = TaskManager(requirement_completeness_checker_config, task_id)
    blob_manager_client = BlobClientManager()
    task = task_manager.get_task()
    if not task:
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    task_status = task.get("status")
    if task_status == TaskStatus.PROCESSING.value:
        return JSONResponse(content={"message": "Task is in progress."}, status_code=202)
    elif task_status != TaskStatus.SUCCESS.value:
        # Additional failure modes can be handled here
        return JSONResponse(
            content={"message": "Task has failed or is in an unrecognized state."},
            status_code=409,
        )

    output_filename = task.get("output_filename")

    if not output_filename:
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    blob_path = f"{task_id}/{output_filename}"
    try:
        file_data = blob_manager_client.get_data_from_blob(blob_path=blob_path, processed=True)
        file_data = file_data.decode("utf-8")
        json_obj = json.loads(file_data)

        # Step 3: Return JSON in response
        return JSONResponse(content=json_obj)

    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Blob download failed")
        raise HTTPException(status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e))

@req_completeness_router.post("/System/task/")
async def create_zip_task(
    user_details: dict = Depends(AuthValidation().wrapper),
    agent_id=Form(...),
    project: Optional[str] = Form(""),
    parent_file: Optional[UploadFile] = File(None),
    child_file: Optional[UploadFile] = File(None),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Creates a new task and uploads the file(s) to Azure Blob Storage.

    Args:
        user_details (dict): User details from AuthValidation.
        agent_id (str): The agent ID.
        project (str): Project name.
        parent_file (UploadFile, optional): Parent file uploaded by the user.
        child_file (UploadFile, optional): Child file uploaded by the user.
        rabbitmq (RabbitMQManager): RabbitMQ manager.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    blob_manager = BlobClientManager()

    # Validate at least one file is provided
    if not parent_file and not child_file:
        raise HTTPException(
            status_code=400,
            detail="At least one of parent_file or child_file must be provided.",
        )

    # Validate file extensions
    for file in [parent_file, child_file]:
        if file and not validate_input_file_type(file.filename):
            raise HTTPException(
                status_code=400,
                detail="Unsupported file type. Only CSV, Excel and Json files are allowed.",
            )


    output_filename = "output.xlsx"

    # Create task data
    task_data = {
        "project": project,
        "email": user_details["email"],
        "agent_id": agent_id,
        "output_filename": output_filename,
        "parent_filename": parent_file.filename if parent_file else None,
        "child_filename": child_file.filename if child_file else None,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
    }

    try:
        result = TaskManager.create_task(requirement_completeness_checker_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    task_manager = TaskManager(requirement_completeness_checker_config, task_id)

    # Upload files to blob storage
    try:
        if parent_file:
            parent_blob_path = f"{task_id}/{parent_file.filename}"
            blob_manager.upload_data_to_blob(
                blob_path=parent_blob_path, data=parent_file.file.read(), processed=False
            )
        if child_file:
            child_blob_path = f"{task_id}/{child_file.filename}"
            blob_manager.upload_data_to_blob(
                blob_path=child_blob_path, data=child_file.file.read(), processed=False
            )
    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Failed to upload file(s)")
        raise HTTPException(status_code=500, detail=f"Failed to upload file(s): {str(e)}")

    data_rabbit_mq = {
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": task_manager.get_collection_name(),
    }

    await rabbitmq.publish_task("req_complete_checker", data_rabbit_mq)
    task_manager.update_status(TaskStatus.PROCESSING.value)

    loguru.logger.info({"message": "Task submitted", "task_id": task_id})
    return {"message": "Task submitted", "task_id": task_id}