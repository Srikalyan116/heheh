"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import io
import json
import logging
import os
from datetime import datetime, timezone
from io import BytesIO
import re
from pathlib import Path
from typing import List, Optional

import numpy as np
import pandas as pd
import requests
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from fastapi.responses import JSONResponse

from src.config.config import requirement_classification_config
from src.controllers.code_beamer_controller import (
    bulk_update_items,
    get_items_by_project,
)
from src.exceptions.common_exceptions import ColumnNotFoundError
from src.utils.auth import AuthValidation
from src.utils.common.azure_helper import BlobClientManager,blob_service_client
from src.utils.common.db_helper import (
    TaskManager,
    get_agent_mappings,
    get_tasks_from_db,
    validate_agent,
)
from src.utils.common.helper import (
    check_column_name_in_columns,
    clean_local_file,
    fetch_dataframe_from_file,
    get_blob_segment,
    get_columns_from_file,
    write_dataframe_to_file, validate_object_id, sanitize_filename,write_dataframe_to_file_for_bytes
)
from src.utils.feature.api_helper import (
    delete_blob_data,
    get_downloadable_data,
    get_task_by_id,
)
from src.utils.utils_enum import FileType, RequestType, TaskStatus

load_dotenv()
router = APIRouter(prefix="/api/req-class", dependencies=[Depends(AuthValidation().wrapper)], tags=["Requirement Classification"])


container_name = os.getenv("BLOB_CONTAINER_NAME")



@router.get("/")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    try:
        return get_tasks_from_db(
            requirement_classification_config,
            email,
            page=page,
            page_size=page_size,
            search=search,
            agent_id=agent_id,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch data from collection: {str(e)}"
        )


@router.post("/filecolumns")
async def get_columns(file: UploadFile = File(...)):
    """Retrieves the column names from the uploaded file.

    Args:
        file (UploadFile): The file from which to extract column names.

    Raises:
        HTTPException: 400 Bad Request if the file is not a valid format.
        HTTPException: 400 Bad Request if there are empty rows below the headers.
        HTTPException: 400 Bad Request if unnamed columns are found.
        HTTPException: 400 Bad Request if columns are non-empty but contain empty rows.
        HTTPException: 500 Internal Server Error if there is an error processing the file.

    Returns:
        dict: A dictionary containing the column names.
            - columns (list): A list of column names.
    """
    try:
        content = await file.read()
        return {"columns": get_columns_from_file(BytesIO(content), file.filename)}
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=f"Value error: {str(ve)}")
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing the file: {str(e)}",
        )


@router.post("/task/")
def create_task(
    background_tasks: BackgroundTasks,
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    agent_id=Form(...),
    agent_name=Form(...),
    prediction_id: str = Form(...),
    prediction_col_name: str = Form(...),
    label_column: Optional[str] = Form(None),
    project: Optional[str] = Form(""),
    file: UploadFile = File(...),
):
    """Creates a new task and uploads the file to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): Background tasks for processing after request return.
        prediction_col_name (str): The column name to be used for prediction.
        project (Optional[str]): Project name associated with the task.
        file (UploadFile): The file to be processed.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    try:
        if not prediction_id or not prediction_col_name:
            raise HTTPException(
                status_code=400,
                detail="Prediction ID or Prediction Column Name cannot be empty.",
            )

        file_extension = os.path.splitext(file.filename)[1]
        if file_extension not in {file_type.value for file_type in FileType}:
            raise HTTPException(status_code=400, detail="Unsupported file type")

        if not validate_agent(
            agent_id, agent_name, requirement_classification_config["feature_name"]
        ):
            raise HTTPException(status_code=400, detail="Agent not found")

        filename = sanitize_filename(file.filename)
        task_data = {
            "agent_id": agent_id,
            "user_id": (user_details["email"]).split("@")[0],
            "project": project,
            "email": user_details["email"],
            "filename": filename,  # None
            "status": TaskStatus.CREATED.value,
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
            "tracker": None,
            "label_column": label_column,
            "prediction_col_name": prediction_col_name,
            "prediction_id": prediction_id,
            "request_type": RequestType.MANUAL.value,
        }

        # Inserting the task in the DB
        result = TaskManager.create_task(requirement_classification_config, task_data)

        # Get the task ID from the insertion
        task_id = str(result.inserted_id)

        task_manager = TaskManager(requirement_classification_config, task_id)

        # Get the blob storage path where we want to save the result
        raw_blob_path = get_blob_segment(
            task_id,
            requirement_classification_config["feature_name"],
            str(task_data["created_timestamp"]),
        )

        file_contents = file.file.read()  # Read file asynchronously
        data = io.BytesIO(file_contents)
        df = fetch_dataframe_from_file(data, file_extension)

        if label_column and not (label_column in df.columns):
            raise HTTPException(
                status_code=404, detail=f"{label_column} label column is not found."
            )

        if not check_column_name_in_columns(prediction_id, df):
            raise ColumnNotFoundError(prediction_id)

        if df[prediction_id].isna().all() or (df[prediction_id] == "").all():
            task_manager.update_status(
                TaskStatus.FAILED.value,
                error_message=f"Empty rows found in the {prediction_id} column.",
            )
            raise HTTPException(
                status_code=404,
                detail=f"Empty rows found in the {prediction_id} column.",
            )

        try:
            # Uploading the input file to Blob Storage
            blob_manager = BlobClientManager()
            blob_manager.upload_data_to_blob(
                blob_path=f"{raw_blob_path}/{filename}", data=file_contents
            )
        except Exception as e:
            task_manager.update_status(
                TaskStatus.FAILED.value,
                error_message=f"Failed to upload file: {str(e)}",
            )
            raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

        background_tasks.add_task(execute_task, task_id, agent_name)
        return {"task_id": task_id, "agent_name": agent_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/retry/{task_id}/{agent_name}")
async def retry_task(
    background_tasks: BackgroundTasks,
    request: Request,
    task_id: str,
    agent_name: str,
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retry a specific task by task_id.

     The task status will be updated to 'PROCESSING',and the task will be added to the background task queue for execution.
    Args:
        task_id (str): The ID of the task to be retried.
        background_tasks (BackgroundTasks): BackgroundTasks instance for adding tasks to the background execution queue.

    Returns:
        dict: A message confirming the task is being retried and the task_id.

    Raises:
        HTTPException: If the task with the specified task_id is not found.
    """
    task_manager = TaskManager(requirement_classification_config, task_id)

    if not task_manager.get_task():
        raise HTTPException(status_code=404, detail="Task not found")

    task_manager.update_status(TaskStatus.PROCESSING.value)
    background_tasks.add_task(execute_task, task_id, agent_name)
    return {"task_id": task_id}


async def execute_task(task_id: str, agent_name: str):
    """Processes a task by executing model predictions and handling file storage.

    Args:
        task_id (str): The unique identifier of the task to be executed.

    Returns:
        dict: A dictionary indicating the execution status.
            - status (str): "success" if execution is successful.
            - message (str): A message describing the outcome.

    Raises:
        HTTPException: 404 Not Found if the task is not found or the downloaded/processed file is missing.
        HTTPException: 500 Internal Server Error if an error occurs during prediction or uploading the processed file.
    """
    # Initiate the task manager for status updates
    task_manager = TaskManager(requirement_classification_config, task_id)

    # Initiate blob manager
    blob_manager = BlobClientManager()

    # Get the mappings of the models
    agent_mappings = get_agent_mappings(agent_name)

    # Updating the status of the task in DB
    task_manager.update_status(TaskStatus.PROCESSING.value)

    # Get data required for processing from DB
    task_data = task_manager.get_task()

    if not task_data:
        raise HTTPException(status_code=404, detail="Task not found")

    filename = task_data.get("filename")
    prediction_col_name = task_data.get("prediction_col_name")
    label_column = task_data.get("label_column")
    prediction_id = task_data.get("prediction_id")
    prediction_columns = []

    # Preparing blob file path to down the content
    # Get the blob storage path where we want to save the result
    blob_path = get_blob_segment(
        task_id,
        requirement_classification_config["feature_name"],
        str(task_data["created_timestamp"]),
    )

    # Generating local file path to store blob data
    local_temp_path = os.path.join("data", f"temp_{filename}")
    os.makedirs(os.path.dirname(local_temp_path), exist_ok=True)

    # Download the requirements file
    try:

        # Loading the temp file for saving the cloud data
        with open(local_temp_path, "wb") as download_file:

            # Downloading the data from cloud
            data = blob_manager.get_data_from_blob(f"{blob_path}/{filename}")

            # Saving cloud data to local temp file
            download_file.write(data)

    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Blob not found")
        raise HTTPException(status_code=404, detail=f"Blob not found: {e}")

    if not os.path.isfile(local_temp_path):
        task_manager.update_status(
            TaskStatus.FAILED.value, error_message="Files not downloaded successfully"
        )
        raise HTTPException(status_code=404, detail="File download failed.")

    source_file_extension = os.path.splitext(filename)[1].lower()
    df = fetch_dataframe_from_file(local_temp_path, source_file_extension)

    # Make the predictions
    for result_column_name, agent_name in agent_mappings.items():

        # Get the data from the dataframe and process with agent over API call
        try:

            # Renaming the Prediction Column to text
            df.rename(columns={prediction_col_name: "text"}, inplace=True)
            df["text"] = df["text"].astype(str)

            # Converting Dataframe to JSON
            data = df.to_json()

            # Payload to send
            payload = {
                "data": data,
                "label_column": label_column,
                "text_column": "text",
            }

            service_url = os.getenv("SERVICE_URL")

            # Triggering the model get prediction
            response = requests.post(service_url + "/" + agent_name, json=payload)

            if response.status_code != 200:
                raise Exception(f"Model API returned status code {response.status_code}")

            results = json.loads(response.json())
            predictions_df = pd.DataFrame(results)

            # Renaming the columns as required
            predictions_df.rename(columns={"text": prediction_col_name}, inplace=True)
            predictions_df.rename(
                columns={"prediction": result_column_name + "_pred"}, inplace=True
            )
            prediction_columns.append(result_column_name + "_pred")

            if "confidence" in list(predictions_df.columns):
                predictions_df["confidence"] = np.floor(predictions_df["confidence"] * 100)
                # if confidence is not available this just get skipped
                predictions_df.rename(
                    columns={"confidence": f"{result_column_name}_confidence"},
                    inplace=True,
                )
                prediction_columns.append(result_column_name + "_confidence")

            # Replace empty strings with NaN in the specified column
            predictions_df[prediction_col_name] = predictions_df[prediction_col_name].replace(
                r"^\s*$", pd.NA, regex=True
            )

            # Drop rows with empty values like "", nan and None in the specified column
            df = predictions_df[
                (predictions_df[prediction_id].notna()) & (predictions_df[prediction_id] != "")
            ]

        except Exception as e:
            task_manager.update_status(
                TaskStatus.FAILED.value,
                error_message="Error during model prediction",
            )
            raise HTTPException(status_code=500, detail=f"Error during model prediction: {e}")

    # Save the prediction to Temporary file
    try:
        # Remove the content of the predicted columns when found empty
        mask = (
            df[prediction_col_name].isna()
            | (df[prediction_col_name].astype(str).str.strip().eq(""))
            | (df[prediction_col_name] == "<NA>")
        )
        df.loc[mask, prediction_columns] = None
        df = df.fillna("").replace("<NA>", "")

        write_dataframe_to_file(df, source_file_extension, local_temp_path)

    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value,
            error_message="Error to save temporary data",
        )
        raise HTTPException(status_code=500, detail=f"Error to save temporary data")

    # Upload the processed file to Azure Blob Storage
    try:
        with open(local_temp_path, "rb") as data:
            blob_manager.upload_data_to_blob(f"{blob_path}/{filename}", data, processed=True)

    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value,
            error_message="Failed to upload processed file: {e}",
        )
        raise HTTPException(status_code=500, detail=f"Failed to upload processed file: {e}")

    # Cleaning, Updating the task and update CodeBeamer
    try:

        # Remove the local temporary file
        clean_local_file(local_temp_path)

        # Update the task status to success
        task_manager.update_status(TaskStatus.SUCCESS.value, filename=filename)

        return {"status": "success", "message": "Task executed successfully."}
    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value,
            error_message="Failed to process file",
        )
        raise HTTPException(status_code=500, detail=f"Failed to process file: {e}")


@router.get("/update/codebeamer/{task_id}")
async def update_codebeamer(
    request: Request,
    task_id: str,
    user_details: dict = Depends(AuthValidation().wrapper),
):
    try:
        await bulk_update_items(request, task_id, user_details)
        return {"message": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to process request : {e}")


@router.delete("/tasks/{id}")
async def delete_task(id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    try:
        delete_blob_data(requirement_classification_config, id)
    except Exception as e:
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    return {"message": "Task deleted"}


@router.get("/download/{task_id}")
def download_task(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    # Download the content and respond with the data
    try:
        # Validate the task data from DB
        task_validation, message, filename, file_data = get_downloadable_data(
            requirement_classification_config, task_id
        )

        # If the validation failed respond with the proper message
        if not task_validation:
            Response(content=message)
        else:
            return Response(
                content=file_data,
                media_type="application/octet-stream",
                headers={
                    "Content-Disposition": f"attachment; filename={filename}",
                    "Access-Control-Expose-Headers": "Content-Disposition",
                },
            )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/cb/task")
async def create_codebeamer_task(
    request: Request,
    background_tasks: BackgroundTasks,
    user_details: dict = Depends(AuthValidation().wrapper),
    agent_id: str = Form(...),
    agent_name: str = Form(...),
    codebeamer_project: str = Form(...),
    codebeamer_tracker: str = Form(...),
    label_column: Optional[str] = Form(None),
) -> None:
    """Method to create a codebeamer classification task.

    Args:
        request (Request): Request object.
        background_tasks (BackgroundTasks): Background tasks object.
        user_details (dict): To authenticate
        agent_id (str): agent id of the model
        agent_name (str): agent id of the model
        auth_token (str, optional): Token for codebeamer authentication. Defaults to Form(...).
        codebeamer_project (str, optional): Name of the codebeamer project. Defaults to Form(...).
        codebeamer_tracker (str, optional): Name of the codebeamer tracker. Defaults to Form(...).
        label_column(str, optional): additional params.
    """
    auth_token = request.headers.get("Authorization")
    if auth_token is None:
        raise HTTPException(
            status_code=500,
            detail="Invalid header. Could not find Authorization token.",
        )
    auth_token = auth_token.replace("Bearer ", "")
    task_data = {
        "agent_id": agent_id,
        "user_id": (user_details["email"]).split("@")[0],
        "project": codebeamer_project,
        "email": user_details["email"],
        "filename": "reqs.xlsx",
        "status": TaskStatus.CREATED.value,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "tracker": codebeamer_tracker,
        "label_column": label_column,
        "prediction_id": "ID",
        "prediction_col_name": "requirement",
        "request_type": RequestType.CODEBEAMER.value,
    }
    # req_objects = get_items_by_project(
    #   auth_token, codebeamer_url, codebeamer_project, codebeamer_tracker, collection, task_id,)
    codebeamer_url = os.getenv("CODEBEAMER_URL")
    req_objects = get_items_by_project(
        auth_token, codebeamer_url, codebeamer_project, codebeamer_tracker
    )

    if req_objects and len(req_objects) > 0:
        pass
    else:

        logging.error(f"No tracker items available:")
        raise HTTPException(status_code=500, detail=f"No available tracker items:")

    reqs = [item["description"] for item in req_objects]
    ids = [item["id"] for item in req_objects]
    df = pd.DataFrame({"ID": ids, "requirement": reqs})
    file_name = "reqs.xlsx"
    local_temp_path = os.path.join("data", file_name)
    os.makedirs(os.path.dirname(local_temp_path), exist_ok=True)
    df.to_excel(local_temp_path, index=False)
    try:
        result = TaskManager.create_task(requirement_classification_config, task_data)
    except Exception as e:
        logging.error(f"Error updating task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))

    task_id = str(result.inserted_id)
    task_manager = TaskManager(requirement_classification_config, task_id)
    blob_path = get_blob_segment(
        task_id,
        requirement_classification_config["feature_name"],
        str(task_data["created_timestamp"]),
    )
    blob_path = f"{blob_path}/{file_name}"
    blob_manager = BlobClientManager()
    try:
        with open(local_temp_path, "rb") as data:
            blob_manager.upload_data_to_blob(blob_path=blob_path, data=data)
    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Blob not found")
        raise HTTPException(status_code=404, detail=f"Blob not found: {e}")

    if os.path.exists(local_temp_path):
        os.remove(local_temp_path)

    background_tasks.add_task(execute_task, task_id, agent_name)

    return {"task_id": task_id, "agent_name": agent_name}


@router.get("/feedback/{task_id}")
def feedback(
    task_id: str,
    page: int = 1,
    page_size: int = 10,
    prediction: Optional[str] = None,
    confidence_score: Optional[str] = "0,100",
):
    """Retrieve paginated feedback data for a given task.

    Args:
        task_id (str): The ID of the task.
        page (int): The page number for pagination. Defaults to 1.
        page_size (int): The number of items per page for pagination. Defaults to 10.

    Returns:
        JSONResponse: A JSON response containing paginated feedback data and total count.

    Raises:
        HTTPException: If the task is not found, if filename or prediction column name is missing,
                       if the prediction column is not found in the file, or if there is any other error.
    """

    # Validate task_id to be a valid MongoDB ObjectId format
    if not validate_object_id(task_id):
        raise HTTPException(status_code=400, detail="Invalid task id")

    task_manager = TaskManager(requirement_classification_config, task_id)
    task_data = task_manager.get_task()
    if not task_data:
        raise HTTPException(status_code=404, detail="Task not found")


    blob_manager = BlobClientManager()
    agent_mapping = get_agent_mappings(agent_id=task_data.get("agent_id"))

    filename = task_data.get("filename")
    if not filename:
        raise HTTPException(status_code=404, detail="Filename missing in task")
    
    # Sanitize the filename to prevent directory traversal
    filename = sanitize_filename(filename)
    filename = os.path.basename(filename)

    pred_id = task_data.get("prediction_id")
    prediction_col_name = task_data.get("prediction_col_name")

    if not prediction_col_name:
        raise HTTPException(status_code=404, detail="Prediction column name missing in task")


    processed_blob_path = get_blob_segment(
        task_id,
        requirement_classification_config["feature_name"],
        str(task_data["created_timestamp"]),
    )
    
     # Validate processed_blob_path has no directory traversal characters
    if not processed_blob_path or any(c in processed_blob_path for c in ['..', '*', '?', '`', '$', '|', '<', '>']):
        raise HTTPException(status_code=400, detail="Invalid blob path")
    
    # Use Path to safely join paths
    blob_path = str(Path(processed_blob_path) / filename)

    try:
        file_data = blob_manager.get_data_from_blob(blob_path, processed=True)

        df = fetch_dataframe_from_file(file_data, filename)
        if not isinstance(df, pd.DataFrame):
            raise HTTPException(status_code=400, detail="Unsupported file format")

        if prediction_col_name not in df.columns:
            raise HTTPException(
                status_code=400,
                detail=f"Column '{prediction_col_name}' not found in file",
            )

        save_the_updated_df = False
        # backward compactibility
        for each in agent_mapping.keys():
            if (each + "_pred") not in df.columns and (each + "_confidence" in df.columns):
                df.rename(columns={each: each + "_pred"}, inplace=True)
                save_the_updated_df = True

        if save_the_updated_df:
            # Use secure path handling with pathlib for all operations
            base_temp_dir = Path(os.getcwd()) / "temp"
            base_temp_dir.mkdir(exist_ok=True)
            # Create a safe filename that cannot contain path traversal
            safe_filename = f"{task_id}_{os.path.basename(filename)}"
            temp_path = (base_temp_dir / safe_filename).resolve()
            # Double-check the path is within temp_dir
            if not str(temp_path).startswith(str(base_temp_dir.resolve())):
                raise HTTPException(status_code=400, detail="Invalid file path detected")
            write_dataframe_to_file(df, ".xlsx", str(temp_path))
            with open(temp_path, "rb") as f:
                blob_manager.upload_data_to_blob(blob_path, f, processed=True)
            clean_local_file(str(temp_path))

        if prediction:  # Ensure the prediction is not empty or None
            # Split and clean up the user input
            prediction_values = prediction.split(",")
            prediction_values = [
                p.strip() for p in prediction_values
            ]  # Title case for consistent matching

            # Initialize the filter condition for the dataframe
            conditions = []

            # Iterate through the prediction values and add conditions
            for pred in prediction_values:
                conditions.append(df[list(agent_mapping.keys())[0] + "_pred"] == pred)
            # If any valid condition is added, combine them with OR (|) and apply the filter
            if conditions:
                # Start with the first condition
                combined_condition = conditions[0]

                # Combine all other conditions with OR
                for condition in conditions[1:]:
                    combined_condition |= condition
                # Apply the combined condition to the dataframe
                df = df[combined_condition]
        if confidence_score:
            if "itemType_confidence" in df.columns:
                try:
                    low, high = confidence_score.split(",")
                    low_val = float(low)
                    high_val = float(high)
                    df = df[
                        (df["itemType_confidence"] >= low_val)
                        & (df["itemType_confidence"] <= high_val)
                    ]
                except ValueError:
                    # Handle malformed confidence score input
                    raise HTTPException(status_code=400, detail="Invalid confidence score format")
                
        # Pagination logic
        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        paginated_df = df.iloc[start_index:end_index]

        # Replace NaN and infinity values
        paginated_df.replace([np.inf, -np.inf], np.nan, inplace=True)

        # Replace 0 with NaN only in float-type columns
        float_cols = paginated_df.select_dtypes(include=["float"]).columns

        paginated_df.loc[:, float_cols].replace(0, None)
        paginated_df.replace("nan", "", inplace=True)

        # Prepare the result with required fields using apply
        def get_row_data(row):
            result = {
                "ID": "" if str(row.get(pred_id, "")) == "nan" else row.get(pred_id, ""),
                "requirement": (
                    ""
                    if str(row.get(prediction_col_name, "")) == "nan"
                    else row.get(prediction_col_name, "")
                ),
            }

            # If old format exists go with "prediction" else use the updated column names
            if row.get("prediction", ""):
                result["prediction"] = row.get("prediction", "")
                result["prediction_feedback"] = row.get("prediction_feedback", "")
            else:
                for column, _ in agent_mapping.items():
                    feedback_name = column + "_feedback"
                    confidence_name = column + "_confidence"
                    column += "_pred"
                    result[column] = (
                        "" if str(row.get(column, "")) == "nan" else row.get(column, "")
                    )
                    result[feedback_name] = (
                        ""
                        if str(row.get(feedback_name, "")) == "nan"
                        else row.get(feedback_name, "")
                    )
                    if confidence_name in row:
                        result[confidence_name] = (
                            ""
                            if str(row.get(confidence_name, "")) == "nan"
                            else row.get(confidence_name, "")
                        )

            return result

        result = paginated_df.apply(get_row_data, axis=1).tolist()
        return JSONResponse(content={"data": result, "total_count": len(df)})

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.patch("/update_feedback/{task_id}")
async def update_feedback(task_id: str, updates: List[dict]):
    """Update feedback data for a given task.

    Args:
        task_id (str): The ID of the task.
        updates (List[UpdateItem]): A list of updates to be applied to the task.

    Returns:
        JSONResponse: A JSON response indicating the success of the operation.

    Raises:
        HTTPException: If the task is not found, if filename or prediction column name is missing,
                       if the prediction column is not found in the file, or if there is any other error.
    """
    task_manager = TaskManager(requirement_classification_config, task_id)
    task = task_manager.get_task()
    blob_manager_client = BlobClientManager()

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    filename = task.get("filename")
    user_id = task.get("user_id")
    pred_id = task.get("prediction_id")
    if not filename:
        raise HTTPException(status_code=404, detail="Filename missing in task")

    prediction_col_name = task.get("prediction_col_name")
    if not prediction_col_name:
        raise HTTPException(status_code=404, detail="Prediction column name missing in task")

    processed_blob_path = get_blob_segment(
        task_id,
        requirement_classification_config["feature_name"],
        str(task["created_timestamp"]),
    )
    blob_path = f"{processed_blob_path}/{filename}"
    try:
        file_data = blob_manager_client.get_data_from_blob(blob_path=blob_path, processed=True)

        # Determine the file type and load data accordingly
        df = fetch_dataframe_from_file(io.BytesIO(file_data), filename)

        if not isinstance(df, pd.DataFrame):
            raise HTTPException(status_code=400, detail="Unsupported file format")

        # Check if prediction_col_name exists in the DataFrame
        if prediction_col_name not in df.columns:
            raise HTTPException(
                status_code=400,
                detail=f"Column '{prediction_col_name}' not found in file",
            )
        # Convert the ID column to string in the DataFrame
        df[pred_id] = df[pred_id].astype(str)

        # Convert updates to DataFrame
        updates_df = pd.DataFrame(updates)

        # Renamining the column names back to original names
        updates_df.rename(columns={"ID": pred_id}, inplace=True)
        updates_df.rename(columns={"requirement": prediction_col_name}, inplace=True)

        # Update the 'feedback' columns with the new values
        df.set_index(pred_id, inplace=True)
        updates_df.set_index(pred_id, inplace=True)

        df.replace([np.inf, -np.inf], np.nan, inplace=True)
        df.fillna("", inplace=True)

        # Getting the feedback names
        feedback_columns: list[str] = [
            each for each in updates_df.columns if each.endswith("_feedback")
        ]

        updates_df["ID"] = list(updates_df.index)
        updates_df["ID"] = updates_df["ID"].astype(str)

        def update_row(row, updates_df, column_name):
            feedback_filtered = updates_df.loc[
                updates_df[prediction_col_name] == row[prediction_col_name]
            ][column_name]
            if len(feedback_filtered) > 1:
                feedback_filtered = feedback_filtered.loc[updates_df[pred_id] == row.name]

            feedback = (
                list(feedback_filtered)[0] if len(feedback_filtered) > 0 else row[column_name]
            )

            if len(feedback) > 0:
                row[column_name] = feedback
            return row

        # Updating the columns
        for column in feedback_columns:
            if column not in df.columns:
                df[column] = ""
            df = df.apply(update_row, axis=1, updates_df=updates_df, column_name=column)

        # Save the updated DataFrame back to a BytesIO object
        output = io.BytesIO()
        write_dataframe_to_file_for_bytes(df, filename, output)
        output.seek(0)

        # Upload the updated file back to Azure Blob Storage
        blob_manager_client.upload_data_to_blob(blob_path=blob_path, data=output, processed=True)
        return "success"

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/getProject/{project_id}")
async def get_project_by_id(project_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    try:
        return get_task_by_id(requirement_classification_config, project_id)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e
