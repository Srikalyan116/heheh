"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import logging
from datetime import datetime, timezone
from io import BytesIO
from typing import Optional

import loguru
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)

from src.config.config import test_coverage_config
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import TaskManager, get_tasks_from_db
from src.utils.common.helper import (
    get_blob_segment,
    get_columns_from_file,
    get_queue_name_from_config,
    validate_input_file_type,
)
from src.utils.feature.api_helper import get_download_url, get_downloadable_data
from src.utils.utils_enum import RequestType, TaskStatus

load_dotenv()
test_coverage_router = APIRouter(
    prefix="/api/test_coverage",
    dependencies=[Depends(AuthValidation().wrapper)],
    tags=["Test Coverage"],
)


def get_rabbitmq(request: Request):
    """Get RabbitMQ Client."""
    return request.app.state.rabbitmq


@test_coverage_router.get("/")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks for authenticated user.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.
        user_details (dict): User details extracted from the validated token.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    try:
        return get_tasks_from_db(
            test_coverage_config,
            email,
            page=page,
            page_size=page_size,
            search=search,
            agent_id=agent_id,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch data from collection: {str(e)}"
        )


@test_coverage_router.post("/filecolumns")
async def get_columns(file: UploadFile = File(...)):
    """Retrieves the column names from the uploaded file.

    Args:
        file (UploadFile): The file from which to extract column names.

    Raises:
        HTTPException: 400 Bad Request if the file is not a valid format.
        HTTPException: 400 Bad Request if there are empty rows below the headers.
        HTTPException: 400 Bad Request if unnamed columns are found.
        HTTPException: 400 Bad Request if columns are non-empty but contain empty rows.
        HTTPException: 500 Internal Server Error if there is an error processing the file.

    Returns:
        dict: A dictionary containing the column names.
            - columns (list): A list of column names.
    """
    try:
        content = await file.read()
        return {"columns": get_columns_from_file(BytesIO(content), file.filename)}
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=f"Value error: {str(ve)}")
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing the file: {str(e)}",
        )


@test_coverage_router.post("/task/")
async def create_task(
    user_details: dict = Depends(AuthValidation().wrapper),
    agent_id=Form(...),
    project: str = Form(),
    requirements_file: UploadFile = File(...),
    testcases_file: UploadFile = File(...),
    reference_document: UploadFile | str | None = None,
    requirements_id_column: str = "",
    requirements_description_column: str = "",
    testcase_id_column: str = "",
    testcase_requirement_mapping_column: str = "",
    testcase_results_column: str = "",
    reference_id_column: str = "",
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
):
    """Creates a new task and uploads the file to Azure Blob Storage.

    Args:
        background_tasks (BackgroundTasks): FastAPI's BackgroundTasks instance for running background tasks.
        email (str): The email address of the user creating the task.
        source_col_name (str): The name of the source column.
        revision_col_name (str): The name of the revision column.
        project (str): The name of the project.
        source_id (str): The ID of the source.
        revision_id (str): The ID of the revision.
        source_file (UploadFile): The source file uploaded by the user.
        target_file (UploadFile): The target file uploaded by the user.

    Raises:
        HTTPException: 400 Bad Request if the uploaded file format is unsupported.
        HTTPException: 500 Internal Server Error if uploading the file fails.

    Returns:
        dict: A dictionary containing the created task ID.
    """
    blob_manager = BlobClientManager()

    # Validate file extensions
    if not validate_input_file_type(requirements_file.filename) and not validate_input_file_type(
        testcases_file.filename
    ):
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only CSV, Excel and Json files are allowed.",
        )

    if isinstance(reference_document, str) and reference_document == "null":
        reference_document = None

    # Create task data
    task_data = {
        "project": project,
        "email": user_details["email"],
        "agent_id": agent_id,
        "output_filename": "output.xlsx",
        "requirements_filename": requirements_file.filename,
        "testcase_filename": testcases_file.filename,
        "reference_doc_filename": reference_document.filename if reference_document else None,
        "filename": requirements_file.filename,
        "requirements_id_column": requirements_id_column,
        "requirements_description_column": requirements_description_column,
        "testcase_id_column": testcase_id_column,
        "testcase_requirement_mapping_column": testcase_requirement_mapping_column,
        "testcase_results_column": testcase_results_column,
        "reference_id_column": reference_id_column,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
    }

    try:
        result = TaskManager.create_task(test_coverage_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    task_manager = TaskManager(test_coverage_config, task_id)
    task_data = task_manager.get_task()
    source_blob_path = get_blob_segment(
        task_id,
        test_coverage_config["feature_name"],
        str(task_data["created_timestamp"]),
    )

    try:

        # upload source file
        blob_manager.upload_data_to_blob(
            blob_path=f"{source_blob_path}/{requirements_file.filename}",
            data=requirements_file.file.read(),
        )
        blob_manager.upload_data_to_blob(
            blob_path=f"{source_blob_path}/{testcases_file.filename}",
            data=testcases_file.file.read(),
        )
        if reference_document:
            blob_manager.upload_data_to_blob(
                blob_path=f"{source_blob_path}/{reference_document.filename}",
                data=reference_document.file.read(),
            )

    except Exception as e:
        task_manager.update_status(TaskStatus.FAILED.value, error_message="Failed to upload file")
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

    data_rabbit_mq = {
        "task_id": task_id,
        "collection_name": task_manager.get_collection_name(),
    }
    data_rabbit_mq.update(task_data)

    await rabbitmq.publish_task(get_queue_name_from_config(test_coverage_config), data_rabbit_mq)
    task_manager.update_status(TaskStatus.PROCESSING.value)

    loguru.logger.info({"message": "Task submitted", "task_id": task_id})
    return {"message": "Task submitted", "task_id": task_id}


@test_coverage_router.get("/download/{task_id}")
def download_task(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    # Download the content and respond with the data
    try:
        # Validate the task data from DB
        task_validation, message, filename, file_data = get_downloadable_data(
            test_coverage_config, task_id
        )

        # If the validation failed respond with the proper message
        if not task_validation:
            Response(content=message)
        else:
            return Response(
                content=file_data,
                media_type="application/octet-stream",
                headers={
                    "Content-Disposition": f"attachment; filename={filename}",
                    "Access-Control-Expose-Headers": "Content-Disposition",
                },
            )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@test_coverage_router.delete("/tasks/{id}")
async def delete_task(id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    task_manager = TaskManager(test_coverage_config, id)
    try:
        result = task_manager.delete_task()
    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value, error_message="Error deleting task in mongodb"
        )
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    if result:
        return {"message": "Task deleted"}
    return {"error": "Task not found"}


@test_coverage_router.get("/getProject/{task_id}")
async def get_project_by_id(task_id: str):
    """Fetch a particular project from MongoDB using its project_id.

    Args:
        project_id (str): The ID of the project to retrieve.

    Returns:
        Dict: The project dictionary if found, otherwise raises an error.
    """
    task_manager = TaskManager(test_coverage_config, task_id)

    try:
        # Fetch the project from the collection using the project_id
        project = task_manager.get_task()

        if project is None:
            raise HTTPException(status_code=404, detail="Project not found")

        # Convert ObjectId to string for serialization
        project["_id"] = str(project["_id"])

        return project

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch project: {str(e)}") from e


@test_coverage_router.get("/download_url/{task_id}")
def temporary_download_url(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    # Download the content and respond with the data
    try:
        # Validate the task data from DB
        task_validation, message, _, url = get_download_url(test_coverage_config, task_id)

        # If the validation failed respond with the proper message
        if not task_validation:
            Response(content=message)
        else:
            return url
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
