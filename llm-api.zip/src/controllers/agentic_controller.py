"""This module contains the agentic apis."""

# Third party imports
from typing import List

# Standard library imports
from fastapi import APIRouter, Depends, HTTPException, status

from src.config.config import agent_config

# Local application imports
from src.models.agent_task import Agent, FeatureList
from src.utils.auth import AuthValidation
from src.utils.mongo_db import MongoDB
from src.utils.common.logger import log as logging
from src.utils.common.logger import set_job_context

routeragentic = APIRouter(prefix="/api/agent", dependencies=[Depends(AuthValidation().wrapper)], tags=["Agentic apis"])


@routeragentic.post("/create-featurelist", status_code=status.HTTP_201_CREATED)
async def create_featurelist(feature_data: FeatureList):
    """Creates a new feature list document in the specified collection.

    This endpoint takes a FeatureList object, checks if a document with the same
    object_id already exists in the collection, and if not, inserts the new document.

    Args:
        feature_data (FeatureList): The feature list data to be inserted. This should
                                    be a valid FeatureList object as per the defined schema.

    Raises:
        HTTPException:
            - 400: If a document with the same object_id already exists in the collection.
            - 500: If the document insertion fails for any reason.

    Returns:
        dict: A dictionary containing a success message and the inserted document's id.
            - message (str): Success message indicating the feature list was created.
            - id (str): The id of the inserted document.
    """
    service = {
        "name": "llm-api",  
        "type": "backend", 
        "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": "/api/agent/create-featurelist/",  # API endpoint
    }

    # Convert the input data to a dictionary
    data = feature_data.dict()
    logging.info("Started Creating API Agent Creating feature list", service=service, api_request=api_request, api_request_data=data)
    project_collection_name = agent_config.get("collection_name")
    collection = MongoDB.get_collection(project_collection_name)

    logging.debug("Checking for existing FeatureList with object_id", object_id=data["object_id"])
    # Check if a document with the same object_id already exists
    if collection.find_one({"object_id": data["object_id"]}):
        logging.warning("FeatureList with this object_id already exists", object_id=data["object_id"])
        raise HTTPException(
            status_code=400, detail="FeatureList with this object_id already exists."
        )

    logging.info("Inserting new FeatureList document", data=data)
    # Insert the new document
    result = collection.insert_one(data)
    set_job_context(str(result.inserted_id))
    if result.inserted_id:
        logging.info("FeatureList created successfully")
        return {"message": "FeatureList created successfully", "id": str(result.inserted_id)}
    else:
        logging.error("Failed to create FeatureList", data=data)
        raise HTTPException(status_code=500, detail="Failed to create FeatureList")


@routeragentic.get("/{co_pilot}/{feature_name}/getAgent", response_model=List[Agent])
async def get_agents(co_pilot: str, feature_name: str):
    """Retrieves a list of agents associated with a specific co-pilot and feature name.

    Args:
        co_pilot (str): The co-pilot identifier used to find the feature.
        feature_name (str): The name of the feature to search for.

    Raises:
        HTTPException:
            - 404: If no document is found with the specified co_pilot and feature_name.

    Returns:
        List[Agent]: A list of agents associated with the specified feature. If no agents
                     are found, an empty list is returned.
    """
    service = {
        "name": "llm-api",
        "type": "backend",
        "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/agent/{co_pilot}/{feature_name}/getAgent",  # API endpoint
    }
    logging.info("Started Getting API Agent", service=service, api_request=api_request)
    project_collection_name = agent_config.get("collection_name")
    logging.debug("Fetching collection for project")
    collection = MongoDB.get_collection(project_collection_name)
    feature = collection.find_one({"co_pilot": co_pilot, "feature_name": feature_name})

    if not feature:
        logging.warning("Feature not found", co_pilot=co_pilot, feature_name=feature_name)
        raise HTTPException(status_code=404, detail="Feature not found")

    # Extract the list of agents
    agents = feature.get("agent", [])
    logging.info("Agents retrieved", count=len(agents), agents=agents)

    return agents
