"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import io
import json
import logging
import os
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from enum import Enum
from fileinput import filename
from io import BytesIO
from pathlib import Path
from typing import List, Optional

import loguru
import numpy as np
import pandas as pd
import requests
from bson import ObjectId
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
)
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from src.config.config import delta_comparator_config
from src.controllers.code_beamer_controller import (
    bulk_update_items,
    get_items_by_project,
)
from src.controllers.requirement_comparision_tracer_controller import get_rabbitmq
from src.exceptions.azure_exceptions import AzureBlobUploadFailedError
from src.exceptions.common_exceptions import ColumnNotFoundError
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.codebeamer_utils import get_tracker_data
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import (
    TaskManager,
    get_agent_mappings,
    get_tasks_from_db,
    validate_agent,
)
from src.utils.common.helper import (
    check_column_name_in_columns,
    clean_local_file,
    fetch_data_from_blob,
    fetch_dataframe_from_file,
    get_blob_segment,
    get_columns_from_file,
    process_requirements,
    write_dataframe_to_file,
)
from src.utils.common.logger import log as logging
from src.utils.common.logger import set_job_context, span_id_ctx, trace_id_ctx
from src.utils.feature.api_helper import (
    delete_blob_data,
    get_auth_token_from_headers,
    get_downloadable_data,
    get_task_by_id,
)
from src.utils.mongo_db import MongoDB
from src.utils.reqifz_conveter import convert_reqifz
from src.utils.requirement_comparision_tracer_schema import (
    get_task_data_code_beamer,
    get_task_data_delta_generator,
)
from src.utils.utility import get_status_message, validate_delta_comparator_input
from src.utils.utils_enum import APIMessages, FileType, RequestType, TaskStatus
from src.utils.validattion_helper import validate_excel_file, validate_json_data

load_dotenv()
delta_router = APIRouter(
    prefix="/api/delta-comparator",
    dependencies=[Depends(AuthValidation().wrapper)],
    tags=["Delta Comparator"],
)

container_name = os.getenv("BLOB_CONTAINER_NAME")


class ImageTypeEnum(str, Enum):
    Image = "Image"
    Text = "Text"
    Table = "Table"


class TextTypeEnum(str, Enum):
    Text = "Text"
    Table = "Table"


@delta_router.get("/")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    try:
        return get_tasks_from_db(
            delta_comparator_config,
            email,
            page=page,
            page_size=page_size,
            search=search,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch data from collection: {str(e)}"
        )


@delta_router.post("/task/")
async def create_task(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
    type_filter: Optional[List[TextTypeEnum]] = Query(
        ["Text", "Table"], description="Select one or more options"
    ),
    key_column: Optional[List[str]] = Query(
        ["text"], description="Enter key name in json file which needs to be processed"
    ),
    revision_files: List[UploadFile] = File(...),
):
    """
    Create a new Delta Comparator task.

    Uploads a base file along with one or more revision files for
    comparison. The files and metadata are saved to Azure Blob Storage,
    the task is stored in MongoDB, and queued for processing in RabbitMQ.

    Args:
        request (Request): The incoming HTTP request.
        user_details (dict): Authenticated user details.
        rabbitmq (RabbitMQManager): RabbitMQ manager instance.
        revision_files (List[UploadFile]): List of revision files to compare.
        key_column (List[str], optional): The key name in JSON files to process. Defaults to ["text"].

    Returns:
        dict: JSON response containing a success message and the created task ID.

    Raises:
        HTTPException: 400 if input validation fails.
        AzureBlobUploadFailedError: If uploading files to Azure Blob fails.
        HTTPException: 500 for unexpected server-side errors.
    """

    # Validate revision files and filenames
    if not revision_files or not all(file.filename for file in revision_files):
        logging.error("One or more uploaded files are missing filenames.")
        raise HTTPException(
            status_code=400,
            detail="All uploaded files must have valid filenames.",
        )

    # Extract file extension from the first file
    file_extension = os.path.splitext(revision_files[0].filename)[1]
    if not file_extension:
        logging.error("The uploaded file does not have a valid extension.")
        raise HTTPException(
            status_code=400,
            detail="The uploaded file must have a valid extension.",
        )

    meta_info = {}
    meta_info["original_file_extension"] = file_extension
    meta_info["file_extension"] = ".json"  # Assuming JSON as default, can be adjusted based on actual file types

    if len(key_column) != len(revision_files):
        logging.info(
            f"Key column length {len(key_column)} is not matching with revision files length {len(revision_files)}"
        )
        raise HTTPException(
            status_code=400,
            detail="Key column length is not matching with revision files length.",
        )

    if len(type_filter) == 0:
        ALLOWED_TYPES = ["Text", "Table"]
        type_filter = ALLOWED_TYPES
    else:
        if len(type_filter) == 1:
            type_filter = [x.strip() for x in type_filter[0].split(",") if x.strip()]
        for type_item in type_filter:
            if type_item not in ["Table", "Text"]:
                logging.info(
                    f"Invalid type filter: {type_item}. Allowed values are 'table', 'text'."
                )
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid type filter: {type_item}. Allowed values are 'table', 'text'.",
                )

    meta_info["type_filter"] = type_filter
    mapping_data = {}
    if key_column is not None:
        for idx, file in enumerate(revision_files):
            if file_extension == ".json":
                mapping_data[file.filename] = key_column[idx]
            elif file_extension in [".xlsx", ".xls"]:
                # columns = get_columns_from_file(file, file_extension)
                # if key_column[idx] not in columns:
                #     logging.info(f"Key column '{key_column[idx]}' not found in file '{file.filename}'. Available columns: {columns}")
                #     raise HTTPException(
                #         status_code=400,
                #         detail=f"Key column '{key_column[idx]}' not found in file '{file.filename}'. Available columns: {columns}",
                #     )
                mapping_data[
                    str(file.filename).replace(".xlsx", ".json").replace(".xls", ".json")
                ] = key_column[idx]
            else:
                logging.info(
                    f"Unsupported file type format: {file_extension}. This service support only json and excel file types."
                )
                raise HTTPException(
                    status_code=400,
                    detail=f"Unsupported file type format: {file_extension}. This service support only json and excel file types.",
                )

    meta_info["key_column_mapping"] = mapping_data
    logging.info("Meta information for delta comparator task ", meta_info=meta_info)
    if file_extension in [".json"]:
        exception = await validate_json_data(revision_files, key_column)
        if exception:
            logging.info("File type is not json. This service support only json file type")
            raise HTTPException(
                status_code=400,
                detail=exception,
            )
    task_data = get_task_data_delta_generator(
        revision_files, user_details, meta_info, file_extension
    )
    logging.info("Task data information: ", task_data=task_data)
    try:
        result = TaskManager.create_task(delta_comparator_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    set_job_context(task_id)
    logging.info(f"Created task with task id : {task_id}")
    source_blob_path = get_blob_segment(
        task_id,
        delta_comparator_config["feature_name"],
        str(task_data["created_timestamp"]),
    )

    task_manager = TaskManager(delta_comparator_config, task_id)

    try:
        blob_manager = BlobClientManager()
        for file in revision_files:
            if file_extension in [".xlsx", ".xls"]:
                # Convert Excel to JSON before uploading
                file.file.seek(0)
                excel_bytes = await file.read()
                df = pd.read_excel(BytesIO(excel_bytes), dtype=object)

                # Remove Excel XML carriage-return artifacts and normalize line breaks
                for col in df.select_dtypes(include=["object"]).columns:
                    df[col] = (
                        df[col]
                        .astype(str)
                        .str.replace(r"_x000D_", "", regex=True)   # remove literal artifact
                        .str.replace(r"\r\n|\r", "\n", regex=True) # normalize CRLF/CR to LF
                        .str.strip()
                    )

                json_bytes = df.to_json(
                    orient="records", indent=4, force_ascii=False
                ).encode("utf-8")
                blob_manager.upload_data_to_blob(
                    f"{source_blob_path}/{str(file.filename).replace('.xlsx', '.json').replace('.xls', '.json')}",
                    json_bytes,
                )
            else:
                blob_manager.upload_data_to_blob(
                    f"{source_blob_path}/{file.filename}",
                    await file.read(),
                )
        logging.info("Files got uploaded to blob storage")
    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value, error_message="Failed to upload the files"
        )
        logging.info(f"Files upload failed with exception :  {TaskStatus.FAILED.value}")
        raise AzureBlobUploadFailedError()

    data_rabbit_mq = {
        "trace_id": trace_id_ctx.get(),
        "parent_span_id": span_id_ctx.get(),
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": delta_comparator_config["collection_name"],
    }
    await rabbitmq.publish_task(
        delta_comparator_config["queue_name"],
        data_rabbit_mq,
    )
    task_manager.update_status_directly(TaskStatus.QUEUED.value)
    logging.info(f"Task published to RabbitMQ: {data_rabbit_mq}")
    loguru.logger.info({"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id})
    return {"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id}


@delta_router.post("/image/task/")
async def create_task(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
    type_filter: Optional[List[ImageTypeEnum]] = Query(
        ["Text", "Table", "Image"], description="Select one or more options"
    ),
    revision_files: List[UploadFile] = File(...),
    key_column: Optional[List[str]] = Query(
        ["text"], description="Enter key name in json file which needs to be processed"
    ),
):
    """
        Create a new Delta Comparator task (Text/Table/Image).

    Creates and queues a comparison job that detects differences primarily across Images and also for
    Text, Table or various combination of all three categories from the provided revision files.
    The endpoint accepts at least two ZIP files, validates inputs, stores files and metadata in
    Azure Blob Storage, persists the task in MongoDB, and publishes a processing message to RabbitMQ.

        Overview:
            - Input files: minimum two `.zip` files (only ZIP is accepted).
            - Comparison types: "Text", "Table", "Image" (one, many, or all).
            - Defaults: If no type filter is provided, all three types are compared.
            - Storage/Processing: Files saved to Azure Blob; task saved in MongoDB;
            processing initiated via RabbitMQ.

        Parameters:
            request (Request):
                The incoming HTTP request context (FastAPI).
            user_details (dict):
                Authenticated user details injected by `AuthValidation().wrapper`.
            rabbitmq (RabbitMQManager):
                RabbitMQ manager instance injected by dependency `get_rabbitmq`.
            type_filter (Optional[List[ImageTypeEnum]]):
                Comparison types to run. Allowed values: "Text", "Table", "Image".
                If omitted or empty, defaults to ["Text", "Table", "Image"].
                Accepts a list or a single comma-separated string (e.g., "Text,Image").
            revision_files (List[UploadFile]):
                List of revision files to compare. Must contain at least two files,
                and every file must have `.zip` or `.reqifz` extension.
            key_column (Optional[List[str]]):
                Key name used when processing JSON content (if applicable). Defaults to "text"
                when not provided.

        Behavior:
            1) Validates that at least two files are provided.
            2) Ensures all uploaded files are ZIP or REQIFZ archives; rejects other types.
            3) Normalizes and validates `type_filter` against allowed values.
            4) Builds task metadata (`meta_info`) including file extension, key name, and filters.
            5) Persists task in MongoDB and obtains a `task_id`.
            6) Uploads each ZIP or REQIFZ file to Azure Blob Storage under a task-specific path.
            7) Publishes a processing message to RabbitMQ with task details.
            8) Updates task status to QUEUED and returns the `task_id`.

        Returns:
            dict:
                JSON object with:
                - "message": Submission confirmation text.
                - "task_id": The newly created task identifier.

        Raises:
            HTTPException (400):
                - If fewer than two files are uploaded.
                - If any uploaded file is not a `.zip` or `.reqifz`.
                - If `type_filter` contains invalid values (not in "Text", "Table", "Image").
            AzureBlobUploadFailedError:
                If uploading files to Azure Blob Storage fails.
            HTTPException (500):
                For unexpected server-side errors (e.g., database insertion issues).

        Notes:
            - `type_filter` handling:
                * If an empty list is provided, the service falls back to all types:
                ["Text", "Table", "Image"].
                * If a single entry with commas is provided, it will be split into multiple values.
            - Observability:
                The function logs validation steps, task creation, and upload progress
                for troubleshooting and traceability.
    """

    if len(revision_files) < 2:
        logging.info(
            f"Request body have less than 2 files. Not sufficient to proceed with camparison."
        )
        raise HTTPException(
            status_code=400,
            detail="Minimum two file is required for comparison.",
        )

    for file in revision_files:
        if not file.filename or not (file.filename.lower().endswith(".reqifz") or file.filename.lower().endswith(".zip")):
            logging.info(f"{file.filename if file.filename else file} is not a zip or reqifz file. This service supports comparison between zip or reqifz files only.")

            raise HTTPException(
                status_code=400,
                detail="Invalid file type. Uploaded file type should only be .zip or .reqifz.",
            )

    meta_info = {}
    file_extension = os.path.splitext(revision_files[0].filename)[1]

    meta_info["original_file_extension"] = file_extension
    meta_info["file_extension"] = ".zip" 

    if not key_column:
        key_column: List[str] = []
    elif isinstance(key_column, str):
        key_column = [x.strip() for x in key_column.split(",") if x.strip()]

    # Ensure all entries are non-empty
    key_column = [x if x else "text" for x in key_column]

    # Adjust length
    if len(key_column) < len(revision_files):
        key_column += ["text"] * (len(revision_files) - len(key_column))
    elif len(key_column) > len(revision_files):
        key_column = key_column[: len(revision_files)]

    # if not key_name:
    #     key_name = ["text"]
    meta_info["key_name"] = key_column
    mapping_data = {}
    if key_column is not None:
        for idx, file in enumerate(revision_files):
            mapping_data[str(file.filename).replace(".reqifz", ".zip")] = key_column[idx]
    meta_info["key_column_mapping"] = mapping_data

    if len(type_filter) == 0:
        ALLOWED_TYPES = ["Text", "Table", "Image"]
        type_filter = ALLOWED_TYPES
        # logging.info(f"Insufficient filter type. At least one type filter is required.")
        # raise HTTPException(
        #     status_code=400,
        #     detail="At least one type filter is required.",
        # )
    else:
        if len(type_filter) == 1:
            type_filter = [x.strip() for x in type_filter[0].split(",") if x.strip()]
        for type_item in type_filter:
            if type_item not in ["Table", "Text", "Image"]:
                logging.info(
                    f"Invalid type filter: {type_item}. Allowed values are 'table', 'text', 'image'."
                )
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid type filter: {type_item}. Allowed values are 'table', 'text', 'image'.",
                )

    meta_info["type_filter"] = type_filter
    # Open the zip from bytes
    # for file in revision_files:
    #     content = await file.read()
    #     with zipfile.ZipFile(io.BytesIO(content)) as zip_ref:
    #         # Check if there is at least one file (not just folders)
    #         has_file = any(not info.is_dir() for info in zip_ref.infolist())

    #     if not has_file:
    #         logging.info(f"Zip file is empty or contains empty folders")
    #         raise HTTPException(status_code=400, detail="Zip file is empty or contains only folders")

    # exception = await validate_json_data(revision_files, key_name)
    # if exception:
    #     raise HTTPException(status_code=400, detail=exception, )
    task_data = get_task_data_delta_generator(
        revision_files, user_details, meta_info, file_extension
    )
    logging.info(f"Task data", task_data=task_data)
    try:
        result = TaskManager.create_task(delta_comparator_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    set_job_context(task_id)
    source_blob_path = get_blob_segment(
        task_id,
        delta_comparator_config["feature_name"],
        str(task_data["created_timestamp"]),
    )

    task_manager = TaskManager(delta_comparator_config, task_id)

    try:
        blob_manager = BlobClientManager()
        # content = await file.read()
        for file in revision_files:
            if file_extension in [".reqifz"]:
                file.file.seek(0)
                filename = file.filename
                tempfolder = Path(tempfile.mkdtemp())
                file_path = tempfolder / filename
                with open(file_path, "wb") as f_out:
                    content = await file.read()
                    f_out.write(content)
                status_code, zip_path = convert_reqifz(file_path, tempfolder)
                if not status_code:
                    logging.info(
                        f"Conversion of reqifz to zip failed for file {file.filename} with error: {zip_path}"
                    )
                    raise HTTPException(
                        status_code=400,
                        detail=f"Conversion of reqifz to zip failed for file {file.filename} with error: {zip_path}",
                    )
                zip_file_name = os.path.basename(zip_path)
                with open(zip_path, "rb") as f:
                    file_bytes = f.read()
                    blob_manager.upload_data_to_blob(
                        f"{source_blob_path}/{zip_file_name}",
                        file_bytes,
                    )
                # Clean up temporary files after upload
                try:
                    if zip_path and os.path.exists(zip_path):
                        os.remove(zip_path)
                    if tempfolder and os.path.exists(tempfolder):
                        shutil.rmtree(tempfolder)
                except Exception as cleanup_exc:
                    logging.info(f"Cleanup failed for temp files: {cleanup_exc}")
            else:
                content = await file.read()
                blob_manager.upload_data_to_blob(
                    f"{source_blob_path}/{file.filename}",
                    content,
                )
    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED, error_message="Failed to upload the files"
        )
        logging.info(f"Files upload failed with exception : {str(e)}  {TaskStatus.FAILED.value}")
        raise AzureBlobUploadFailedError()

    data_rabbit_mq = {
        "trace_id": trace_id_ctx.get(),
        "parent_span_id": span_id_ctx.get(),
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": delta_comparator_config["collection_name"],
    }
    await rabbitmq.publish_task(
        delta_comparator_config["queue_name"],
        data_rabbit_mq,
    )
    task_manager.update_status_directly(TaskStatus.QUEUED.value)
    logging.info(f"Task published to RabbitMQ: {data_rabbit_mq}")
    loguru.logger.info({"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id})
    return {"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id}


@delta_router.get("/status/{task_id}")
def download_task(task_id: str):
    """
    Get the status or results of a Delta Comparator task.

    Retrieves the status of a task by its ID. If completed successfully,
    downloads all processed result files from Azure Blob Storage, packages
    them into a ZIP archive, and returns the file. If still processing or
    failed, a descriptive status message is returned.

    Args:
        task_id (str): The unique identifier of the task.

    Returns:
        Response: A ZIP file of result data if the task succeeded.
        Response: A status message if the task is pending or failed.

    Raises:
        HTTPException: 404 if the task is not found.
        HTTPException: 500 if blob download fails or other unexpected errors occur.
    """
    # Download the content and respond with the data
    try:
        # Validate the task data from DB
        task_manager = TaskManager(delta_comparator_config, task_id)
        task_data = task_manager.get_task()
        if not task_data:
            logging.info(f"{task_data} is invalid")
            message = "Please check the mentioed task id. Given task id is invalid"
            return JSONResponse(
                content={"message": message, "task_status": "NOT_FOUND"}, status_code=404
            )
        task_status = task_data.get("status")
        if task_status == TaskStatus.SUCCESS.value:
            try:
                # Create an in-memory buffer
                blob_manager = BlobClientManager()
                blob_path = get_blob_segment(
                    task_id,
                    delta_comparator_config["feature_name"],
                    str(task_data["created_timestamp"]),
                )

                zip_buffer = io.BytesIO()

                # Write files into the in-memory zip

                blob_files = blob_manager.list_all_files_from_blob(blob_path, processed=True)
                logging.info(blob_files)
                logging.info("Listing with prefix: %s", blob_path)
                with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
                    for blob_file in blob_files:
                        blob_name = blob_file.name
                        logging.info(blob_name)
                        logging.info("Found blob: %s", blob_file.name)
                        relative_path = os.path.relpath(
                            blob_name, blob_path
                        )  # preserves folder structure
                        data = blob_manager.get_data_from_blob(blob_name, processed=True)
                        zipf.writestr(relative_path, data)

                # with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:
                #     blob_files = blob_manager.list_all_files_from_blob(blob_path, processed=True)
                #     logging.info(blob_files)
                #     for blob_file in blob_files:
                #         blob_name = blob_file.name
                #         logging.info(blob_name)
                #         data = blob_manager.get_data_from_blob(blob_name, processed=True)
                #         relative_path = os.path.relpath(blob_name, blob_path)
                #         zipf.writestr(relative_path, data)

                # Important: move cursor back to start
                zip_buffer.seek(0)

                # Return as response
                return Response(
                    content=zip_buffer.getvalue(),
                    media_type="application/zip",
                    headers={
                        "Content-Disposition": f"attachment; filename={task_id}.zip",
                        "Access-Control-Expose-Headers": "Content-Disposition",
                    },
                )
            except Exception as e:
                logging.info(f"Error in download data from blob {str(e)}")
                message = "error in download data from blob"
            #     raise HTTPException(status_code=500, detail=str(message))
        else:
            message, task_status = get_status_message(task_status)
            logging.info(f"Task status is {task_status}")
        logging.info(f"Task status: {task_status}", message=message)
        return JSONResponse(
            content={"message": message, "task_status": task_status}, status_code=202
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@delta_router.delete("/task/{task_id}")
async def delete_task(task_id: str):
    """Deletes the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to deleted.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if deleting the task fails.

    Returns:
        dict: A message indicating the result of the delete operation.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "DELETE",  # HTTP method
        "endpoint": f"/api/delta-comparator/task/{task_id}",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
    }
    logging.info(f"Received DELETE request on /api/delta-comparator/task/{task_id}. Fetching and deleting task", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(delta_comparator_config, task_id)
    try:
        logging.info(f"Deleting task details from DB")
        task_manager.delete_task()
        return {"message": "Task deleted"}
    except Exception as e:
        logging.error(f"Failed deleting tasks from MongoDB. {str(e)}")
        task_manager.update_status(
            TaskStatus.FAILED, error_message="Error deleting task in mongodb"
        )
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))
        



@delta_router.post("/cb/task/")
async def create_cb_task(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
    project: str = Form(...),
    source_tracker: str = Form(...),
    revision_tracker: str = Form(...),
):
    # Acknowledge that RabbitMQ manager is available for further task processing.
    token = get_auth_token_from_headers(request)
    codebeamer_url = os.getenv("CODEBEAMER_URL")
    logging.debug(f"RabbitMQ manager instance available for CB task: {rabbitmq}")
    if not all([source_tracker, revision_tracker, project]):
        logging.info("Missing required form data for codebeamer endpoint")
        raise HTTPException(
            status_code=400,
            detail="Missing required form data. Please provide source_tracker, revision_tracker, and project.",
        )
    # Get  Sourece Tracker and Revision Tracker data from codebeamer using API and validate the data.
    try:
        status_code, source_tracker_data = get_tracker_data(
            token,
            codebeamer_url=codebeamer_url,
            codebeamer_project=project,
            codebeamer_tracker=source_tracker,
        )
        if status_code != 200:
            logging.info(
                f"Error in retrieving tracker data from codebeamer for source tracker: {source_tracker_data}"
            )
            raise HTTPException(
                status_code=400,
                detail=f"Error in retrieving tracker data from codebeamer for source tracker: {source_tracker_data}",
            )
        status_code, revision_tracker_data = get_tracker_data(
            token,
            codebeamer_url=codebeamer_url,
            codebeamer_project=project,
            codebeamer_tracker=revision_tracker,
        )
        if status_code != 200:
            logging.info(
                f"Error in retrieving tracker data from codebeamer for revision tracker: {revision_tracker_data}"
            )
            raise HTTPException(
                status_code=400,
                detail=f"Error in retrieving tracker data from codebeamer for revision tracker: {revision_tracker_data}",
            )
        logging.info("Successfully retrieved tracker data from codebeamer")
    except Exception as e:
        logging.info(f"Error in retrieving tracker data from codebeamer: {e}")
        raise HTTPException(
            status_code=400,
            detail=f"Error in retrieving tracker data from codebeamer: {str(e)}",
        )
    source_tracker_filename = os.path.basename(source_tracker_data)
    revision_tracker_filename = os.path.basename(revision_tracker_data)
    task_data = get_task_data_code_beamer(
        user_details,
        source_tracker,
        revision_tracker,
        project,
        source_tracker_name=source_tracker_filename,
        revision_tracker_name=revision_tracker_filename,
    )
    logging.info(f"Task data", task_data=task_data)
    files = {
        source_tracker_filename: source_tracker_data,
        revision_tracker_filename: revision_tracker_data,
    }
    try:
        result = TaskManager.create_task(delta_comparator_config, task_data)
    except Exception as e:
        loguru.logger.info(
            f"There is an error with inserting the data in MongoDB. The error is {e}."
        )
    task_id = str(result.inserted_id)
    set_job_context(task_id)
    source_blob_path = get_blob_segment(
        task_id,
        delta_comparator_config["feature_name"],
        str(task_data["created_timestamp"]),
    )

    task_manager = TaskManager(delta_comparator_config, task_id)

    try:
        blob_manager = BlobClientManager()
        # content = await file.read()
        for filename, content in files.items():
            with open(content, "rb") as f:
                file_bytes = f.read()
                blob_manager.upload_data_to_blob(
                    f"{source_blob_path}/{filename}",
                    file_bytes,
                )
            # After uploading, delete the local files and their parent folders
            try:
                temp_folder = os.path.dirname(content)
                if temp_folder and os.path.exists(temp_folder):
                    shutil.rmtree(temp_folder)
            except Exception as cleanup_exc:
                logging.info(f"Cleanup failed for local files or folders: {cleanup_exc}")
    except Exception as e:
        task_manager.update_status(
            TaskStatus.FAILED.value, error_message="Failed to upload the files"
        )
        logging.info(f"Files upload failed with exception :  {TaskStatus.FAILED.value}")
        raise AzureBlobUploadFailedError()

    data_rabbit_mq = {
        "trace_id": trace_id_ctx.get(),
        "parent_span_id": span_id_ctx.get(),
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": delta_comparator_config["collection_name"],
    }
    await rabbitmq.publish_task(
        delta_comparator_config["queue_name"],
        data_rabbit_mq,
    )
    task_manager.update_status_directly(TaskStatus.QUEUED.value)
    logging.info(f"Task published to RabbitMQ", data_rabbit_mq)
    loguru.logger.info({"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id})
    return {"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id}


@delta_router.get("/feedback/{task_id}")
def feedback(task_id: str, page: int = 1, page_size: int = 10, prediction: Optional[str] = None):
    """Retrieve paginated feedback data for a given task.

    Args:
        task_id (str): The ID of the task.
        page (int): The page number for pagination. Defaults to 1.
        page_size (int): The number of items per page for pagination. Defaults to 10.
        prediction (Optional[str]): Filter by prediction value. Defaults to None.
        change_type (Optional[str]): Filter by change_type value. Defaults to None.

    Returns:
        JSONResponse: A JSON response containing paginated feedback data and total count.

    Raises:
        HTTPException: If the task is not found,
    """
    logging.info(
        f"Received request to retrieve feedback for task ID: {task_id}, page: {page}, page_size: {page_size}"
    )
    try:
        task_manager = TaskManager(delta_comparator_config, task_id)
        task = task_manager.get_task()
        if not task:
            logging.error(f"Task with ID {task_id} not found.")
            raise HTTPException(status_code=404, detail="Task not found")

        filename = "change_tracer.json"
        if not filename:
            logging.error(f"Filename missing in task with ID {task_id}.")
            raise HTTPException(status_code=404, detail="Filename missing in task")

        temp = get_blob_segment(
            task_id,
            delta_comparator_config["feature_name"],
            str(task["created_timestamp"]),
        )
        blob_path = f"{temp}/{filename}"
        logging.debug(f"Blob path for task ID {task_id}: {blob_path}")

        blob_manager = BlobClientManager()
        file_data = blob_manager.get_data_from_blob(blob_path, processed=True)
        file_name = Path(filename)
        print(file_name.suffix)
        print(type(file_data))
        if file_name.suffix == ".json":
            file_data = json.loads(file_data.decode("utf-8"))
        return process_requirements(
            file_data, page=page, page_size=page_size, prediction=prediction
        )
    except HTTPException as http_exc:
        raise http_exc
