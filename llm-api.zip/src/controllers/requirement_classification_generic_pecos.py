"""This module contains the routes and associated logic for the FastAPI application handling task items."""

import io
import json
import os
from enum import Enum
from typing import List
import tempfile
from dotenv import load_dotenv
from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Query,
    Request,
    Response,


    UploadFile,
)
from fastapi.responses import JSONResponse

from src.config.config import (
    requirement_classification_pecos_config,
)
from src.utils.utility import validate_json_input
from src.controllers.requirement_comparision_tracer_controller import get_rabbitmq
from src.exceptions.azure_exceptions import AzureBlobUploadFailedError
from src.exceptions.common_exceptions import ColumnNotFoundError
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.logger import set_job_context,trace_id_ctx,span_id_ctx
from src.utils.common.logger import log as logging
from src.utils.json_to_excel import json_to_excel
from src.utils.excel_to_json import excel_to_json
from src.utils.common.db_helper import (
    TaskManager,

)
from src.utils.common.helper import (
    get_blob_segment,
)
from src.utils.utility import get_status_message

load_dotenv()
router = APIRouter(prefix="/api/req-pecos", dependencies=[Depends(AuthValidation().wrapper)], tags=["Requirement Classification PECOS"])

container_name = os.getenv("BLOB_CONTAINER_NAME")
from src.utils.requirement_comparision_tracer_schema import get_task_data_xmc, get_task_data_pecos
from src.utils.utils_enum import APIMessages, RequestType, TaskStatus

class TypeEnum(str, Enum):
    item_type = "Item Type"
    assign_subsys_dis = "Assign Subsys Dis"
    pcm_owner = "PCM Owner"


@router.post("/task/")
async def create_task(
    request: Request,
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
    data_file: UploadFile = File(...),
    types: List[TypeEnum] = Query(..., description="Select one or more options"),
    prediction_key: str = Query(..., description="Key name for predictions"),
):
    """
    Create a new requirement classification PECOS task.

    This endpoint allows users to upload a data file and initiate
    a classification task. The file is uploaded to Azure Blob Storage,
    task metadata is stored in MongoDB, and the task is queued for
    processing via RabbitMQ.

    Args:
        request (Request): The incoming HTTP request object.
        user_details (dict): User details obtained from the authentication wrapper.
        rabbitmq (RabbitMQManager): RabbitMQ manager instance used for publishing the task.
        data_file (UploadFile): The uploaded file containing input data.
        types (List[TypeEnum]): One or more classification types.

    Returns:
        dict: A JSON response containing a success message and the created task ID.

    Raises:
        HTTPException: For input validation failures or server errors.
        AzureBlobUploadFailedError: If uploading the input file to Azure Blob fails.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/req-pecos/task/",  # API endpoint
    }
    # Extract email from user_details
    email = user_details["email"]

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "filename": data_file.filename,
        "types": types,
        "prediction_key": prediction_key,
    }
    logging.info("Creating Requirement classification PECOS task", service=service, api_request=api_request, task_data=api_request_data)
    # Validate that the uploaded file has a .json extension
    filename = data_file.filename
    if not filename.endswith(".json") and not filename.endswith(".xlsx") and not filename.endswith(".xls"):
        logging.error(f"Invalid file type uploaded: {filename}")
        raise HTTPException(
            status_code=400,
            detail="Invalid file type. Only .json and .xlsx/.xls files are allowed.",
        )
    if filename.endswith(".xlsx") or filename.endswith(".xls"):
        logging.debug(f"Excel file uploaded: {filename}. Attempting to convert to JSON.")
        try:
            # Convert Excel to JSON using the utility function
            json_data = await excel_to_json(data_file, prediction_key)
            # Convert the JSON data back to bytes for blob upload
            content = json.dumps(json_data).encode('utf-8')
            logging.debug(f"Successfully converted Excel file to JSON format for file: {filename}")
        except Exception as e:
            logging.error(f"Failed to convert Excel file to JSON: {str(e)}")
            raise HTTPException(
                status_code=400,
                detail=f"Failed to convert Excel file to JSON: {str(e)}"
            )
    else:  
        logging.debug(f"Validating JSON input for file: {filename}")
        # Validate the JSON structure - it must be a list of dicts, each containing 'text'
        exception = await validate_json_input(data_file, prediction_key)
        if exception:
            logging.error(f"Validation failed: {exception}")
            raise HTTPException(
                status_code=400,
                detail=exception,
            )
    
    # Read and parse JSON content from the uploaded file asynchronously
    try:
        if not filename.endswith(".xlsx") and not filename.endswith(".xls"):
            content = await data_file.read()  # Read file as bytes
        data = json.loads(content)        # Parse JSON content
        logging.debug(f"Successfully read and parsed JSON file: {filename}")
    except Exception as e:
        logging.error(f"Failed to read or parse the uploaded JSON file: {str(e)}")
        raise HTTPException(
            status_code=400,
            detail=f"Failed to read or parse the uploaded JSON file: {str(e)}"
        )

    # Prepare task metadata for insertion into MongoDB
    logging.debug("Preparing task metadata for MongoDB insertion")
    task_data = get_task_data_pecos(user_details, data_file, types, prediction_key)
    request_type = task_data.get("request_type")

    # Insert task metadata into MongoDB and get the generated task ID
    try:
        logging.debug("Inserting task metadata into MongoDB")
        result = TaskManager.create_task(requirement_classification_pecos_config, task_data)
    except Exception as e:
        logging.error(f"MongoDB insertion error: {e}")
        logging.error(f"Failed to create task in DB: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to create task in DB")

    task_id = str(result.inserted_id)
    set_job_context(task_id)
    logging.info(f"Meta data stored into Database with ID: {task_id}")

    # Generate the blob storage path segment based on task ID and timestamp
    source_blob_path = get_blob_segment(
        task_id,
        requirement_classification_pecos_config["feature_name"],
        str(task_data["created_timestamp"]),
    )
    logging.debug(f"Generated blob path: {source_blob_path}")

    # Initialize task manager instance to update task status later
    task_manager = TaskManager(requirement_classification_pecos_config, task_id)

    # Upload the original JSON file content to Azure Blob Storage
    try:
        blob_manager = BlobClientManager()
        # Use the content bytes we already read to avoid re-reading sync
        if filename.endswith(".xlsx") or filename.endswith(".xls"):
            # If the original file was Excel, we need to upload the converted JSON content
            blob_manager.upload_data_to_blob(
                f"{source_blob_path}/{filename.rsplit('.', 1)[0]}.json",
                content,
            )
            logging.debug(f"Uploaded converted JSON content to blob for file: {filename}")
        else:
            blob_manager.upload_data_to_blob(
                f"{source_blob_path}/{filename}",
                content,
            )
        logging.info("File uploaded to File Storage successfully")
    except Exception as e:
        # On failure, update task status as failed and raise custom error
        task_manager.update_status(
            TaskStatus.FAILED.value,
            error_message="Failed to upload the source file to File Storage",
        )
        logging.error(f"Failed to upload file to File Storage: {str(e)}")
        raise AzureBlobUploadFailedError()

    # Prepare the message payload for RabbitMQ to queue the classification task
    data_rabbit_mq = {
        "trace_id": trace_id_ctx.get(),
        "parent_span_id": span_id_ctx.get(),
        "task_id": task_id,
        "task_details": task_data,
        "collection_name": requirement_classification_pecos_config["collection_name"],
        "request_type": request_type,
    }
    logging.debug(f"Publishing task to RabbitMQ queue")

    # Publish the task message asynchronously to RabbitMQ queue
    await rabbitmq.publish_task(
        requirement_classification_pecos_config["queue_name"],
        data_rabbit_mq,
    )
    logging.debug("Task published to RabbitMQ successfully")

    # Update task status to QUEUED after successful publish
    task_manager.update_status_directly(TaskStatus.QUEUED.value)

    # Return success response with the created task ID
    logging.info(f"Task is Created with ID: {task_id} and it is QUEUED")
    return {"message": APIMessages.TASK_SUBMITTED_MSG.value, "task_id": task_id}



@router.get("/status/{task_id}")
def download_task(task_id: str):
    """
    Get the status or result of a requirement classification PECOS task.

    This endpoint retrieves the status of a task by its ID. If the task
    has successfully completed, it downloads and returns the result JSON
    file from Azure Blob Storage. If the task is still processing or
    failed, an appropriate status message is returned.

    Args:
        task_id (str): The unique identifier of the task.

    Returns:
        JSONResponse: The result JSON when the task has completed successfully.
        Response: A status message when the task is still in progress or has failed.

    Raises:
        HTTPException (404): If the task is not found.
        HTTPException (500): If downloading the result from blob fails or an unexpected error occurs.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/req-pecos/status/{task_id}",  # API endpoint
    }

    set_job_context(task_id)
    logging.info("Getting requirement classification PECOS task status", service=service, api_request=api_request)

    try:
        logging.debug("Initializing TaskManager to retrieve task data from MongoDB")
        # Initialize TaskManager to retrieve task data from MongoDB
        task_manager = TaskManager(requirement_classification_pecos_config, task_id)
        task_data = task_manager.get_task()

        # Check if task exists
        if not task_data:
            logging.error("Task not found in Database")
            message = "Please check the mentioned task id. Given task id is invalid."
            return JSONResponse(
                content={"message": message, "task_status": "NOT_FOUND"},
                status_code=404,
            )

        task_status = task_data.get("status")
        output_filename = task_data.get("output_filename")
        logging.info(f"Task Status: {task_status}")

        # If task is completed successfully, fetch result JSON from blob
        if task_status == TaskStatus.SUCCESS.value:
            logging.debug("Task completed successfully. Preparing to fetch result from blob storage.")
            blob_manager = BlobClientManager()
            blob_path = get_blob_segment(
                task_id,
                requirement_classification_pecos_config["feature_name"],
                str(task_data["created_timestamp"]),
            )

            try:
                logging.debug(f"Attempting to download file {output_filename} from blob path {blob_path}")
                file_data = blob_manager.get_data_from_blob(
                    f"{blob_path}/{output_filename}", processed=True
                )
                logging.info(f"Successfully downloaded result file")
                tempfolder = tempfile.mkdtemp()
                output_filename = output_filename.rsplit(".", 1)[0] + ".xlsx"  # Change extension to .xlsx for download 
                temp_file_path = os.path.join(tempfolder, output_filename)
                json_to_excel(json.loads(file_data), temp_file_path)  # Convert JSON to Excel and save temporarily
                # Return file content with appropriate headers for download
                return Response(
                    content=open(temp_file_path, "rb").read(),
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={
                        "Content-Disposition": f'attachment; filename="{output_filename}"',
                        "Access-Control-Expose-Headers": "Content-Disposition",
                    },
                )
            except Exception as e:
                logging.error(f"Error downloading data from blob for task_id {task_id}: {e}")
                raise HTTPException(
                    status_code=500,
                    detail="Error occurred while downloading data from blob storage.",
                )
            finally:
                # Clean up the temporary file after processing
                if os.path.exists(temp_file_path):
                    os.remove(temp_file_path)
                if os.path.exists(tempfolder):
                    os.rmdir(tempfolder)
        else:
            # If task is not successful, return current status message and code 202 (Accepted)
            message, status = get_status_message(task_status)
            logging.info(f"Task {task_id} is not completed. Current status: {task_status}")
            return JSONResponse(
                content={"message": message, "task_status": status},
                status_code=202,
            )

    except Exception as e:
        logging.error(f"Unexpected error in download_task for task_id {task_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))
