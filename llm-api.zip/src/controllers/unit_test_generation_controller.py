import asyncio
import os
import shutil
import stat
import json
import tempfile
from io import BytesIO
from datetime import datetime, timezone
import uuid
from filelock import FileLock, Timeout
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse, unquote

from fastapi import (
    APIRouter, 
    Request, 
    HTTPException, 
    Depends, 
    BackgroundTasks,
    Response,
    Form,
    Query
)
from fastapi.responses import JSONResponse

from src.utils.auth import AuthValidation
from src.utils.common.db_helper import TaskManager, get_tasks_from_db
from src.config.config import unit_test_generation_config
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.helper import get_blob_segment
from src.utils.common.logger import log as logging, trace_id_ctx, span_id_ctx, parent_span_id_ctx
from src.utils.mongo_db import MongoDB
from src.utils.utils_enum import RequestType, TaskError, TaskStatus
from src.exceptions.azure_exceptions import AzureSasUrlExpiredError
from src.utils.unit_test_generation_utils import (
    RepoMetadataManager,
    list_folders_ado,
    normalize_list_field,
    validate_clone_request_inputs,
    validate_context_request_inputs,
    validate_unit_test_request_inputs,
    validate_build_folder_download_request_inputs,
    validate_coverage_report_request_inputs,
    bypass_unit_test_generation,
    Stage
)

router = APIRouter(prefix="/api/unit-test-generation", dependencies=[Depends(AuthValidation().wrapper)], tags=["Unit Test Generation"])

UNIT_TEST_TASK_QUEUE = "unit_test_tasks"
unit_test_azure_blob_container_name = os.getenv("UNIT_TEST_AZURE_BLOB_CONTAINER_NAME", "unit-tests-generation")
blob_unit_test_artifacts_root_folder = os.getenv("BLOB_UNIT_TEST_ARTIFACTS_ROOT_FOLDER", "unit_test_artifacts")
blob_unit_test_task_result_root_folder = os.getenv("BLOB_UNIT_TEST_TASK_RESULT_ROOT_FOLDER", "unit_test_task_results")


# ---------- Utils ----------
def get_rabbitmq(request: Request):
    """Get RabbitMQ Client."""
    return request.app.state.rabbitmq

def force_delete_readonly(func, path, excinfo):
    os.chmod(path, stat.S_IWRITE)
    func(path)

def get_lock_file(path: str, workspace: str | None = None) -> str | None:
    if not path:
        return None
    
    if workspace:
        user_mail = workspace.split(os.sep)[-1]
        parts = path.split(os.sep)
        
        if user_mail not in parts:  # Expecting /opt/data/<user>/<project>/<subfolder>
            return None
        else:
            workspace_index = parts.index(user_mail)
            project_folder = parts[workspace_index + 1] if len(parts) > workspace_index + 1 else None
            if not project_folder:
                return None
            lock_file_path = os.sep.join(parts[:workspace_index + 1] + [f"{project_folder}.lock"])
            return lock_file_path

    path = os.path.normpath(path)
    parts = path.split(os.sep)

    # Expect: /opt/data/<user>/<project>/<subfolder>
    if len(parts) < 5:
        return None

    workspace_root = os.sep.join(parts[:4])   # /opt/data/<user>
    project_folder = parts[4]                 # llm-xyz

    return os.path.join(workspace_root, f"{project_folder}.lock")

def delete_folder(path: str):
    """Safely delete folder if it exists."""
    if not path:
        return

    print("Received delete", path)
    p = Path(path)
    if p.exists() and p.is_dir():
        try:
            logging.info(f"[CLEANUP] Deleting folder: {p}")
            shutil.rmtree(p, ignore_errors=False, onerror=force_delete_readonly)
        except Exception as e:
            logging.error(f"[CLEANUP] Failed to delete {p}: {e}")
    else:
        logging.info(f"[CLEANUP] Skip — folder does not exist: {p}")


# def cleanup_task_folders(task: dict):
#     """Background job to cleanup folders only if task failed."""
#     task_id = task.get("task_id")
#     clone_dir = task.get("clone_dir")
#     context_dir = task.get("context_gen_output")
#     utt_dir = task.get("unit_test_output_dir")


#     logging.info(f"[CLEANUP] Background cleanup for task {task_id} started")

#     delete_folder(clone_dir)
#     delete_folder(context_dir)
#     delete_folder(utt_dir)

#     logging.info(f"[CLEANUP] Completed background cleanup for task {task_id}")

def cleanup_task_folders(task: dict):
    """Cleanup folders only if corresponding project lock is free."""

    task_id = task.get("task_id")
    clone_dir = task.get("clone_dir", None)
    context_dir = task.get("context_gen_output", None)
    utt_dir = task.get("unit_test_output_dir", None)
    workspace = task.get("workspace", None)

    if not any([clone_dir, context_dir, utt_dir]):
        logging.warning(f"[CLEANUP] No folders to clean for task {task_id}")
        return {'message': "Cleanup skipped as no folders found to clean"}

    logging.info(f"[CLEANUP] Background cleanup for task {task_id} started")
 
    # Resolve lock file from any available path
    lock_file_path = (
        get_lock_file(clone_dir, workspace)
        or get_lock_file(context_dir, workspace)
        or get_lock_file(utt_dir, workspace)
    )

    if not lock_file_path:
        logging.error(f"[CLEANUP] Could not resolve lock file for task {task_id}")
        raise Exception("Cleanup skipped due to unresolved lock file")

    lock = None

    try:
        logging.info(f"[CLEANUP] Attempting to acquire lock {lock_file_path}")

        lock = FileLock(lock_file_path)
        lock.acquire(timeout=0)  # non-blocking

        logging.info(f"[CLEANUP] Lock acquired → safe to delete")

        # --- Perform deletion ---
        delete_folder(clone_dir)
        delete_folder(context_dir)
        delete_folder(utt_dir)

        logging.info(f"[CLEANUP] Successfully deleted folders for task {task_id}")

    except Timeout:
        logging.error(
            f"[CLEANUP] Skipping deletion for task {task_id} "
            f"(active task holding lock: {lock_file_path})"
        )
        raise Exception("Cleanup skipped due to active task holding lock. Please cancel the running task before deletion.")

    except Exception as e:
        logging.error(f"[CLEANUP] Error during cleanup: {e}")

    finally:
        if lock:
            try:
                lock.release()
            except Exception:
                pass

    logging.info(f"[CLEANUP] Completed background cleanup for task {task_id}")

# ---------- API ----------
@router.get("/status/{task_id}")
async def get_task_status(
    task_id: str
):
    """
    Get status of the task
    
    Args:
        task_id (str): Task ID

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.
    
    Returns:
        JSONResponse: The status of the task with the given task_id
    """
    service = {
        "name": "llm-api",
        "type": "backend",
        "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/unit-test-generation/status",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
    }
    logging.info("Received GET request on /api/unit-test-generation/status. Fetching task status", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(unit_test_generation_config, task_id)
    task = task_manager.get_task()
    if not task:
        logging.error(f"Failed fetching task details.")
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)
    
    task_deleted_status = task.get("deleted", False)
    if task_deleted_status:
        logging.info(f"Task with id {task_id} is marked as deleted.")
        return JSONResponse(content=f"Task is marked as deleted.", status_code=400)

    # Check the task status
    task_status = task.get("overall_status", None)
    task_stage = task.get("pipeline_stage", None)
    result_dir = None
    clone_dir = task.get("clone_dir", None)
    context_dir = task.get("context_gen_output", None)
    unit_test_dir = task.get("unit_test_output_dir", None)
    output_filename = task.get("output_filename", None)
    if task_stage == Stage.CLONE and task_status == "SUCCESS":
        clone_dir = task.get("clone_dir", None)
        if clone_dir:
            result_dir = clone_dir
    elif task_stage == Stage.CONTEXT and task_status == "SUCCESS":
        context_dir = task.get("context_gen_output", None)
        if context_dir:
            result_dir = context_dir
    elif task_stage == Stage.UNIT_TEST and task_status == "SUCCESS":
        unit_test_dir = task.get("unit_test_output_dir", None)
        if unit_test_dir:
            result_dir = unit_test_dir
    else:
        pass

    return {"Task Status": task_status,
            "Task ID": task_id,
            "result_dir": result_dir,
            "clone_dir": clone_dir,
            "context_dir": context_dir,
            "unit_test_dir": unit_test_dir,
            "output_filename": output_filename if task_stage == Stage.UNIT_TEST else None,
            "message": "Successfully fetched status of the task"}

@router.delete('/task/{task_id}')
async def delete_task(task_id: str, background_tasks: BackgroundTasks):
    """Deletes the data related to task. Also, Deletes all folders associated with the task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 400 Bad Request if the task is still processing or if task-status check is not satisfied for deletion.
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        JSONResponse: The response indicating the result of the delete operation.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "DELETE",  # HTTP method
        "endpoint": f"/api/unit-test-generation/task",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
    }
    logging.info("Received DELETE request on /api/unit-test-generation/task. Fetching and deleting task", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(unit_test_generation_config, task_id)
    try:
        logging.info(f"Fetching task details from DB for deleting")
        task = task_manager.get_task() if task_manager else None
        if task:

            # if task is already deleted, return appropriate message
            task_deleted_status = task.get("deleted", False)
            if task_deleted_status:
                logging.info(f"Task with id {task_id} is already marked as deleted.")
                return JSONResponse(content=f"Task is already marked as deleted.", status_code=400)
            
            overall_status = task.get("overall_status", "UNKNOWN")
            if overall_status == TaskStatus.PROCESSING.value:
                logging.info(f"Task is under processing. Cancel the task before deletion.")
                return JSONResponse(content="Task is under processing. Cancel the task using cancel endpoint before deletion.", status_code=400)
            if overall_status in ["FAILED", "CANCELLED", "SUCCESS"]:
                logging.info("[DELETE] Scheduling background cleanup for task")
                logging.info(f"Deleting task details from DB")
                try:
                    task_manager.delete_task()
                    logging.info(f"Successfully Deleted task details from DB")
                except Exception as e:
                    logging.error(f"Error deleting task from DB: {str(e)}")
                    raise HTTPException(status_code=500, detail="Error deleting task from DB")
                background_tasks.add_task(cleanup_task_folders, task)
                return JSONResponse(status_code=204, content="Task deleted. Cleanup scheduled.")
            else:
                return JSONResponse(content={"message": "Task not deleted as task-status check is not satisfied"}, status_code=400)
        else:
            return JSONResponse(content={"error": "Task not found"}, status_code=404)
    except Exception as e:
        logging.error(f"Failed deleting tasks {str(e)}")
        task_manager.update_status(
            TaskStatus.FAILED, error_message="Error deleting directories"
        )
        logging.error(f"Error deleting task in mongodb: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post('/retry_task/{task_id}')
async def retry_task(task_id: str,
                     rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
                     user_details: dict = Depends(AuthValidation().wrapper)):
    """Retries the task by re-publishing the extracted task data as message to RabbitMQ. 
    Also, Deletes all folders associated with the task before retrying.

    Args:
        task_id (str): The unique identifier of the task to retry.
    """
    email = user_details["email"]
    access_token = user_details["token"]
    service = {
        "name": "llm-api",
        "type": "backend",
        "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",
        "endpoint": f"/api/unit-test-generation/retry_task/{{task_id}}",
    }
    api_request_data = {
        "email": email,
        "task_id": task_id,
    }
    logging.info("Received POST request on /api/unit-test-generation/retry_task. Retrying task", service=service, api_request=api_request, task_data=api_request_data)

    try:
        task_manager = TaskManager(unit_test_generation_config, task_id)
        task = task_manager.get_task() if task_manager else None
        if not task:
            logging.error(f"Task not found for retry: {task_id}")
            raise HTTPException(status_code=404, detail="Task not found")
        
        task_status = task.get("overall_status", None)
        task_stage_status = task.get("status", None)
        task_stage = task.get("pipeline_stage", None)
        task_deleted_status = task.get("deleted", False)

        unit_tests_from_build_artifacts = task.get("unit_tests_from_build_artifacts", False)

        if task_deleted_status:
            logging.info(f"Task with id {task_id} is marked as deleted. Please submit a new request for unit test generation.")
            return JSONResponse(content=f"Task is marked as deleted. Please submit a new request for unit test generation.", status_code=400)
        
        if task_status == TaskStatus.PROCESSING.value and task_stage_status == "CANCELLATION_RECEIVED":
            logging.info(f"Task with id {task_id} is currently processing but cancellation has been requested. Please wait for the cancellation to be processed before retrying.")
            return JSONResponse(content=f"Task is currently under cancellation process. Please wait for the cancellation to be processed before retrying.", status_code=400)

        if task_status not in [TaskStatus.FAILED.value, TaskStatus.CANCELLED.value]:
            logging.info(f"Task with id {task_id} is in {task_status} status. Only tasks in FAILED or CANCELLED status can be retried.")
            return JSONResponse(content=f"Task status is '{task_status}'. Only tasks with FAILED or CANCELLED status can be retried.", status_code=400)

        if unit_tests_from_build_artifacts:
            logging.info(f"Retry requested for unit test generation from build artifacts which, is not supported currently. Please submit a new request for unit test generation from build artifacts.")
            return JSONResponse(content=f"Retry requested for unit test generation from build artifacts which, is not supported currently. Please submit a new request for unit test generation from build artifacts.", status_code=400)
        
        # Schedule cleanup of old folders
        try:
            logging.info(f"Scheduling cleanup of old folders for task retry: {task_id}")
            cleanup_task_folders(task)
        except Exception as e:
            logging.error(f"Error during cleanup of task folders for retry: {str(e)}")
            raise HTTPException(status_code=500, detail="Error during cleanup of task folders for retry")

        # Prepare message for RabbitMQ
        collection_name = unit_test_generation_config.get("collection_name")
        data_rabbit_mq = {
            "email": email,
            "task_id": task_id,
            "repo_url": task.get("repo_url"),
            "branch": task.get("branch"),
            "latest_commit": task.get("latest_commit", None),
            "token": access_token,
            "component_dir": task.get("component_dir"),
            "component_names": task.get("component_names"),
            "vector_cast_version": task.get("vector_cast_version"),
            "force_retry": True,
            "run_all": task.get("run_all"),
            "llm_refinements": task.get("llm_refinements"),
            "destination": task.get("destination"),
            "workspace": task.get("workspace"),
            "unit_tests_from_build_artifacts": unit_tests_from_build_artifacts,
            "cancellation_requested": False,
            "pipeline_stage": Stage.CLONE,   # Restarting from the beginning of the pipeline
            "pipeline": task.get("pipeline"),
            "collection_name": collection_name,
            "status_code": 102,
            "trace_id": trace_id_ctx.get(),
            "span_id": span_id_ctx.get()
        }
        logging.info(f"Re-publishing task to Queue {unit_test_generation_config['queue_name']}")
        asyncio.create_task(
            rabbitmq.publish_task(unit_test_generation_config['queue_name'], data_rabbit_mq)
        )
        logging.info(f"Task retry submitted: {task_id}")
        return {
            "success": True,
            "task_id": task_id,
            "message": "Task retry scheduled: cleanup and re-queue successful"
        }
    except HTTPException as e:
        raise e
    except Exception as e:
        logging.error(f"Failed to retry task {task_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retry task {task_id}: {e}")

@router.delete('/user_workspace/{email}')
async def delete_user_workspace(email: str, 
                                background_tasks: BackgroundTasks,
                                user_details: dict = Depends(AuthValidation().wrapper)):
    """Deletes all unit test data in user workspace. Deletes all folders associated with the user.

    Args:
        email (str): The email of the user whose workspace is to be deleted.

    Raises:
        HTTPException: 500 Internal Server Error if deleting the workspace fails.

    Returns:
        JSONResponse: 202 The response indicating the result of the delete operation.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "DELETE",  # HTTP method
        "endpoint": f"/api/unit-test-generation/user_workspace/{email}",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
    }
    logging.info("Received DELETE request on /api/unit-test-generation/user_workspace. Fetching and deleting user workspace", service=service, api_request=api_request, task_data=api_request_data)

    # task_manager = TaskManager(unit_test_generation_config, task_id)
    try:
        logging.info(f"Fetching user details")
        user_email = user_details.get("email", None)

        if os.name != "nt":
            destination = "/opt/data"
        else:
            destination = None

        if user_email and user_email != email.strip():
            logging.error(f"Unauthorized attempt to delete workspace for {email} by {user_email}")
            raise HTTPException(status_code=403, detail="Unauthorized to delete this workspace. Please provide a valid email or reach out to the team for support.")
        
        if not destination:
            logging.error(f"Invalid destination path for user workspace deletion {destination}")
            raise HTTPException(status_code=500, detail="Invalid destination path for workspace deletion")
        
        # build folder paths based on email
        safe_email = user_email.replace('.', '_').split('@')[0]
        user_defined_workspace = os.path.join(destination,safe_email)
        logging.info(f"User workspace to delete: {user_defined_workspace}")

        if os.path.exists(user_defined_workspace) and os.path.isdir(user_defined_workspace):
            # check for any locks on the folder and try to remove them before deletion
            dir_contents = os.listdir(user_defined_workspace)
            for item in dir_contents:

                if not item.endswith(".lock"):
                    continue

                lock_file_path = os.path.join(user_defined_workspace, item)

                try:
                    logging.info(f"Found lock file {lock_file_path}. Attempting to acquire it.")

                    lock = FileLock(lock_file_path)
                    lock.acquire(timeout=0)

                    try:
                        os.remove(lock_file_path)
                        logging.info(f"Removed stale lock {lock_file_path}")
                    finally:
                        lock.release()

                except Timeout:
                    raise HTTPException(
                        status_code=409,
                        detail=f"Workspace is currently in use (active task detected: {item}). "
                            "Please cancel the running task before deleting the workspace."
                    )

                except FileNotFoundError:
                    logging.info(f"Lock file already removed: {lock_file_path}")

                except Exception as e:
                    logging.warning(f"Unexpected lock handling error for {lock_file_path}: {e}")
            logging.info(f"[DELETE WORKSPACE] Scheduling background cleanup for user workspace {user_defined_workspace}")
            background_tasks.add_task(delete_folder, user_defined_workspace)
            return JSONResponse(
                content={"message": f"User workspace deletion scheduled for path - {user_defined_workspace}."},
                status_code=202
            )
    except HTTPException as e:
        raise e
    except Exception as ex:
        logging.error(f"Failed deleting user workspace {str(ex)}")
        raise HTTPException(status_code=500, detail=str(ex))

@router.get('/download/{task_id}')
def download_task(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        StreamingResponse: The file response to be downloaded.
    """
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/unit-test-generation/download",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id,
    }
    logging.info("Received GET request on /api/unit-test-generation/download. Fetching task results", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(unit_test_generation_config, task_id)
    task = task_manager.get_task()
    blob_manager_client = BlobClientManager()
    if not task:
        logging.error(f"Failed fetching task details.")
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)
    
    # Check the task status
    overall_task_status = task.get("overall_status")
    output_filename = task.get("output_filename")
    created_timestamp = str(task.get("created_timestamp"))

    task_deleted_status = task.get("deleted", False)
    if task_deleted_status:
        logging.info(f"Task with id {task_id} is marked as deleted. Results are no longer available. Please submit a new request for unit test generation.")
        return JSONResponse(content=f"Task is marked as deleted. Results are no longer available.", status_code=400)

    if overall_task_status == TaskStatus.PROCESSING.value:
        logging.info(f"Task under processing. Please, try again later")
        return JSONResponse(content="Unit Test Generation is still processing, please try again later.")
    elif overall_task_status == TaskStatus.FAILED.value:
        logging.error(f"Unit test generation has failed or is in an unrecognized state.")
        return JSONResponse(content="Unit Test generation has failed or is in an unrecognized state.", status_code=404)
    elif overall_task_status == TaskStatus.CANCELLED.value:
        logging.error(f"Unit test generation has been cancelled.")
        return JSONResponse(content="Unit Test generation has been cancelled.", status_code=404)
    elif overall_task_status == TaskStatus.DELETED.value:
        logging.error(f"The task has been deleted.")
        return JSONResponse(content="Task has been deleted.", status_code=404)
    elif overall_task_status == TaskStatus.SUCCESS.value:
        # if task status is success
        result_zip_path = task.get("output_filename", None)
        try:
            logging.info(f"Fetching results {result_zip_path}")
            if (not result_zip_path):
                raise HTTPException(status_code=404, detail="Output file not found")
            
            chronologic_blob_path = get_blob_segment(task_id, blob_unit_test_task_result_root_folder, str(created_timestamp))
            final_blob_path = f"{chronologic_blob_path}/{output_filename}"
            logging.info(f"Constructed blob path for download: {final_blob_path}")

            file_data = blob_manager_client.get_data_from_blob(
                final_blob_path,
                False,
                unit_test_azure_blob_container_name
            )
            return Response(
                content=file_data,
                media_type="application/octet-stream",
                headers={
                    "Content-Disposition": f"attachment; filename={output_filename}",
                    "Access-Control-Expose-Headers": "Content-Disposition",
                },
            )
        except Exception as e:
            raise e
    else:
        raise HTTPException(status_code=500, detail="Internal Error. Task status could not be verified.")

@router.get("/download_url/{task_id}")
def temporary_download_url(task_id: str):
    """Downloads the result of a processed task.

    Args:
        task_id (str): The unique identifier of the task to download.

    Raises:
        HTTPException: 404 Not Found if the task or file is not found.
        HTTPException: 500 Internal Server Error if downloading the file fails.

    Returns:
        Response: The URL of the file to be downloaded.
    """
    service = {
        "name": "llm-api",
        "type": "backend",
        "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/unit-test-generation/download_url",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "task_id": task_id
    }
    logging.info("Received GET request on /api/unit-test-generation/download_url. Downloading task results", service=service, api_request=api_request, task_data=api_request_data)

    task_manager = TaskManager(unit_test_generation_config, task_id)
    blob_manager_client = BlobClientManager()
    task = task_manager.get_task()
    if not task:
        logging.error(f"Failed fetching task details")
        raise HTTPException(status_code=404, detail=TaskError.NOT_FOUND.value)

    # Check the task status
    overall_status = task.get("overall_status")

    zip_blob_name = task.get("output_filename")
    created_timestamp = str(task.get("created_timestamp"))

    task_deleted_status = task.get("deleted", False)
    if task_deleted_status:
        logging.info(f"Task with id {task_id} is marked as deleted. Results are no longer available.")
        return JSONResponse(content=f"Task is marked as deleted. Results are no longer available.", status_code=400)

    if not zip_blob_name:
        logging.error(f"Missing zip file details from the task details")
        raise HTTPException(status_code=404, detail=TaskError.MISSING_FILENAME.value)

    if overall_status == TaskStatus.PROCESSING.value:
        logging.error(f"Unit Test generation is in progress. Please, try again later")
        return JSONResponse(status_code=202, content="Unit Test is in progress, please try again later.")
    elif overall_status == TaskStatus.CANCELLED.value:
        logging.error(f"Unit test generation has been cancelled.")
        return JSONResponse(content="Unit Test generation has been cancelled.", status_code=404)
    elif overall_status == TaskStatus.DELETED.value:
        logging.error(f"The task has been deleted.")
        return JSONResponse(content="Task has been deleted.", status_code=404)
    elif overall_status == TaskStatus.FAILED.value:
        # Additional failure modes can be handled here
        logging.error(f"Unit Test generation has failed or is in an unrecognized state.")
        return JSONResponse(status_code=500, content="Unit Test has failed or is in an unrecognized state.")
    
    chronologic_blob_path = get_blob_segment(task_id, blob_unit_test_task_result_root_folder, str(created_timestamp))
    final_blob_path = f"{chronologic_blob_path}/{zip_blob_name}"
    logging.info(f"Constructed blob path for download: {final_blob_path}")
    try:
        logging.info(f"Fetching download URL from blob {final_blob_path}")
        return blob_manager_client.get_downlod_url(blob_path=final_blob_path, processed=True, container_name=unit_test_azure_blob_container_name)
    except Exception as e:
        raise HTTPException(status_code=500, detail=TaskError.BLOB_DOWNLOAD_FAIL.value + str(e))

@router.post("/cancel/{task_id}")
async def cancel_task(task_id: str, 
                rabbitmq: RabbitMQManager = Depends(get_rabbitmq),
                user_details: dict = Depends(AuthValidation().wrapper)):
    """
    Endpoint to cancel a running task.

    Args:
        task_id (str): The unique identifier of the task to cancel.

    Returns:
        dict: A dictionary containing the status of the cancellation request.
    """
    try:
        email = user_details["email"]                                           
        service = {
                "name": "llm-api",
                "type": "backend",
                "framework": "FastAPI",
        }
        api_request = {
            "method": "POST",  # HTTP method
            "endpoint": f"/api/unit-test-generation/cancel",  # API endpoint
        }

        # Prepare task_data with all required fields
        api_request_data = {
            "email": email,
            "task_id": task_id
        }
        logging.info("Received request on /api/unit-test-generation/cancel.", service=service, api_request=api_request, task_data=api_request_data)
        
        # check task status from DB, if task is already in "SUCCESS" or "FAILED" status, then do not cancel the task
        task_manager = TaskManager(unit_test_generation_config, task_id)
        task_details_db = task_manager.get_task() if task_manager else None
        if not task_details_db:
            logging.error(f"Task details not found in DB for the given task_id {task_id}. Cannot proceed with cancellation.")
            raise HTTPException(status_code=404, detail="Provide a valid task_id")
        
        task_deleted_status = task_details_db.get("deleted", False)
        if task_deleted_status:
            logging.info(f"Task with id {task_id} is marked as deleted. Cancellation not possible and results are no longer available.")
            return JSONResponse(content=f"Task is marked as deleted. Cancellation not possible.", status_code=400)
        
        current_status_of_task = task_details_db.get("overall_status", None)
        if current_status_of_task in [TaskStatus.SUCCESS.value, TaskStatus.FAILED.value, TaskStatus.CANCELLED.value, TaskStatus.DELETED.value]:
            logging.info(f"Task with {task_id} is already in {current_status_of_task} status. Cancellation not required.")
            return JSONResponse(status_code=400, content=f'Task is in {current_status_of_task} status. Cancellation not required.')
        
        # Publish cancellation message to RabbitMQ
        cancellation_message = {
            "email": email,
            "task_id": task_id,
            "cancellation_requested": True,
            "token": "Not required for cancellation",
            "repo_url": task_details_db.get("repo_url", None),
            "collection_name": unit_test_generation_config.get("collection_name"),
        }
        asyncio.create_task(
            rabbitmq.publish_task(unit_test_generation_config['queue_name'], cancellation_message)
        )
        logging.info(f"Task {task_id} cancellation requested and message published to RabbitMQ.")
        return JSONResponse(content=f"Task {task_id} cancellation requested. Kindly, wait till the cancellation is processed.", status_code=202)
    
    except HTTPException as e:
        raise e
    except Exception as e:
        logging.error(f"Failed to cancel task {task_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to cancel task {task_id}: {e}")

@router.get("/tasks")
async def find_all_tasks(
    page: int = Query(..., description="Page number, starting from 1", gt=0),
    page_size: int = Query(..., description="Number of tasks per page", gt=0),
    search: Optional[str] = Query(
        None, description="Search keyword for filtering tasks across multiple fields"
    ),
    agent_id: Optional[str] = Query(None, description="Id of the agent"),
    user_details: dict = Depends(AuthValidation().wrapper),
):
    """Retrieves a paginated list of all tasks for authenticated user.

    Args:
        page (int): The page number, must be greater than 0.
        page_size (int): The number of tasks per page, must be greater than 0.
        user_details (dict): User details extracted from the validated token.

    Raises:
        HTTPException: 400 Bad Request if either page or page_size is less than or equal to zero.

    Returns:
        dict: A dictionary containing the retrieved tasks and the total count of tasks.
            - Tasks (list): A list of task data.
            - total_count (int): The total number of tasks in the collection.
    """
    email = user_details["email"]  # Extracting email from user details provided by AuthValidation
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "GET",  # HTTP method
        "endpoint": f"/api/unit-test-generation/",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "page": page,
        "page_size": page_size,
        "search": search,
        "agent_id": agent_id,
    }
    logging.info("Received request on /api/unit-test-generation/. Fetching all tasks", service=service, api_request=api_request, task_data=api_request_data)

    try:
        return get_tasks_from_db(
            unit_test_generation_config,
            email,
            page=page,
            page_size=page_size,
            search=search,
            agent_id=agent_id,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch data from collection: {str(e)}"
        )

@router.get("/list_components")
def list_components(
    repo_url: str = Query(..., description="Git repository URL"),
    branch: str = Query("master", description="Branch name to use"),
    component_dir: str | None = Query(r"source/Components", description="Path in the repo where Components are found",),
    user_details: dict = Depends(AuthValidation().wrapper)
):
    """
    Endpoint to inform the user of available components
    Components are considered to be folders with in provided 'component_dir' path

    Args:
        repo_url (str): Git repository URL
        branch (str): Branch name to checkout
        component_dir (str): Component directory as path from repo root
    """
    try:
        if not component_dir:
            raise HTTPException(status_code=400, detail="Component directory path is required to fetch available components")
        access_token = user_details["token"]  
        available_components = list_folders_ado(
            repo_url,
            branch,
            component_dir,
            access_token
        )
        if available_components and len(available_components):
            return {
                "msg": "Successfully fetched available components from the repo",
                "status": "SUCCESS",
                "available_components": available_components
            }
        else:
            raise HTTPException(status_code=404, detail="No components found in the repo for the given path")
    except HTTPException as e:
        raise e
    except Exception as ex:
        logging.error(f"Failed to fetch available components from the repo {ex}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch available components from the repo - {ex}")
    
@router.post("/clone")
async def start_clone_task(
    repo_url: str = Form(..., description="Git repository URL"),
    branch: str = Form("master", description="Branch name to use"),
    component_dir: str = Form(r"source/Components", description="Path in the repo where Components are found", example='source/Components'),
    component_names: Optional[List[str]] = Form(None, description="Individual Component names to process.", example='["AkcInput, AkcOutput"]'),
    run_all: bool | None = Form(False, description="Set this flag to True if you wish to generate unit test for all components"),
    vector_cast_version: str | None = Form("24.sp7 (02/06/25)", description="Vector Cast Version", example="24.sp7 (02/06/25)"),
    force_retry: bool = Form(False, description="Flag to bypass pulling results from existing database and generate Unit tests for the given componets"),
    pipeline: bool = Form(True, description="Flag to run the entire pipeline"),
    llm_refinements: int | None = Form(0, description="Number of times code is run through the LLM for unit test generation", ge=0, le=3),
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq)):
    """
    Endpoint to clone the repo
    0. Check if the unit test data already exists for given repo_url, branch
    1. Insert task record into MongoDB
    2. Get generated task_id
    3. Publish task message to RabbitMQ for cloning worker
    4. Return task_id

    Args:
        email (str): The email address of the user creating the task.
        repo_url (str): Git repository URL
        branch (str): Branch name to checkout
        component_dir (str): Component directory as path from repo root
        component_names (List(str)): Component names to process
        run_all (bool): Flag to specify generate unit test for all components
        vector_cast_version (str): VectorCAST tool version
        pipeline (bool): Flag to run the entire pipeline
        force_retry (bool): Flag to bypass checking of existing unit test results, removes all existing data and re-runs entire pipeline

    Raises:
        HTTPException: 400 Invalid request Error
        HTTPException: 500 Internal Server Error

    Returns:
        dict: A dictionary containing the created task ID.
    """
    email = user_details["email"]
    access_token = user_details["token"]                                           
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/unit-test-generation/clone",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "repo_url": repo_url,
        "branch": branch,
        "component_dir": component_dir,
        "component_names": component_names,
        "run_all": run_all,
        "vector_cast_version": vector_cast_version,
        "force_retry": force_retry,
        "pipeline": pipeline,
        "llm_refinements": llm_refinements
    }
    logging.info("Received request on /api/unit-test-generation/clone.", service=service, api_request=api_request, task_data=api_request_data)

    if os.name != "nt":
        destination = "/opt/data"
    else:
        destination = None

    try:
        collection_name = unit_test_generation_config.get("collection_name")

        validate_clone_request_inputs(repo_url=repo_url,
                                branch=branch,
                                component_dir=component_dir,
                                component_names=component_names,
                                token=access_token,
                                run_all=run_all,
                                destination=None)

        if not force_retry:
            if not component_names and run_all:
                component_names = list_folders_ado(
                    repo_url,
                    branch,
                    component_dir,
                    access_token
                )
            existing_tests_results = await bypass_unit_test_generation(
                repo_url=repo_url,
                branch=branch,
                component_dir=component_dir,
                component_names=component_names,
                access_token=access_token,
                email=email,
                destination=destination,
                vector_cast_version=vector_cast_version,
                llm_refinements=llm_refinements,
                pipeline=pipeline,
                force_retry=force_retry,
                collection_name=collection_name,
                rabbitmq=rabbitmq,
            )
            if existing_tests_results:
                return existing_tests_results
        # Insert into MongoDB 
        task_data = {
            "email": email,
            "repo_url": repo_url,
            "branch": branch,
            "component_dir": component_dir,
            "component_names": normalize_list_field(component_names),
            "vector_cast_version": vector_cast_version,
            "destination": destination,
            "pipeline": pipeline,
            "force_retry": force_retry,
            "run_all": run_all,
            "llm_refinements": llm_refinements,
            "unit_tests_from_build_artifacts": False,
            "pipeline_stage": Stage.CLONE,
            "status": TaskStatus.CREATED.value,
            "status_update_message": None,
            "status_code": 102,
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
            "request_type": RequestType.MANUAL.value,
        }
        try:
            logging.info(f"Creating task data")
            result = TaskManager.create_task(unit_test_generation_config, task_data)
        except Exception as e:
            logging.error(f"Failed writing data to MongoDB. {str(e)}")
            raise Exception("Failed to insert task into MongoDB")
        
        if result:
            task_id = str(result.inserted_id)

        if not access_token:
            logging.error(f"Invalid token")
            raise HTTPException(status_code=400, detail="Failed as token validation has failed")
        
        if task_id:
            # Frame Message for queue
            data_rabbit_mq = {
                "email": email,
                "task_id": task_id,
                "repo_url": repo_url,
                "branch": branch,
                "token": access_token,
                "component_dir": component_dir,
                "component_names": normalize_list_field(component_names),
                "vector_cast_version": vector_cast_version,
                "force_retry": force_retry,
                "run_all": run_all,
                "llm_refinements": llm_refinements,
                "unit_tests_from_build_artifacts": False,
                "destination": destination,
                "pipeline_stage": Stage.CLONE,
                "pipeline": pipeline,
                "collection_name": collection_name,
                "status_code": 102,
                "trace_id": trace_id_ctx.get(),
                "span_id": span_id_ctx.get()
            }

            logging.info(f"Publishing task to Queue {unit_test_generation_config['queue_name']}")
            asyncio.create_task(
                rabbitmq.publish_task(unit_test_generation_config['queue_name'], data_rabbit_mq)
            )
            logging.info(f"Task submitted: {task_id}")
            
            return {
                "success": True,
                "task_id": task_id,
                "message": "Task created and queued successfully"
            }
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/context")
async def start_context_task(
    task_id: str = Form(..., description="Task ID for already existing task from DB"),
    component_names: Optional[List[str]] = Form(None, description="Component names to process", example='["AkcInput, AkcOutput"]'),
    run_all: bool | None = Form(False, description="Set this flag to True if you wish to generate unit test for all components"),
    vector_cast_version: str | None = Form("24.sp7 (02/06/25)", description="Vector Cast Version", example="24.sp7 (02/06/25)"),
    force_retry: bool = Form(False, description="Flag to bypass pulling results from existing database and generate Unit tests for the given componets"),
    pipeline: bool = Form(False, description="Flag to run the entire pipeline"),
    llm_refinements: int | None = Form(0, description="Number of times code is run through the LLM for unit test generation", ge=0, le=3),
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq)):
    """
    Endpoint to generate context for the 
    1. Fetch details from MongoDB using task_id
    2. Publish task message to RabbitMQ for cloning worker
    4. Return task_id

    Args:
        email (str): The email address of the user creating the task.
        component_dir (str): Component directory as path from repo root
        component_names (List(str)): Component names to process
        run_all (bool): Flag to specify generate unit test for all components
        vector_cast_version (str): VectorCAST tool version
        task_id (str): Task ID for already existing task from DB
        clone_dir (str): Cloned repo path
        pipeline (bool): Flag to run the entire pipeline

    Raises:
        HTTPException: 500 Internal Server Error

    Returns:
        dict: A dictionary containing the created task ID.
    """
    email = user_details["email"]
    access_token = user_details["token"]
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/unit-test-generation/context",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "component_names": component_names,
        "vector_cast_version": vector_cast_version,
        "force_retry": force_retry,
        "run_all": run_all,
        "task_id": task_id,
        "pipeline_stage": Stage.CONTEXT,
        "pipeline": pipeline        
    }
    logging.info("Received request on /api/unit-test-generation/context.", service=service, api_request=api_request, task_data=api_request_data)

    if os.name != "nt":
        destination = "/opt/data"
    else:
        destination = None


    try:
        collection_name = unit_test_generation_config.get("collection_name")
        
        # if user provides task_id
        if task_id:
            task_manager = TaskManager(unit_test_generation_config, task_id)
            task_details_db = task_manager.get_task()
            
            # verifying task record
            if not task_details_db:
                # if task details are not found
                # donot proceed with context task creation
                logging.info(f"Task details not found in DB {task_id}. Try with a new task.")
                raise HTTPException(status_code=500, detail="Provide a valid task_id")
            
            task_deleted_status = task_details_db.get("deleted", False)
            if task_deleted_status:
                logging.info(f"Task with id {task_id} is marked as deleted. Results are no longer available.")
                return JSONResponse(content=f"Task is marked as deleted. Results are no longer available.", status_code=400)
            
            # if task details are found with given task_id
            logging.info(f"Fetching task details from DB {task_id}")
            task_data_fetched = task_details_db
            # Check if the current status of the task is "PROCESSING"
            # if the task is under "PROCESSING" dont accept the task
            current_status_of_task = task_data_fetched.get("overall_status", None)
            current_stage_of_task = task_data_fetched.get("pipeline_stage", None)
            if current_status_of_task and current_stage_of_task:
                if current_status_of_task == "PROCESSING":
                    logging.error(f"The task with {task_id} is currently in progress at {current_stage_of_task} stage. Please try again after it completes.")
                    return {
                        "success": False,
                        "task_id": task_id,
                        "message": f"The task is currently in progress at {current_stage_of_task} stage. Please try again after it completes."
                    }

            clone_dir = task_data_fetched.get("clone_dir", None)
            component_dir = task_data_fetched.get("component_dir", None)

            if not clone_dir:
                logging.error(f"Path where the repo is cloned (clone_dir) is not found within the task details")
                return {
                    "success": False,
                    "task_id": task_id,
                    "message": f"Path where the repo is cloned (clone_dir) is not found within the task details"
                }
            
            if not component_dir:
                logging.error(f"Component directory path (component_dir) is not found within the task details")
                return {
                    "success": False,
                    "task_id": task_id,
                    "message": f"Component directory path (component_dir) is not found within the task details"
                }
            
            validate_context_request_inputs(
                clone_dir=clone_dir,
                component_dir=component_dir,
                component_names=component_names,
                run_all=run_all
            )
            
            if not force_retry:
                # Check if unit tests are already available for the given repo, branch and commit
                # Get necessary data from task details
                repo_url = task_data_fetched.get("repo_url", None)
                branch = task_data_fetched.get("branch", None)
                commit_id = task_data_fetched.get("latest_commit", None)
                if repo_url and branch and commit_id:
                    if not component_names and run_all:
                        component_names = list_folders_ado(
                            repo_url,
                            branch,
                            component_dir,
                            access_token
                        )
                    existing_tests_results = await bypass_unit_test_generation(
                        repo_url=repo_url,
                        branch=branch,
                        component_dir=component_dir,
                        component_names=component_names,
                        access_token=access_token,
                        email=email,
                        destination=destination,
                        vector_cast_version=vector_cast_version,
                        llm_refinements=llm_refinements,
                        pipeline=pipeline,
                        force_retry=force_retry,
                        collection_name=collection_name,
                        rabbitmq=rabbitmq,
                    )
                    if existing_tests_results:
                        return existing_tests_results    
            
            new_changes = {
                "component_dir": component_dir,
                "component_names": normalize_list_field(component_names),
                "destination": destination,
                "pipeline": pipeline,
                "force_retry": force_retry,
                "run_all": run_all,
                "llm_refinements": llm_refinements,
                "status_code": 102,
                "status": TaskStatus.CREATED.value,
                "unit_tests_from_build_artifacts": False,
                "overall_status": TaskStatus.CREATED.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
                "request_type": RequestType.MANUAL.value,
                "pipeline_stage": Stage.CONTEXT,
                "collection_name": collection_name,
            }
            task_data_fetched.update(new_changes)
            task_data = task_data_fetched

        if task_id and task_data:
            # Frame Message for queue
            data_rabbit_mq = task_data.copy()
            data_rabbit_mq.update({
                "email": email,
                "task_id": task_id,
                "component_dir": component_dir,
                "pipeline": pipeline,
                "vector_cast_version": vector_cast_version,
                "component_names": normalize_list_field(component_names),
                "unit_tests_from_build_artifacts": False,
                "status": TaskStatus.CREATED.value,
                "overall_status": TaskStatus.CREATED.value,
                "destination": destination,
                "pipeline_stage": Stage.CONTEXT,
                "lastupdated_timestamp": datetime.now(timezone.utc),
            })

            logging.info(f"Publishing task to Queue {unit_test_generation_config['queue_name']}")
            asyncio.create_task(
                rabbitmq.publish_task(unit_test_generation_config['queue_name'], data_rabbit_mq)
            )
            logging.info(f"Task submitted: {task_id}")
            
            return {
                "success": True,
                "task_id": task_id,
                "message": "Task created and queued successfully"
            }
        else:
            return {
                "success": False,
                "task_id": task_id,
                "message": f"Task could not be created as task details are not found for {task_id}"
            }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/unit_test")
async def start_unit_test_task(
    task_id: str = Form(..., description="Task ID for already existing task from DB"),
    component_names: Optional[List[str]] = Form(None, description="Component names to process", example='["AkcInput, AkcOutput"]'),
    run_all: bool | None = Form(False, description="Set this flag to True if you wish to generate unit test for all components"),
    vector_cast_version: str | None = Form("24.sp7 (02/06/25)", description="Vector Cast Version", example="24.sp7 (02/06/25)"),
    force_retry: bool = Form(False, description="Flag to bypass pulling results from existing database and generate Unit tests for the given componets"),
    llm_refinements: int | None = Form(0, description="Number of times code is run through the LLM for unit test generation", ge=0, le=3),
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq)):
    """
    Endpoint to create unit tests for the provided context directory
    1. Fetch details from MongoDB using task_id
    2. Publish task message to RabbitMQ for cloning worker
    4. Return task_id

    Args:
        email (str): The email address of the user creating the task.
        context_dir (str): Context directory path
        component_names (List(str)): Component names to process
        vector_cast_version (str): VectorCAST tool version
        task_id (str): Task ID from DB
        clone_dir (str): Cloned repo path

    Raises:
        HTTPException: 500 Internal Server Error

    Returns:
        dict: A dictionary containing the created task ID.
    """
    email = user_details["email"]
    access_token = user_details["token"]
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/unit-test-generation/unit_test",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "task_id": task_id,
        "component_names": component_names,
        "vector_cast_version": vector_cast_version,
        "force_retry": force_retry,
        "run_all": run_all,
        "pipeline_stage": Stage.CONTEXT,
    }
    logging.info("Received request on /api/unit-test-generation/unit-test.", service=service, api_request=api_request, task_data=api_request_data)

    if os.name != "nt":
        destination = "/opt/data"
    else:
        destination = None

    try:
        
        if task_id:
            collection_name = unit_test_generation_config.get("collection_name")
            task_manager = TaskManager(unit_test_generation_config, task_id)
            task_details_db = task_manager.get_task()

            # verifying task record
            if not task_details_db:
                # if task details are not found
                # donot proceed with unit test task creation
                logging.info(f"Task details not found in DB {task_id}. Works only with existing task")
                raise HTTPException(status_code=500, detail="Failed to create task")
            
            task_deleted_status = task_details_db.get("deleted", False)
            if task_deleted_status:
                logging.info(f"Task with id {task_id} is marked as deleted. Results are no longer available.")
                return JSONResponse(content=f"Task is marked as deleted. Results are no longer available.", status_code=400)

            # if task details are found with given task_id
            logging.info(f"Fetching task details from DB {task_id}")
            task_data_fetched = task_details_db
            # Check if the current status of the task is "PROCESSING"
            # if the task is under "PROCESSING" dont accept the task
            current_status_of_task = task_data_fetched.get("overall_status", None)
            current_stage_of_task = task_data_fetched.get("pipeline_stage", None)
            if current_status_of_task and current_stage_of_task:
                if current_status_of_task == "PROCESSING":
                    logging.error(f"The task with {task_id} is currently in progress at {current_stage_of_task} stage. Please try again after it completes.")
                    return {
                        "success": False,
                        "task_id": task_id,
                        "message": f"The task is currently in progress at {current_stage_of_task} stage. Please try again after it completes."
                    }

            context_dir = task_data_fetched.get("context_gen_output", None) 
            component_dir = task_data_fetched.get("component_dir", None)
            if not context_dir:
                # if task details are not found
                # donot proceed with unit test task creation
                logging.info(f"Context generated for the repo not found (context_dir)")
                raise HTTPException(status_code=500, detail="Failed to create task")
            
            if not component_dir:
                logging.error(f"Component directory path (component_dir) is not found within the task details")
                return {
                    "success": False,
                    "task_id": task_id,
                    "message": f"Component directory path (component_dir) is not found within the task details"
                }
            
            # validate inputs - func same for context and unit test
            validate_unit_test_request_inputs(
                context_dir=context_dir,
                component_names=component_names,
                run_all=run_all)
            
            if not force_retry:
                # Check if unit tests are already available for the given repo, branch and commit
                # Get necessary data from task details
                repo_url = task_data_fetched.get("repo_url", None)
                branch = task_data_fetched.get("branch", None)
                commit_id = task_data_fetched.get("latest_commit", None)
                if repo_url and branch and commit_id:
                    if not component_names and run_all:
                        component_names = list_folders_ado(
                            repo_url,
                            branch,
                            component_dir,
                            access_token
                        )
                    existing_tests_results = await bypass_unit_test_generation(
                        repo_url=repo_url,
                        branch=branch,
                        component_dir=None,
                        component_names=component_names,
                        access_token=access_token,
                        email=email,
                        destination=destination,
                        vector_cast_version=vector_cast_version,
                        llm_refinements=llm_refinements,
                        force_retry=force_retry,
                        pipeline=False,
                        collection_name=collection_name,
                        rabbitmq=rabbitmq,
                    )
                    if existing_tests_results:
                        return existing_tests_results
                    
            new_changes = {
                "vector_cast_version": vector_cast_version,
                "component_names": normalize_list_field(component_names),
                "llm_refinements": llm_refinements,
                "force_retry": force_retry,
                "run_all": run_all,
                "unit_tests_from_build_artifacts": False,
                "status_code": 102,
                "status": TaskStatus.CREATED.value,
                "status": TaskStatus.CREATED.value,
                "overall_status": TaskStatus.CREATED.value,
                "lastupdated_timestamp": datetime.now(timezone.utc),
                "request_type": RequestType.MANUAL.value,
                "pipeline_stage": Stage.UNIT_TEST,
            }
            task_data_fetched.update(new_changes)
            task_data = task_data_fetched
                
        if task_id and task_data:
            # Frame Message for queue
            data_rabbit_mq = task_data.copy()
            data_rabbit_mq.update({
                "email": email,
                "task_id": task_id,
                "component_names": component_names,
                "vector_cast_version": vector_cast_version,
                "unit_tests_from_build_artifacts": False,
                "pipeline_stage": Stage.UNIT_TEST,
                "lastupdated_timestamp": datetime.now(timezone.utc),
                "collection_name": collection_name
            })

            logging.info(f"Publishing task to Queue {unit_test_generation_config['queue_name']}")
            asyncio.create_task(
                rabbitmq.publish_task(unit_test_generation_config['queue_name'], data_rabbit_mq)
            )
            logging.info(f"Task submitted: {task_id}")
            
            return {
                "success": True,
                "task_id": task_id,
                "message": "Task created and queued successfully"
            }
        else:
            return {
                "success": False,
                "task_id": task_id,
                "message": f"Task could not be created as task details are not found for {task_id}"
            }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 

@router.post("/unit_test_from_build")
async def generate_unit_test_from_build(
    build_folder_download_url: str = Form(..., description="Link to download the build folder"),
    component_names: Optional[List[str]] = Form(None, description="Individual Component names to process.", example='["AkcInput, AkcOutput"]'),
    run_all: bool | None = Form(False, description="Set this flag to True if you wish to generate unit test for all components"),
    vector_cast_version: str | None = Form("24.sp7 (02/06/25)", description="Vector Cast Version", example="24.sp7 (02/06/25)"),
    llm_refinements: int | None = Form(0, description="Number of times code is run through the LLM for unit test generation", ge=0, le=3),
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq)):
    """
    Endpoint to generate unit tests using the build folder
    1. Accept build folder download URL and other details from the user
    2. Publish task message to RabbitMQ for unit test generation worker
    3. Return task_id

    Args:
        email (str): The email address of the user creating the task.
        build_folder_download_url (str): Link to download the build folder
        component_names (List(str)): Component names to process
        run_all (bool): Flag to specify generate unit test for all components
        vector_cast_version (str): VectorCAST tool version

    Raises:
        HTTPException: 400 Invalid request Error
        HTTPException: 500 Internal Server Error

    Returns:
        dict: A dictionary containing the created task ID.
    """
    email = user_details["email"]
    access_token = user_details["token"]                                           
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/unit-test-generation/unit_test_from_build",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "build_folder_download_url": "XXX",  # Avoid logging the actual URL for security reasons
        "component_names": component_names,
        "run_all": run_all,
        "vector_cast_version": vector_cast_version,
        "llm_refinements": llm_refinements
    }
    logging.info("Received request on /api/unit-test-generation/unit_test_from_build.", service=service, api_request=api_request, task_data=api_request_data)

    if os.name != "nt":
        destination = "/opt/data"
    else:
        destination = None

    try:
        collection_name = unit_test_generation_config.get("collection_name")
        blob_manager_client = BlobClientManager()

        output_destination = destination if destination else tempfile.gettempdir()
        email_sanitized = email.replace('.', '_').split('@')[0]
        temp_folder = str(uuid.uuid4())
        zip_name = os.path.basename(unquote(urlparse(build_folder_download_url).path))
        task_workspace = os.path.join(output_destination, email_sanitized, 'build_artifacts', temp_folder)
        task_raw_folder = os.path.join(task_workspace, 'raw')
        task_filepath = os.path.join(task_raw_folder, zip_name)
        os.makedirs(task_raw_folder, exist_ok=True)

        # download build folder from the provided URL
        try:
            logging.info(f"Fetching build folder from blob")
            blob_manager_client.download_file_from_sas_url(sas_url=build_folder_download_url, output_path=task_filepath)
        except AzureSasUrlExpiredError:
            raise HTTPException(status_code=400, detail="Provided build folder download URL is expired or invalid. Please provide a valid SAS URL.")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to download build folder: {str(e)}")

        # validate inputs
        # unzip and look for source_context_info.json in the downloaded folder 
        # to get component_dir and other details required for validation
        try:
            unzipped_path = validate_build_folder_download_request_inputs(
                build_folder_path=task_filepath,
                component_names=component_names,
                run_all=run_all
            )
            logging.info(f"Validation successful for the downloaded build folder. Unzipped path: {unzipped_path}")
        except HTTPException as e:
            raise e
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")
        
        # Frame output path
        output_dir = str(Path(task_workspace) / 'processed')
        os.makedirs(output_dir, exist_ok=True)

        # Insert into MongoDB 
        task_data = {
            "email": email,
            "context_gen_output": unzipped_path,
            "output_dir_path": output_dir,
            "component_names": normalize_list_field(component_names),
            "vector_cast_version": vector_cast_version,
            "destination": destination,
            "run_all": run_all,
            "llm_refinements": llm_refinements,
            "pipeline_stage": Stage.UNIT_TEST,
            "build_folder_download_url": build_folder_download_url,
            "workspace": task_workspace,
            "unit_tests_from_build_artifacts": True,
            "status": TaskStatus.CREATED.value,
            "status_update_message": None,
            "status_code": 102,
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
            "request_type": RequestType.MANUAL.value,
            "repo_url": None,
            "branch": None,
            "component_dir": None,
            "pipeline": False,
            "force_retry": False,
        }
        try:
            logging.info(f"Creating task data")
            result = TaskManager.create_task(unit_test_generation_config, task_data)
        except Exception as e:
            logging.error(f"Failed writing data to MongoDB. {str(e)}")
            raise HTTPException(status_code=500, detail="Failed to create task")
        
        if result:
            task_id = str(result.inserted_id)

        if not access_token:
            logging.error(f"Invalid token")
            raise HTTPException(status_code=400, detail="Failed as token validation has failed")
        
        if task_id:
            # Frame Message for queue
            data_rabbit_mq = {
                "email": email,
                "task_id": task_id,
                "context_gen_output": unzipped_path,
                "output_dir_path": output_dir,
                "component_names": normalize_list_field(component_names),
                "vector_cast_version": vector_cast_version,
                "run_all": run_all,
                "llm_refinements": llm_refinements,
                "destination": destination,
                "pipeline_stage": Stage.UNIT_TEST,
                "collection_name": collection_name,
                "unit_tests_from_build_artifacts": True,
                "workspace": task_workspace,
                "status_code": 102,
                "token": access_token,
                "repo_url": None,
                "branch": None,
                "component_dir": None,
                "force_retry": False,
                "pipeline": False,
                "trace_id": trace_id_ctx.get(),
                "span_id": span_id_ctx.get()
            }

            logging.info(f"Publishing task to Queue {unit_test_generation_config['queue_name']}")
            asyncio.create_task(
                rabbitmq.publish_task(unit_test_generation_config['queue_name'], data_rabbit_mq)
            )
            logging.info(f"Task submitted: {task_id}")
            
            return {
                "success": True,
                "task_id": task_id,
                "message": "Task created and queued successfully"
            }
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@router.post("/unit_test_with_coverage_report")
async def generate_unit_test_with_coverage_report(
    task_id: str = Form(..., description="Task ID for already existing task from DB"),
    build_folder_download_url: str = Form(..., description="Link to download the build folder"),
    coverage_report_html_url: str = Form(..., description="Link to download the Vector cast coverage report"),
    component_name: str = Form(..., description="Component name to process"),
    user_details: dict = Depends(AuthValidation().wrapper),
    rabbitmq: RabbitMQManager = Depends(get_rabbitmq)):
    """
    Endpoint to generate unit tests using the build folder and vector cast coverage report
    1. Fetch details from MongoDB using task_id for which the unit test are generated
    2. Download the generated unit tests from blob 
    3. Accept build folder download URL and other details from the user
    4. Publish task message to RabbitMQ for unit test generation worker
    5. Return task_id

    Args:
        email (str): The email address of the user creating the task.
        task_id (str): Task ID for already existing task from DB
        build_folder_download_url (str): Link to download the build folder
        coverage_report_html_url (str): Link to download the Vector cast coverage report

    Raises:
        HTTPException: 400 Invalid request Error
        HTTPException: 500 Internal Server Error

    Returns:
        dict: A dictionary containing the created task ID.
    """
    email = user_details["email"]
    access_token = user_details["token"]                                           
    service = {
            "name": "llm-api",
            "type": "backend",
            "framework": "FastAPI",
    }
    api_request = {
        "method": "POST",  # HTTP method
        "endpoint": f"/api/unit-test-generation/unit_test_with_coverage_report",  # API endpoint
    }

    # Prepare task_data with all required fields
    api_request_data = {
        "email": email,
        "build_folder_download_url": "XXX",  # Avoid logging the actual URL for security reasons
        "coverage_report_html_url": "XXX",  # Avoid logging the actual URL for security reasons
        "component_name": component_name,
    }
    logging.info("Received request on /api/unit-test-generation/unit_test_with_coverage_report.", service=service, api_request=api_request, task_data=api_request_data)

    if os.name != "nt":
        destination = "/opt/data"
    else:
        destination = None

    try:
        collection_name = unit_test_generation_config.get("collection_name")
        blob_manager_client = BlobClientManager()

        output_destination = destination if destination else tempfile.gettempdir()
        email_sanitized = email.replace('.', '_').split('@')[0]
        temp_folder = str(uuid.uuid4())
        build_folder_zip_name = os.path.basename(unquote(urlparse(build_folder_download_url).path))
        coverage_report_file_name = os.path.basename(unquote(urlparse(coverage_report_html_url).path))
        task_workspace = os.path.join(output_destination, email_sanitized, 'build_artifacts', temp_folder)
        task_raw_folder = os.path.join(task_workspace, 'raw')
        task_processed_folder = os.path.join(task_workspace, 'processed')
        build_context_filepath = os.path.join(task_raw_folder, build_folder_zip_name)
        coverage_report_filepath = os.path.join(task_raw_folder, 'coverage', coverage_report_file_name)

        # get task details from DB using task_id and verify the record
        try:
            logging.info(f"Fetching task details from DB {task_id}")
            task_manager = TaskManager(unit_test_generation_config, task_id)
            old_task_details = task_manager.get_task()  # This will raise an error if the task_id is invalid
            if not old_task_details:
                logging.error(f"Task details not found in DB for task_id: {task_id}. Try with a new task.")
                raise HTTPException(status_code=400, detail=f"Task {task_id} not found. Provide a valid task_id")
            task_deleted_status = old_task_details.get("deleted", False)
            if task_deleted_status:
                logging.info(f"Task with id {task_id} is marked as deleted. Results are no longer available.")
                return JSONResponse(content=f"Task {task_id} is marked as deleted. Results are no longer available.", status_code=400)
        except Exception as e:
            logging.error(f"Task details not found in DB for task_id: {task_id}. Error: {str(e)}")
            raise HTTPException(status_code=400, detail=f"Task {task_id} not found. Provide a valid task_id")
        
        # get unit tests generated for the given task_id and download the unit tests to local temp folder
        try:
            task_from_build_folder_flag = old_task_details.get('unit_tests_from_build_artifacts', False)
            overall_status = old_task_details.get('overall_status', None)
            output_filename = old_task_details.get('output_filename', None)
            created_timestamp = old_task_details.get('created_timestamp', None)
            component_names_from_db = old_task_details.get('component_names', None)
            run_all_from_db = old_task_details.get('run_all', None)
            vector_cast_version_from_db = old_task_details.get('vector_cast_version', None)
            llm_refinements_from_db = old_task_details.get('llm_refinements', None)

            if not task_from_build_folder_flag:
                logging.error(f"Unit tests for the task_id: {task_id} are not generated from build artifacts. This endpoint is only for tasks with unit tests generated from build artifacts.")
                raise HTTPException(status_code=400, detail=f"Unit tests for the task_id: {task_id} are not generated from build artifacts. This endpoint is only for tasks with unit tests generated from build artifacts.")
            
            if overall_status != TaskStatus.SUCCESS.value:
                logging.error(f"Unit test generation for the task_id: {task_id} is not successful yet. Current status: {overall_status}. Please try again after the unit test generation is completed.")
                raise HTTPException(status_code=400, detail=f"Unit test generation for the task_id: {task_id} is not successful yet. Current status: {overall_status}. Please try again after the unit test generation is completed.")
            
            if not created_timestamp:
                logging.error(f"Created timestamp not found for task_id: {task_id}")
                raise HTTPException(status_code=400, detail=f"Created timestamp not found for task_id: {task_id}")
            
            if not output_filename:
                logging.error(f"Output filename not found for task_id: {task_id}")
                raise HTTPException(status_code=400, detail=f"Output filename not found for task_id: {task_id}")
            
            if not component_names_from_db:
                logging.error(f"Component names not found for task_id: {task_id}")
                raise HTTPException(status_code=400, detail=f"Component names not found for task_id: {task_id}")
            
            # download unit tests zip file from blob storage to local temp folder
            os.makedirs(task_raw_folder, exist_ok=True)
            previous_unit_test_results_zip_path = os.path.join(task_raw_folder, output_filename)  

            unit_test_results_file_path = get_blob_segment(task_id, blob_unit_test_task_result_root_folder, str(created_timestamp))
            unit_test_results_blob_path = f"{unit_test_results_file_path}/{output_filename}"
            unit_test_data = blob_manager_client.get_data_from_blob(blob_path=unit_test_results_blob_path, container_name=unit_test_azure_blob_container_name)

            if isinstance(unit_test_data, BytesIO):
                unit_test_payload = unit_test_data.getvalue()
            else:
                unit_test_payload = bytes(unit_test_data)

            with open(previous_unit_test_results_zip_path, 'wb') as f:
                f.write(unit_test_payload)
            logging.info(f"Successfully downloaded unit test results from blob storage for task_id: {task_id} to {previous_unit_test_results_zip_path}")
        except Exception as e:
            logging.error(f"Failed to download unit test results from blob storage for task_id: {task_id}. Error: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to download unit test results from blob storage for task_id: {task_id}. Error: {str(e)}")
        
        # get coverage report from the provided URL and save to local temp folder
        try:
            logging.info(f"Fetching coverage report from provided URL")
            os.makedirs(os.path.join(task_raw_folder, 'coverage'), exist_ok=True)
            blob_manager_client.download_file_from_sas_url(sas_url=coverage_report_html_url, output_path=coverage_report_filepath)
            logging.info(f"Successfully downloaded coverage report from blob storage to {coverage_report_filepath}")
        except AzureSasUrlExpiredError:
            raise HTTPException(status_code=400, detail="Provided coverage report download URL is expired or invalid. Please provide a valid SAS URL.")
        except Exception as e:
            logging.error(f"Failed to download coverage report from blob storage. Error: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Failed to download coverage report from blob storage. Error: {str(e)}")

        # download build folder from the provided URL
        try:
            logging.info(f"Fetching build folder from blob")
            blob_manager_client.download_file_from_sas_url(sas_url=build_folder_download_url, output_path=build_context_filepath)
        except AzureSasUrlExpiredError:
            raise HTTPException(status_code=400, detail="Provided build folder download URL is expired or invalid. Please provide a valid SAS URL.")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to download build folder: {str(e)}")

        # Frame output path
        os.makedirs(task_processed_folder, exist_ok=True)

        # validate inputs
        # unzip and look for source_context_info.json in the downloaded folder 
        build_context_folder_extracted_path = None
        previous_unit_test_results_extracted_path = None
        try:
            build_context_folder_extracted_path, previous_unit_test_results_extracted_path = validate_coverage_report_request_inputs(
                    previous_unit_test_results_path=previous_unit_test_results_zip_path,
                    build_folder_path=build_context_filepath,
                    coverage_report_path=coverage_report_filepath,
                    old_component_names=component_names_from_db,
                    given_component_name=component_name,
                    task_processed_folder=task_processed_folder,
                )
            if not build_context_folder_extracted_path or not previous_unit_test_results_extracted_path:
                logging.error(f"Validation failed for the coverage report request inputs. Required JSON files not found after validation.")
                raise HTTPException(status_code=400, detail=f"Validation failed for the coverage report request inputs. Required source_context_info.json files not found during validation.")
            logging.info(f"Validation successful for the coverage report task.")
        except HTTPException as e:
            raise e
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")

        # Insert into MongoDB 
        task_data = {
            "email": email,
            "context_gen_output": build_context_folder_extracted_path,
            "output_dir_path": previous_unit_test_results_extracted_path,
            "component_names": normalize_list_field([component_name]),
            "vector_cast_version": vector_cast_version_from_db,
            "destination": destination,
            "run_all": run_all_from_db,
            "llm_refinements": llm_refinements_from_db,
            "pipeline_stage": Stage.UNIT_TEST,
            "build_folder_download_url": build_folder_download_url,
            "coverage_report_html_url": coverage_report_html_url,
            "coverage_report_filepath": coverage_report_filepath,
            "workspace": task_workspace,
            "unit_tests_from_build_artifacts": True,
            "status": TaskStatus.CREATED.value,
            "status_update_message": None,
            "status_code": 102,
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
            "request_type": RequestType.MANUAL.value,
            "repo_url": None,
            "branch": None,
            "component_dir": None,
            "pipeline": False,
            "force_retry": False,
        }
        try:
            logging.info(f"Creating task data")
            result = TaskManager.create_task(unit_test_generation_config, task_data)
        except Exception as e:
            logging.error(f"Failed writing data to MongoDB. {str(e)}")
            raise HTTPException(status_code=500, detail="Failed to create task")
        
        if result:
            task_id = str(result.inserted_id)

        if not access_token:
            logging.error(f"Invalid token")
            raise HTTPException(status_code=400, detail="Failed as token validation has failed")
        
        if task_id:
            # Frame Message for queue
            data_rabbit_mq = {
                "email": email,
                "task_id": task_id,
                "context_gen_output": build_context_folder_extracted_path,
                "output_dir_path": previous_unit_test_results_extracted_path,
                "component_names": normalize_list_field([component_name]),
                "vector_cast_version": vector_cast_version_from_db,
                "run_all": run_all_from_db,
                "llm_refinements": llm_refinements_from_db,
                "destination": destination,
                "pipeline_stage": Stage.UNIT_TEST,
                "coverage_report_filepath": coverage_report_filepath,
                "collection_name": collection_name,
                "unit_tests_from_build_artifacts": True,
                "workspace": task_workspace,
                "status_code": 102,
                "token": access_token,
                "repo_url": None,
                "branch": None,
                "component_dir": None,
                "force_retry": False,
                "pipeline": False,
                "trace_id": trace_id_ctx.get(),
                "span_id": span_id_ctx.get()
            }

            logging.info(f"Publishing task to Queue {unit_test_generation_config['queue_name']}")
            asyncio.create_task(
                rabbitmq.publish_task(unit_test_generation_config['queue_name'], data_rabbit_mq)
            )
            logging.info(f"Task submitted: {task_id}")
            
            return {
                "success": True,
                "task_id": task_id,
                "message": "Task created and queued successfully"
            }
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))