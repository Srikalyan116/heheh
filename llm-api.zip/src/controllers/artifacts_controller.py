import os
import json
import re
import shutil
import uuid
from datetime import datetime, timezone
from fastapi.responses import FileResponse
import yaml

from bson import json_util
from fastapi import APIRouter, Depends, Query, HTTPException, BackgroundTasks
from dotenv import load_dotenv

from src.utils.common.logger import log as logger
from src.utils.mongo_db import MongoDB
from src.utils.auth import AuthValidation
from src.utils.repo_clone_azure import AzureReposDownloader, extract_org_project
from src.config.config import artifacts_config, agent_artifacts_config

load_dotenv()

APPLICATION_CHANGE_LOG_COLLECTION = artifacts_config["application_change_log_collection_name"]
AGENT_METADATA_COLLECTION = agent_artifacts_config["agent_data_collection_name"]
AGENT_HOSTED_REPO_URL = os.getenv("AGENT_HOSTED_REPO_URL")
AGENT_ARTIFACTS_HOME_DIR = "/opt/agent_artifacts" if os.path.exists("/opt/agent_artifacts") else os.getcwd()
AGENT_ARTIFACTS_CACHE_DIR = os.path.join(AGENT_ARTIFACTS_HOME_DIR, "data", "agent_artifacts_cache")
AGENT_ARTIFACTS_INDEX_FILE = os.path.join(AGENT_ARTIFACTS_CACHE_DIR, "agent_artifacts_index.json")


artifacts_router = APIRouter(
    prefix="/artifacts",
    tags=["Artifacts"],
)


def _safe_agent_name(agent_name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", agent_name)


def _load_artifacts_index() -> dict:
    if not os.path.exists(AGENT_ARTIFACTS_INDEX_FILE):
        return {"agents": {}}
    try:
        with open(AGENT_ARTIFACTS_INDEX_FILE, "r", encoding="utf-8") as index_file:
            data = json.load(index_file)
            if isinstance(data, dict) and isinstance(data.get("agents"), dict):
                return data
    except Exception as ex:
        logger.warning(f"Failed to read artifacts index file. Reinitializing. Error: {ex}")
    return {"agents": {}}


def _save_artifacts_index(index_data: dict) -> None:
    os.makedirs(AGENT_ARTIFACTS_CACHE_DIR, exist_ok=True)
    with open(AGENT_ARTIFACTS_INDEX_FILE, "w", encoding="utf-8") as index_file:
        json.dump(index_data, index_file, indent=2)


def _delete_path(path: str) -> None:
    if not path or not os.path.exists(path):
        return
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)
    else:
        os.remove(path)

@artifacts_router.get("/change_logs")
async def get_changes_logs(feature: str = Query(..., description="Feature to filter and extract change logs")):
    try:
        logger.info(f"Received request to find application change logs on feature {feature}")
        collection = MongoDB.get_collection(APPLICATION_CHANGE_LOG_COLLECTION)
        results = list(collection.find({"feature": feature}))
        logger.info(f"Found {len(results)} for specified feature {feature}")
        return json.loads(json_util.dumps(results))
    except Exception as ex:
        logger.error(f"Error while fetching logs from Change Log collection: {ex}")
        raise HTTPException(status_code=500, detail=f"Error fetching change logs {ex}")
    

@artifacts_router.get("/agent_data")
async def get_agent_data(background_tasks: BackgroundTasks,
                         agent_name: str = Query(..., description="Agent name to filter and extract agent data"),
                         user_details: dict = Depends(AuthValidation().wrapper)):
    try:
        logger.info(f"Received request to get agent files for agent - {agent_name}")
        collection = MongoDB.get_collection(AGENT_METADATA_COLLECTION)
        search_results = list(collection.find({"agent": {"$regex": f"^{re.escape(agent_name)}"}}))
        if not search_results:
            logger.error(f"No agent data found for agent {agent_name}")
            raise HTTPException(status_code=404, detail=f"No agent data found for agent {agent_name}")
        logger.info(f"Found {len(search_results)} for specified agent {agent_name}")

        # get latest commit from the hosted repo
        if not AGENT_HOSTED_REPO_URL:
            logger.error("AGENT_HOSTED_REPO_URL is not configured")
            raise HTTPException(status_code=500, detail="AGENT_HOSTED_REPO_URL is not configured")
        organization, project, repo_name = extract_org_project(AGENT_HOSTED_REPO_URL)

        azure_repo_downloader = AzureReposDownloader(
            organization=organization,
            project=project,
            repo_name=repo_name,
            branch="main",
            token= user_details.get("token")
        )
        try:
            clone_results = await azure_repo_downloader.download_entire_repository(output_dir=AGENT_ARTIFACTS_HOME_DIR)
            cloned_dir = clone_results.get("cloning_dir")
            latest_commit = clone_results.get("latest_commit")
            errors = clone_results.get("errors")
            if errors:
                logger.error(f"Errors occurred during cloning the repo: {errors}")
                raise HTTPException(status_code=500, detail=f"Errors occurred during cloning the repo: {errors}")
            if not cloned_dir:
                logger.error(f"Cloning failed for repo {AGENT_HOSTED_REPO_URL}")
                raise HTTPException(status_code=500, detail=f"Cloning failed for repo {AGENT_HOSTED_REPO_URL}")
            if not latest_commit:
                logger.error("Latest commit id is missing from clone response")
                raise HTTPException(status_code=500, detail="Latest commit id is missing from clone response")
            if not os.path.exists(cloned_dir) and not os.path.exists(os.path.join(cloned_dir, ".READY")):
                logger.error(f"Cloned directory not found for repo {AGENT_HOSTED_REPO_URL}")
                raise HTTPException(status_code=500, detail=f"Cloned directory not found for repo {AGENT_HOSTED_REPO_URL}")
            logger.info(f"Successfully cloned repo to {cloned_dir} at commit {latest_commit}")
        except Exception as ex:
            logger.error(f"Error while downloading agent hosted repo: {ex}")
            raise HTTPException(status_code=500, detail=f"Error while downloading agent hosted repo: {ex}")

        os.makedirs(AGENT_ARTIFACTS_CACHE_DIR, exist_ok=True)
        artifacts_index = _load_artifacts_index()
        agent_cache = artifacts_index["agents"].get(agent_name, {})
        cached_commit = agent_cache.get("latest_commit")

        if cached_commit and cached_commit != latest_commit:
            logger.info(f"New commit detected for {agent_name}. Cleaning old artifacts for commit {cached_commit}")
            old_cloned_dir = agent_cache.get("cloned_dir")
            if old_cloned_dir and old_cloned_dir != cloned_dir:
                _delete_path(old_cloned_dir)

        # merge results with same agent name
        merged_results = {}
        merged_results["agents"] = []
        merged_results["instructions"] = []
        merged_results["skills"] = []
        merged_results["servers"] = {}
        for result in search_results:
            metadata = result.get("metadata", {})
            if metadata:
                agents = metadata.get("agents", [])
                instructions = metadata.get("instructions", [])
                skills = metadata.get("skills", [])
                servers = metadata.get("servers", {})
                merged_results["agents"].extend(agents)
                merged_results["instructions"].extend(instructions)
                merged_results["skills"].extend(skills)
                merged_results["servers"].update(servers)

        # Remove duplicates while preserving original order.
        merged_results["agents"] = list(dict.fromkeys(merged_results["agents"]))
        merged_results["instructions"] = list(dict.fromkeys(merged_results["instructions"]))
        merged_results["skills"] = list(dict.fromkeys(merged_results["skills"]))

        # create a temp directory and gather files together based on the file paths in the metadata
        safe_agent_name = _safe_agent_name(agent_name)
        temp_dir = os.path.join(AGENT_ARTIFACTS_CACHE_DIR, f"{safe_agent_name}_temp_{str(uuid.uuid4())[:8]}")
        os.makedirs(os.path.join(temp_dir, ".github"), exist_ok=True)
        

        # gather files together using merged_results and cloned_dir
        # get agent versions from the files and add to merged_results
        logger.info(f"Gathering agent files for agent {agent_name} based on metadata and cloned repo")
        merged_agents_data = merged_results.get("agents", [])
        if not merged_agents_data:
            logger.error(f"No agent data found in metadata for agent {agent_name}")
            raise HTTPException(status_code=404, detail=f"No agent data found in metadata for agent {agent_name}")
        for agent_data in merged_agents_data:
            absolute_file_path = os.path.normpath(os.path.join(cloned_dir, agent_data))
            if os.path.exists(absolute_file_path):
                with open(absolute_file_path, "r", encoding="utf-8", errors="replace") as f:
                    agent_file_content = f.read()
                # Extract YAML front matter between the first two '---' lines.
                version = None
                front_matter_match = re.search(r"^---\s*\n(.*?)\n---", agent_file_content, re.DOTALL)
                if front_matter_match:
                    front_matter_content = front_matter_match.group(1)
                    front_matter = yaml.safe_load(front_matter_content) or {}

                    metadata = front_matter.get("metadata", {})
                    if isinstance(metadata, dict):
                        version = metadata.get("version")

                    # Fallback for files where version is defined at top-level.
                    if not version:
                        version = front_matter.get("version")

                if version:
                    merged_results.setdefault("agents_version", []).append(version)
                else:
                    logger.warning(f"No version found in file {absolute_file_path} for agent {agent_name}")
            else:
                logger.error(f"No file path specified in agent data for agent {agent_name}")
        
        # copy the seggregated agent files to a temp directory
        agents_dir = os.path.join(temp_dir, ".github", "agents")
        os.makedirs(agents_dir, exist_ok=True)
        for agent_file in merged_agents_data:
            # check if agent_file exists in cloned_dir and copy to temp_dir maintaining the directory structure
            agent_filepath = os.path.normpath(os.path.join(cloned_dir, agent_file))
            if os.path.exists(agent_filepath):
                shutil.copy(agent_filepath, agents_dir)

        # copy instruction files
        merged_instructions = merged_results.get("instructions", [])
        if merged_instructions:
            instructions_dir = os.path.join(temp_dir, ".github", "instructions")
            os.makedirs(instructions_dir, exist_ok=True)
            for instruction_file in merged_instructions:
                instruction_filepath = os.path.normpath(os.path.join(cloned_dir, instruction_file))
                if os.path.exists(instruction_filepath):
                    shutil.copy(instruction_filepath, instructions_dir)

        # copy skill files
        merged_skills = merged_results.get("skills", [])
        if merged_skills:
            # os.makedirs(skills_dir, exist_ok=True)
            for skill_file in merged_skills:
                skill_filepath = os.path.normpath(os.path.join(cloned_dir, skill_file))
                skill_directory = os.path.basename(skill_filepath)
                skills_dir = os.path.join(temp_dir, ".github", "skills", skill_directory)
                if os.path.exists(skill_filepath):
                    shutil.copytree(skill_filepath, skills_dir, dirs_exist_ok=True)

        # create mcp.json in .vscode folder with the servers data
        merged_servers = merged_results.get("servers", {})
        if merged_servers:
            os.makedirs(os.path.join(temp_dir, ".vscode"), exist_ok=True)
            mcp_json_path = os.path.join(temp_dir, ".vscode", "mcp.json")
            with open(mcp_json_path, "w") as mcp_json_file:
                json.dump({"servers": merged_servers, "inputs": []}, mcp_json_file, indent=4)
        
        logger.info(f"Finished gathering files for agent {agent_name}. Creating zip archive.")
        # create a zip file of the temp directory and return the path to the zip file
        zip_base_name = os.path.join(
            AGENT_ARTIFACTS_CACHE_DIR,
            f"{safe_agent_name}_{latest_commit}_{str(uuid.uuid4())[:8]}"
        )
        zip_path = shutil.make_archive(zip_base_name, "zip", temp_dir)

        # remove temp staging folder after zip creation
        _delete_path(temp_dir)

        artifacts_index["agents"][agent_name] = {
            "latest_commit": latest_commit,
            "cloned_dir": cloned_dir,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        _save_artifacts_index(artifacts_index)
        logger.info(f"Agent data successfully prepared and zipped for agent {agent_name}. Returning zip file.")
        background_tasks.add_task(_delete_path, zip_path)
        return FileResponse(zip_path, media_type="application/zip", filename=f"{agent_name}.zip")
    except HTTPException as http_ex:
        raise http_ex
    except Exception as ex:
        logger.error(f"Error while fetching logs from Agent Data collection: {ex}")
        raise HTTPException(status_code=500, detail=f"Error fetching agent data logs {ex}")