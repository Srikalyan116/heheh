"""Configurations pertaining to respective api's."""
import os

requirement_classification_config = {
    "collection_name": "req_classification_collection",
    "feature_name": "requirement_classification",
}

regulation_comparision_config = {"collection_name": "reg_comparision_collection"}

document_retriever_config = {
    "project_manage_collection_name": "project_metadata_collection",
    "task_collection_name": "task_metadata_collection",
}

requirement_comparison_tracer_config = {
    "collection_name": "req_comparison_tracer_collection",
    "feature_name": "req_comparison_tracer",
    "queue_name": "req_change_tracer",
}

requirement_classification_xmc_config = {
    "collection_name": "req_classification_xmc_collection",
    "feature_name": "requirement_classification_xmc",
    "queue_name": "requirement_classification",
}

requirement_classification_pecos_config = {
    "collection_name": "req_classification_collection",
    "feature_name": "requirement_classification_pecos",
    "queue_name": "requirement_classification_pecos",
}

iso_config = {
    "collection_name": "iso_collection",
    "feature_name": "iso",
    "queue_name": "iso",
}

incose_config = {
    "collection_name": "incose_collection",
    "feature_name": "incose",
    "queue_name": "incose",
}

delta_comparator_config = {
    "collection_name": "delta_comparator_collection",
    "feature_name": "delta-comparator",
    "queue_name": "delta_comparator",
}

requirement_comparison_tracer_prompt_config = {
    "feature_name": "requirement_document_finder",
    "collection_name": "req_comparison_tracer_prompt_collection",
}

test_case_generation_task_config = {
    "feature_name": "test_case_generation",
    "collection_name": "test_case_generation_task_collection",
}
test_case_generation_config = {
    "collection_name": "test_case_generation_collection",
    "feature_name": "test_case_generation",
}
code_search_config = {"collection_name": "code_search_collection"}
agent_config = {"collection_name": "agent_collection"}
agent_mappings_config = {"collection_name": "agents_mapping_collection"}
mongo_config = {"db_name": os.getenv("DB_NAME", "llmsd-dev")}
requirement_completeness_checker_config = {
    "collection_name": "req_completeness_checker_collection",
    "feature_name": "requirement_completeness_check",
}
design_requirement_config = {
    "collection_name": "design_requirement_collection",
    "feature_name": "design_requirement",
    "queue_name": "design_requirement",
}

test_coverage_config = {
    "collection_name": "test_coverage_collection",
    "feature_name": "test_coverage",
    "queue_name": "test_coverage",
}

unit_test_generation_config = {
    "collection_name": "unit_test_generation_collection",
    "results_collection_name": "unit_test_generation_results_tracking",
    "feature_name": "unit_test_generation",
    "queue_name": "unit_test_generation"
}

comstack_config = {
    "collection_name": "comstack_collection",
    "feature_name": "comstack",
    "queue_name": "comstack",
}

artifacts_config = {
    "application_change_log_collection_name": "application_change_log",
}

agent_artifacts_config = {
    "agent_data_collection_name": "agent_metadata_collection",
}