"""agent module for the FastAPI application."""

from typing import List

from pydantic import BaseModel


class Agent(BaseModel):
    """Represents an agent associated with a specific feature.

    Attributes:
        agent_id (str): A unique identifier for the agent.
        agent_name (str): The name of the agent.
        agent_desc (str): A description of the agent's role or functionality.
    """

    agent_id: str
    agent_name: str
    agent_desc: str


class FeatureList(BaseModel):
    """Represents a feature list in the system which includes details about a specific feature.

    Attributes:
        object_id (int): A unique identifier for the feature list object.
        co_pilot (str): The identifier of the co-pilot associated with this feature.
        feature_name (str): The name of the feature.
        feature_desc (str): A description of the feature.
        agent (List[Agent]): A list of agents associated with this feature.
    """

    object_id: int
    co_pilot: str
    feature_name: str
    feature_desc: str
    agent: List[Agent]
