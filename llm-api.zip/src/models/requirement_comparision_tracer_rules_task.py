"""This module contains the rules for the FastAPI application handling task items."""

from typing import Optional

from pydantic import BaseModel


class Rules(BaseModel):
    """Represents the rules structure for a task.

    Attributes:
        major (Optional[str]): Describes significant changes or additions that affect the task.
        minor (Optional[str]): Describes minor changes or adjustments that do not significantly alter the task.
        no_change (Optional[str]): Describes cosmetic or non-functional changes that do not affect the task outcome.
    """

    major: Optional[str]
    minor: Optional[str]
    no_change: Optional[str]
