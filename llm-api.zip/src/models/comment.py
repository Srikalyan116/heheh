"""Pydantic model for comment reference."""

from pydantic import BaseModel

from src.models.user_reference import UserRef


class Comment(BaseModel):
    """Base class for comment in codebeamer.

    Args:
        BaseModel: Base Model by pydantic.
    """

    id: int
    name: str
    createdAt: str
    createdBy: UserRef
    modifiedAt: str
    modifiedBy: UserRef
    version: int
    attachments: list
    comment: str
    commentFormat: str
    parent: object = None
