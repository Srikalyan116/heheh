"""Pydantic model for tracker item."""

from pydantic import BaseModel

from src.models.item_reference import ItemRef
from src.models.user_reference import UserRef


class TrackerItem(BaseModel):
    """Base Class for tracker item in codebeamer.

    Args:
        BaseModel: Base Model from pydantic.
    """

    id: int
    name: str
    description: str
    descriptionFormat: str
    createdAt: str
    createdBy: UserRef
    modifiedAt: str
    modifiedBy: UserRef
    owners: list
    version: int
    tracker: ItemRef
    children: list
    customFields: list
    status: ItemRef
    categories: list
    subjects: list[ItemRef]
    teams: list
    versions: list
    ordinal: int
    typeName: str
    comments: list
    tags: list
