"""This module defines the Task class model for representing tasks in the application."""

from pydantic import BaseModel


class TestCaseGenerationTask(BaseModel):
    """A model representing a Task with detailed attributes for tracking and management.

    Attributes:
        task_name (str): The name of the task.
        project_name(str): The name of the project.
        did_requirement_file(str): requirement file that is uploaded.
        req_text_col(str) : Text column that is required.
        req_id_col(str) :  Id column that is required.
        project_id(str) :   Id of the project.
        created_timestamp (str): The timestamp when the task was created.
        lastupdated_timestamp (str): The timestamp when the task was last updated.
        test_case_generation_status (str): The status of test case generation like success or processing or failed.
        test_case_generation_output_file_name (str): Test case generation output file name.
        test_procedure_generation_status (str):  The status of test procedure generation like success or processing or failed.
        test_procedure_generation_output_filename (str): Test procedure generation output file name.


    """

    task_name: str
    agent_id: str
    email: str
    project_name: str
    project_id: str
    req_text_col: str
    req_id_col: str
    project_id: str
    created_timestamp: str
    lastupdated_timestamp: str
    test_case_generation_status: str
    test_case_generation_output_file_name: str
    test_procedure_generation_status: str
    test_procedure_generation_output_filename: str
    status_error_message: str
    # template_test_case: str
