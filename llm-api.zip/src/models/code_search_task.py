"""This module defines the Task class model for representing tasks in the application."""

from pydantic import BaseModel


class CodeSearchTask(BaseModel):
    """A model representing a Task with detailed attributes for tracking and management.

    Attributes:
        email (str): The email address of the user.
        project(str) :   Name of the project.
        repo_url(str) : The url of the repository.
        branch_name(str) : Name of the branch.
        created_timestamp (str): The timestamp when the task was created.
        lastupdated_timestamp (str): The timestamp when the task was last updated.
        status_error_message(str): Error message of status.
    """

    email: str
    repo_url: str
    branch_name: str
    project_name: str
    status: str
    repo_type: str
    branch: str
    production_lines: str
    timestamp: str
    status_update_message: dict
    status_code: str
