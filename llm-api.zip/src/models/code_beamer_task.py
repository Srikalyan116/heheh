"""Data model for query parameters."""

from typing import List

from pydantic import BaseModel


class Value(BaseModel):
    """Value Model."""

    id: int
    type: str


class FieldValue(BaseModel):
    """Field Value Model."""

    fieldId: int
    type: str
    values: List[Value]


class Item(BaseModel):
    """Item Model."""

    itemId: int
    fieldValues: List[FieldValue]


class UpdateResponse(BaseModel):
    """Updating response model."""

    status: str
    # updatedItems: List[Item]
    successfulOperationsCount: int
