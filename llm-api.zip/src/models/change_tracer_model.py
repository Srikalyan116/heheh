from typing import Optional

from fastapi import File, Form, UploadFile


class ChangeTracerForm:
    def __init__(
        self,
        agent_id: str = Form(...),
        rule_id: str = Form(...),
        project: Optional[str] = Form(""),
        source_file: UploadFile = File(...),
        revision_file: UploadFile = File(...),
        isIdSelected: bool = Form(False, description="Set it to True if change tracer is id based"),
        source_id: Optional[str] = Form(None, description="Enter source column ID"),
        source_col_name: Optional[str] = Form(None, description="Enter source column name"),
        revision_id: Optional[str] = Form(None, description="Enter revision column ID"),
        revision_col_name: Optional[str] = Form(None, description="Enter  revision column name"),
    ):
        self.agent_id = agent_id
        self.rule_id = rule_id
        self.project = project
        self.source_col_name = source_col_name
        self.revision_col_name = revision_col_name
        self.isIdSelected = isIdSelected
        self.source_id = source_id
        self.revision_id = revision_id
        self.source_file = source_file
        self.revision_file = revision_file


def individual_serial(task) -> dict:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the tsak item.
    """
    return {
        "id": str(task.get("_id", "")),
        "rule_id": task.get("rule_id", ""),
        "rule_name": task.get("rule_name", ""),
        "request_type": task.get("request_type", ""),
        "source_tracker": task.get("source_tracker", ""),
        "revision_tracker": task.get("revision_tracker", ""),
        "user_id": task.get("user_id", ""),
        "project": task.get("project", ""),
        "email": task.get("email", ""),
        "output_filename": task.get("output_filename", ""),
        "source_filename": task.get("source_filename", ""),
        "revision_filename": task.get("revision_filename", ""),
        "source_col_name": task.get("source_col_name", ""),
        "revision_col_name": task.get("revision_col_name", ""),
        "source_id": task.get("source_id", ""),
        "revision_id": task.get("revision_id", ""),
        "status": task.get("status", ""),
        "created_timestamp": task.get("created_timestamp", ""),
        "lastupdated_timestamp": task.get("lastupdated_timestamp", ""),
        "status_error_message": task.get("status_error_message", ""),
        "status_update_message": task.get("status_update_message", {}),
        "status_code": task.get("status_code", 500),
    }


def list_serial(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial(task) for task in tasks]
