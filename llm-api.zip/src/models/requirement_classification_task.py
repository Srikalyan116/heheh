"""This module defines the Task class model for representing tasks in the application."""

from pydantic import BaseModel


class RequirementClassTask(BaseModel):
    """A model representing a Task with detailed attributes for tracking and management.

    Attributes:
        status (str): The current status of the task (e.g., pending, completed).
        created_timestamp (str): The timestamp when the task was created.
        lastupdated_timestamp (str): The timestamp when the task was last updated.
        project (str): The name of the project this task is associated with.
        tracker (str): The tracking identifier for project management tools.
    """

    id: str
    agent_id: str
    agent_name: str
    project: str
    filename: str
    status: str
    created_timestamp: str
    lastupdated_timestamp: str
    tracker: str
    prediction_id: str
    prediction_col_name: str
    label_column: str
    request_type: str
    status_error_message: str
    code_beamer_status: str
    code_beamer_error_message: str
    successfulOperationsCount: str
