"""This module contains the definition for the UpdateItem class."""

from typing import Optional

from pydantic import BaseModel


class UpdateItem(BaseModel):
    """UpdateItem represents the structure for updating an item.

    Attributes:
        ID (str): The unique identifier for the item.
        source (str): The source of the item.
        revision (str): The revision number of the item.
        changeType (str): The type of change being made.
        changes (str): The detailed description of the changes.
        feedback (str): Any feedback related to the changes.
    """

    ID: Optional[str] = None
    source: str
    revision: str
    changeType: str
    changes: str
    feedback: str
