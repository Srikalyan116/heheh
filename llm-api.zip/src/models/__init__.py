"""Module for pydantic models."""
