"""This module contains the definition for the UpdateItem class."""

from pydantic import BaseModel


class UpdateItem(BaseModel):
    """Represents an item update with prediction feedback and rating.

    Attributes:
        ID (str): The unique identifier for the item.
        requirement (str): The requirement description for the item.
        prediction (str): The prediction made for the requirement.
        prediction_feedback (str): Feedback on the prediction.
        #rating (str): The rating given based on the feedback.
    """

    ID: str
    requirement: str
    prediction: str
    prediction_feedback: str
    # rating: str
