"""Pydantic model for user reference."""

from pydantic import BaseModel


class UserRef(BaseModel):
    """Base class for user reference in codebeamer.

    Args:
        BaseModel: Base Model by pydantic.
    """

    id: int
    name: str
    type: str
    email: str
