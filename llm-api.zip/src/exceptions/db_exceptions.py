"""Exceptions which are related to DB Operations."""


class SerializationError(Exception):
    """Object to string conversion failed error."""

    def __init__(self):
        """Error Initialization."""
        self.message = "Failed to convert the data from DB"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class DBFetchError(Exception):
    """Fetching the documents from DB failed error."""

    def __init__(self):
        """Error Initialization."""
        self.message = "Fetching from Mongo DB Failed"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class TaskNotFoundError(Exception):
    """Task ID is not found in the DB."""

    def __init__(self):
        """Error Initialization."""
        self.message = "Task Not Available in DB"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class RecordInsertionFailed(Exception):
    """Inserting records to the DB failed."""

    def __init__(self):
        """Error Initialization."""
        self.message = "Failed to add the Record in DB"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class InvalidIDFormatError(Exception):
    """ID is not in the intended format to be searched."""

    def __init__(self, id):
        """Error Initialization."""
        self.message = f"'{id}' ID is invalid"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message
