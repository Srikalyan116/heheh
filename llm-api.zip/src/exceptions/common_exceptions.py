"""Common Exceptions for general operations."""


class FileNotSupportedError(Exception):
    """File Validation failed error."""

    def __init__(self, file_extension):
        """Error Initialization."""
        self.message = f"File with the extension '{file_extension}' is not supported"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class EmptyColumnsError(Exception):
    """Empty dataframe error."""

    def __init__(self, filename):
        """Error Initialization."""
        self.message = f"File {filename} does has 0 Columns"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class InvalidColumnsError(Exception):
    """Column names are not proper."""

    def __init__(self, filename):
        """Error Initialization."""
        self.message = f"File {filename} does not have appropriate column names"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class ColumnNotFoundError(Exception):
    """Column name verification failed."""

    def __init__(self, column_name: str):
        """Error Initialization."""
        self.message = f"'{column_name}' column is not present in the file"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class DeletingTaskError(Exception):
    """Soft Delete of the record failed."""

    def __init__(self, task_id):
        """Error Initialization."""
        self.message = f"'{task_id}' failed to delete in blob or soft delete in db"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class InvalidHeaderError(Exception):
    """Invalid request header of an API."""

    def __init__(self):
        """Error Initialization."""
        self.message = "Failed to get Auth Token from the header"
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message
