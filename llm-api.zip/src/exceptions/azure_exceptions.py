"""Custom Exceptions for Azure functions."""


class AzureBlobDownloadError(Exception):
    """Blob Download failure."""

    def __init__(self):
        """Error Initialization."""
        self.message = "Failed to download the data from Azure Blob "
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class AzureBlobUploadFailedError(Exception):
    """Blob Upload Failure."""

    def __init__(self):
        """Error Initialization."""
        self.message = "Failed to upload the data to Azure Blob "
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message


class AzureSasUrlExpiredError(Exception):
    """SAS URL is expired or invalid."""

    def __init__(self):
        """Error Initialization."""
        self.message = "SAS URL has expired or is invalid."
        super().__init__(self.message)

    def __str__(self):
        """String representation of the error."""
        return self.message
