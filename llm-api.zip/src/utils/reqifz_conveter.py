#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ReqIF/ReqIFZ exporter (full + general, auto German detection)

Outputs:
- <stem>_full.json    : everything (attributes, enums, images, tables)
- <stem>_general.json : compact list of { id, images, text, type, header [, text_de] }
- <stem>_full.xlsx    : Excel view (default: ON; disable with --no-xlsx)
- resources/          : extracted images
- resources/tables/   : extracted tables as CSV

Usage:
  python reqif_export_both.py INPUT.reqifz --outdir out_folder [--no-xlsx]
"""
import tempfile, zipfile, json, re, unicodedata, logging, os
import matplotlib.pyplot as plt
from src.utils.common.logger import log as logging
from logging import root
import pandas as pd
import dataframe_image as dfi
from unittest import result
import argparse, base64, csv, json, re, unicodedata, zipfile
from pathlib import Path
from urllib.parse import unquote
import xml.etree.ElementTree as ET
import json
import xml.etree.ElementTree as ET

# ---------- Namespaces ----------
REQIF_NS = {"reqif": "http://www.omg.org/spec/ReqIF/20110401/reqif.xsd"}
XHTML_NS = {"xhtml": "http://www.w3.org/1999/xhtml"}

# ---------- Globals ----------
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".svg", ".bmp", ".tif", ".tiff", ".webp"}

# ---------- Utils ----------
def strip_ns(tag: str) -> str:
    return tag.split("}")[-1] if "}" in tag else tag

def normspace(s: str) -> str:
    return " ".join((s or "").split())

def dehyphenate(text: str) -> str:
    if not text:
        return text
    return re.sub(r'(\w)-\s+(\w)', r'\1\2', text)

def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p

def _nz(v):
    if v is None: return None
    if isinstance(v, str):
        v2 = v.strip()
        return v2 if v2 else None
    return v

def _normalize_for_match(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return s.lower()

def _tokens(s: str) -> list[str]:
    return re.split(r"[^a-z0-9]+", _normalize_for_match(s))

def _slug(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", s or "")

# ---------- Loading ----------
def load_reqif(path: Path):
    """Return (root, zip_ref or None, inner_name)."""
    if path.suffix.lower() == ".reqifz":
        zf = zipfile.ZipFile(path, "r")
        inner = next((n for n in zf.namelist() if n.lower().endswith(".reqif")), None)
        if not inner:
            raise RuntimeError("No .reqif found in archive")
        return ET.parse(zf.open(inner)).getroot(), zf, inner
    return ET.parse(path).getroot(), None, path.name

def get_content(root: ET.Element) -> ET.Element:
    core = root.find("reqif:CORE-CONTENT", REQIF_NS)
    if core is None:
        raise RuntimeError("No CORE-CONTENT found")
    return core.find("reqif:REQ-IF-CONTENT", REQIF_NS) or core

# ---------- Attribute + Enum discovery ----------
def build_attr_name_map(content: ET.Element) -> dict:
    """Map attribute-definition IDENTIFIER -> LONG-NAME."""
    amap = {}
    st = content.find("reqif:SPEC-TYPES", REQIF_NS)
    if st is None:
        return amap
    for stype in st.findall("reqif:SPEC-OBJECT-TYPE", REQIF_NS):
        sa = stype.find("reqif:SPEC-ATTRIBUTES", REQIF_NS)
        if sa is None: continue
        for ad in list(sa):
            aid = ad.get("IDENTIFIER", "")
            ln  = ad.get("LONG-NAME", "") or ad.findtext("reqif:LONG-NAME", default="", namespaces=REQIF_NS) or ""
            if aid:
                ln = (ln or aid).replace("_de-DE", "_de").strip()
                amap[aid] = ln
    # Save attribute name map to JSON in extract folder
    # out_dir = Path(__file__).parent / "export"
    # out_dir.mkdir(parents=True, exist_ok=True)
    # attr_map_path = out_dir / "attribute_name_map.json"
    # with attr_map_path.open("w", encoding="utf-8") as f:
    #     json.dump(amap, f, indent=2, ensure_ascii=False)
    return amap

def build_enum_catalog(content: ET.Element):
    """
    Returns:
      enum_label_map: { enumValueID -> label }
      enum_catalog:   { enumDatatypeLongName -> [ {id,label,key} ] }
      enum_dtype_id2name: { datatype_identifier -> datatype_long_name }
    """
    enum_label_map = {}
    enum_catalog = {}
    enum_dtype_id2name = {}

    dts = content.find("reqif:DATATYPES", REQIF_NS)
    if dts is None:
        return enum_label_map, enum_catalog, enum_dtype_id2name

    for dt in dts:
        if strip_ns(dt.tag) != "DATATYPE-DEFINITION-ENUMERATION":
            continue

        dtype_name = (dt.get("LONG-NAME") or
                      dt.findtext("reqif:LONG-NAME", default="", namespaces=REQIF_NS) or
                      dt.findtext("LONG-NAME", default="") or "").strip() or dt.get("IDENTIFIER", "ENUM")
        dtype_id = dt.get("IDENTIFIER", "")
        if dtype_id:
            enum_dtype_id2name[dtype_id] = dtype_name

        options = []
        for ev in dt.iter():
            if strip_ns(ev.tag) != "ENUM-VALUE":
                continue
            ev_id = ev.get("IDENTIFIER", "") or ev.get("IDENTIFIER-REF", "")
            if not ev_id:
                continue
            label = (ev.get("LONG-NAME") or
                     ev.findtext("reqif:LONG-NAME", default="", namespaces=REQIF_NS) or
                     ev.findtext("LONG-NAME", default="") or "").strip()
            key = ""
            props = ev.find("reqif:PROPERTIES", REQIF_NS) or ev.find("PROPERTIES")
            if props is not None:
                emb = props.find("reqif:EMBEDDED-VALUE", REQIF_NS) or props.find("EMBEDDED-VALUE")
                if emb is not None:
                    key = (emb.get("KEY") or "").strip()

            if label:
                enum_label_map[ev_id] = label
            options.append({"id": ev_id, "label": label or ev_id, "key": key})

        if options:
            enum_catalog[dtype_name] = options
    # Save enum maps to JSON in extract folder
    # out_dir = Path(__file__).parent / "export"
    # out_dir.mkdir(parents=True, exist_ok=True)
    # enum_maps_path = out_dir / "enum_maps.json"
    # with enum_maps_path.open("w", encoding="utf-8") as f:
    #     json.dump({
    #         "enum_label_map": enum_label_map,
    #         "enum_catalog": enum_catalog,
    #         "enum_dtype_id2name": enum_dtype_id2name
    #     }, f, indent=2, ensure_ascii=False)
    return enum_label_map, enum_catalog, enum_dtype_id2name

def build_attr_enumtype_map(content: ET.Element) -> dict:
    """Return mapping: attribute LONG-NAME -> enum datatype identifier (for option listing)."""
    amap = {}
    st = content.find("reqif:SPEC-TYPES", REQIF_NS)
    if st is None: return amap
    for stype in st.findall("reqif:SPEC-OBJECT-TYPE", REQIF_NS):
        sa = stype.find("reqif:SPEC-ATTRIBUTES", REQIF_NS)
        if sa is None: continue
        for ad in list(sa):
            if strip_ns(ad.tag) != "ATTRIBUTE-DEFINITION-ENUMERATION":
                continue
            attr_long_name = (ad.get("LONG-NAME") or ad.findtext("reqif:LONG-NAME", default="", namespaces=REQIF_NS) or "").strip() \
                             or ad.get("IDENTIFIER", "").strip()
            attr_long_name = attr_long_name.replace("_de-DE", "_de")
            t = ad.find("reqif:TYPE", REQIF_NS) or ad.find("TYPE")
            dtype_ref = None
            if t is not None:
                for child in list(t):
                    dtype_ref = (child.text or "").strip() or child.get("IDENTIFIER-REF") or child.get("REF")
                    if dtype_ref: break
            if dtype_ref:
                amap[attr_long_name] = dtype_ref
    # Save attribute enumtype map to JSON in extract folder
    # out_dir = Path(__file__).parent / "export"
    # out_dir.mkdir(parents=True, exist_ok=True)
    # enumtype_map_path = out_dir / "attribute_enumtype_map.json"
    # with enumtype_map_path.open("w", encoding="utf-8") as f:
    #     json.dump(amap, f, indent=2, ensure_ascii=False)
    return amap

def attr_ref_from_definition(def_el: ET.Element) -> str | None:
    if def_el is None: return None
    for child in list(def_el):
        if child.text and child.text.strip():
            return child.text.strip()
        rid = child.get("IDENTIFIER-REF")
        if rid: return rid
    return def_el.get("IDENTIFIER-REF")

# ---------- Value readers ----------
def read_string_value(val_el: ET.Element) -> str:
    return (val_el.get("THE-VALUE") or
            val_el.findtext(".//reqif:THE-VALUE", default="", namespaces=REQIF_NS) or
            "").strip()

def read_simple_value(val_el: ET.Element) -> str:
    return (val_el.get("THE-VALUE") or
            val_el.findtext(".//reqif:THE-VALUE", default="", namespaces=REQIF_NS) or
            "").strip()

def xhtml_text(xhtml_root: ET.Element) -> str:
    if xhtml_root is None: return ""
    txt = normspace("".join(xhtml_root.itertext()))
    return dehyphenate(txt)

# ---------- XHTML images + tables ----------
def extract_images_from_xhtml(xhtml_elem: ET.Element, zip_ref, res_dir: Path, id_hint: str) -> list[str]:
    saved = []
    if xhtml_elem is None: return saved
    ensure_dir(res_dir)

    for tag, attr in [("img","src"), ("object","data")]:
        for el in xhtml_elem.findall(f".//{{{XHTML_NS['xhtml']}}}{tag}"):
            ref = (el.get(attr) or "").strip()
            if not ref: continue

            # Case A: data:image/*;base64,...
            if ref.startswith("data:"):
                m = re.match(r"data:(?P<mime>[^;]+);base64,(?P<b64>.+)$", ref, flags=re.I|re.S)
                if not m: continue
                mime, b64 = m.group("mime").lower(), m.group("b64")
                if not mime.startswith("image/"): continue
                ext = {
                    "image/png": ".png","image/jpeg": ".jpg","image/jpg": ".jpg","image/gif": ".gif",
                    "image/svg+xml": ".svg","image/bmp": ".bmp","image/webp": ".webp","image/tiff": ".tiff",
                }.get(mime, ".bin")
                try:
                    raw = base64.b64decode(b64)
                except Exception:
                    continue
                fname = f"{id_hint}_{len(saved)+1}{ext}"
                (res_dir / fname).write_bytes(raw)
                saved.append(f"resources/{fname}")
                continue

            # Case B: file reference inside zip (or relative path)
            ref_path = unquote(ref).lstrip("./\\").split("#", 1)[0]
            if zip_ref is not None:
                for nm in zip_ref.namelist():
                    if nm == ref_path or nm.replace("\\","/") == ref_path or Path(nm).name.lower() == Path(ref_path).name.lower():
                        out_name = f"{id_hint}_{len(saved)+1}_{Path(nm).name}"
                        if Path(out_name).suffix.lower() in IMAGE_EXTS:
                            (res_dir / out_name).write_bytes(zip_ref.read(nm))
                            saved.append(f"resources/{out_name}")
                        break
    return saved

def _iter_tables(xhtml_elem: ET.Element):
    if xhtml_elem is None:
        return []
    return xhtml_elem.findall(f".//{{{XHTML_NS['xhtml']}}}table")

def _parse_table(table_el: ET.Element):
    rows_2d, has_header, max_cols = [], False, 0
    trs = table_el.findall(f".//{{{XHTML_NS['xhtml']}}}tr")
    for r_idx, tr in enumerate(trs):
        row, th_present = [], False
        for cell in list(tr):
            tag = strip_ns(cell.tag).lower()
            if tag not in {"td","th"}: continue
            if tag == "th": th_present = True
            txt = dehyphenate(normspace("".join(cell.itertext())))
            colspan = int(cell.get("colspan", "1") or "1")
            colspan = max(colspan, 1)
            for _ in range(colspan):
                row.append(txt)
        if r_idx == 0 and th_present: has_header = True
        rows_2d.append(row)
        max_cols = max(max_cols, len(row))
    for r in rows_2d:
        if len(r) < max_cols:
            r += [""] * (max_cols - len(r))
    return rows_2d, has_header, max_cols

def _table_to_markdown(rows_2d, has_header, max_cols):
    if not rows_2d:
        return ""
    if has_header:
        header, body = rows_2d[0], rows_2d[1:]
    else:
        header, body = [f"Col{i+1}" for i in range(max_cols)], rows_2d
    def _mkline(cells): return "| " + " | ".join(cells) + " |"
    lines = [_mkline(header), "| " + " | ".join(["---"] * max_cols) + " |"]
    lines += [_mkline(r) for r in body[:50]]  # limit preview
    return "\n".join(lines)

def extract_tables_from_xhtml(xhtml_elem: ET.Element, res_tables_dir: Path, id_hint: str, attr_hint: str):
    tables = []
    if xhtml_elem is None: return tables
    ensure_dir(res_tables_dir)
    safe_attr = _slug(attr_hint or "Attr")
    for idx, t in enumerate(_iter_tables(xhtml_elem), start=1):
        rows_2d, has_header, max_cols = _parse_table(t)
        if not rows_2d: continue
        if False:  # For debugging: save all tables as CSV + markdown preview
            table_name = f"{_slug(id_hint)}_{safe_attr}_{idx}.csv"
            csv_path = res_tables_dir / table_name
            with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                for r in rows_2d:
                    writer.writerow(r)
        else:  # For production: only save tables with header and at least 2 rows (configurable)
            table_name = f"{_slug(id_hint)}_{safe_attr}_{idx}.png"
            img_path = res_tables_dir / table_name

            # Convert to DataFrame
            df = pd.DataFrame(rows_2d[1:], columns=rows_2d[0])
            #print(f"Extracted table with {len(rows_2d)-1} rows and {max_cols} cols for attribute '{attr_hint}' (has_header={has_header})")
            # Export as image
            #dfi.export(df, img_path)
            # Create figure
            fig, ax = plt.subplots()
            ax.axis('tight')
            ax.axis('off')

            # Create table
            table = ax.table(cellText=rows_2d, loc='center')

            # Optional: improve layout
            table.auto_set_font_size(False)
            table.set_fontsize(10)
            table.auto_set_column_width(col=list(range(len(rows_2d[0]))))

            # Save image
            plt.savefig(img_path, bbox_inches='tight', dpi=100)
            plt.close()
        md = _table_to_markdown(rows_2d, has_header, max_cols)
        tables.append({
            "attribute": attr_hint,
            "file_name": f"resources/tables/{table_name}",
            "rows": len(rows_2d),
            "cols": max_cols,
            "has_header": has_header,
            "markdown_preview": md
        })
    return tables

# ---------- Extra: scan image-like strings in attributes ----------
def scan_images_in_attrs(attrs: dict, current: list[str]) -> list[str]:
    out = list(current or [])
    seen = {p.lower() for p in out}
    for v in (attrs or {}).values():
        if not v: continue
        vals = v if isinstance(v, list) else [v]
        for s in vals:
            s = str(s)
            if re.search(r"\.(png|jpg|jpeg|gif|svg|bmp|tif|tiff|webp)\b", s, flags=re.I):
                if s.lower() not in seen:
                    out.append(s)
                    seen.add(s.lower())
    return out

# ---------- Enum + attr helpers ----------
def parse_enum_ref_text(raw: str) -> str:
    if not raw: return ""
    parts = raw.split("--", 1)
    return parts[0].strip()

# ---------- Universal field resolvers (for general.json) ----------
_POS_TYPE_CORE   = {"type","typ","art","class","category","kategorie","klasse","kind"}
_POS_TYPE_OBJECT = {"object","objekt","artifact","artefact","requirement","anforderung"}
_NEG_TYPE        = {"data","daten","attribute","attribut","value","wert","status","state","phase","format","datatype","valuetype"}
_PRIMITIVE_VALUES = {"string","text","integer","int","float","double","real","boolean","bool","date","datetime","xhtml","number"}

def _looks_like_primitive_value(val: str) -> bool:
    v = _normalize_for_match(str(val))
    return v in _PRIMITIVE_VALUES

def resolve_type_anyfile(attrs: dict, enum_attr_names: set[str] | None = None) -> str | None:
    enum_attr_names = enum_attr_names or set()
    best_val, best_score = None, float("-inf")
    for k, v in (attrs or {}).items():
        if v is None or v == "": continue
        if isinstance(v, list): v = " | ".join(map(str, v))
        val = str(v).strip()
        if not val or _looks_like_primitive_value(val): continue
        toks = set(_tokens(k)); nk = _normalize_for_match(k)
        score = 0
        if nk.endswith("type"): score += 3
        if toks & _POS_TYPE_CORE: score += 2
        if toks & _POS_TYPE_OBJECT: score += 2
        if toks & _NEG_TYPE: score -= 3
        if k in (enum_attr_names or set()): score += 1
        if len(val) <= 60: score += 1
        if score > best_score:
            best_val, best_score = val, score
    return best_val if best_score > 0 else None

def resolve_id_anyfile(spec_id: str, attrs: dict) -> str:
    """Prefer Customer*/Prefix, then Foreign/External/Source IDs; else SPEC-OBJECT GUID."""
    candidates = []
    for k, v in (attrs or {}).items():
        vv = _nz(v)
        if vv is None: continue
        nk = _normalize_for_match(k); sval = str(vv).strip()
        score = 0
        if "customer" in nk or "kunde" in nk: score += 3
        if "prefix" in nk: score += 2
        if "foreign" in nk or "external" in nk or "extern" in nk: score += 3
        if "sourceid" in nk or "source" in nk: score += 1
        if "id" in nk or "identifier" in nk or "ident" in nk: score += 2
        if any(s in nk for s in ("parent","attribute","class","type","datatype","valuetype")): score -= 4
        candidates.append((score, sval))
    if candidates:
        candidates.sort(reverse=True)
        if candidates[0][0] > 0:
            return candidates[0][1]
    return spec_id

# ---- NEW: header/number resolver for general.json ----
_HEADER_KEYS = ["ReqIF.ChapterNumber", "CustomerChapterNumber", "ReqIF.Name"]

def resolve_header_anyfile(attrs: dict) -> str | None:
    """
    Resolve numbering like '1.1', '2', '3.4' for the 'header' field in general.json.
    Priority:
      1) ReqIF.ChapterNumber
      2) CustomerChapterNumber
      3) Try to parse a leading number pattern from ReqIF.Name (e.g., '1.2.3 Title')
    """
    # 1 & 2: direct fields
    for k in ("ReqIF.ChapterNumber", "CustomerChapterNumber"):
        v = _nz(attrs.get(k))
        if v:
            return str(v).strip()

    # 3) Parse from ReqIF.Name: pick leading "1", "1.2", "1.2.3", etc.
    name = _nz(attrs.get("ReqIF.Name"))
    if name:
        m = re.match(r"\s*(\d+(?:\.\d+){0,5})\b", str(name))
        if m:
            return m.group(1)
    return None

_POS_TEXT = {"text","description","content","beschreibung","inhalt","requirement"}
_NEG_TEXT = {"criteria","criterion","verification","akzeptanz","acceptance","rationale","note","comment","kommentar","status","method","quelle","source"}
_LANG_DE_HINTS = ("_de","de-de","german","deutsch","textde")

def _key_has_lang_hint(k: str, lang: str) -> bool:
    nk = _normalize_for_match(k)
    if lang == "de":
        return any(h in nk for h in _LANG_DE_HINTS)
    if lang == "en":
        return ("_en" in nk) or ("english" in nk) or nk.endswith("texten")
    return False

def resolve_text_anyfile(attrs: dict, lang: str, require_lang_hint: bool = False) -> str | None:
    best, best_score = None, float("-inf")
    for k, v in (attrs or {}).items():
        vv = _nz(v)
        if vv is None: continue
        toks = set(_tokens(k)); nk = _normalize_for_match(k)
        score = 0
        if toks & _POS_TEXT: score += 3
        if toks & _NEG_TEXT: score -= 2
        if _key_has_lang_hint(k, lang): score += 4
        L = len(vv)
        if 20 <= L <= 20000: score += 1
        elif L < 5: score -= 2
        if score > best_score:
            best, best_score = vv, score
    if best_score > 0: return best
    if not require_lang_hint:
        for k, v in (attrs or {}).items():
            vv = _nz(v)
            if vv is None: continue
            toks = set(_tokens(k))
            if toks & _POS_TEXT and not (toks & _NEG_TEXT):
                return vv
    return None

# --- Language detection ---
GERMAN_CHARS = set("äöüÄÖÜß")
GERMAN_HINTS = {" der ", " die ", " das ", " und ", " nicht ", " wird ", " sollen ", " muss ", " gemäß ", " für ", " mit ", " ohne ", " sowie "}
EN_HINTS     = {" the ", " shall ", " should ", " must ", " will ", " is ", " are ", " each ", " per "}

def is_german(s: str) -> bool:
    if not s:
        return False
    t = " " + s.lower() + " "
    score_de = sum(t.count(w) for w in GERMAN_HINTS)
    score_en = sum(t.count(w) for w in EN_HINTS)
    if any(c in s for c in GERMAN_CHARS):
        score_de += 2
    # German must clearly win (or at least 2 strong hints)
    return score_de >= max(2, score_en + 1)

def select_text_auto(attrs: dict) -> tuple[str|None, str|None]:
    """
    Returns (text_final, text_de_final_or_none)
    Strategy:
      1) Prefer EN-hinted as main text.
      2) If DE-hinted exists and is actually German, include as text_de.
      3) Otherwise look at generic; if generic looks German, use as text_de (and main if no EN).
      4) Only include text_de if it's truly German and not identical to main text.
    """
    text_en_hint = resolve_text_anyfile(attrs, "en", require_lang_hint=True)
    text_de_hint = resolve_text_anyfile(attrs, "de", require_lang_hint=True)
    if text_de_hint and not is_german(text_de_hint):
        text_de_hint = None

    # Both hinted (valid)
    if text_en_hint and text_de_hint:
        return text_en_hint, text_de_hint

    generic = resolve_text_anyfile(attrs, "en", require_lang_hint=False)
    generic_de = generic if (generic and is_german(generic)) else None

    if text_en_hint:
        # EN main; DE only if valid (hint or generic)
        return text_en_hint, (text_de_hint or generic_de)

    if text_de_hint:
        # DE only; use DE as main and as text_de
        return text_de_hint, text_de_hint

    # Neither hinted: fall back to generic
    if generic:
        if generic_de:
            # generic is German
            return generic, generic
        return generic, None

    return None, None

# ---------- Core extraction ----------
def run(in_path: Path, out_dir: Path, write_xlsx: bool):
    root, zip_ref, inner_name = load_reqif(in_path)
    content = get_content(root)
    hierarchy_map = build_hierarchy_map(content)
    # Store hierarchy_map in JSON file in export folder
    hierarchy_json_path = out_dir / "hierarchy_map.json"
    with hierarchy_json_path.open("w", encoding="utf-8") as f:
        json.dump(hierarchy_map, f, indent=2, ensure_ascii=False)
    # maps
    attr_name_by_id = build_attr_name_map(content)
    enum_label_map, enum_catalog, enum_dtype_id2name = build_enum_catalog(content)
    attr_enumtype_ref = build_attr_enumtype_map(content)  # attr long-name -> enum datatype id

    # build enum -> options per attribute long-name
    enumCatalogByAttribute = {}
    for attr_lname, dtype_ref in attr_enumtype_ref.items():
        dtype_name = enum_dtype_id2name.get(dtype_ref, dtype_ref)
        options = enum_catalog.get(dtype_name, [])
        enumCatalogByAttribute[attr_lname] = {"datatype": dtype_name, "options": options}

    # iterate objects
    sobjs_el = content.find("reqif:SPEC-OBJECTS", REQIF_NS)
    if sobjs_el is None:
        raise SystemExit("No SPEC-OBJECTS found.")

    items, all_attr_names = [], set()
    res_dir = ensure_dir(out_dir / "resources")
    res_tables_dir = ensure_dir(res_dir / "tables")

    for sobj in sobjs_el.findall("reqif:SPEC-OBJECT", REQIF_NS):
        sid   = sobj.get("IDENTIFIER", "")
        sname = (sobj.findtext("reqif:LONG-NAME", default="", namespaces=REQIF_NS) or "").strip()
        attributes, images, tables_meta = {}, [], []

        values = sobj.find("reqif:VALUES", REQIF_NS)
        if values is not None:
            for val in values:
                tag = strip_ns(val.tag)
                def_el = val.find("reqif:DEFINITION", REQIF_NS)
                ref_id = attr_ref_from_definition(def_el)
                attr_long_name = attr_name_by_id.get(ref_id, ref_id or tag)

                if tag == "ATTRIBUTE-VALUE-STRING":
                    v = read_string_value(val)
                    if v:
                        prev = attributes.get(attr_long_name, "")
                        attributes[attr_long_name] = (prev + (" | " if prev else "") + v)
                        all_attr_names.add(attr_long_name)

                elif tag == "ATTRIBUTE-VALUE-XHTML":
                    the = val.find("reqif:THE-VALUE", REQIF_NS)
                    txt = xhtml_text(the)
                    if txt:
                        prev = attributes.get(attr_long_name, "")
                        attributes[attr_long_name] = (prev + (" | " if prev else "") + txt)
                        all_attr_names.add(attr_long_name)
                    imgs = extract_images_from_xhtml(the, zip_ref, res_dir, id_hint=sid or "obj")
                    if imgs:
                        images.extend(imgs)
                    tmeta = extract_tables_from_xhtml(the, res_tables_dir, id_hint=sid or "obj", attr_hint=attr_long_name)
                    if tmeta:
                        tables_meta.extend(tmeta)

                elif tag == "ATTRIBUTE-VALUE-ENUMERATION":
                    enum_ids = []
                    for r in val.findall(".//reqif:VALUES/reqif:ENUM-VALUE-REF", REQIF_NS):
                        raw = (r.text or "").strip() or r.get("IDENTIFIER-REF", "") or r.get("REF", "")
                        if raw: enum_ids.append(parse_enum_ref_text(raw))
                    for r in val.findall(".//ENUM-VALUE-REF"):
                        raw = (r.text or "").strip() or r.get("IDENTIFIER-REF", "") or r.get("REF", "")
                        if raw: enum_ids.append(parse_enum_ref_text(raw))
                    if not enum_ids:
                        for r in val.iter():
                            if strip_ns(r.tag) == "ENUM-VALUE-REF":
                                raw = (r.text or "").strip() or r.get("IDENTIFIER-REF", "") or r.get("REF", "")
                                if raw: enum_ids.append(parse_enum_ref_text(raw))
                    labels = [enum_label_map.get(eid, eid) for eid in enum_ids if eid]
                    if labels:
                        prev = attributes.get(attr_long_name)
                        if prev is None:
                            attributes[attr_long_name] = labels[0] if len(labels) == 1 else " | ".join(labels)
                        else:
                            attributes[attr_long_name] = (prev + " | " + " | ".join(labels))
                        all_attr_names.add(attr_long_name)

                elif tag in {"ATTRIBUTE-VALUE-INTEGER","ATTRIBUTE-VALUE-REAL","ATTRIBUTE-VALUE-BOOLEAN",
                             "ATTRIBUTE-VALUE-DATE","ATTRIBUTE-VALUE-DATE-TIME"}:
                    v = read_simple_value(val)
                    if v:
                        prev = attributes.get(attr_long_name, "")
                        attributes[attr_long_name] = (prev + (" | " if prev else "") + v)
                        all_attr_names.add(attr_long_name)

                else:
                    v = read_simple_value(val)
                    if v:
                        prev = attributes.get(attr_long_name, "")
                        attributes[attr_long_name] = (prev + (" | " if prev else "") + v)
                        all_attr_names.add(attr_long_name)

        # Attribute strings can also contain file refs -> capture them
        images = scan_images_in_attrs(attributes, images)

        items.append({
            "id": sid,
            "parentId": hierarchy_map.get(sid),
            "longName": sname,
            "attributes": attributes,
            "images": images,
            "tables": tables_meta
        })

    # ---------- Write FULL JSON ----------
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(inner_name).stem
    json_full_path = out_dir / f"{stem}_full.json"

    payload = {
        "summary": {
            "innerFile": inner_name,
            "specObjects": len(items),
            "uniqueAttributes": len(all_attr_names),
            "enumTypes": list(enum_catalog.keys()),
        },
        "enumCatalog": enum_catalog,
        "enumCatalogByAttribute": {k: {"datatype": v["datatype"], "options": v["options"]}
                                   for k, v in enumCatalogByAttribute.items()},
        "specObjects": items
    }
    payload_final = {}
    for item_data in items:
        payload_final[item_data["id"]] = item_data["attributes"].get("ReqIF.ChapterName") or item_data["attributes"].get("ReqIF.Text")
    payload["specObjects"] = payload_final  # simplified map for backward compatibility; full data is in "specObjects_full"
    payload["specObjects_full"] = items  # keep full data in "specObjects_full" for backward compatibility; "payload_final" is the new simplified map
    final_repsonse = []
    for item_Data in items:
        if item_Data.get("images"):
            final_repsonse.append({
                "type": "image",
                "parent" : payload_final.get(item_Data["parentId"], None),
                "img_path": item_Data.get("images", [])[0] if item_Data.get("images", []) else ""
            })
        elif item_Data.get("tables"):
            final_repsonse.append({
                "type": "table",
                "parent" : payload_final.get(item_Data["parentId"], None),
                "img_path": item_Data.get("tables", [])[0]["file_name"] if item_Data.get("tables", []) else "",
                "text": item_Data.get("tables", [])[0]["markdown_preview"] if item_Data.get("tables", []) else ""
            })
        else:
            final_repsonse.append({
                "id": item_Data["id"],
                "type": "text",
                "text": item_Data["attributes"].get("ReqIF.ChapterName") or item_Data["attributes"].get("ReqIF.Text"),
                "parent" : payload_final.get(item_Data["parentId"], None)

            })
    # Store final_response in structured.json
    structured_json_path = out_dir / "structured.json"
    structured_json_path.write_text(json.dumps(final_repsonse, indent=2, ensure_ascii=False), encoding="utf-8")
    # payload["final_response"] = final_repsonse
    # #

    # json_full_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    # # ---------- Build GENERAL JSON (now includes 'header') ----------
    # enum_attr_names = set(attr_enumtype_ref.keys())
    # general_records = []
    # for it in items:
    #     attrs  = it.get("attributes", {}) or {}
    #     images = list(it.get("images") or [])

    #     gid    = resolve_id_anyfile(it.get("id",""), attrs)
    #     gtype  = resolve_type_anyfile(attrs, enum_attr_names)
    #     gtext, gtext_de = select_text_auto(attrs)
    #     gheader = resolve_header_anyfile(attrs)  # <-- NEW

    #     rec = {
    #         "id": gid,
    #         "images": images,
    #         "text": gtext,
    #         "type": gtype,
    #         "header": gheader,   # <-- included in general JSON
    #     }
    #     # Only include text_de if it's truly German and not identical to text
    #     if gtext_de and is_german(gtext_de):
    #         if not gtext or gtext_de.strip() != gtext.strip():
    #             rec["text_de"] = gtext_de

    #     general_records.append(rec)

    # json_gen_path = out_dir / f"{stem}_general.json"
    # json_gen_path.write_text(json.dumps(general_records, indent=2, ensure_ascii=False), encoding="utf-8")

    # # ---------- Excel (DEFAULT: ON; disable with --no-xlsx) ----------
    # xlsx_path = out_dir / f"{stem}_full.xlsx"
    # wrote_xlsx = False
    # if write_xlsx:
    #     try:
    #         import pandas as pd  # noqa
    #         base_cols = ["SpecObject.ID", "LongName", "Images"]
    #         attr_cols = sorted(all_attr_names)
    #         rows = []
    #         for it in items:
    #             row = {"SpecObject.ID": it["id"], "LongName": it["longName"], "Images": "; ".join(it["images"])}
    #             for col in attr_cols:
    #                 row[col] = it["attributes"].get(col, "")
    #             rows.append(row)

    #         # tables index
    #         tab_rows = []
    #         for it in items:
    #             sid = it["id"]
    #             for i, t in enumerate(it.get("tables", []), start=1):
    #                 tab_rows.append({
    #                     "SpecObject.ID": sid,
    #                     "Attribute": t.get("attribute",""),
    #                     "TableIndex": i,
    #                     "Rows": t.get("rows", 0),
    #                     "Cols": t.get("cols", 0),
    #                     "CSV": t.get("csv",""),
    #                     "MarkdownPreview": t.get("markdown_preview","")
    #                 })

    #         import pandas as pd
    #         df_main = pd.DataFrame(rows, columns=base_cols + attr_cols)
    #         df_general = pd.DataFrame(general_records)  # includes header column
    #         if not df_general.empty and "images" in df_general.columns:
    #             df_general["images"] = df_general["images"].apply(
    #                 lambda xs: "; ".join(xs) if isinstance(xs, list) else (xs or "")
    #             )

    #         enum_rows = []
    #         for dtype, opts in (enum_catalog or {}).items():
    #             for o in opts:
    #                 enum_rows.append({"EnumType": dtype, "ValueID": o.get("id",""), "Label": o.get("label",""), "Key": o.get("key","")})
    #         df_enum_types = pd.DataFrame(enum_rows) if enum_rows else pd.DataFrame(columns=["EnumType","ValueID","Label","Key"])

    #         enum_attr_rows = []
    #         for attr, info in (enumCatalogByAttribute or {}).items():
    #             dtype = info.get("datatype","")
    #             for o in info.get("options", []):
    #                 enum_attr_rows.append({
    #                     "Attribute": attr, "EnumType": dtype,
    #                     "ValueID": o.get("id",""), "Label": o.get("label",""), "Key": o.get("key","")
    #                 })
    #         df_enum_by_attr = pd.DataFrame(enum_attr_rows) if enum_attr_rows else pd.DataFrame(columns=["Attribute","EnumType","ValueID","Label","Key"])

    #         df_tables_index = pd.DataFrame(tab_rows) if tab_rows else pd.DataFrame(
    #             columns=["SpecObject.ID","Attribute","TableIndex","Rows","Cols","CSV","MarkdownPreview"]
    #         )

    #         from openpyxl import Workbook  # ensure engine present
    #         with pd.ExcelWriter(xlsx_path, engine="openpyxl") as xw:
    #             df_main.to_excel(xw, sheet_name="spec_objects", index=False)
    #             df_enum_types.to_excel(xw, sheet_name="enum_catalog", index=False)
    #             df_enum_by_attr.to_excel(xw, sheet_name="enum_by_attribute", index=False)
    #             df_general.to_excel(xw, sheet_name="general_normalized", index=False)
    #             df_tables_index.to_excel(xw, sheet_name="tables_index", index=False)
    #         wrote_xlsx = True
    #         print(f" Excel       : {xlsx_path}")
    #     except Exception as e:
    #         print(f"(!) Excel step skipped (install pandas & openpyxl). Reason: {e}")

    # print(f" Full JSON   : {json_full_path}")
    # print(f" General JSON: {json_gen_path}")
    # if write_xlsx:
    #     print(f" Excel OK?   : {'yes' if wrote_xlsx else 'no'}")
    # print(f" Images      : {out_dir / 'resources'}")
    # print(f" Tables CSVs : {out_dir / 'resources' / 'tables'}")

def parse_spec_hierarchy(element):
    obj_ref = None
    obj = element.find('./reqif:OBJECT/reqif:SPEC-OBJECT-REF', REQIF_NS)
    if obj is not None:
        obj_ref = obj.text
    children = [
        parse_spec_hierarchy(child)
        for child in element.findall('./reqif:CHILDREN/reqif:SPEC-HIERARCHY', REQIF_NS)
    ]
    return {'SPEC-OBJECT-REF': obj_ref, 'children': children}

def flatten_spec_objects(data):
    def recurse(node, parent):
        ref = node.get('SPEC-OBJECT-REF')
        if ref is not None:
            yield {'child': ref, 'parent': parent}
        for child in node.get('children', []):
            yield from recurse(child, ref)
    for item in data:
        yield from recurse(item, None)

def build_hierarchy_map(content):
    """
    Build a mapping of SPEC-OBJECT-REF to its parent SPEC-OBJECT-REF.
    Returns: dict {child_id: parent_id or None}
    """
    hierarchy_map = {}
    # Find all <SPECIFICATION> elements (top-level specs)
    specs = content.findall(".//reqif:SPECIFICATION", REQIF_NS)
    for spec in specs:
        # Each <SPECIFICATION> has a <CHILDREN> section
        children_section = spec.find("reqif:CHILDREN", REQIF_NS)
        if children_section is not None:
            # Each <CHILDREN> can have multiple <SPEC-HIERARCHY>
            hierarchies = children_section.findall("reqif:SPEC-HIERARCHY", REQIF_NS)
            for sh in hierarchies:
                tree = parse_spec_hierarchy(sh)
                for rel in flatten_spec_objects([tree]):
                    child = rel.get("child")
                    parent = rel.get("parent")
                    if child:
                        hierarchy_map[child] = parent
    return hierarchy_map

    # Use children_sections directly as it is already an Element

# ---------- CLI ----------
def parse_args():
    ap = argparse.ArgumentParser(description="Export full + general JSON from ReqIF/ReqIFZ (and Excel by default).")
    ap.add_argument("input", help="Path to .reqif or .reqifz")
    ap.add_argument("--outdir", default=None, help="Output folder (default: <input folder>/export)")
    ap.add_argument("--no-xlsx", action="store_true", help="Disable Excel generation")
    return ap.parse_args()

def convert_reqifz(file_path: str, tempfolder: str ):
    try:
        filename = os.path.basename(file_path)
        try:
            logging.debug(f"Processing file: {file_path}")
            run(file_path, tempfolder, write_xlsx=True)
            logging.info(f"ReqIF Conversion completed for: {file_path}")
        except Exception as e:
            logging.error(f"Error during ReqIF processing: {e}")
            return False, str(e)

        zip_output = os.path.join(tempfolder, filename).replace(".reqifz", ".zip")
        try:
            with zipfile.ZipFile(zip_output, "w", zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(tempfolder):
                    for f in files:
                        if f.endswith(".zip"):
                            continue
                        file_path = os.path.join(root, f)
                        arcname = os.path.relpath(file_path, tempfolder)
                        zipf.write(file_path, arcname)
            logging.info(f"Created ZIP: {zip_output}")
            return True, zip_output
        except Exception as e:
            logging.error(f"Error creating ZIP archive: {e}")
            return False, str(e)
    except Exception as e:
        logging.error(f"Unexpected error in convert_reqifz: {e}")
        return False, str(e)
