# logger.py
import logging
import sys
import uuid
import contextvars
import structlog
from fastapi import Request
from structlog.contextvars import merge_contextvars
import os


logging.getLogger("uvicorn").handlers.clear()
logging.getLogger("uvicorn.error").handlers.clear()
logging.getLogger("uvicorn.access").handlers.clear()
logging.getLogger("app").handlers.clear()

logging.getLogger('pymongo').setLevel(logging.WARNING)
logging.getLogger('aio_pika').setLevel(logging.WARNING)
logging.getLogger('pamqp').setLevel(logging.WARNING)
logging.getLogger('pika').setLevel(logging.WARNING)
logging.getLogger('azure').setLevel(logging.WARNING)
# ----------------------
# ContextVars (per-request/task)
# ----------------------
trace_id_ctx = contextvars.ContextVar("trace_id", default=None)
span_id_ctx = contextvars.ContextVar("span_id", default=None)
parent_span_id_ctx = contextvars.ContextVar("parent_span_id", default=None)
job_id_ctx = contextvars.ContextVar("job_id", default=None)

env = os.getenv("ENV", "dev").lower()

if env == "local":
    log_handler = logging.DEBUG
    # Custom log path
    import os
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs") # logs path should be same for api and core
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "application_delta.log")
    handler = logging.FileHandler(log_file)
elif env == "dev":
    log_handler = logging.INFO
elif env == "prod":
    log_handler = logging.INFO
else:
    log_handler = logging.INFO

# ----------------------
# Context helpers
# ----------------------
def set_trace_context_from_headers(request: Request):
    """Extract trace/span/parent from headers or generate new ones"""
    trace_id = request.headers.get("x-trace-id") or str(uuid.uuid4())
    parent_span_id = request.headers.get("x-span-id")  # caller's span becomes parent
    span_id = str(uuid.uuid4())  # new span for this request

    trace_id_ctx.set(trace_id)
    span_id_ctx.set(span_id)
    parent_span_id_ctx.set(parent_span_id)

    structlog.contextvars.bind_contextvars(
        trace_id=trace_id,
        span_id=span_id,
        parent_span_id=parent_span_id
    )

def set_trace_context_consumer(trace_id: str = None, parent_span_id: str = None):
    """Extract trace/span/parent from headers or generate new ones"""
    span_id = str(uuid.uuid4())  # new span for this request

    trace_id_ctx.set(trace_id)
    span_id_ctx.set(span_id)
    parent_span_id_ctx.set(parent_span_id)

    structlog.contextvars.bind_contextvars(
        trace_id=trace_id,
        span_id=span_id,
        parent_span_id=parent_span_id
    )

def set_trace_context():
    trace_id = str(uuid.uuid4())
    span_id = str(uuid.uuid4())
    parent_span_id = None

    trace_id_ctx.set(trace_id)
    span_id_ctx.set(span_id)
    parent_span_id_ctx.set(parent_span_id)

    structlog.contextvars.bind_contextvars(
        trace_id=trace_id,
        span_id=span_id,
        parent_span_id=parent_span_id
    )



def set_job_context(job_id: str):
    job_id_ctx.set(job_id)
    structlog.contextvars.bind_contextvars(job_id=job_id)

def clear_context():
    structlog.contextvars.clear_contextvars()


# ---------------------------
# Configure stdlib logging
# ---------------------------
if env == "local":
    logging.basicConfig(
        format="%(message)s",
        # stream=sys.stdout, 
        level=log_handler,
        handlers=[handler]
    )
else:
    logging.basicConfig(
        format="%(message)s",
        # stream=sys.stdout, 
        level=log_handler,
    )

# ----------------------
# Custom processor: reorder fields
# ----------------------
def reorder_fields(logger, method_name, event_dict):
    """Ensure standard fields come first, extras last"""
    if env == "local":
        standard_fields = ["timestamp", "level","trace_id", "event","job_id","span_id", "parent_span_id","pathname", "func_name","lineno"]  # Added pathname and lineno in local
    else:
        standard_fields = ["timestamp", "level","trace_id", "event","job_id","span_id", "parent_span_id", "func_name"]
    reordered = {k: event_dict[k] for k in standard_fields if k in event_dict}
    # add remaining extra fields at the end
    for k in event_dict:
        if k not in reordered:
            reordered[k] = event_dict[k]
    return reordered

if env == "local":
    # ---------------------------
    # Configure structlog
    # ---------------------------
    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),              # timestamp
            structlog.processors.add_log_level,                       # log level
            merge_contextvars,    
            structlog.processors.CallsiteParameterAdder(
                parameters=[
                    structlog.processors.CallsiteParameter.FUNC_NAME,
                    structlog.processors.CallsiteParameter.PATHNAME,
                    structlog.processors.CallsiteParameter.LINENO,
                ]                  # pathname + line number
            ),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            reorder_fields,  
            structlog.processors.JSONRenderer(),                      # JSON logs
        ],
        wrapper_class=structlog.make_filtering_bound_logger(log_handler),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=False,
    )
else:
    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),              # timestamp
            structlog.processors.add_log_level,                       # log level
            merge_contextvars,    
            structlog.processors.CallsiteParameterAdder(
                parameters=[
                    structlog.processors.CallsiteParameter.FUNC_NAME,
                ]                  # function name
            ),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            reorder_fields,  
            structlog.processors.JSONRenderer(),                      # JSON logs
        ],
        wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=False,
    )

# ---------------------------
# Export logger
# ---------------------------
log = structlog.get_logger()