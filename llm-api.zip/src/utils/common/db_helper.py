"""Operations related to Mongo DB."""

from datetime import datetime, timezone

from bson import ObjectId
from bson.errors import InvalidId
from pymongo import DESCENDING

from src.config.config import agent_config, agent_mappings_config
from src.exceptions.db_exceptions import DBFetchError, InvalidIDFormatError
from src.utils.common.helper import get_collection_using_config
from src.utils.common.logger import log as logging
from src.utils.generic_tasks_schema import list_serial_generic
from src.utils.utils_enum import TaskStatus


def validate_agent(agent_id, agent_name, feature_name) -> bool:
    """Validate the agent with the agent in DB."""
    found = False

    # Get the Mappings from DB
    agents_collection = get_collection_using_config(agent_config)
    agents_data_from_db = agents_collection.find_one({"feature_name": feature_name})
    agents_data = agents_data_from_db["agent"]
    for agent in agents_data:
        if agent_id == agent["agent_id"] and agent_name == agent["agent_name"]:
            found = True
    return found


def get_agent_mappings(agent_name: str = "", agent_id: str = "") -> dict:
    """Get the mapping of the agent from DB using agent name.

    Parameters
    ----------
    agent_name: str
        name of the agent whose mapping we want to get
    agent_id: str
        Id of the agent whose mapping we want to get

    Returns
    -------
    dict
        which contains the mappings of the agent name from DB
        If not found in db default value is returned (for backward compatability)
    """
    # Default Value
    agent_mappings_data = {"prediction": agent_name}

    # Get the Mappings from DB
    agent_mappings_collection = get_collection_using_config(agent_mappings_config)

    if agent_name:
        agent_mappings_data_from_db = agent_mappings_collection.find_one({"agent_name": agent_name})
    else:
        agent_mappings_data_from_db = agent_mappings_collection.find_one({"agent_id": agent_id})

    # Return mapping if it is available in DB
    if agent_mappings_data_from_db:
        return agent_mappings_data_from_db["agents"]

    return agent_mappings_data


def get_tasks_from_db(
    collection_config: dict,
    email: str,
    page: int = 1,
    page_size: int = 10,
    search: str | None = None,
    agent_id: str | None = None,
    additionaly_filters: dict = {},
) -> dict:
    """Get all the tasks from the DB using the given inputs.

    Parameters:
    collection_config: dict
        collection of the feature where the collection names is stored
    email: str
        useremail to make sure only users data is fetched
    page: int
        page number
    page_size: int
        number of tasks in a given page
    search: str
        string match if needed
    agent_id: str
        narrow down by using agent_id

    Returns
    -------
    dict
        tasks and its count
    """
    try:
        collection = get_collection_using_config(collection_config)
        logging.info(f"Running query for tasks on {collection} collection")
        query = {
            "email": email,
        }
        if search:
            search_regex = {
                "$regex": search,
                "$options": "i",
            }  # Case-insensitive partial match
            query["$or"] = [
                {"project": search_regex},
                {"request_type": search_regex},
                {"filename": search_regex},
                {"status": search_regex},
                additionaly_filters,
            ]

        if agent_id == "exists_false":
            query["agent_id"] = {"$exists": False}
        elif agent_id:
            query["agent_id"] = agent_id

        skip = (page - 1) * page_size
        records_cur = (
            collection.find(query).sort("created_timestamp", DESCENDING).skip(skip).limit(page_size)
        )
        tasks = list_serial_generic(records_cur)
        total_count = collection.count_documents(query)
        logging.info(f"Found {total_count} records for the query")
    except Exception as e:
        logging.error(f"Failed to fetch tasks from DB: {e}")
        raise DBFetchError()
    return {"Tasks": tasks, "total_count": total_count}


class TaskManager:
    """Manager which helps with getting the task data and updating the status."""

    def __init__(self, collection_config, task_id):
        """Initialize the Task manager."""
        self.collection = get_collection_using_config(collection_config)
        self.collection_config = collection_config
        self._id = task_id

    def get_collection_name(self):
        """Get Name of the collection."""
        return self.collection_config["collection_name"]

    def get_task(self) -> dict:
        """Get the details of the task from DB."""
        logging.info(f"Retrieving task data from DB for {self._id}")
        try:
            try:
                obj_id = ObjectId(self._id)
            except (InvalidId, TypeError) as e:
                logging.error(f"Invalid task_id format: {self._id}")
                return None
            task_data = self.collection.find_one(
                {
                    "_id": ObjectId(self._id),
                    "$or": [{"deleted": {"$exists": False}}, {"deleted": False}],
                }
            )
            if task_data:
                task_data["_id"] = str(task_data["_id"])
                return task_data
            else:
                task_data = self.collection.find_one(
                    {
                        "_id": self._id,
                        "$or": [{"deleted": {"$exists": False}}, {"deleted": False}],
                    }
                )
                task_data["_id"] = str(task_data["_id"])
                return task_data
        except Exception as ex:
            logging.error(f"Error retrieving task {self._id}: {ex}")
            return None

    @staticmethod
    def create_task(collection_config: dict, task_data: dict) -> None:
        """Insert a record."""
        logging.info(f"Creating task data and inserting to DB")
        collection = get_collection_using_config(collection_config)
        task_data["deleted"] = False
        return collection.insert_one(task_data)

    def delete_task(self):
        """Soft delete the record from MongoDB."""
        logging.info(f"Updating the status to 'deleted' for task {self._id}")
        self.collection.update_one(
            {"_id": ObjectId(self._id)},
            {"$set": {"deleted": True}},
        )

    def hard_delete_task(self):
        """Delete permanently from DB."""
        logging.info(f"Permanently deleting the record for task {self._id}")
        return self.collection.find_one_and_delete({"_id": ObjectId(self._id)})

    def update_module_status(self, module_name, status) -> None:
        """Update Module Status If exists."""
        self.collection.update_one(
            {"_id": ObjectId(self._id)},
            {
                "$set": {
                    f"{module_name}_status": status,
                    "lastupdated_timestamp": datetime.now(timezone.utc),
                }
            },
        )

    def update_record(self, attributes_to_update):
        """Update any attributes that need to be updated in the DB."""
        logging.info("Updating record for task {self._id}")
        self.collection.update_one(
            {"_id": ObjectId(self._id)},
            {"$set": attributes_to_update},
        )

    def update_status(
        self,
        status: TaskStatus,
        filename: str = "",
        error_message: str = "",
        status_update_message: dict = {},
    ) -> None:
        """Update the status of the task as required."""
        logging.info(f"Updating task status to '{status}' for {self._id}")
        if status == TaskStatus.PROCESSING.value:
            self.collection.update_one(
                {"_id": ObjectId(self._id)},
                {
                    "$set": {
                        "status": TaskStatus.PROCESSING.value,
                        "lastupdated_timestamp": datetime.now(timezone.utc),
                    }
                },
            )
        elif status == TaskStatus.FAILED.value:
            self.collection.update_one(
                {"_id": ObjectId(self._id)},
                {
                    "$set": {
                        "status": TaskStatus.FAILED.value,
                        "status_error_message": error_message,
                        "lastupdated_timestamp": datetime.now(timezone.utc),
                    }
                },
            )
        elif status == TaskStatus.SUCCESS.value:
            self.collection.update_one(
                {"_id": ObjectId(self._id)},
                {
                    "$set": {
                        "status": TaskStatus.SUCCESS.value,
                        "filename": filename,
                        "lastupdated_timestamp": datetime.now(timezone.utc),
                    }
                },
            )
        elif status == TaskStatus.TASK_RESTARTED.value:
            if status_update_message:
                self.collection.update_one(
                    {"_id": ObjectId(self._id)},
                    {
                        "$set": {
                            "status": TaskStatus.PROCESSING.value,
                            "lastupdated_timestamp": datetime.now(timezone.utc),
                            "status_update_message": status_update_message,
                        }
                    },
                )
            else:
                self.collection.update_one(
                    {"_id": ObjectId(self._id)},
                    {
                        "$set": {
                            "status": TaskStatus.PROCESSING.value,
                            "lastupdated_timestamp": datetime.now(timezone.utc),
                        }
                    },
                )

    def update_status_directly(self, status) -> None:
        self.collection.update_one(
            {"_id": ObjectId(self._id)},
            {
                "$set": {
                    "status": status,
                    "lastupdated_timestamp": datetime.now(timezone.utc),
                }
            },
        )
