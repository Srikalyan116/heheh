"""Functions to help with redundent tasks for better maintainability."""

import os
import re
from io import BytesIO
from pathlib import Path

import pandas as pd
from azure.storage.blob import BlobServiceClient
from bson import ObjectId

from src.exceptions.common_exceptions import (
    EmptyColumnsError,
    FileNotSupportedError,
    InvalidColumnsError,
)
from src.utils.common.logger import log as logging
from src.utils.mongo_db import MongoDB


def fetch_dataframe_from_file(data: BytesIO, file_extension: str) -> pd.DataFrame | None:
    """Create dataframe from csv or excel with the help of extension.

    Parameters
    ----------
    data: io.BytesIO
        bytes stream of the dataframe
    file_extension: str
        It can be filename or extension name we try to check with endswith()

    Returns
    -------
    pandas.dataframe:
        Dataframe created out of the byte stream
    """
    if (
        file_extension.endswith(".xlsx")
        or file_extension.endswith(".xls")
        or file_extension.endswith(".xlsm")
    ):
        return pd.read_excel(data)
    elif file_extension.endswith(".csv"):
        if isinstance(data, bytes):
            return pd.read_csv(BytesIO(data))
        return pd.read_csv(data)
    elif file_extension.endswith(".json"):
        return pd.read_json(data)


def fetch_data_from_blob(data: bytes, file_extension: str) -> bytes:
    """Fetch data from blob storage for the given blob path.

    Parameters
    ----------
    blob_path: str
        path of the blob to fetch the data

    Returns
    -------
    bytes
        bytes data which is fetched from the blob storage
    """
    # reset cursor if stream-like object
    if hasattr(data, "seek"):
        data.seek(0)

    if file_extension.endswith(".json"):
        return pd.read_json(data)


def fetch_dataframe_with_sheets(excel_data: BytesIO, sheet_name: str) -> pd.DataFrame | None:
    """Fetch data from the excel sheet for the given sheet name.

    Parameters
    ----------
    excel_data: IO.BytesIO
        excel sheet data from the blob
    sheet_name: str
        name of the sheet in the excel sheet


    Returns
    -------
    dataframe
        dataframe which is read from the bytes
    """
    return pd.read_excel(excel_data, sheet_name)


def write_dataframe_to_file(
    dataframe: pd.DataFrame, file_extension: str, path: str
) -> pd.DataFrame | None:
    """Write to csv or excel using Dataframe.

    Parameters
    ----------
    dataframe: pd.DataFrame
        dataframe which need to be saved
    file_extension: str
        It can be filename or extension name we try to check with endswith()
    path: str
        path where the data need to be written

    Returns
    -------
    pandas.dataframe:
        Dataframe created out of the byte stream
    """
    dirname = os.path.dirname(path)
    basename = os.path.basename(path)
    safe_basename = sanitize_filename(basename)
    safe_path = os.path.join(dirname, safe_basename)
    if file_extension.endswith(".xlsx") or file_extension.endswith(".xls"):
        dataframe.to_excel(safe_path)
    elif file_extension.endswith(".csv"):
        dataframe.to_csv(safe_path)


def write_dataframe_to_file_for_bytes(
    dataframe: pd.DataFrame, file_extension: str, path: str
) -> pd.DataFrame | None:
    """Write to csv or excel using Dataframe.

    Parameters
    ----------
    dataframe: pd.DataFrame
        dataframe which need to be saved
    file_extension: str
        It can be filename or extension name we try to check with endswith()
    path: str
        path where the data need to be written

    Returns
    -------
    pandas.dataframe:
        Dataframe created out of the byte stream
    """
    if file_extension.endswith(".xlsx") or file_extension.endswith(".xls"):
        dataframe.to_excel(path)
    elif file_extension.endswith(".csv"):
        dataframe.to_csv(path)


def validate_input_file_type(file_name: str) -> bool:
    """Validate the file type.

    Parameters
    ----------
    file_name: str
        Input filename which is uploaded
    """
    file_types = [".csv", ".xlsx", ".xls", ".json", ".xlsm"]
    for file_type in file_types:
        if file_name.endswith(file_type):
            return True
    return False


def get_collection_using_config(config: dict):
    """Get collection from MongoDB using the config.

    Parameters
    ----------
    config: dict
        config of the classification

    Returns
    -------
    Collection
        Collection from MongoDB using the config
    """
    return MongoDB.get_collection(config.get("collection_name"))


def get_queue_name_from_config(config: dict):
    """Get the queue name from the config.

    Parameters
    ----------
    config: dict
        confirm of the feature
    """
    return config["queue_name"]


def clean_local_file(file_path) -> None:
    """Remove the local temporary file.

    Parameters
    ----------
    file_path : str
        file path to a temporary file which need to be removed
    """
    if os.path.exists(file_path):
        os.remove(file_path)


def validate_input_file_type_for_design_requirement(file_name: str) -> bool:
    """Validate the file type.

    Parameters
    ----------
    file_name: str
        Input filename which is uploaded
    """
    file_types = [".c", ".cpp", ".zip"]
    for file_type in file_types:
        if file_name.endswith(file_type):
            return True
    return False


def get_seperated_date_from_timestamp(timestamp: str) -> list[int]:
    """Get dd mm yyyy as a list for blob storage segment.

    Parameters
    ----------
    timestamp: str
        timestamp from mongo which need to be decoded

    Returns
    -------
    list[int]
        dd, mm, yyyy will be returned as a part of date from the timestamp for blob segmentation
    """
    date_from_timestamp = timestamp.split("T")[0].split(" ")[0]
    return date_from_timestamp.split("-")


def get_blob_segment(task_id, feature_name, date_string, module_name=""):
    """Getting the path for downloading blob.

    Parameters
    ----------
    task_id: str
        timestamp from mongo which need to be decoded
    feature_name: str
        feature name to which blob storage need to be fetched
    date_string: str
        timestamp string from mongo
    module_name:
        module name if needed

    Returns
    -------
    string
        blob path for blob storage
    """
    blob_string_elements = []

    # Get the segments of the date from the timestamp string
    segmented_date = get_seperated_date_from_timestamp(date_string)

    # add feature name
    blob_string_elements.append(feature_name)

    # add the date folders
    blob_string_elements += segmented_date

    # Add the task_id folder
    blob_string_elements.append(task_id)

    # add the module name if any
    if module_name:
        blob_string_elements.append(module_name)

    return "/".join(blob_string_elements)


def get_columns_from_file(file_content: BytesIO, filename: str) -> list[str]:
    """Get Columns of the dataframe.

    Parameters
    ----------
    file_content: BytesIO
        contains the byte stream of the data
    filename: str
        name of the file

    Returns
    -------
    list[str]
        get the list of column names
    """
    columns: list[str] = []
    filename: Path = Path(filename)
    file_extension = filename.suffix

    if not validate_input_file_type(file_extension):
        logging.error(f"Unsupported file type: {file_extension}")
        raise FileNotSupportedError(file_extension)

    try:
        df = fetch_dataframe_from_file(file_content, file_extension)

        if df.dropna(how="all", axis=0).empty:
            raise EmptyColumnsError(status_code=400, detail="The rows below the headers are empty.")

        # Drop columns that are completely empty
        df = df.dropna(how="all", axis=1)

        # id unamed 2
        columns = df.columns.tolist()

        # Check for 'Unnamed' columns that might be generated if headers are not properly provided
        if any("Unnamed" in col for col in columns):
            logging.error(f"Invalid columns found in file {filename.name}: {columns}")
            raise InvalidColumnsError(filename.name)

    except pd.errors.EmptyDataError:
        logging.error(f"Empty data error for file {filename.name}")
        raise Exception(message="The uploaded file is empty.")
    except pd.errors.ParserError:
        logging.error(f"Error parsing the file {filename.name}.")
        raise Exception(
            message="Error parsing the file. Please check the file content.",
        )
    return columns


def check_column_name_in_columns(column_name: str, df: pd.DataFrame) -> bool:
    """Check if the column name is present in the columns of the Dataframe.

    Parameters
    ----------
    column_name : str
        Column name which need to be validated
    df : pd.Dataframe
        Dataframe where we need to verify if the column exists

    Returns
    -------
    bool
        If present we say it as True else False

    """
    return True if column_name in list(df.columns) else False


def get_feature_name_from_config(config: dict) -> str:
    """Get the feature name from the config.

    Parameters
    ----------
    config: dict
        confirm of the feature
    """
    return config["feature_name"]


def sanitize_filename(filename):
    """
    Sanitize a filename to prevent directory traversal attacks.
    Args:
        filename (str): The filename to sanitize
    Returns:
        str: A sanitized filename
    """

    # Remove any directory traversal characters and get just the basename
    return os.path.basename(filename)


def validate_object_id(_id: str) -> bool:
    """
    Validate if the given string is a valid MongoDB ObjectId.

    Args:
        _id (str): The string to validate.

    Returns:
        bool: True if valid ObjectId, False otherwise.
    """
    try:
        ObjectId(_id)
        return True
    except Exception:
        return False


def process_requirements(requirements_json, page=1, page_size=10, prediction=""):
    requirements = requirements_json
    count = {
        "Major Change": 0,
        "Minor Change": 0,
        "No Change": 0,
        "Skipped": 0,
        "Unidentified": 0,
        "Deleted": 0,
        "New": 0,
    }
    result = []
    for req in requirements["requirements"]:
        v1 = req["versions"]["v1"]
        v2 = req["versions"]["v2"]
        change_log = req["Change_log"]["v1-v2"]
        change_type = change_log.get("change_type", "")
        count[change_type] = count.get(change_type, 0) + 1
        if prediction == None or prediction == change_type:
            obj = {
                "type": req["kind"],
                "source": v1["text"],
                "revision": v2["text"],
                "matched": change_log.get("change_type", "") == "No Change",
                "changeType": change_log.get(
                    "change_type",
                ),
                "changes": change_log.get("change_description", ""),
                "source_image": v1.get("img_path", ""),
                "revision_image": v2.get("img_path", ""),
            }
            result.append(obj)

    # Pagination
    start = (page - 1) * page_size
    end = start + page_size
    paged_result = result[start:end]
    return {
        "count": count,
        "data": paged_result,
        "page": page,
        "page_size": page_size,
        "total": len(result),
    }
