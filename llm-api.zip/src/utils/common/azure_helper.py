"""Azure Cloud Helper."""

import os
import requests
from io import BytesIO
import zipfile
from datetime import datetime, timedelta, timezone
from io import BytesIO
from pathlib import Path

from azure.identity import ClientSecretCredential
from azure.storage.blob import (
    BlobClient,
    BlobSasPermissions,
    BlobServiceClient,
    ContainerClient,
    generate_blob_sas,
)

from src.utils.common.logger import log as logging
from src.utils.common.helper import get_blob_segment
from src.exceptions.azure_exceptions import AzureBlobUploadFailedError, AzureSasUrlExpiredError

from src.exceptions.azure_exceptions import AzureBlobUploadFailedError

raw_container_name = os.getenv("BLOB_CONTAINER_NAME_RAW")
processed_container_name = os.getenv("BLOB_CONTAINER_NAME_PROCESS")

unit_test_azure_blob_container_name = os.getenv("UNIT_TEST_AZURE_BLOB_CONTAINER_NAME", "unit-tests-generation")
blob_unit_test_artifacts_root_folder = os.getenv("BLOB_UNIT_TEST_ARTIFACTS_ROOT_FOLDER", "unit_test_artifacts")
blob_unit_test_task_result_root_folder = os.getenv("BLOB_UNIT_TEST_TASK_RESULT_ROOT_FOLDER", "unit_test_task_results")

account_url = os.environ.get("BLOB_ACCOUNT_URL")
tenant_id = os.environ.get("TENANT_ID")
client_id = os.environ.get("CLIENT_ID")
client_secret = os.environ.get("CLIENT_SECRET")
if not account_url and tenant_id and client_id and client_secret:
    logging.error(
        "Missing required environment variables for Azure Blob Storage. Check BLOB_ACCOUNT_URL, TENANT_ID, CLIENT_ID, CLEINT_SECRET."
    )
    raise ValueError(
        "Missing required environment variable: BLOB_ACCOUNT_URL,TENANT_ID,CLIENT_ID,CLEINT_SECRET."
    )
credential = ClientSecretCredential(tenant_id, client_id, client_secret)
blob_service_client = BlobServiceClient(account_url=account_url, credential=credential)


class BlobClientManager:
    """Blob Manager for processing cloud functions."""

    def __init__(self):
        """Initialize the blob service client."""
        self.blob_service_client = blob_service_client

    def get_data_from_blob(
        self, 
        blob_path: str, 
        processed: bool = False,
        container_name: str | None = None
    ) -> BytesIO:
        """Download the stream of data from cloud."""
        container = processed_container_name if processed else raw_container_name
        if container_name:
            container = container_name
        blob_client = self.blob_service_client.get_blob_client(
            container=container,
            blob=blob_path,
        )
        try:
            stream_downloader = blob_client.download_blob()
            data = stream_downloader.readall()
            logging.info(f"Successfully downloaded blob: {blob_path}")
            return data
        except Exception as e:
            logging.error(f"Failed to download blob {blob_path}: {e}")
            raise

    def upload_data_to_blob(
        self,
        blob_path: str,
        data: BytesIO,
        processed: bool = False,
        container_name: str | None = None
    ) -> None:
        """Upload the stream of data to Cloud."""
        container = processed_container_name if processed else raw_container_name
        if container_name:
            container = container_name
        blob_client: BlobClient = self.blob_service_client.get_blob_client(
            container=container,
            blob=blob_path,
        )
        try:
            blob_client.upload_blob(data, overwrite=True)
        except Exception as e:
            error_message = (
                f"Failed to upload file to Azure Blob Storage.\n"
                f"Blob Path: {blob_path}\n"
                f"Container: {container}\n"
                f"Error: {str(e)}"
            )
            logging.error(error_message)
            raise AzureBlobUploadFailedError(error_message) from e

    def delete_data_from_blob(
        self, 
        blob_path: str, 
        processed=False, 
        container_name: str | None = None
    ):
        """Delete the file from blob path."""
        container = processed_container_name if processed else raw_container_name
        if container_name:
            container = container_name
        blob_client: BlobClient = self.blob_service_client.get_blob_client(
            container=container,
            blob=blob_path,
        )
        try:
            blob_client.delete_blob(delete_snapshots="include")
            logging.info(f"Successfully deleted blob: {blob_path}")
        except Exception as e:
            logging.error(f"Failed to delete blob {blob_path}: {e}")
            raise

    def delete_data_from_blob_path(
        self, 
        blob_path: str, 
        processed=False,
        container_name: str | None = None
    ):
        """Delete all the files from blob path."""
        container = processed_container_name if processed else raw_container_name
        if container_name:
            container = container_name
        container_client: ContainerClient = self.blob_service_client.get_container_client(
            container=container,
        )
        try:
            for file_obj in container_client.list_blobs(name_starts_with=blob_path):
                blob_client = self.blob_service_client.get_blob_client(
                    container=container,
                    blob=file_obj.name,
                )
                blob_client.delete_blob(delete_snapshots="include")
                logging.info(f"Deleted blob: {file_obj.name}")
            logging.info(f"Successfully deleted all blobs with prefix: {blob_path}")
        except Exception as e:
            logging.error(f"Failed to delete blobs with prefix {blob_path}: {e}")
            raise

    def list_all_files_from_blob(
        self, 
        blob_path: str, 
        processed=False,
        container_name: str | None = None
    ):
        """List all the files from blob path."""
        container = processed_container_name if processed else raw_container_name
        if container_name:
            container = container_name
        container_client: ContainerClient = self.blob_service_client.get_container_client(
            container=container,
        )
        try:
            blobs = list(container_client.list_blobs(name_starts_with=blob_path))
            logging.info(f"Found {len(blobs)} blobs with prefix: {blob_path}")
            return blobs
        except Exception as e:
            logging.error(f"Failed to list blobs with prefix {blob_path}: {e}")
            raise

    def get_downlod_url(
        self, 
        blob_path: str, 
        processed: bool = False,
        container_name: str | None = None
    ) -> BytesIO:
        """Download the stream of data from cloud."""
        container = processed_container_name if processed else raw_container_name
        if container_name:
            container = container_name
        permissions = BlobSasPermissions(read=True)
        sas_valid_for_minutes = 60
        cred = ClientSecretCredential(
            tenant_id=tenant_id, client_id=client_id, client_secret=client_secret
        )

        blob_client = BlobClient(account_url, container, blob_path)

        now = datetime.now(timezone.utc)
        udk = self.blob_service_client.get_user_delegation_key(
            key_start_time=now - timedelta(minutes=5), key_expiry_time=now + timedelta(hours=2)
        )

        try:
            expiry = now + timedelta(minutes=sas_valid_for_minutes)
            sas_token = generate_blob_sas(
                account_name=self.blob_service_client.account_name,
                container_name=container,
                blob_name=blob_path,
                user_delegation_key=udk,
                protocol="https",
                permission=permissions,
                expiry=expiry,
                start=now - timedelta(minutes=1),  # small clock skew buffer
            )

        except Exception as e:
            logging.error(f"Failed to download blob {blob_path}: {e}")
            raise

        return blob_client.url + "?" + sas_token
    
    def upload_components_to_blob(
        self,
        task_details: dict,
        components_to_process: list[str],
        source_path: str,
        processed: bool = False,
        force_run: bool = False,
        container_name: str | None = None
    ):
        """
        Upload all component test folders to Azure Blob Storage under:
        <container>/<repo>_<branch>_<hash>/<component_name>/<files>
        """
        try:
            repo_name = task_details.get("repo_name")
            branch = task_details.get("branch")
            latest_commit = task_details.get("latest_commit")

            if not (repo_name and branch and latest_commit):
                raise ValueError(
                    f"[UPLOAD] Missing required values in task_details: repo_name={repo_name}, "
                    f"branch={branch}, latest_commit={latest_commit}"
                )

            base_blob_prefix = f"{blob_unit_test_artifacts_root_folder}/{repo_name}_{branch}_{latest_commit}"

            for component in components_to_process:

                local_path = Path(source_path) / component
                if not local_path.exists():
                    raise FileNotFoundError(
                        f"[UPLOAD] Component folder does not exist locally: {local_path}"
                    )

                # Azure blob virtual path
                component_blob_prefix = f"{base_blob_prefix}/{component}"

                # Get existing files (to decide skip/overwrite)
                existing_blobs = self.list_all_files_from_blob(
                    component_blob_prefix, 
                    processed=processed,
                    container_name=container_name
                )
                existing_blob_names = {Path(existing_blob).name.replace(component_blob_prefix + "/", "")
                                    for existing_blob in existing_blobs}

                # ---- Upload all files inside the component folder ----
                for root, _, files in os.walk(local_path):
                    root_path = Path(root)

                    for file in files:
                        full_local_file = root_path / file

                        # Create blob path preserving folder structure
                        rel_path = full_local_file.relative_to(local_path)
                        blob_path = f"{component_blob_prefix}/{rel_path.as_posix()}"

                        if not force_run and rel_path in existing_blob_names:
                            continue

                        # Upload file
                        with open(full_local_file, "rb") as f:
                            self.upload_data_to_blob(
                                blob_path=blob_path,
                                data=BytesIO(f.read()),
                                processed=processed,
                                container_name=container_name
                            )

                print(f"[UPLOAD] Uploaded component '{component}' to blob prefix '{component_blob_prefix}'")
        except Exception as ex:
            logging.error(f"Failed uploading components to ")

    def download_components_and_zip(
        self,
        task_details: dict,
        components: list[str],
        download_dir: str,
        zip_name: str | None = None,
        processed: bool = False,
        container_name: str | None = None,
    ) -> Path:
        """
        Download component folders from blob storage and zip them.

        Returns:
            Path to the created zip file
        """
        task_id = task_details.get("task_id")
        repo_name = task_details.get("repo_name")
        branch = task_details.get("branch")
        latest_commit = task_details.get("latest_commit")

        if not (task_id and repo_name and branch and latest_commit):
            raise ValueError("[DOWNLOAD] Missing repo/branch/hash in task_details")

        if not zip_name:
            zip_name = f"{repo_name}_{branch}_{latest_commit}_{task_id}.zip"
        base_blob_prefix = f"{blob_unit_test_artifacts_root_folder}/{repo_name}_{branch}_{latest_commit}"

        download_dir = Path(download_dir)
        download_dir.mkdir(parents=True, exist_ok=True)

        zip_path = download_dir / zip_name

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:

            for component in components:
                component_prefix = f"{base_blob_prefix}/{component}"

                blobs = self.list_all_files_from_blob(
                    component_prefix,
                    processed=processed,
                    container_name=container_name,
                )

                if not blobs:
                    logging.warning(
                        f"[DOWNLOAD] No blobs found for component '{component}'"
                    )
                    continue

                for blob in blobs:
                    # Preserve relative path inside zip
                    rel_path = Path(blob.name).relative_to(blob_unit_test_artifacts_root_folder)

                    blob_data = self.get_data_from_blob(
                        blob.name,
                        processed=processed,
                        container_name=container_name,
                    )

                    zipf.writestr(rel_path.as_posix(), blob_data)

        logging.info(f"[ZIP] Created zip file at: {zip_path}")
        return zip_path
    
    def download_file_from_sas_url(
        self, 
        sas_url: str, 
        output_path: str
        ) -> None:
        """
        Download a file from Azure Blob Storage using a SAS URL.

        Args:
            sas_url (str): The SAS URL to the blob.
            output_path (str): The local path to save the downloaded file.


        Returns:
            bytes: The content of the blob.
        """

        try:
            with requests.get(sas_url, stream=True, timeout=300) as response:
                response.raise_for_status()
                with open(output_path, "wb") as file:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            file.write(chunk)
            logging.info(f"Successfully downloaded file from SAS URL to {output_path}")
        except requests.exceptions.HTTPError as http_err:
            if http_err.response is not None and http_err.response.status_code == 403:
                logging.error("SAS URL has expired or is invalid.")
                raise AzureSasUrlExpiredError() from http_err
            else:
                logging.error(f"HTTP error occurred: {http_err}")
                raise Exception(f"HTTP error occurred: {http_err}") from http_err
        except Exception as e:
            logging.error(f"Failed to download file from SAS URL: {e}")
            raise