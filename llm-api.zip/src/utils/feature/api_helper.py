"""Common functions used by most of the features."""

from io import BytesIO

from fastapi import Request

from src.exceptions.azure_exceptions import AzureBlobDownloadError
from src.exceptions.common_exceptions import DeletingTaskError, InvalidHeaderError
from src.exceptions.db_exceptions import TaskNotFoundError
from src.utils.common.azure_helper import BlobClientManager
from src.utils.common.db_helper import TaskManager
from src.utils.common.helper import get_blob_segment, get_feature_name_from_config
from src.utils.common.logger import log as logging
from src.utils.utils_enum import TaskStatus


def get_auth_token_from_headers(request: Request) -> str:
    """Get the token from the API header.

    Parameters
    ----------
    request: Request
        request from the API.

    Returns
    -------
    str
        token with out the Bearer
    """
    token = request.headers.get("Authorization", "")
    if not token:
        logging.error("Authorization header missing in request.")
        raise InvalidHeaderError()
    return token.replace("Bearer ", "")


def get_downloadable_data(
    config: dict, task_id: str, module_name: str = ""
) -> tuple[bool, str, str, BytesIO]:
    """Get the downloadable blob from the Azure by using the task details.

    Parameters
    ----------
    config: dict
        to get the data from DB
    task_id: str
        ID of the task we want to download the data for
    module_name: str
        if there is module added which might be needed to download the data

    Returns
    -------
    bool
        validation if the data is present
    str
        failure messages
    str
        filename
    BytesIO
        data from the Azure blob storage
    """
    # Task Manager
    task_manager = TaskManager(config, task_id)
    task_data = task_manager.get_task()

    if not task_data:
        logging.error(f"Task not found for task_id: {task_id}")
        raise TaskNotFoundError()

    # Get the task status
    task_status = task_data.get("status")

    validation: bool = True
    message: str = ""
    filename: str = ""
    file_data: BytesIO = None

    # Validations
    if "output_filename" in task_data:
        filename = task_data.get("output_filename")
    elif "filename" in task_data:
        filename = task_data.get("filename")
    if not filename:
        validation = False
        message = "Filename missing from the task"

    else:
        if task_status == TaskStatus.PROCESSING.value:
            validation = False
            message = "Task is still processing, please try again later."

        elif task_status == TaskStatus.FAILED.value:
            validation = False
            message = "Task has failed."

        elif task_status != TaskStatus.SUCCESS.value:
            validation = False
            message = "Task is in an unrecognized state."

    # Download only when Data is validated
    if validation:

        # initialize blob manager
        blob_manager = BlobClientManager()

        # Get blob segment which need to be downloaded
        blob_path = get_blob_segment(
            task_id,
            get_feature_name_from_config(config),
            str(task_data["created_timestamp"]),
            module_name=module_name,
        )

        # Download and return
        try:
            file_data = blob_manager.get_data_from_blob(f"{blob_path}/{filename}", processed=True)
        except Exception as e:
            logging.error(f"Failed to download blob data for task_id: {task_id}, error: {e}")
            raise AzureBlobDownloadError()

    return validation, message, filename, file_data


def get_download_url(
    config: dict, task_id: str, module_name: str = ""
) -> tuple[bool, str, str, BytesIO]:
    """Get the downloadable blob from the Azure by using the task details.

    Parameters
    ----------
    config: dict
        to get the data from DB
    task_id: str
        ID of the task we want to download the data for
    module_name: str
        if there is module added which might be needed to download the data

    Returns
    -------
    bool
        validation if the data is present
    str
        failure messages
    str
        filename
    BytesIO
        data from the Azure blob storage
    """
    # Task Manager
    task_manager = TaskManager(config, task_id)
    task_data = task_manager.get_task()

    if not task_data:
        logging.error(f"Task not found for task_id: {task_id}")
        raise TaskNotFoundError()

    # Get the task status
    task_status = task_data.get("status")

    validation: bool = True
    message: str = ""
    filename: str = ""
    file_data: BytesIO = None

    # Validations
    if "output_filename" in task_data:
        filename = task_data.get("output_filename")
    elif "filename" in task_data:
        filename = task_data.get("filename")
    if not filename:
        validation = False
        message = "Filename missing from the task"

    else:
        if task_status == TaskStatus.PROCESSING.value:
            validation = False
            message = "Task is still processing, please try again later."

        elif task_status == TaskStatus.FAILED.value:
            validation = False
            message = "Task has failed."

        elif task_status != TaskStatus.SUCCESS.value:
            validation = False
            message = "Task is in an unrecognized state."

    # Download only when Data is validated
    if validation:

        # initialize blob manager
        blob_manager = BlobClientManager()

        # Get blob segment which need to be downloaded
        blob_path = get_blob_segment(
            task_id,
            get_feature_name_from_config(config),
            str(task_data["created_timestamp"]),
            module_name=module_name,
        )

        # Download and return
        try:
            url = blob_manager.get_downlod_url(f"{blob_path}/{filename}", processed=True)
        except Exception as e:
            logging.error(f"Failed to download blob data for task_id: {task_id}, error: {e}")
            raise AzureBlobDownloadError()

    return validation, message, filename, url


def get_task_by_id(config, task_id) -> dict:
    """Get the task from the DB.

    Parameters
    ----------
    config: dict
        to get the data from DB
    task_id: str
        ID of the task we want to download the data for

    Returns
    -------
    dict
        task data from db.
    """
    task_manager = TaskManager(config, task_id)
    task_data = task_manager.get_task()

    if task_data is None:
        logging.error(f"Task not found for task_id: {task_id}")
        raise TaskNotFoundError()

    return task_data


def delete_blob_data(config, task_id) -> None:
    """Delete the blob object from the Azure Storage and soft delete from db.

    Parameters
    ----------
    config: dict
        to get the data from DB
    task_id: str
        ID of the task we want to download the data for
    """
    try:
        # Initialize the Task Manager for the operations
        task_manager = TaskManager(config, task_id)

        # Get the Blob data for deleting blob raw and processed data
        task_details = task_manager.get_task()

        if task_details:
            blob_path = get_blob_segment(
                task_id,
                get_feature_name_from_config(config),
                str(task_details["created_timestamp"]),
            )

            blob_manager = BlobClientManager()

            # Delete the folder from raw
            blob_manager.delete_data_from_blob_path(blob_path)

            # Delete the folder from processed
            blob_manager.delete_data_from_blob_path(blob_path, processed=True)

            # Soft delete the task from db
            task_manager.delete_task()
        else:
            logging.error(f"Failed to delete task: Task details not found for task_id: {task_id}")
            raise DeletingTaskError(task_id)

    except Exception as e:
        logging.error(
            f"Exception occurred while deleting blob data for task_id: {task_id}, error: {e}"
        )
        raise DeletingTaskError(task_id)
