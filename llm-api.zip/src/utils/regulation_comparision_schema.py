"""Module for serializing task items into dictionaries for consistent data handling."""


def individual_serial(task) -> dict:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the tsak item.
    """
    return {
        "id": str(task.get("_id", "")),
        "agent_id": task.get("agent_id", ""),
        "email": task.get("email", ""),
        "output_filename": task.get("output_filename", ""),
        "match_json_file": task.get("match_json_file", ""),
        "source_filename": task.get("source_filename", ""),
        "target_filename": task.get("target_filename", ""),
        "source_extract_col_name": task.get("source_extract_col_name", ""),
        "target_extract_col_name": task.get("target_extract_col_name", ""),
        "status": task.get("status", ""),
        "created_timestamp": task.get("created_timestamp", ""),
        "lastupdated_timestamp": task.get("lastupdated_timestamp", ""),
        "status_error_message": task.get("status_error_message", ""),
        "status_update_message": task.get("status_update_message", {}),
        "status_code": task.get("status_code", 500),
    }


def list_serial(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial(task) for task in tasks]
