
from ast import List

import json
import os

from src.utils.common.logger import log as logging
import pandas as pd


def flatten_json(nested_json, parent_key='', sep='_'):
    """
    Flatten a nested JSON object.
    """
    items = []
    for k, v in nested_json.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_json(v, new_key, sep=sep).items())
        elif isinstance(v, list):
            for i, item in enumerate(v):
                items.extend(flatten_json({f"{new_key}[{i}]": item}).items())
        else:
            items.append((new_key, v))
    return dict(items)

def json_to_excel(data, excel_file):
    """
    Convert a JSON file to an Excel file.
    """
    # # Read JSON file
    # with open(json_file, 'r', encoding='utf-8') as file:
    #     data = json.load(file)
    
    # Ensure the data is a list of dictionaries
    if isinstance(data, dict):
        data = [data]
    elif not isinstance(data, list):
        raise ValueError("JSON data must be a dictionary or a list of dictionaries.")
    
    # Flatten each JSON object
    flattened_data = [flatten_json(item) for item in data]
    
    # Convert to DataFrame
    df = pd.DataFrame(flattened_data)
    
    # Write to Excel
    df.to_excel(excel_file, index=False, engine='openpyxl')
    logging.info(f"Data successfully written to {excel_file}")