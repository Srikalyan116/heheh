"""Basic utilities needed for validations."""

import json
import os
from io import BytesIO

import pandas as pd
from src.utils.common.logger import log as logging
from src.utils.utils_enum import FileType, RequestType, TaskStatus


from src.utils.constant import (
    CSV,
    CSV_XLSX_NON_ID_COLUMN_REVISED,
    CSV_XLSX_NON_ID_COLUMN_SOURCE,
    ID_SUPPORTED_EXTENSIONS,
    ID_TYPE,
    NON_ID_SUPPORTED_EXTENSIONS,
    NON_ID_TYPE,
    TYPE_REVISION,
    TYPE_SOURCE,
    XLSX,
)
from src.utils.utils_enum import APIMessages


def validate_csv_and_xlsx(form_data, file_extension, type, id_type):
    """Validate CSV and Excel data.

    Parameters
    ----------
    form_data: InputData
        input obtained from API
    file_extension: str
        suffix of the filename
    type: str
        Type of the file
    id_type: str
        Source of the file
    """
    id_column, name_column, file = None, None, None
    file_validated, message = True, None

    logging.debug(f"Starting validation for {type} file with extension {file_extension} and id_type {id_type}")

    if type == TYPE_SOURCE:
        id_column = form_data.source_id
        name_column = form_data.source_col_name
        file = form_data.source_file
        logging.debug(f"Source file details - ID Column: {id_column}, Name Column: {name_column}")

    elif type == TYPE_REVISION:
        id_column = form_data.revision_id
        name_column = form_data.revision_col_name
        file = form_data.revision_file
        logging.debug(f"Revision file details - ID Column: {id_column}, Name Column: {name_column}")

    file_content = file.file.read()  # Read file content into memory
    logging.debug(f"Read content from {type} file")
    stream = BytesIO(file_content)
    file.file.seek(0)

    try:
        if file_extension == CSV:
            data = pd.read_csv(stream)
            logging.debug(f"Loaded CSV data for {type} file")
        elif file_extension == XLSX:
            data = pd.read_excel(stream)
            logging.debug(f"Loaded Excel data for {type} file")
    except Exception as e:
        logging.error(f"Error reading {type} file: {str(e)}")
        return False, f"Error reading {type} file: {str(e)}", form_data

    all_columns = list(data.columns)
    logging.debug(f"Columns in {type} file: {all_columns}")  
    if id_type == ID_TYPE:
        if not id_column:
            file_validated, message = False, f"ID column is not entered for {type} file"
            logging.debug(message)
        elif id_column and id_column not in all_columns:
            file_validated, message = (
                False,
                f"Entered ID column '{id_column}' is missing in {type} file",
            )
            logging.debug(message)

    if file_validated:
        if not name_column:
            file_validated, message = (
                False,
                f"Requirement column is not provided for {type} file",
            )
            logging.debug(message)
        elif name_column and name_column not in all_columns:
            file_validated, message = (
                False,
                f"Requirement column '{name_column}' is missing in {type} file",
            )
            logging.debug(message)

    if file_validated:
        columns_to_keep = []
        if type == TYPE_SOURCE:
            columns_to_keep = CSV_XLSX_NON_ID_COLUMN_SOURCE
            if "original" in all_columns and name_column != "original":
                del data["original"]
                logging.debug("Removed 'original' column from source data")
            data.rename(columns={name_column: "original"}, inplace=True)
            logging.debug(f"Renamed column '{name_column}' to 'original'")
            try:
                if id_type == ID_TYPE:
                    columns_to_keep.append("ID")
                    if "ID" in all_columns and id_column != "ID":
                        del data["ID"]
                        logging.debug("Removed 'ID' column from source data")
                    data.rename(columns={id_column: "ID"}, inplace=True)
                    logging.debug(f"Renamed column '{id_column}' to 'ID'")
            except Exception as e:
                logging.info(f"id_type: {id_type}, all_columns: {all_columns}, id_column: {id_column}, columns_to_keep before ID check: {columns_to_keep} and {ID_TYPE}")
                logging.error(f"Error processing ID column for source data: {str(e)}")

        elif type == TYPE_REVISION:
            columns_to_keep = CSV_XLSX_NON_ID_COLUMN_REVISED
            if "revised" in all_columns and name_column != "revised":
                del data["revised"]
                logging.debug("Removed 'revised' column from revision data")
            data.rename(columns={name_column: "revised"}, inplace=True)
            logging.debug(f"Renamed column '{name_column}' to 'revised'")
            try:
                if id_type == ID_TYPE:
                    columns_to_keep.append("ID")
                    if "ID" in all_columns and id_column != "ID":
                        del data["ID"]
                        logging.debug("Removed 'ID' column from revision data")
                    data.rename(columns={id_column: "ID"}, inplace=True)
                    logging.debug(f"Renamed column '{id_column}' to 'ID'")
            except Exception as e:
                logging.info(f"id_type: {id_type}, all_columns: {all_columns}, id_column: {id_column}, columns_to_keep before ID check: {columns_to_keep} and {ID_TYPE}")
                logging.error(f"Error processing ID column for revision data: {str(e)}")

        data = data[columns_to_keep]
        logging.debug(f"Filtered columns to keep: {columns_to_keep}")

        output = BytesIO()
        try:
            if file_extension == CSV:
                output.write(data.to_csv(index=False).encode())  # Write encoded CSV content
                logging.debug("CSV data written to output buffer")
            elif file_extension == XLSX:
                data.to_excel(output, index=False, engine="openpyxl")
                logging.debug("Excel data written to output buffer")
            output.seek(0)
            if type == TYPE_SOURCE:
                form_data.source_file.file = output
            else:
                form_data.revision_file.file = output
        except Exception as e:
            logging.error(f"Error writing {type} file to output buffer: {str(e)}")
            return False, f"Error processing {type} file: {str(e)}", form_data

    file.file.seek(0)
    logging.debug(f"Validation completed for {type} file. Result: {file_validated}, Message: {message}")
    return file_validated, message, form_data


def validate_input(form_data):
    """Validate the inputfile.

    Parameters
    ----------
    form_data: InputData
        Input from the API for a file
    """
    source_file_extension = os.path.splitext(form_data.source_file.filename)[1]
    target_file_extension = os.path.splitext(form_data.revision_file.filename)[1]
    logging.info(f"Source file extension: {source_file_extension}, Target file extension: {target_file_extension}")
    # Define supported file extensions
    SUPPORTED_EXTENSIONS = ID_SUPPORTED_EXTENSIONS
    id_type = ID_TYPE
    exception = False
    # if NON_ID_TYPE.lower() in form_data.agent_id.lower():
    if form_data.isIdSelected != True:
        SUPPORTED_EXTENSIONS = NON_ID_SUPPORTED_EXTENSIONS
        id_type = NON_ID_TYPE
        form_data.source_id = None
        form_data.revision_id = None
        logging.info("Non-ID type selected, updating supported extensions and id_type")
    if (
        source_file_extension not in SUPPORTED_EXTENSIONS
        or target_file_extension not in SUPPORTED_EXTENSIONS
    ):
        logging.error("Unsupported file extension detected")
        return True, APIMessages.UNSUPPORTED_ERROR_MESSAGE.value, "", ""
    validation = True
    if source_file_extension in ID_SUPPORTED_EXTENSIONS:
        validation, message, form_data = validate_csv_and_xlsx(
            form_data, source_file_extension, TYPE_SOURCE, id_type
        )
    if validation and target_file_extension in ID_SUPPORTED_EXTENSIONS:
        validation, message, form_data = validate_csv_and_xlsx(
            form_data, source_file_extension, TYPE_REVISION, id_type
        )
    if not validation:
        logging.warning(f"Validation failed: {message}")
        return True, message, "", ""

    pdf_params = {}
    logging.debug("Input validation successful")
    return exception, "", id_type, pdf_params


async def validate_xmc_input(data_file, prediction_col_name):
    exception_message = ""
    
    file_extension = os.path.splitext(data_file.filename)[1]
    logging.debug(f"Validating XMC input file with extension: {file_extension}")
    if file_extension not in [".json"]:
        exception_message = "Unsupported file type for classification"
        logging.warning(exception_message)
    else:
        file_bytes = await data_file.read()
        data = pd.read_json(BytesIO(file_bytes))
        column_name = list(data.columns)
        logging.debug(f"Columns in XMC input: {column_name}")
        print(prediction_col_name)
        if prediction_col_name not in column_name:
            exception_message = "Prediction key name missing in data file"
            logging.warning(exception_message)
        data_file.file.seek(0)
    return exception_message



async def validate_delta_comparator_input(source_file, revision_files):
    exception_message = ""
    file_extension = os.path.splitext(source_file.filename)[1]
    logging.debug(f"Validating delta comparator input. Source file extension: {file_extension}")
    extensions = [".xlsx", ".json", ".reqifz", ".pdf"]
    if file_extension not in extensions:
        exception_message = "Unsupported file type for source file"
        logging.warning(exception_message)
    revision_extension =  [ os.path.splitext(f.filename)[1] for f in revision_files]
    for name in revision_extension:
        if name != file_extension:
            exception_message = "All revision files should be of same extension type"
            logging.warning(exception_message)
            break
    return exception_message


async def validate_json_input(data_file, prediction_col_name):
    try:
        exception_message = ""
        
        file_extension = os.path.splitext(data_file.filename)[1]
        logging.debug(f"Validating input file")
        if file_extension not in [".json"]:
            exception_message = "Unsupported file type"
        else:
            file_bytes = await data_file.read()
            data = pd.read_json(BytesIO(file_bytes))
            column_name = list(data.columns)
            if prediction_col_name not in column_name:
                exception_message = f"Prediction key: {prediction_col_name} missing in data file"
            data_file.file.seek(0)
        return exception_message
    except Exception as e:
        logging.error(f"Error occurred during JSON validation: {str(e)}")
        return f"JSON validation error: {str(e)}"


def get_status_message(task_status):
    status = "FAILED"
    logging.debug(f"Getting status message for task status: {task_status}")
    if task_status == TaskStatus.QUEUED.value:
        message = "Task is still in queue, please try again later."
        status = "QUEUED"
    elif task_status in [
        TaskStatus.PROCESSING.value,
        "MODEL_PREDICTION_COMPLETED",
    ]:
        message = "Task is still in processing, please try again later."
        status = "PROCESSING"
    elif task_status == TaskStatus.FAILED.value:
        message = "Task is still in Failed state, please try again later."
    elif task_status == "FAILED_TO_DOWNLOAD_FILE":
        message = "Task has failed in dowload files. Please try again."
    elif task_status == "UPLOAD_TO_FAILED_FILES":
        message = "Task has failed in uploading the result. Please try again."
    else:
        message = f"Task is in an unrecognized state. with state {task_status}"
        status = "PROCESSING"
    logging.info(f"Status: {status}, Message: {message}")
    return message, status