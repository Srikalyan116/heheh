"""Module for serializing task items into dictionaries for consistent data handling."""

from src.models.requirement_classification_task import RequirementClassTask


def individual_serial(task) -> RequirementClassTask:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the task item.
    """
    return RequirementClassTask(
        id=str(task["_id"]),
        agent_id=str(task.get("agent_id", "")),
        agent_name=str(task.get("agent_name", "")),
        user_id=str(task["user_id"]),
        project=str(task["project"]),
        filename=str(task["filename"]),
        status=str(task["status"]),
        created_timestamp=str(task["created_timestamp"]),
        lastupdated_timestamp=str(task["lastupdated_timestamp"]),
        label_column=str(task.get("label_column", "")),
        prediction_id=str(task.get("prediction_id", "")),
        prediction_col_name=str(task["prediction_col_name"]),
        request_type=str(task["request_type"]),
        tracker=str(task["tracker"]),
        status_error_message=str(task.get("status_error_message", "")),
        code_beamer_status=str(task.get("code_beamer_status", "")),
        code_beamer_error_message=str(task.get("code_beamer_error_message", "")),
        successfulOperationsCount=str(task.get("successfulOperationsCount", "")),
    )


def list_serial(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial(task) for task in tasks]
