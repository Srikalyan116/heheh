from src.utils.common.logger import log as logging
import json
import openpyxl
from io import BytesIO
from fastapi import UploadFile
from fastapi import HTTPException


async def excel_to_json(file: UploadFile,prediction_column: str ):
    """
    Convert the first sheet of an Excel file to a JSON object.
    """
    contents = await file.read()
    logging.debug(f"Loaded contents for Excel file: {file.filename}")
    workbook = openpyxl.load_workbook(BytesIO(contents))
    
    # Process only the first sheet
    first_sheet_name = workbook.sheetnames[0]
    logging.debug(f"Processing first sheet: {first_sheet_name} in file: {file.filename}")
    sheet = workbook[first_sheet_name]
    rows = list(sheet.iter_rows(values_only=True))

    if not rows or not rows[0]:
        logging.warning(f"First sheet {first_sheet_name} in file {file.filename} is empty.")
        return []

    headers = rows[0]
    if prediction_column not in headers:
        logging.error(f"First sheet {first_sheet_name} in file {file.filename} does not contain '{prediction_column}' in headers.")
        raise HTTPException(status_code=400, detail=f"The Prediction Key '{prediction_column}' is missing in the Excel file.")

    def make_serializable(val):
        try:
            json.dumps(val)
            return val
        except TypeError:
            return str(val)

    data = [
        {header: make_serializable(cell) for header, cell in zip(headers, row)}
        for row in rows[1:] if any(row)
    ]
    logging.debug(f"Extracted data from first sheet {first_sheet_name}: {data}")

    return data
