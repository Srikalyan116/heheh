import json
import pandas as pd
from io import BytesIO
import os
from src.utils.common.logger import log as logging


async def validate_json_key(file, key):
    logging.info("validate_json_key: start")
    try:
        try:
            file_bytes = file.file.read()
            file.file.seek(0)
        except Exception:
            file_bytes = file.read()
            file.seek(0)
        json_data = json.loads(file_bytes.decode("utf-8"))
        df = pd.DataFrame(json_data)
        file.file.seek(0)
        if key not in list(df.columns):
            return False
        return True
    except Exception as e:
        logging.exception(f"Exception in validate_json_key: {e}")
        return False

async def validate_excel_file(file, column_name, file_type: str = "revision"):
    try:
        result = ""
        try:
            file_content = await file.read()
        except Exception:
            file_content = await file.file.read()
        stream = BytesIO(file_content)
        data = pd.read_excel(stream)
        all_columns = list(data.columns)

        if column_name and column_name not in all_columns:
            result = f"ID column '{column_name}' not found in {file_type} file"
    except Exception as e:
        logging.exception(f"Exception in validate_excel_file: {e}")
        result = f"Error reading {file_type} file: {str(e)}"
    return result


async def  validate_json_data( revision_files, key_name):
    result = await validate_json( revision_files)
    if result:
        return result
    if isinstance(key_name, list):
        for idx, file in enumerate(revision_files):
            key = key_name[idx]
            if not await validate_json_key(file, key):
                return  f"Key column '{key}' missing in base {file.filename}"
    else:
        for file in revision_files:
            if not await validate_json_key(file, key_name):
                return  f"Key column missing in base {file.filename}"

    

async def validate_json( revision_files):
    if  len(revision_files) < 2:
        return "At least two revision file is required."
    
    for file in revision_files:
        if os.path.splitext(file.filename)[1] not in [".json"]: 
            return "Please Upload Json  revision files only."     
    
    return ""
