"""Global Constants."""

ID_SUPPORTED_EXTENSIONS = [".csv", ".xlsx"]
NON_ID_SUPPORTED_EXTENSIONS = [".csv", ".xlsx", ".pdf", ".reqifz"]
ID_TYPE = "id_based"
NON_ID_TYPE = "nonId"


TYPE_SOURCE = "source"
TYPE_REVISION = "revision"

CSV = ".csv"
XLSX = ".xlsx"
ID = "ID"
CSV_XLSX_NON_ID_COLUMN_SOURCE = ["original"]
CSV_XLSX_NON_ID_COLUMN_REVISED = ["revised"]

MENDATORY_KEYS_FOR_FEEDBACK = [
    "Critical",
    "Major",
    "Minor",
    "No Changes",
    "unidentified_count",
]
