"""Module for serializing task items into dictionaries for consistent data handling."""


def individual_serial(task) -> dict:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the tsak item.
    """
    return {
        "project_id": str(task["_id"]),
        "agent_id": task.get("agent_id", ""),
        "email": task.get("email", ""),
        "project_name": task.get("project_name", ""),
        "project_description": task.get("project_description", ""),
        "services_sheet_name": task.get("services_sheet_name", ""),
        "services_sheet_top_header_rows": task.get("services_sheet_top_header_rows", ""),
        "did_sheet_name ": task.get("did_sheet_name", ""),
        "did_sheet_top_header_rows": task.get("did_sheet_top_header_rows", ""),
        "did_col_num": task.get("did_col_num", ""),
        "dtc_sheet_name": task.get("dtc_sheet_name", ""),
        "dtc_sheet_top_header_rows": task.get("dtc_sheet_top_header_rows", ""),
        "dtc_col_num": task.get("dtc_col_num", ""),
        "control_routine_sheet_name": task.get("control_routine_sheet_name", ""),
        "control_routine_sheet_top_header_rows": task.get(
            "control_routine_sheet_top_header_rows", ""
        ),
        "control_routine_col_num": task.get("control_routine_col_num", ""),
        "created_timestamp": task.get("created_timestamp", ""),
        "project_requirement_file": task.get("project_requirement_file", ""),
        "status_error_message": task.get("status_error_message", ""),
    }


def list_serial_project(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial(task) for task in tasks]
