"""This module provides a MongoDB utility class to manage database \
connections using the singleton pattern."""

import logging
import os

from src.utils.common.logger import log as logging
from dotenv import load_dotenv
from pymongo import MongoClient

from src.config.config import mongo_config

# Load environment variables
load_dotenv()



class MongoDB:
    """Class for managing MongoDB connections.

    This class initializes and provides access to the MongoDB client, database, and collections,
    ensuring that only one instance of each exists within the application context.
    """

    _client: MongoClient = None
    _db = None
    _collection = None

    @classmethod
    def initialize(cls, uri=None, db_name=None, collection_name=None):
        """Initializes the MongoDB client, database, and collection as a singleton.

        Uses environment variables for the URI, database name, and collection name if not provided.

        Args:
            uri (str): The URI for the MongoDB connection.
            db_name (str): The name of the database to connect to.
            collection_name (str): The name of the collection to access.
        """
        logging.debug("Initializing MongoDB.")
        if cls._client is None:
            uri = os.getenv("MONGODB_URI")
            db_name = db_name or mongo_config.get("db_name")
            cls._client = MongoClient(uri)
            cls._db = cls._client.get_database(db_name)
        else:
            logging.info("MongoDB client already initialized.")

    @classmethod
    def get_client(cls):
        """Returns the MongoDB client instance if initialized.

        Raises:
            Exception: If the client has not been initialized.

        Returns:
            MongoClient: The singleton MongoDB client instance.
        """
        if cls._client is None:
            raise Exception(
                "MongoDB client has not been initialized. Please call 'initialize()' first."
            )
        return cls._client

    @classmethod
    def get_db(cls):
        """Returns the database instance if initialized.

        Raises:
            Exception: If the database has not been initialized.

        Returns:
            Database: The singleton database instance.
        """
        if cls._db is None:
            raise Exception("Database has not been initialized. Please call 'initialize()' first.")
        return cls._db

    @classmethod
    def get_collection(cls, collection):
        """Returns the collection instance if initialized.

        Raises:
            Exception: If the collection has not been initialized.

        Returns:
            Collection: The singleton collection instance.
        """
        db = cls.get_db()
        return db[collection]
