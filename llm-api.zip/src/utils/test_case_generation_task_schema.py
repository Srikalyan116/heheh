"""Module for serializing task items into dictionaries for consistent data handling."""


def individual_serial(task) -> dict:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the tsak item.
    """
    return {
        "task_name": task.get("task_name", ""),
        "task_id": str(task.get("_id", "")),
        "agent_id": task.get("agent_id", ""),
        "email": task.get("email", ""),
        "project_name": task.get("project_name", ""),
        "project_id": task.get("project_id", ""),
        "did_requirement_file": task.get("did_requirement_file", ""),
        "req_text_col": task.get("req_text_col", ""),
        "req_id_col": task.get("req_id_col", ""),
        "project_id": task.get("project_id", ""),
        "created_timestamp": task.get("created_timestamp", ""),
        "lastupdated_timestamp": task.get("lastupdated_timestamp"),
        "test_case_generation_status": task.get("test_case_generation_status"),
        "test_case_generation_output_file_name": task.get("test_case_generation_output_file_name"),
        "test_procedure_generation_status": task.get("test_procedure_generation_status"),
        "test_procedure_generation_output_filename": task.get(
            "test_procedure_generation_output_filename"
        ),
        "status_error_message": task.get("status_error_message", ""),
        # "template_test_case": task.get("template_test_case")
    }


def list_serial(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial(task) for task in tasks]
