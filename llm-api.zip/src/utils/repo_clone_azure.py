import asyncio
import os
import logging
from pathlib import Path
from typing import List, Dict
import httpx
import configparser
import platform
import uuid
import shutil
from io import StringIO
from urllib.parse import urlparse

from matplotlib.units import registry

from src.utils.common.logger import log as logger

MAX_CONCURRENT = 5
MAX_SUBMODULE_DEPTH = 5


# Disable httpx and requests logging
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("requests").setLevel(logging.WARNING)

# Remove directory with Windows MAX_PATH support
def safe_unlink(path):
    local_path = os.path.normpath(path)
    if platform.system() == "Windows":
        if not local_path.startswith('\\\\?\\'):
            local_path = os.path.abspath(local_path)
            local_path = f'\\\\?\\{local_path}'
    try:
        os.unlink(local_path)
    except Exception as e:
        print(f"Failed to delete {local_path}: {e}")

def windows_bypass_max_path(path):
    """
    Utility to bypass Windows MAX_PATH limitation by using the extended-length prefix.
    Returns the path with the \\?\ prefix if running on Windows and not already present.
    """
    local_path = os.path.normpath(path)
    if platform.system() == "Windows":
        if not local_path.startswith('\\\\?\\'):
            # Normalize and add prefix
            local_path = os.path.abspath(local_path)
            return f'\\\\?\\{local_path}'
    return path

def extract_org_project(url: str):
    """
    Extract organization and project from Azure DevOps repo URL.
    Returns (organization, project)
    """
    if not url:
        logger.error("Requires valid URL to extract organization and project")
        raise ValueError("Requires valid URL to extract organization and project")

    # Remove protocol and split by '/'
    parts = urlparse(url).path.strip('/').split('/')
    if len(parts) >= 3:
        organization = parts[0]
        project = parts[1]
        repo_name = parts[3]

        return organization, project, repo_name
    else:
        raise ValueError("Invalid Azure DevOps repo URL format")
    
class AzureReposDownloader:

    def __init__(self, organization, project, repo_name, branch=None, token=None, commit_id=None):
        self.organization = organization
        self.project = project
        self.repo_name = repo_name
        self.branch = branch
        self.commit_id = commit_id
        self.token = token
        self.full_commit_id = None

        self.base_url = (
            f"https://dev.azure.com/"
            f"{organization}/{project}/_apis/git/repositories/{repo_name}"
        )

        self.headers = {
            "Authorization": f"Bearer {token}"
        }

        self.client = httpx.AsyncClient(timeout=120)

        self.errors = []

    async def _verify_access(self):
        """
        Verifies access to the repository and branch by attempting to fetch repository details.
        Returns True if access is successful, otherwise raises an exception.
        """
        url = f"{self.base_url}?api-version=7.0"
        r = await self.client.get(url, headers=self.headers)
        if r.status_code == 200:
            return True
        
        if r.status_code == 301 or r.status_code == 302:
            raise RuntimeError("Unexpected redirect during token validation. Check the token or repository URL.")

        if r.status_code == 401:
            raise PermissionError("Token invalid or expired")

        if r.status_code == 403:
            raise PermissionError("Token does not have access to this repository")

        if r.status_code == 404:
            raise FileNotFoundError("Repository not found")

        else:
            r.raise_for_status()

    def _normalize_submodule_repo(self, url: str) -> str:
        """
        Converts submodule URL into a clean repo name.
        Handles:
            ../repo
            https://.../_git/repo
            https://.../_git/repo?version=XXXX
        """

        # relative path
        if url.startswith("../"):
            return url.replace("../", "").strip()

        parsed = urlparse(url)

        # Azure format: /project/_git/repo
        parts = parsed.path.split("/")

        if "_git" in parts:
            idx = parts.index("_git")
            return parts[idx + 1]

        # fallback
        return parts[-1]

    async def _resolve_repo_project(self, repo_name):
        """
        Finds which project contains the repo.
        Prevents submodule 404 failures.
        """

        url = f"https://dev.azure.com/{self.organization}/_apis/git/repositories?api-version=7.0"

        r = await self.client.get(url, headers=self.headers)
        r.raise_for_status()

        repos = r.json()["value"]

        for repo in repos:
            if repo["name"].lower() == repo_name.lower():

                project = repo["project"]["name"]

                logger.info(
                    f"Resolved submodule repo '{repo_name}' -> project '{project}'"
                )

                return project

        raise Exception(f"Submodule repo not found: {repo_name}")
    
    def _should_skip_path(self, path: str) -> bool:
        """
        Skip hidden / accessory directories, except required config folders.
        Example:
            .azuredevops
            .github
            .gitlab
            .tools
        """

        parts = path.strip("/").split("/")
        allowed_hidden_parts = {".github", ".vscode"}

        return any(
            part.startswith(".") and part not in allowed_hidden_parts
            for part in parts
        )

    async def _get_version_params(self):
        if self.full_commit_id:
            return {
                "versionDescriptor.version": self.full_commit_id,
                "versionDescriptor.versionType": "commit"
            }
        elif self.commit_id and len(self.commit_id) != 40:
            self.full_commit_id = await self._expand_commit_id(self.branch, self.commit_id)
            logger.info(f'Extracted full commit id: {self.full_commit_id}')
            return {
                "versionDescriptor.version": self.full_commit_id,
                "versionDescriptor.versionType": "commit"
            }
        else:
            return {
                "versionDescriptor.version": self.branch,
                "versionDescriptor.versionType": "branch"
            }
    # --------------------------------------------------------

    def _is_downloadable_file(self, item: dict):

        return (
            item.get("gitObjectType") == "blob"
        )

    # --------------------------------------------------------

    async def _list_items(self, branch):

        url = f"{self.base_url}/items"

        params = {
            "scopePath": "/",
            "recursionLevel": "Full",
            **await self._get_version_params(),
            "api-version": "7.0"
        }

        r = await self.client.get(url, headers=self.headers, params=params)
        r.raise_for_status()

        return r.json()["value"]
    
    # --------------------------------------------------------

    async def _expand_commit_id(self, branch, short_commit):
        url = f"{self.base_url}/commits"

        params = {
            "searchCriteria.itemVersion.version": branch,
            "searchCriteria.itemVersion.versionType": "branch",
            "$top": 200,  # adjust if needed
            "api-version": "7.0"
        }

        r = await self.client.get(url, headers=self.headers, params=params)
        r.raise_for_status()

        commits = r.json().get("value", [])

        for c in commits:
            if c["commitId"].startswith(short_commit):
                return c["commitId"]

        raise Exception(f"Commit not found in branch {branch}: {short_commit}")

    async def get_latest_commit_short(self, branch=None):
        """
        Fetches the latest commit for the given branch and returns the first 10 characters.
        """
        branch = branch or self.branch
        url = f"{self.base_url}/commits"
        params = {
            "searchCriteria.itemVersion.version": branch,
            "searchCriteria.itemVersion.versionType": "branch",
            "$top": 1,
            "api-version": "7.0"
        }
        r = await self.client.get(url, headers=self.headers, params=params)
        r.raise_for_status()
        commits = r.json().get("value", [])
        if not commits:
            raise Exception(f"No commits found for branch: {branch}")
        latest_commit = commits[0]["commitId"]
        return latest_commit[:12]

    # --------------------------------------------------------

    async def _download_file(self, 
                             path, 
                             branch, 
                             task_id="",
                             tasks_registry=None
                             ):

        url = f"{self.base_url}/items"

        params = {
            "path": path,
            **await self._get_version_params(),
            "api-version": "7.0"
        }

        if tasks_registry and await tasks_registry.is_cancelled(task_id):
            return None

        for attempt in range(3):
            try:
                r = await self.client.get(url, headers=self.headers, params=params)
                r.raise_for_status()
                return r.text
            except Exception:
                await asyncio.sleep(2 ** attempt)

        logger.error(f"Failed downloading {path}")
        self.errors.append(f"{path}")
        return None

    # --------------------------------------------------------

    def _parse_gitmodules(self, content):

        parser = configparser.ConfigParser()
        parser.read_file(StringIO(content))

        modules = []

        for section in parser.sections():

            modules.append({
                "path": parser.get(section, "path"),
                "url": parser.get(section, "url"),
            })

        return modules

    # --------------------------------------------------------

    async def _download_repo_recursive(
        self,
        output_dir,
        branch,
        depth=0,
        file_counter=None,
        task_id="",
        tasks_registry=None
    ):
        if tasks_registry and await tasks_registry.is_cancelled(task_id):
            logger.warning(f"[CANCELLED] Clone aborted by user: {task_id}")
            return {"cancelled": True}
        response = {}
        if os.path.exists(output_dir) and os.path.exists(os.path.join(output_dir, ".READY")):
            logger.info(f"Output directory already exists: {output_dir}")
            return {"errors": [], "files_found": file_counter[0] if file_counter else 0}
        if file_counter is None:
            file_counter = [0]
        try:
            if depth > MAX_SUBMODULE_DEPTH:
                logger.warning("Max submodule depth reached")
                response["errors"] = [f"Max submodule depth ({MAX_SUBMODULE_DEPTH}) reached"]
                return response
            # tmp_output_dir = f"{output_dir}.tmp_{uuid.uuid4().hex}"
            Path(output_dir).mkdir(parents=True, exist_ok=True)
            items = await self._list_items(branch)
            semaphore = asyncio.Semaphore(MAX_CONCURRENT)
            files = [
                i for i in items
                if self._is_downloadable_file(i)
                and not self._should_skip_path(i["path"])
            ]
            total_files = len(files)
            logger.info(f"Found {total_files} files in {self.repo_name} (branch: {branch})")
            async def worker(item):
                if tasks_registry and await tasks_registry.is_cancelled(task_id):
                    return
                async with semaphore:
                    content = await self._download_file(
                        item["path"],
                        branch
                    )
                    local_path = os.path.join(
                        output_dir,
                        item["path"].lstrip("/")
                    )
                    local_path = os.path.normpath(local_path)
                    Path(os.path.dirname(local_path)).mkdir(
                        parents=True,
                        exist_ok=True
                    )

                    # Create the file even when content retrieval failed/returned None.
                    safe_content = "" if content is None else content
                    with open(local_path, "w", encoding="utf-8") as f:
                        f.write(safe_content)
                    file_counter[0] += 1
                    
            # tasks = []
            # for f in files:
            #     if tasks_registry and await tasks_registry.is_cancelled(task_id):
            #         break
            #     tasks.append(worker(f))
            # await asyncio.gather(*tasks)

            pending = set()

            for item in files:

                if tasks_registry and await tasks_registry.is_cancelled(task_id):

                    # Cancel all running tasks
                    for t in pending:
                        t.cancel()

                    await asyncio.gather(*pending, return_exceptions=True)
                    return {"cancelled": True}

                # Start new task
                task = asyncio.create_task(worker(item))
                pending.add(task)

                # Remove completed tasks
                task.add_done_callback(pending.discard)

                # Respect concurrency limit
                if len(pending) >= MAX_CONCURRENT:
                    done, pending = await asyncio.wait(
                        pending,
                        return_when=asyncio.FIRST_COMPLETED
                    )

            # Wait remaining tasks
            if pending:
                await asyncio.gather(*pending)


            if tasks_registry and await tasks_registry.is_cancelled(task_id):
                return {"cancelled": True}

            logger.info(f"{len(files)} files downloaded from {self.repo_name}")
            gitmodules = next(
                (i for i in items if i["path"] == "/.gitmodules"),
                None
            )
            response["files_found"] = file_counter[0]

            gitmodules = next(
                (i for i in items if i["path"] == "/.gitmodules"),
                None
            )

            response["files_found"] = file_counter[0]

            if gitmodules:
                logger.info("Submodules detected")

                content = await self._download_file("/.gitmodules", branch, task_id, tasks_registry)

                if content:
                    submodules = self._parse_gitmodules(content)

                    for sub in submodules:

                        if tasks_registry and await tasks_registry.is_cancelled(task_id):
                            return {"cancelled": True}


                        if self._should_skip_path(sub["path"]):
                            continue

                        sub_item = next(
                            (i for i in items if i["path"].lstrip("/") == sub["path"]),
                            None
                        )
                        if not sub_item:
                            continue

                        commit = sub_item["objectId"]
                        repo_name = self._normalize_submodule_repo(sub["url"])

                        project = await self._resolve_repo_project(repo_name)


                        sub_downloader = AzureReposDownloader(
                            self.organization,
                            project,
                            repo_name,
                            branch=None,
                            commit_id=commit,
                            token=self.token
                        )

                        await sub_downloader._download_repo_recursive(
                            os.path.join(output_dir, sub["path"]),
                            commit,
                            depth + 1,
                            file_counter,
                            task_id,
                            tasks_registry
                        )

            if tasks_registry and await tasks_registry.is_cancelled(task_id):
                return {"cancelled": True}

            # create .READY
            ready_file = os.path.join(output_dir, ".READY")

            logger.info(f"Writing READY marker → {ready_file}")

            Path(ready_file).touch()

            return response
        
        except httpx.HTTPStatusError as e:

            if e.response.status_code in (401, 403, 404):

                logger.warning(
                    f"Skipping module (no access): {repo_name}"
                )
            else:
                raise e
        except Exception as e:
            logger.error(f"Error downloading repository: {str(e)}")
            response["errors"] = [str(e)]
            return response

    # --------------------------------------------------------

    async def download_entire_repository(self, output_dir=None, force_retry=False, task_id="", tasks_registry=None) -> Dict:
        try:

            if tasks_registry and await tasks_registry.is_cancelled(task_id):
                logger.warning(f"[CANCELLED] Task aborted by user: {task_id}")
                return {"cloning_dir": None, "repo_name": self.repo_name, "branch": self.branch, "latest_commit": None, "errors": [], "file_count": 0, "cancelled": True}

            logger.info(f"Starting download of repository '{self.repo_name}' (branch: {self.branch})")
            await self._verify_access()

            if not self.commit_id:
                self.commit_id = (await self.get_latest_commit_short())[:12]  # shorten to 12 chars

            download_dir = f"{self.repo_name}_{self.branch}_{self.commit_id}"
            
            if not output_dir:
                output_dir = os.path.join(
                    os.getcwd(),
                    download_dir
                )
            else:
                output_dir = os.path.join(
                    output_dir,
                    download_dir
                )

            output_dir = windows_bypass_max_path(output_dir)    

            if not force_retry:
                # Check if the repository has already been downloaded
                if os.path.exists(output_dir) and os.path.exists(os.path.join(output_dir, ".READY")):
                    logger.info(f"Repository '{self.repo_name}' (branch: {self.branch}) already downloaded.")
                    return {"cloning_dir": output_dir, 
                            "repo_name": self.repo_name,
                            "branch": self.branch,
                            "latest_commit": self.commit_id,
                            "errors": []}
            else:
                logger.info("Force retry enabled: re-downloading repository.")
                if os.path.exists(output_dir):
                    logger.info(f"Removing existing directory: {output_dir}")
                    shutil.rmtree(output_dir)
                    logger.info("Existing directory removed.")
            file_counter = [0]
            result = await self._download_repo_recursive(
                output_dir,
                self.branch,
                0,
                file_counter,
                task_id, 
                tasks_registry
            )
            await self.client.aclose()
            print(result)
            if result.get("cancelled"):
                logger.warning(f"Download cancelled by user: {task_id}")
                return {"cloning_dir": None, "repo_name": self.repo_name, "branch": self.branch, "latest_commit": None, "errors": [], "file_count": 0, "cancelled": True}
            if not result or result.get("files_found", 0) == 0:
                logger.error("No files were downloaded.")
                return {"cloning_dir": output_dir.lstrip("\\\\?\\"),
                        "repo_name": self.repo_name,
                        "branch": self.branch,
                        "latest_commit": self.commit_id,
                        "errors": [True,],
                        "file_count": 0}
            
            logger.info(f"Download complete. Total files downloaded (including submodules): {file_counter[0]}")
            return {"cloning_dir": output_dir.lstrip("\\\\?\\"),
                    "repo_name": self.repo_name,
                    "branch": self.branch,
                    "latest_commit": self.commit_id,
                    "errors": [],
                    "file_count": result.get("files_found", 0)}
        except httpx.HTTPStatusError as e:

            if e.response.status_code in (401, 403, 404):

                logger.warning(
                    f"Skipping submodule (no access)"
                )
                return {"cloning_dir": None, "repo_name": self.repo_name, "branch": self.branch, "latest_commit": None, "errors": [f"Access error: {e.response.status_code}"], "file_count": 0}    

            else:
                raise e
        except Exception as e:
            logger.error(f"Error downloading repository: {str(e)}")
            return {"cloning_dir": None, "repo_name": self.repo_name, "branch": self.branch, "latest_commit": None, "errors": [str(e)], "file_count": 0}

if __name__ == "__main__":

    downloader = AzureReposDownloader(
        organization="SW4ZF",
        project="AZP-340_DivC_DI_Projects",    #AZP-340_DivC_DI_Projects, AZP-377_DivDI_LLM
        repo_name="akc_mb_ea_l_dummy",       #akc_mb_ea_l_dummy, llm-akc-test-project
        branch="master",
    )

    asyncio.run(downloader.download_entire_repository())