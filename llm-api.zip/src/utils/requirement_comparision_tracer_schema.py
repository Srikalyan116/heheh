"""Module for serializing task items into dictionaries for consistent data handling."""

from datetime import datetime, timezone
from pathlib import Path

from src.utils.utils_enum import RequestType, TaskStatus


def get_task_data(user_details, form_data, rule_task, id_type, pdf_params):
    """Generate Task Data based on the inputs.

    Parameters
    ----------
    user_details: dict
        contains user info
    form_data: FileUpload
        contains the uploaded file along with its metadata
    rule_task: str
        Rule data
    id_type: str
        source of the id
    pdf_params: dict
        additionaly params for PDF Usecase

    Returns
    -------
    dict
        task detials which can be added to mongodb

    """
    output_filename = Path(form_data.source_file.filename)
    output_filename = f"{output_filename.stem}_output.xlsx"
    return {
        "rule_id": form_data.rule_id,
        "rule_name": rule_task.get("rule_name"),
        "project": form_data.project,
        "email": user_details["email"],
        "agent_id": form_data.agent_id,
        "output_filename": output_filename,
        "source_filename": form_data.source_file.filename,
        "revision_filename": form_data.revision_file.filename,
        "source_col_name": form_data.source_col_name,
        "revision_col_name": form_data.revision_col_name,
        "source_id": form_data.source_id,
        "revision_id": form_data.revision_id,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
        "id_type": id_type,
        **pdf_params,
    }


def get_task_data_xmc(user_details, data_file, prediction_col_name):
    """Generate Task Data based on the inputs.

    Parameters
    ----------
    user_details: dict
        contains user info
    form_data: FileUpload
        contains the uploaded file along with its metadata
    rule_task: str
        Rule data
    id_type: str
        source of the id
    pdf_params: dict
        additionaly params for PDF Usecase

    Returns
    -------
    dict
        task detials which can be added to mongodb

    """
    output_filename = Path(data_file.filename)
    output_filename = f"{output_filename.stem}_output.xlsx"
    return {
        "email": user_details["email"],
        "output_filename": output_filename,
        "source_filename": data_file.filename,
        "prediction_col_name": prediction_col_name,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
    }


def get_task_data_pecos(user_details, data_file, types, prediction_key):
    """Generate Task Data based on the inputs.

    Parameters
    ----------
    user_details: dict
        contains user info
    form_data: FileUpload
        contains the uploaded file along with its metadata
    rule_task: str
        Rule data
    id_type: str
        source of the id
    pdf_params: dict
        additionaly params for PDF Usecase

    Returns
    -------
    dict
        task detials which can be added to mongodb

    """
    if data_file.filename.endswith(".xlsx") or data_file.filename.endswith(".xls"):
        output_filename = Path(data_file.filename)
        output_filename = f"{output_filename.stem}_output.json"
        file_name = data_file.filename.replace(".xlsx", ".json").replace(".xls", ".json")
    else:
        output_filename = Path(data_file.filename)
        output_filename = f"{output_filename.stem}_output.json"
        file_name = data_file.filename
    return {
        "email": user_details["email"],
        "output_filename": output_filename,
        "source_filename": file_name if file_name else data_file.filename,
        "prediction_key": prediction_key,
        "types": types,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
    }


def get_task_data_delta_generator(revision_files, user_details, meta_info, file_extension):
    """Generate Task Data based on the inputs.

    Parameters
    ----------
    user_details: dict
        contains user info
    form_data: FileUpload
        contains the uploaded file along with its metadata
    rule_task: str
        Rule data
    id_type: str
        source of the id
    pdf_params: dict
        additionaly params for PDF Usecase

    Returns
    -------
    dict
        task detials which can be added to mongodb

    """
    if file_extension in [".xlsx", ".xls", ".reqifz"]:
        original_filename = [f.filename for f in revision_files]
        revision_filename = [
            str(f.filename)
            .replace(".xlsx", ".json")
            .replace(".xls", ".json")
            .replace(".reqifz", ".zip")
            for f in revision_files
        ]
        output_filename = Path(revision_filename[0])
        output_filename = f"{output_filename.stem}_output.xlsx"
    else:
        original_filename = [f.filename for f in revision_files]
        revision_filename = [f.filename for f in revision_files]
        output_filename = Path(revision_filename[0])
        output_filename = f"{output_filename.stem}_output.json"
    return {
        "username": user_details["email"],
        "user_id": user_details["email"],
        "email": user_details["email"],
        "output_filename": output_filename,
        "original_filename": original_filename,
        "revision_filename": revision_filename,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.MANUAL.value,
        **meta_info,
    }


def get_task_data_code_beamer(
    user_details,
    source_tracker,
    revision_tracker,
    project,
    source_tracker_name,
    revision_tracker_name,
):
    """Generate Task Data for CodeBeamer based on the inputs.

    Parameters
    ----------
    user_details: dict
        contains user info
    source_tracker: str
        contains the source tracker information
    revision_tracker: str
        contains the revision tracker information
    project: str
        Name of the codebeamer project
    source_tracker_name: str
        Name of the source tracker
    revision_tracker_name: str
        Name of the revision tracker

    Returns
    -------
    dict
        task details which can be added to mongodb

    """
    output_filename = f"{source_tracker_name}_{revision_tracker_name}_output.json"
    revision_filename = [source_tracker_name, revision_tracker_name]
    return {
        "username": user_details["email"],
        "user_id": user_details["email"],
        "email": user_details["email"],
        "codebeamer_project": project,
        "source_tracker": source_tracker,
        "revision_tracker": revision_tracker,
        "revision_filename": revision_filename,
        "output_filename": output_filename,
        "status": TaskStatus.CREATED.value,
        "status_update_message": {
            datetime.now(timezone.utc).isoformat(): TaskStatus.TASK_STARTED.value
        },
        "status_code": None,
        "created_timestamp": datetime.now(timezone.utc),
        "lastupdated_timestamp": datetime.now(timezone.utc),
        "request_type": RequestType.CODEBEAMER.value,
        "key_name": ["text", "text"],
        "key_column_mapping": {source_tracker_name: "text", revision_tracker_name: "text"},
        "file_extension": ".zip",
        "type_filter": ["Text", "Table", "Image"],
    }
