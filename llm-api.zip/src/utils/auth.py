"""Includes JWT & user validation utilities to be used for damage calculation Service operator."""

import json
from datetime import datetime
from typing import Optional

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.openapi.models import HTTPBearer as HTTPBearerModel
from fastapi.requests import Request
from fastapi.security import HTTPAuthorizationCredentials
from fastapi.security.http import HTTPBase
from fastapi.security.utils import get_authorization_scheme_param
from starlette.status import HTTP_403_FORBIDDEN
from src.utils.common.logger import log as logging


class CustomHTTPBearer(HTTPBase):  # pylint: disable=too-few-public-methods
    """Overwriting bearer authorization logic."""

    def __init__(  # pylint: disable=super-init-not-called
        self,
        *,
        bearerFormat: Optional[str] = None,
        scheme_name: Optional[str] = None,
        description: Optional[str] = None,
        auto_error: bool = True,
    ):
        """Initializes the auth bearer schema.

        Args:
            bearerFormat (Optional[str], optional): _description_. Defaults to None.
            scheme_name (Optional[str], optional): _description_. Defaults to None.
            description (Optional[str], optional): _description_. Defaults to None.
            auto_error (bool, optional): _description_. Defaults to True.
        """
        self.model = HTTPBearerModel(bearerFormat=bearerFormat, description=description)
        self.scheme_name = scheme_name or self.__class__.__name__
        self.auto_error = auto_error

    async def __call__(self, request: Request) -> Optional[HTTPAuthorizationCredentials]:
        """Call back function checking crediantials.

        Args:
            request (Request): _description_

        Raises:
            HTTPException: _description_
            HTTPException: _description_

        Returns:
            Optional[HTTPAuthorizationCredentials]: _description_
        """
        logging.debug("Checking Authorization header in request.")
        authorization: str = request.headers.get("Authorization")
        scheme, credentials = get_authorization_scheme_param(authorization)
        if not authorization:
            logging.warning("No Authorization header found. Checking for service-domain header.")
            headers_dict = {
                key.decode(): val.decode()
                for key, val in request.headers.raw
                if key.decode() == "service-domain" and val.decode()
            }
            if headers_dict:
                logging.debug("service-domain header found, skipping auth.")
                return None
        if not (authorization and scheme and credentials):
            logging.error("Authorization, scheme, or credentials missing.")
            if self.auto_error:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated"
                )
            return None
        if scheme.lower() != "bearer":
            logging.error("Authorization scheme is not Bearer.")
            if self.auto_error:
                raise HTTPException(
                    status_code=HTTP_403_FORBIDDEN,
                    detail="Invalid authentication credentials",
                )
            return None
        logging.info("Credentials validated successfully.")
        return HTTPAuthorizationCredentials(scheme=scheme, credentials=credentials)


class AuthValidation:
    """To validate the auth token.

    Raises:
        HTTPException: _description_
        HTTPException: _description_
        HTTPException: _description_
        HTTPException: _description_

    Returns:
        _type_: _description_
    """

    user_details = {}

    def validate_token(self, request, token: str):
        """Validate token.

        Args:
            request (_type_): _description_
            token (str): _description_

        Raises:
            HTTPException: _description_
            HTTPException: _description_
            HTTPException: _description_

        Returns:
            _type_: _description_
        """
        try:
            logging.debug("Validating JWT token.")
            token_new = request.headers["Authorization"]
            token_new = token_new.replace("Bearer ", "")
            alg = jwt.get_unverified_header(token_new)["alg"]
            decoded_access_token = jwt.decode(
                token_new, algorithms=[alg], options={"verify_signature": False}
            )
            token_expiry = datetime.utcfromtimestamp(decoded_access_token["exp"])
            now = datetime.utcnow()
            time_to_expiry = token_expiry - now
            logging.debug(f"Token expires in {time_to_expiry}.")
            if time_to_expiry.days < 0:
                logging.warning("Token expired.")
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED, detail="Token expired"
                )
            uniques_name_key = "unique_name"
            if uniques_name_key in decoded_access_token.keys():
                self.user_details["email"] = decoded_access_token["unique_name"]
            else:
                self.user_details["email"] = decoded_access_token["email"]
            self.user_details["token"] = token_new
            request.state.user = self.user_details
            logging.debug(f"User details set in request state: {self.user_details}")
            return self.user_details

        except Exception as e:
            logging.error(f"Token validation failed: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Token validation failed: {str(e)}",
            )

    async def wrapper(
        self, request: Request, auth: HTTPAuthorizationCredentials = Depends(CustomHTTPBearer())
    ):
        """Validate token auth.

        Args:
            request (Request): _description_
            auth (HTTPAuthorizationCredentials, optional): _description_. Defaults to Depends(CustomHTTPBearer()).

        Raises:
            HTTPException: _description_

        Returns:
            _type_: _description_
        """
        if not auth.credentials:
            logging.error("No credentials provided in Authorization header.")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="No credentials provided"
            )
        return self.validate_token(request, auth.credentials)
