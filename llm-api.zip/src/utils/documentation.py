"""This helper module for add documentation for swaggerUI."""

readme_description = """
# Orchestration Layer API

This powers up GenAI UI/UX

## Rules
1. **Authentication**: All API requests must be authenticated using a valid token.

## Getting Started
To authenticate, follow these steps:
1. Download the zip file from auth token help file([Download zip here](https://azp078rg9a96.blob.core.windows.net/genai-authentication/Token%20Parser-4d477102-561f-469c-a913-9ac7b243b10d.zip?sp=r&st=2024-09-18T06:36:37Z&se=2025-11-30T14:36:37Z&spr=https&sv=2022-11-02&sr=b&sig=mXEF42yoVE2KBZvErh90suVXGGoqHJZ1hWmPpGZjjhQ%3D)).
2. Unzip the file and then you have token_parser.py, requirements.txt and README.md file.
3. Please run pip install -r requirement.txt on Command line interface of the same directory.
4. After installing all the requirements successfully, then you have to run token_parser.py file.
5. To run the script `token_parser.py` and pass your email and password as arguments, use the following command:

```bash
python token_parser.py <email> <password>

use this token in our swagger doc.
"""
