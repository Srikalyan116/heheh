"""Module for serializing task items into dictionaries for consistent data handling."""

from src.exceptions.db_exceptions import SerializationError

def individual_serial(task) -> dict[str, str | int]:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the task item.
    """
    task_details = {}
    for key, value in task.items():
        if key == "_id":
            key = "id"
            value = str(value)
        task_details[key] = value
    return task_details


def list_serial_generic(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    try:
        return [individual_serial(task) for task in tasks]
    except Exception:
        raise SerializationError()
