"""Module for serializing task items into dictionaries for consistent data handling."""

from src.models.code_serach_task import CodeSearchTask


def individual_serial(task) -> dict:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the tsak item.
    """
    return {
        "email": task.get("email", ""),
        "repo_url": task.get("repo_url", ""),
        "branch_name": task.get("branch_name", ""),
        "project_name": task.get("project_name", ""),
        "repo_type": task.get("repo_type", ""),
        "branch": task.get("branch", ""),
        "production_lines": task.get("production_lines", ""),
        "status": task.get("status", ""),
        "status_code": task.get("status_code", ""),
        "timestamp": task.get("created_timestamp", ""),
        "status_update_message": task.get("status_update_message", ""),
    }


def list_serial(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial(task) for task in tasks]
