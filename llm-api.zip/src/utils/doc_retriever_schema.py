"""Schemas for representing users, files, projects, and tasks in the application."""

from typing import List, Literal

from pydantic import BaseModel


class UserSchema(BaseModel):
    """Represents a user in the application.

    Args:
        - name (str): The name of the user.
        - id (str): A unique identifier for the user.

    This schema is used to encapsulate user-related information and ensure that
    the provided data adheres to the expected types and constraints.
    """

    name: str
    id: str


class FileSchema(BaseModel):
    """Represents a file uploaded in the application.

    Args:
    - file_name (str): The name of the file.
    - uploaded_by (UserSchema): The user who uploaded the file, represented
      by a UserSchema instance.
    - project_name (str): The name of the project associated with the file.
    - last_update_timestamp (str): The timestamp of the last update to the file
    - location (str): The storage location of the file (e.g., a file path or URL).
    - download_link (str): A URL link that allows downloading the file.

    This schema ensures that all required information about a file is captured
    and validated, facilitating consistent data handling within the application.
    """

    file_name: str
    uploaded_by: UserSchema
    project_name: str
    last_update_timestamp: str
    location: str
    download_link: str


class ProjectSchema(BaseModel):
    """Represents a project in the application.

    Args:
    - project_name (str): The name of the project.
    - admin (UserSchema): The user who is the administrator of the project,
      represented by a UserSchema instance.
    - agent_id (str): A unique identifier for the agent associated with the project.
    - last_updated_by (UserSchema): The user who last updated the project,
      represented by a UserSchema instance.
    - create_timestamp (str): The timestamp when the project was created
    - update_timestamp (str): The timestamp of the last update to the project,
    - files (List[FileSchema]): A list of files associated with the project,
      each represented by a FileSchema instance.

    This schema ensures that all relevant information about a project is captured
    and validated, enabling effective project management within the application.
    """

    project_name: str
    admin: UserSchema
    agent_id: str
    last_updated_by: UserSchema
    create_timestamp: str
    update_timestamp: str
    files: List[FileSchema]


class TaskSchema(BaseModel):
    """Represents a task associated with a project in the application.

    Args:
    - id (str): A unique identifier for the task.
    - project (str): The name of the project to which the task belongs.
    - filename (str): The name of the file associated with the task.
    - task_name (str): The name or title of the task.
    - status (str): The current status of the task (e.g., 'Pending', 'In Progress', 'Completed').
    - created_timestamp (str): The timestamp when the task was created
    - lastupdated_timestamp (str): The timestamp of the last update to the task
    - tracker (str): An identifier for the task tracking mechanism or system used.
    - description_col_name (str): The name of the column that contains task descriptions.
    - id_col_name (str): The name of the column that contains task IDs.
    - search_type (str): The type of search being performed (e.g., 'full_text', 'exact').
    - request_type (str): The type of request associated with the task (e.g., 'manual', 'automated').

    This schema ensures that all relevant information about a task is captured
    and validated, facilitating effective task management within the application.
    """

    id: str
    agent_id: str
    project: str
    filename: str
    task_name: str
    status: str
    created_timestamp: str
    lastupdated_timestamp: str
    tracker: str
    description_col_name: str
    id_col_name: str
    search_type: str
    request_type: str
    status_error_message: str


def individual_serial_task(task) -> TaskSchema:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the task item.

    """
    return TaskSchema(
        id=str(task.get("_id", "")),
        agent_id=str(task.get("agent_id", "")),
        project=str(task.get("project", "")),
        filename=str(task.get("filename", "")),
        task_name=str(task.get("task_name", "")),
        status=str(task.get("status", "")),
        created_timestamp=str(task.get("created_timestamp", "")),
        lastupdated_timestamp=str(task.get("lastupdated_timestamp", "")),
        description_col_name=str(task.get("description_col_name", "")),
        id_col_name=str(task.get("id_col_name", "")),
        request_type=str(task.get("request_type", "")),
        tracker=str(task.get("tracker", "")),
        search_type=str(task.get("search_type", "")),
        status_error_message=str(task.get("status_error_message", "")),
    )


def list_serial_task(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial_task(task) for task in tasks]


def individual_serial_project(project) -> ProjectSchema:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the task item.
    """

    def get_file_schema(file):
        return FileSchema(
            file_name=file["file_name"],
            uploaded_by=file["uploaded_by"],
            project_name=file["project_name"],
            last_update_timestamp=str(file["last_update_timestamp"]),
            location=file["location"],
            download_link=file["download_link"],
        )

    return ProjectSchema(
        project_name=str(project["project_name"]),
        # agent_id=str(project["agent_id"]),
        agent_id=project.get("agent_id", ""),
        admin=UserSchema(name=project["admin"]["name"], id=project["admin"]["id"]),
        last_updated_by=UserSchema(
            name=project["last_updated_by"]["name"], id=project["last_updated_by"]["id"]
        ),
        create_timestamp=str(project["create_timestamp"]),
        update_timestamp=str(project["update_timestamp"]),
        files=[get_file_schema(file) for file in project["files"]],
    )


def list_serial_project(projects) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial_project(project) for project in projects]


def transform_data(data):
    """Transforms output data in specific output format.

    Args:
        data (json): input json file.

    Returns:
        json: formatted output json file.
    """
    transformed_data = []

    for entry in data:
        transformed_entry = {"ID": entry["ID"], "Description": entry["Description"], "hits": []}

        # Collect hits
        i = 0
        while f"hit_{i}_text" in entry:
            hit = {
                "text": entry[f"hit_{i}_text"],
                "file_name": entry[f"hit_{i}_file_name"],
                "file_path": entry[f"hit_{i}_file_path"],
                "page_no": entry[f"hit_{i}_page_no"],
            }
            transformed_entry["hits"].append(hit)
            i += 1

        transformed_data.append(transformed_entry)

    return transformed_data
