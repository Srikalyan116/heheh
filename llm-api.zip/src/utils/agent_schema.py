"""Module for agent task items into dictionaries for consistent data handling."""


def individual_serial_agent(task) -> dict:
    """Serialize an individual task item into a dictionary.

    This function takes a task item represented as a dictionary and transforms it into a
    structured dictionary suitable for network transmission or further processing.

    Args:
        task (dict): A dictionary representing the task item to serialize.

    Returns:
        dict: A dictionary containing structured data about the tsak item.
    """
    return {
        "agent_id": task.get("agent_id", ""),
        "agent_name": str(task.get("agent_name", "")),
        "agent_desc": task.get("agent_desc", ""),
        "object_id": task.get("object_id", ""),
        "co_pilot": task.get("co_pilot", ""),
        "feature_name": task.get("feature_name", ""),
        "feature_desc": task.get("feature_desc", ""),
        "agent": task.get("agent", ""),
    }


def list_serial_agent(tasks) -> list:
    """Serialize a list of task items using the individual_serial function.

    This function processes a list of task items, applying the individual_serial function to
    each item in the list to produce a list of serialized dictionaries.

    Args:
        tasks (list): A list of dictionary objects, each representing a tasks item.

    Returns:
        list: A list of dictionaries, each containing structured data about a task item.
    """
    return [individual_serial_agent(task) for task in tasks]
