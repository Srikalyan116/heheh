"""Utils for codebeamer integration."""

import json
import logging
import os
import re
from typing import Optional

import pandas as pd
import requests
from bson import ObjectId
from fastapi import HTTPException
from requests import Response
import json
from fastapi import HTTPException
import requests
import zipfile
import io
import os
import tempfile
import sys
import concurrent.futures
import logging

from src.utils.utils_enum import TaskStatus


def clean_tracker_id_value(value: str) -> str:
    """Method to clean the value for the Cust Req ID and Cus Object ID.

    Args:
        value (str): Value of Cust Req ID or Cus Object ID.

    Returns:
        Cleaned value as string.
    """
    match = re.search(r"\^\^([A-Za-z0-9~\-]+)\^\^", value)
    if match:
        return match.group(1).replace("~-", "-")
    # If the closing ^^ is missing, extract after ^^ up to % or end
    match = re.search(r"\^\^([A-Za-z0-9~\-]+)", value)
    if match:
        return match.group(1).replace("~-", "-")
    # Extract any valid alphanumeric + dashes group
    match = re.search(r"[A-Za-z0-9]+(?:~\-?[A-Za-z0-9]+)+", value)
    if match:
        return match.group(0).replace("~-", "-")
    return value


def get_items_by_project(
    auth_token: str,
    codebeamer_url: str,
    codebeamer_project: str,
    codebeamer_tracker: str,
    # collection,
    # task_id,
) -> Response:
    """Method to fetch tracker items from codebeamer based on project name.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer project api.
        codebeamer_project (str): Name of the codebeamer project.

    Returns:
        Response: Object of paginated tracker items from codebeamer.
    """
    endpoint = "/v3/items/query"
    codebeamer_url += endpoint
    tracker_items = []
    page_number = 1

    while True:
        # Query param containing comma seperated project names
        params = {
            "queryString": f"project.name IN ('{codebeamer_project}') and \
                tracker.name IN ('{codebeamer_tracker}') ORDER BY item.id ASC",
            "page": page_number,
            "pageSize": 500,
        }

        # Set header for token based auth
        headers = {"Authorization": f"Bearer {auth_token}"}

        response = requests.request(
            "GET",
            codebeamer_url,
            headers=headers,
            data={},
            params=params,
            timeout=60,
            verify=False,
        )
        if response.status_code != 200:
            logging.error(
                f"Issue fetching items from codebeamer, response code {response.status_code} {response.text}"
            )
            raise HTTPException(
                status_code=500,
                detail=f"Issue fetching data from codebeamer, response code {response.status_code}",
            )

        res = json.loads(response.text)
        items = res.get("items", "")
        if items and len(items) > 0:
            tracker_items.extend(items)
            page_number += 1
        else:
            break
    return tracker_items


#check for images in item description and download them locally and update the description with local path of the image


def save_tracker_items_as_excel(
    auth_token: str,
    codebeamer_url: str,
    codebeamer_project: str,
    codebeamer_tracker: str,
    tracker_uid: str,
) -> str:
    """Method to save specific tracker items for a project as an excel file.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer project api.
        codebeamer_project (str): Name of the codebeamer project.
        codebeamer_tracker (str): Name of the tracker.
        tracker_uid (str): Unique identifier for the tracker

    Retuens:
        Excel file path.
    """
    req_objects = get_items_by_project(
        auth_token, codebeamer_url, codebeamer_project, codebeamer_tracker
    )
    if req_objects and len(req_objects) > 0:
        pass
    else:
        logging.error(f"No tracker items available:")
        raise HTTPException(
            status_code=500,
            detail=f"No requirements available in: {codebeamer_tracker}",
        )
    reqs = [item["description"] for item in req_objects]
    ids = []
    for item in req_objects:
        custom_fields = item.get("customFields", [])
        id_field = next(
            (f["value"] for f in custom_fields if f.get("name").lower() == tracker_uid.lower()),
            None,
        )
        value = id_field if id_field is not None else item.get("id")
        if isinstance(value, str):
            value = clean_tracker_id_value(value)
        ids.append(value)
    df = pd.DataFrame({"ID": ids, "Requirement": reqs})
    file_name = codebeamer_tracker + ".xlsx"
    local_temp_path_cb = os.path.join("data", file_name)
    os.makedirs(os.path.dirname(local_temp_path_cb), exist_ok=True)
    df.to_excel(local_temp_path_cb, index=False)
    return local_temp_path_cb


def get_item_by_id(auth_token: str, codebeamer_url: str, item_id: int):
    """Method to fetch tracker item from codebeamer based on item id.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer project api.
        codebeamer_project (str): Name of the codebeamer project.
        item_id (int): ID of the item to be fetched.

    Returns:
        Response: Object of the item from codebeamer.
    """
    endpoint = f"/v3/items/{item_id}"
    codebeamer_url += endpoint
    # Set header for token based auth
    headers = {"Authorization": f"Bearer {auth_token}"}
    response = requests.request("GET", codebeamer_url, headers=headers, timeout=60, verify=False)
    if response.status_code == 200:
        response = json.loads(response.text)
        return response
    else:
        logging.error = f"Issue fetching data from codebeamer, response code {response.status_code}"
        raise Exception(
            f"Issue fetching data from codebeamer, response code {response.status_code}"
        )


def update_item_by_id(auth_token: str, codebeamer_url: str, item):
    """Method to update a tracker item by id.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer project api.
        tracker_item (object): Tracker item json from codebeamer.

    Returns:
        Response: Response object.
    """
    endpoint = f"/v3/items/{item['id']}/"
    codebeamer_url += endpoint

    # Set header for token based auth
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {auth_token}",
    }

    # Create payload for request body
    res = json.dumps(item)

    response = requests.request(
        "PUT", codebeamer_url, headers=headers, data=res, timeout=60, verify=False
    )
    if response.status_code == 200:
        return response
    else:
        logging.error = f"Issue fetching data from codebeamer, response code {response.status_code}"
        raise Exception(f"Issue updATING codebeamer, response code {response.status_code}")


def get_all_projects(
    auth_token: str,
    codebeamer_url: str,
):
    """Method to get all projects from codebeamer.

    Parameters
    ----------
    auth_token : str
        Authentication token.
    codebeamer_url : str
        URL of the codebeamer project api.
    """
    endpoint = "/v3/projects"
    codebeamer_url += endpoint
    projects = []
    # Set header for token based auth
    headers = {"Authorization": f"Bearer {auth_token}"}
    # query = {"email": email}
    # if agent_id:
    #     query["agent_id"] = agent_id
    try:
        response = requests.request(
            "GET", codebeamer_url, headers=headers, timeout=60, verify=False
        )
        if response.status_code == 200:
            response = json.loads(response.text)
            if len(response) == 0:
                raise HTTPException(status_code=404, detail="No projects available.")
            projects.extend(response)
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Issue fetching data from codebeamer {response.text}",
            )
    except Exception as e:
        logging.error(f"Failed to send request to codebeamer: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to send request to codebeamer: {e}")
    return projects


def get_trackers_by_project_id(auth_token: str, codebeamer_url: str, project_id: int):
    """Get tracker by project id.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer instance.
        project_id (int): Project ID to get trackers for.
    """
    endpoint = f"/v3/projects/{project_id}/trackers"
    codebeamer_url += endpoint
    trackers = []
    # Set header for token based auth
    headers = {"Authorization": f"Bearer {auth_token}"}
    try:
        response = requests.request(
            "GET", codebeamer_url, headers=headers, timeout=60, verify=False
        )
        if response.status_code == 200:
            res = json.loads(response.text)
            if len(res) == 0:
                raise HTTPException(status_code=404, detail="No trackers available.")
            trackers.extend(res)
    except Exception as e:
        logging.error(f"Failed to send request to codebeamer: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to send request to codebeamer: {e}")
    return trackers



class CodeBeamerDelta:
    @classmethod
    def process(cls, token, tracker_items, codebeamer_url, tracker_name):
        tempfolder = tempfile.mkdtemp()
        output_file = os.path.join(tempfolder, "structured.json")
        try:
            def extract_fields(obj):
                desc = obj.get("description", "")
                if '{Image wiki=' in desc:
                    try:
                        image_part = desc.split("{Image wiki='")[1].split("'")[0]
                        image_filename = image_part.split('[!')[1].split(']')[0].split('#')[0]
                        image_id = next(c['id'] for c in obj['comments'] if c['name'] == image_filename)
                        image_path = f"images/{obj.get('id')}/" + f"{image_id}_{image_filename}" if image_filename else None
                    except (IndexError, AttributeError, StopIteration):
                        image_filename = None
                        image_path = None
                    return {
                        "id": obj.get("id"),
                        "name": obj.get("name"),
                        "text": desc,
                        "img_path": image_path,
                        "image_filename": image_filename,
                        "type": "image",
                        "parent": obj.get("parent"),
                        "comments": obj.get("comments")
                    }
                else:
                    return {
                        "id": obj.get("id"),
                        "name": obj.get("name"),
                        "text": obj.get("name") if obj.get("name") else desc,
                        "type": "text",
                        "parent": obj.get("parent"),
                        "comments": obj.get("comments")
                    }

            def load_and_clean_json(data):
                if isinstance(data, list):
                    cleaned = [extract_fields(item) for item in data]
                elif isinstance(data, dict):
                    cleaned = [extract_fields(item) for item in data.get("items", [])]
                else:
                    cleaned = [extract_fields(data)]
                image_ids = [item["id"] for item in cleaned if item.get("img_path")]
                return cleaned, image_ids

            def save_json(data, output_file):
                with open(output_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)

            def fetch_attachments_content(ids, mime_types=None, token=None):
                url = f"{codebeamer_url}/api/v3/items/attachments/content"
                headers = {
                    "accept": "application/zip",
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token}"
                }
                payload = {
                    "items": [{"id": i} for i in ids],
                    "mimeTypes": mime_types or ["image/png", "application/zip"]
                }
                response = requests.post(url, headers=headers, json=payload, stream=True, timeout=60)
                response.raise_for_status()
                return response.content

            def batch_fetch_and_extract(image_ids, image_folder, batch_size=100):
                batches = (image_ids[i:i+batch_size] for i in range(0, len(image_ids), batch_size))
                def process_batch(batch):
                    content = fetch_attachments_content(batch, token=token)
                    with zipfile.ZipFile(io.BytesIO(content)) as zip_ref:
                        zip_ref.extractall(image_folder)
                with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                    list(executor.map(process_batch, batches))

            def get_valid_image_paths(cleaned_data, tempfolder):
                valid_paths = set()
                for item in cleaned_data:
                    image_path = item.get("img_path")
                    image_filename = item.get("image_filename")
                    if image_path and image_filename:
                        dir_path = os.path.join(tempfolder, os.path.dirname(image_path))
                        if os.path.exists(dir_path):
                            for fname in os.listdir(dir_path):
                                if fname.endswith(image_filename):
                                    valid_paths.add(os.path.abspath(os.path.join(dir_path, fname)))
                return valid_paths

            def cleanup_images(image_folder, valid_image_paths):
                for root, _, files in os.walk(image_folder):
                    for filename in files:
                        file_path = os.path.abspath(os.path.join(root, filename))
                        if file_path not in valid_image_paths:
                            os.remove(file_path)

            cleaned, image_ids = load_and_clean_json(tracker_items)
            save_json(cleaned, output_file)

            image_folder = os.path.join(tempfolder, "images")
            os.makedirs(image_folder, exist_ok=True)

            if image_ids:
                batch_fetch_and_extract(image_ids, image_folder, batch_size=100)

            with open(output_file, "r", encoding="utf-8") as f:
                cleaned_data = json.load(f)

            valid_image_paths = get_valid_image_paths(cleaned_data, tempfolder)
            cleanup_images(image_folder, valid_image_paths)
            print("#### tracker name in delta comparator", tracker_name)
            zip_output = os.path.join(tempfolder, f"{tracker_name}.zip")
            with zipfile.ZipFile(zip_output, "w", zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(tempfolder):
                    for file in files:
                        if file.endswith(".zip"):
                            continue
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, tempfolder)
                        zipf.write(file_path, arcname)
            return 200, zip_output
        except Exception as e:
            logging.error(f"Error processing tracker items: {e}")
            return 500, str(e)

def get_tracker_data(
    auth_token: str,
    codebeamer_url: str,
    codebeamer_project: str,
    codebeamer_tracker: str,
) -> requests.Response:
    """Method to fetch tracker items from codebeamer based on project name and tracker name.

    Args:
        auth_token (str): Authentication token.
        codebeamer_url (str): URL of the codebeamer project api.
        codebeamer_project (str): Name of the codebeamer project.
        codebeamer_tracker (str): Name of the codebeamer tracker.
    Returns:
        requests.Response: Object of paginated tracker items from codebeamer.
    """
    endpoint = "/v3/items/query"
    codebeamer_url += endpoint
    tracker_items = []
    page_number = 1

    try:
        while True:
            params = {
                "queryString": f"project.name IN ('{codebeamer_project}') and \
                    tracker.name IN ('{codebeamer_tracker}') ORDER BY item.id ASC",
                "page": page_number,
                "pageSize": 500,
            }

            headers = {"Authorization": f"Bearer {auth_token}"}

            response = requests.request(
                "GET",
                codebeamer_url,
                headers=headers,
                data={},
                params=params,
                timeout=60,
                verify=False,
            )
            if response.status_code != 200:
                logging.error(
                    f"Issue fetching items from codebeamer, response code {response.status_code} {response.text}"
                )
                raise HTTPException(
                    status_code=500,
                    detail=f"Issue fetching data from codebeamer, response code {response.status_code}",
                )

            res = json.loads(response.text)
            items = res.get("items", "")
            if items and len(items) > 0:
                tracker_items.extend(items)
                page_number += 1
            else:
                break

        return CodeBeamerDelta.process(token=auth_token, tracker_items=tracker_items, codebeamer_url=codebeamer_url.replace(endpoint, ""),tracker_name=codebeamer_tracker)
    except Exception as e:
        logging.error(f"Error fetching tracker items: {e}")
        raise HTTPException(status_code=500, detail=f"Error fetching tracker items: {e}")