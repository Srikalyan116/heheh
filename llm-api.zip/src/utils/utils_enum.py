"""This module contains enumeration classes for various constants used in the application.

Enumerations:
    FileType: Enum for supported file types.
    TaskStatus: Enum for task statuses.
    RequestType: Enum for request types.
    TaskError: Enum for task-related error messages.
"""

from enum import Enum


class FileType(Enum):
    """Enum for supported file types."""

    CSV = ".csv"
    EXCEL = ".xlsx"
    JSON = ".json"


class TaskStatus(Enum):
    """Enum for task statuses."""

    CREATED = "CREATED"
    PROCESSING = "PROCESSING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    TASK_STARTED = "PROCESS STARTED"
    TASK_NOT_STARTED = "PROCESS NOT STARTED"
    TASK_RESTARTED = "PROCESS RESTARTED"
    QUEUED = "QUEUED"
    DELETED = "DELETED"


class RequestType(Enum):
    """Enum for request types."""

    MANUAL = "MANUAL"
    CODEBEAMER = "CODEBEAMER"


class SearchType(Enum):
    """Search type for document retriever."""

    TEXT_SEARCH = "TEXT_SEARCH"
    FILE_UPLOAD = "FILE_UPLOAD"


class TaskTypes(Enum):
    """Types of Tasks."""

    SEARCH = "SEARCH"
    UPLOAD_FILE = "UPLOAD_FILE"
    DELETE_FILE = "DELETE_FILE"
    CREATE_PROJECT = "CREATE_PROJECT"
    UPDATE_FILE = "UPDATE_FILE"
    DELETE_PROJECT = "DELETE_PROJECT"


class TaskError(Enum):
    """Enum for task-related error messages."""

    NOT_FOUND = "Task not found"
    MISSING_FILENAME = "Filename is missing in the task."
    BLOB_DOWNLOAD_FAIL = "Failed to download blob: "


class CodebeamerTaskType(Enum):
    """Enum for task type in codebeamer."""

    INFORMATION = {"id": 14, "text": "Information"}

    REQUIREMENT = {"id": 4, "text": "Technical Requirement (FR | NFR)"}

    FUNCTIONAL_REQUIREMENT = {"id": 2, "name": "Functional Requirement (FR)"}

    NON_FUNCTIONAL_REQUIREMENT = {"id": 3, "name": "Non Functional Requirement (NFR)"}

    HEADLINE = {"id": 1, "name": "Headline"}

    PROCESS_REQUIREMENT = {"id": 5, "name": "Process Requirement (NFR)"}

    MODULE = {"id": 6, "name": "Module", "type": "ChoiceOptionReference"}


class APIMessages(Enum):
    """Enum for API Messages."""

    UNSUPPORTED_ERROR_MESSAGE = "Unsupported file type. Only CSV and Excel files are allowed."
    PDF_PAGE_ERROR_MSG = "enter valid start page and end page for pdf parsing"
    STATUS_ERROR_MESSAGE = "Failed to upload file"
    TASK_SUBMITTED_MSG = "Task submitted successfully"
