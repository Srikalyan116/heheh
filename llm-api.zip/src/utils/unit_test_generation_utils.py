import os
import asyncio
import zipfile
import requests
import json
import shutil
from datetime import datetime, timezone
from dotenv import load_dotenv
from enum import Enum
from typing import List, Optional, Dict
from urllib.parse import urlparse
from pathlib import Path

from fastapi import HTTPException
from pymongo.collection import Collection

from src.utils.mongo_db import MongoDB
from src.utils.common.db_helper import TaskManager
from src.config.config import unit_test_generation_config
from src.rabbitMQ_manager import RabbitMQManager
from src.utils.common.logger import log as logging, trace_id_ctx, span_id_ctx, parent_span_id_ctx
from src.utils.utils_enum import RequestType, TaskError, TaskStatus

load_dotenv()

# Stages as Enumeration
class Stage(str, Enum):
    CLONE = "CLONE"
    CONTEXT = "CONTEXT"
    UNIT_TEST = "UNIT_TEST"

# Basic helpers

def extract_repo_name(repo_url: str) -> str:
    repo = repo_url.rstrip("/").split("/")[-1]
    return repo.replace(".git", "")


def short_hash(full_hash: str, length: int = 12) -> str:
    return full_hash[:length]


def normalize_commit_hash(commit_hash: str) -> str:
    return short_hash(commit_hash)


def get_headers(token: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        # "Accept": "application/json",
        "Content-Type": "application/json"
    }

def normalize_list_field(value):
    """
    Converts:
        ["A, B, C"]  -> ["A", "B", "C"]
        ["A"]        -> ["A"]
    """
    if not value:
        return []

    result = []
    for item in value:
        if item:
            if "," in item:
                parts = [x.strip() for x in item.split(",") if x.strip() and x]
                result.extend(parts)
            else:
                result.append(item.strip())
    return result


def raise_for_ado_http_error(response: requests.Response, action: str) -> None:
    """Raise API-friendly exceptions for common Azure DevOps HTTP failures."""
    status_code = response.status_code

    if status_code in (200, 203):
        return

    if status_code == 401:
        raise HTTPException(
            status_code=401,
            detail=f"Authentication failed while {action}. Please provide a valid Azure DevOps token.",
        )

    if status_code == 403:
        raise HTTPException(
            status_code=403,
            detail=f"Permission denied while {action}. Token does not have required access.",
        )

    if status_code == 404:
        raise HTTPException(
            status_code=404,
            detail=f"Requested resource not found while {action}.",
        )

    raise HTTPException(
        status_code=400,
        detail=f"Azure DevOps API failed while {action} ({status_code}): {response.text}",
    )

# Azure DevOps helpers

def extract_ado_repo_info(repo_url: str) -> Dict[str, str]:
    """
    Extract org, project, repo_name from a standard Azure DevOps git URL.

    Example:
    https://dev.azure.com/{org}/{project}/_git/{repo}
    """
    parsed = urlparse(repo_url)

    if parsed.netloc != "dev.azure.com":
        raise ValueError(f"Not a valid Azure DevOps URL: {repo_url}")

    parts = parsed.path.strip("/").split("/")

    if len(parts) < 4 or parts[2] != "_git":
        raise ValueError(
            "Invalid Azure DevOps repo URL format. "
            "Expected: https://dev.azure.com/{org}/{project}/_git/{repo}"
        )

    return {
        "org": parts[0],
        "project": parts[1],
        "repo_name": parts[3],
        "repo_url": repo_url,
    }


def validate_ado_path_exists(
    *,
    repo_url: str,
    branch: str,
    path: str,
    token: str,
):
    """
    Verifies that a given path exists and is a folder in ADO.
    """
    info = extract_ado_repo_info(repo_url)

    api_url = (
        f"https://dev.azure.com/{info['org']}/{info['project']}"
        f"/_apis/git/repositories/{info['repo_name']}/items"
    )

    params = {
        "path": path if path.startswith("/") else f"/{path}",
        "versionDescriptor.versionType": "branch",
        "versionDescriptor.version": branch,
        "api-version": "7.0",
    }

    response = requests.get(api_url, params=params, headers=get_headers(token))

    raise_for_ado_http_error(
        response,
        f"validating component_dir '{path}' in branch '{branch}'",
    )

    try:
        data = response.json()
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid response while validating component_dir '{path}'"
        )

    # ADO returns single item for path query
    if not data or not data.get("isFolder", False):
        raise HTTPException(
            status_code=400,
            detail=f"component_dir '{path}' exists but is not a folder"
        )


# Azure DevOps REST: latest commit
async def get_latest_commit_hash(
    repo_url: str,
    branch: str,
    token: str,
) -> str:
    """
    Get latest commit hash for a branch using Azure DevOps REST API.
    """
    info = extract_ado_repo_info(repo_url)

    api_url = (
        f"https://dev.azure.com/{info['org']}/{info['project']}"
        f"/_apis/git/repositories/{info['repo_name']}/refs"
    )

    params = {
        "filter": f"heads/{branch}",
        "api-version": "7.0",
    }

    def _fetch():
        resp = requests.get(api_url, headers=get_headers(token), params=params)
        raise_for_ado_http_error(resp, f"fetching branch refs for '{branch}'")

        data = resp.json().get("value", [])
        if not data:
            raise ValueError(f"Branch '{branch}' not found")

        return data[0]["objectId"]

    return await asyncio.to_thread(_fetch)


# Azure DevOps REST: list folders

def list_folders_ado(
    repo_url: str,
    branch: str,
    path: str,
    token: str,
) -> List[str]:
    info = extract_ado_repo_info(repo_url)

    folders = []
    api_url = (
        f"https://{token}@dev.azure.com/{info['org']}/{info['project']}"
        f"/_apis/git/repositories/{info['repo_name']}/items"
    )
    # logging.info(api_url)
    params = {
        "scopePath": path if path.startswith("/") else f"/{path}",
        "recursionLevel": "OneLevel",
        "versionDescriptor.versionType": "branch",
        "versionDescriptor.version": branch,
        "includeContentMetadata": "true",
        "api-version": "7.0",
    }
    parent_folder = Path(path).name
    try:
        response = requests.get(
            api_url,
            headers=get_headers(token),
            params=params,
        )
    except Exception as ex:
        logging.error(f"Failed fetching details {ex}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch component list from Azure DevOps: {str(ex)}")

    raise_for_ado_http_error(response, f"listing components in path '{path}' for branch '{branch}'")

    if not response.text.strip():
        raise HTTPException(status_code=400, detail="Azure DevOps API returned empty response")

    data = response.json()

    folders = [
        item["path"].split("/")[-1]
        for item in data.get("value", [])
        if item.get("isFolder")
    ]

    if parent_folder in folders:
        folders.remove(parent_folder)
    
    return folders


def validate_clone_request_inputs(
    *,
    repo_url: str,
    branch: str,
    component_dir: str | None,
    component_names: list[str] | None,
    token: str,
    run_all: bool | None,
    destination: str | None,
):
    # ---- repo_url ----
    parsed = urlparse(repo_url.strip())
    if parsed.scheme not in {"http", "https"}:
        raise HTTPException(
            status_code=400,
            detail="repo_url must be a valid HTTP/HTTPS URL"
        )

    if "dev.azure.com" not in parsed.netloc:
        raise HTTPException(
            status_code=400,
            detail="repo_url must be a valid Azure DevOps repository URL"
        )

    # ---- branch ----
    branch = branch.strip()
    if not branch:
        raise HTTPException(
            status_code=400,
            detail="branch cannot be empty"
        )

    if " " in branch:
        raise HTTPException(
            status_code=400,
            detail="branch must not contain spaces"
        )

    # ---- component_dir ----
    if component_dir is not None:
        component_dir = component_dir.strip()
        if not component_dir:
            raise HTTPException(
                status_code=400,
                detail="component_dir cannot be an empty string"
            )

        # ---- Validate component_dir exists in repo ----
        validate_ado_path_exists(
            repo_url=repo_url,
            branch=branch,
            path=component_dir,
            token=token,
        )

    # ---- component_names vs run_all ----
    given_component_names = normalize_list_field(component_names)

    available_components = list_folders_ado(repo_url, branch, component_dir, token)

    for component in given_component_names:
        if available_components:
            if component not in available_components:
                raise HTTPException(
                    status_code=400,
                    detail=f"Given component '{component}' not found in component path {component_dir}. Please, validate and try again."
                )

    # validate given component names against available components

    if run_all and given_component_names:
        raise HTTPException(
            status_code=400,
            detail="Provide either component_names OR set run_all=True, not both"
        )

    if not run_all and not given_component_names:
        raise HTTPException(
            status_code=400,
            detail="Either component_names must be provided or run_all flag must be True"
        )

def validate_context_request_inputs(
    *,
    clone_dir: str,
    component_dir: str | None,
    component_names: list[str] | None,
    run_all: bool | None,
):
    
    if not clone_dir:
        raise HTTPException(
            status_code=400,
            detail="clone_dir cannot be an empty string"
        )
    
    if component_dir is not None:
        component_dir = component_dir.strip()
        if not component_dir:
            raise HTTPException(
                status_code=400,
                detail="component_dir cannot be an empty string"
            )

        available_components = []

        final_component_dir = os.path.join(clone_dir, component_dir)

        if os.path.exists(final_component_dir) and os.path.isdir(final_component_dir):
            available_components = os.listdir(final_component_dir)
    
    # ---- component_names vs run_all ----
    given_component_names = normalize_list_field(component_names)

    for component in given_component_names:
        if available_components:
            if component not in available_components:
                raise HTTPException(
                    status_code=400,
                    detail=f"Given component '{component}' not found in component path {component_dir}. Please, validate and try again."
            )

    # validate given component names against available components

    if run_all and given_component_names:
        raise HTTPException(
            status_code=400,
            detail="Provide either component_names OR set run_all=True, not both"
        )

    if not run_all and not given_component_names:
        raise HTTPException(
            status_code=400,
            detail="Either component_names must be provided or run_all flag must be True"
        )

def validate_unit_test_request_inputs(
    *,
    context_dir: str,
    component_names: list[str] | None,
    run_all: bool | None,
):
    if not context_dir:
        raise HTTPException(
            status_code=400,
            detail="context_dir cannot be an empty string"
        )
    
    available_components = None
    source_context_json_path = os.path.join(context_dir, 'source_context_info.json')
    if os.path.exists(source_context_json_path):
        with open(source_context_json_path, 'r') as f:
            content = json.load(f)
        available_components = list(content.keys())
    given_component_names = normalize_list_field(component_names)

    for component in given_component_names:
        if available_components:
            if component not in available_components:
                raise HTTPException(
                    status_code=400,
                    detail=f"Given component '{component}' not found or context is missing. Please, validate and try again from clone/Context API."
                )
            
    if run_all and given_component_names:
        raise HTTPException(
            status_code=400,
            detail="Provide either component_names OR set run_all=True, not both"
        )

    if not run_all and not given_component_names:
        raise HTTPException(
            status_code=400,
            detail="Either component_names must be provided or run_all flag must be True"
        )
    
def validate_build_folder_download_request_inputs(
    *,
    build_folder_path: str,
    component_names: list[str] | None,
    run_all: bool | None
):
    """Validate inputs for build folder download and components.
    Validations:
    - unzip the build folder and 
    - look for source_context_info.json to get available components for validation
    - validate that the given component names exist in the available components"""

    def _extract_zip_with_normalized_paths(zip_ref: zipfile.ZipFile, extract_root: str) -> None:
        """Extract zip members while normalizing Windows-style path separators."""
        extract_root_abs = os.path.abspath(extract_root)

        for member in zip_ref.infolist():
            normalized_name = member.filename.replace("\\", "/").lstrip("/")
            if not normalized_name:
                continue

            target_path = os.path.abspath(os.path.join(extract_root_abs, *normalized_name.split("/")))

            # Guard against zip-slip path traversal.
            if os.path.commonpath([extract_root_abs, target_path]) != extract_root_abs:
                raise HTTPException(status_code=400, detail="Invalid file path in zip archive")

            if member.is_dir() or normalized_name.endswith("/"):
                os.makedirs(target_path, exist_ok=True)
                continue

            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            with zip_ref.open(member, "r") as source, open(target_path, "wb") as target:
                shutil.copyfileobj(source, target)

    if not build_folder_path:
        raise HTTPException(
            status_code=400,
            detail="build_folder_path cannot be an empty string"
        )
    
    if not os.path.exists(build_folder_path):
        raise HTTPException(
            status_code=400,
            detail=f"build_folder_path '{build_folder_path}' does not exist"
        )
    
    if run_all and component_names:
        raise HTTPException(
            status_code=400,
            detail="Provide either component_names OR set run_all=True, not both"
        )

    if not run_all and not component_names:
        raise HTTPException(
            status_code=400,
            detail="Either component_names must be provided or run_all flag must be True"
        )

    available_components = []
    
    # unzip the build folder if it's a zip file
    if build_folder_path.endswith(".zip"):
        with zipfile.ZipFile(build_folder_path, 'r') as zip_ref:
            extract_path = build_folder_path[:-4]
            _extract_zip_with_normalized_paths(zip_ref, extract_path)
            build_folder_path = extract_path
    else:
        raise HTTPException(
            status_code=400,
            detail=f"build_folder_path '{build_folder_path}' is not a zip file"
        )
    
    # walk through the directory to find source_context_info.json and get available components
    source_context_json_path = None
    for root, dirs, files in os.walk(build_folder_path):
        if 'source_context_info.json' in files:
            source_context_json_path = os.path.join(root, 'source_context_info.json')
            with open(source_context_json_path, 'r') as f:
                content = json.load(f)
            available_components = list(content.keys())
            break

    if not available_components:
        raise HTTPException(
            status_code=400,
            detail=f"No components found in the source_context_info.json. Cannot proceed."
        )
    print(available_components)
    given_component_names = normalize_list_field(component_names)

    for component in given_component_names:
        present_in_available = False
        if available_components:
            for available_component in available_components:
                if available_component.lower() == component.lower():
                    present_in_available = True
                    break
            if not present_in_available:
                raise HTTPException(
                    status_code=400,
                    detail=f"Given component '{component}' not found or context is missing. Please, validate and try again."
                )
        else:
            raise HTTPException(
                status_code=400,
                detail=f"No components found in the build folder for validation. Please, validate and try again."
            )
        
    if source_context_json_path:
        return str(Path(source_context_json_path).parent)
    else:
        return None
    
def validate_coverage_report_request_inputs(
    *,
    previous_unit_test_results_path: str,
    build_folder_path: str,
    coverage_report_path: str,
    task_processed_folder: str,
    old_component_names: list[str] | str,
    given_component_name: str
):
    """Validate inputs for previous results, build folder and coverage report paths.
    Validations:
    - unzip the previous unit test results zip file
    - validate that html coverage report exists in the given coverage_report_path
    - unzip the build folder and 
    - look for source_context_info.json inside the build folder
    - look for source_context_info.json inside the unit test results folder
    - no validation of available components"""

    def _extract_zip_with_normalized_paths(zip_ref: zipfile.ZipFile, extract_root: str) -> None:
        """Extract zip members while normalizing Windows-style path separators."""
        extract_root_abs = os.path.abspath(extract_root)

        for member in zip_ref.infolist():
            normalized_name = member.filename.replace("\\", "/").lstrip("/")
            if not normalized_name:
                continue

            target_path = os.path.abspath(os.path.join(extract_root_abs, *normalized_name.split("/")))

            # Guard against zip-slip path traversal.
            if os.path.commonpath([extract_root_abs, target_path]) != extract_root_abs:
                raise HTTPException(status_code=400, detail="Invalid file path in zip archive")

            if member.is_dir() or normalized_name.endswith("/"):
                os.makedirs(target_path, exist_ok=True)
                continue

            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            with zip_ref.open(member, "r") as source, open(target_path, "wb") as target:
                shutil.copyfileobj(source, target)

    if not previous_unit_test_results_path:
        raise HTTPException(
            status_code=400,
            detail="previous_unit_test_results_path cannot be an empty string"
        )
    
    if not os.path.exists(previous_unit_test_results_path):
        raise HTTPException(
            status_code=400,
            detail=f"Previous unit test results path '{previous_unit_test_results_path}' does not exist"
        )

    if not build_folder_path:
        raise HTTPException(
            status_code=400,
            detail="build_folder_path cannot be an empty string"
        )
    
    if not os.path.exists(build_folder_path):
        raise HTTPException(
            status_code=400,
            detail=f"build_folder_path '{build_folder_path}' does not exist"
        )
    
    if not coverage_report_path:
        raise HTTPException(
            status_code=400,
            detail="coverage_report_path cannot be an empty string"
        )
    
    if not os.path.exists(coverage_report_path):
        raise HTTPException(
            status_code=400,
            detail=f"coverage_report_path '{coverage_report_path}' does not exist"
        )
    
    if given_component_name not in old_component_names:
        raise HTTPException(
            status_code=400,
            detail=f"Given component '{given_component_name}' not found in the previous unit test results. Please, validate and try again."
        )
    
    # unzip the build folder if it's a zip file
    if build_folder_path.endswith(".zip"):
        with zipfile.ZipFile(build_folder_path, 'r') as zip_ref:
            extract_path = build_folder_path[:-4]
            _extract_zip_with_normalized_paths(zip_ref, extract_path)
            build_folder_path = extract_path
    else:
        raise HTTPException(
            status_code=400,
            detail=f"build_folder_path '{build_folder_path}' is not a zip file"
        )
    
    if not coverage_report_path.endswith(".html"):
        raise HTTPException(
            status_code=400,
            detail=f"coverage_report_path '{coverage_report_path}' is not an HTML file"
        )
    
    # unzip the previous unit test results if it's a zip file
    if previous_unit_test_results_path.endswith(".zip"):
        with zipfile.ZipFile(previous_unit_test_results_path, 'r') as zip_ref:
            extract_path = previous_unit_test_results_path[:-4]
            _extract_zip_with_normalized_paths(zip_ref, extract_path)
            previous_unit_test_results_path = extract_path
    else:
        raise HTTPException(
            status_code=400,
            detail=f"previous_unit_test_results_path '{previous_unit_test_results_path}' is not a zip file"
        )
    
    # walk through the build folder to find source_context_info.json and get available components
    build_context_source_context_json_path = None
    for root, dirs, files in os.walk(build_folder_path):
        if 'source_context_info.json' in files:
            build_context_source_context_json_path = os.path.join(root, 'source_context_info.json')
            break

    # walk through the previous unit test results folder to find sources_tst_info.json
    previous_unit_test_results_json_path = None
    for root, dirs, files in os.walk(previous_unit_test_results_path):
        if 'sources_tst_info.json' in files:
            previous_unit_test_results_json_path = os.path.join(root, 'sources_tst_info.json')
            break

    if not build_context_source_context_json_path:
        raise HTTPException(
            status_code=400,
            detail=f"No source_context_info.json found in the downloaded build folder. Cannot proceed."
        )

    if not previous_unit_test_results_json_path:
        raise HTTPException(
            status_code=400,
            detail=f"No sources_tst_info.json found in the previous unit test results. Cannot proceed."
        )

    # copy the contents of previous unit test results into processed folder
    shutil.copytree(str(Path(previous_unit_test_results_json_path).parent), task_processed_folder, dirs_exist_ok=True)

    if not os.path.exists(os.path.join(task_processed_folder, 'sources_tst_info.json')):
        raise HTTPException(
            status_code=400,
            detail=f"Failed to copy previous unit test results to processed folder. Cannot proceed."
        )
    
    if build_context_source_context_json_path and previous_unit_test_results_json_path:
        return str(Path(build_context_source_context_json_path).parent), task_processed_folder
    else:
        return None, None
    

async def bypass_unit_test_generation(
    *,
    repo_url: str,
    branch: str,
    component_dir: str | None,
    component_names: list[str] | None,
    access_token: str,
    email: str,
    destination: str | None,
    vector_cast_version: str | None,
    llm_refinements: int | None,
    pipeline: bool,
    force_retry: bool,
    collection_name: str,
    rabbitmq: RabbitMQManager,
) -> dict | None:
    """
    If unit-test results already exist, create a SUCCESS task,
    publish it, and return the response payload.
    Returns None if no existing results found.
    """
    try:

        logging.info(f"Checking existing task results")
        repo_metadata_manager = RepoMetadataManager()
        normalized_components = normalize_list_field(component_names)

        lookup = await repo_metadata_manager.get_record(
            repo_url,
            branch,
            normalized_components,
            llm_refinements,
            access_token,
        )
        print(lookup)
        if not lookup or lookup.get("status") != "EXISTS":
            logging.info(f"No records found for given repo details {repo_url}, {branch}. Proceeding with unit test generation.")
            return None

        data = lookup.get("data")
        if not data:
            logging.info(f"No records found for given repo details '{repo_url}', '{branch}' and '{normalized_components}'. Proceeding with unit test generation.")
            return None

        repo_name = data["repo_name"]
        branch = data["branch"]
        latest_commit = data["latest_commit"]
        storage_path = data.get("storage_path")

        task_data = {
            "email": email,
            "repo_url": repo_url,
            "branch": branch,
            "latest_commit": latest_commit,
            "component_dir": component_dir,
            "component_names": normalize_list_field(data.get("component_names")),
            "vector_cast_version": vector_cast_version,
            "storage_path": storage_path,
            "destination": destination,
            "pipeline": pipeline,
            "force_retry": force_retry,
            "llm_refinements": llm_refinements,
            "pipeline_stage": Stage.UNIT_TEST,
            "status": TaskStatus.SUCCESS.value,
            "overall_status": TaskStatus.PROCESSING.value,
            "status_update_message": None,
            "status_code": 102,
            "created_timestamp": datetime.now(timezone.utc),
            "lastupdated_timestamp": datetime.now(timezone.utc),
            "request_type": RequestType.MANUAL.value,
        }

        result = TaskManager.create_task(unit_test_generation_config, task_data)
        if not result:
            return None

        task_id = str(result.inserted_id)

        message = (
            f"Unit Test results for the {repo_name} repo, {branch} "
            f"and commit {latest_commit} already exist. "
            f"Use task_id {task_id} to download results. "
            f"Use force_retry=True to regenerate."
        )

        rabbitmq_payload = {
            "email": email,
            "task_id": task_id,
            "repo_url": repo_url,
            "repo_name": repo_name,
            "branch": branch,
            "latest_commit": latest_commit,
            "token": access_token,
            "component_dir": component_dir,
            "component_names": normalized_components,
            "vector_cast_version": vector_cast_version,
            "force_retry": force_retry,
            "llm_refinements": llm_refinements,
            "destination": destination,
            "pipeline_stage": Stage.UNIT_TEST,
            "pipeline": pipeline,
            "collection_name": collection_name,
            "status_code": 200,
            "status": TaskStatus.SUCCESS.value,
            "overall_status": TaskStatus.PROCESSING.value,
            "trace_id": trace_id_ctx.get(),
            "span_id": span_id_ctx.get(),
        }

        logging.info(f"Publishing task to Queue {unit_test_generation_config['queue_name']}")
        asyncio.create_task(
            rabbitmq.publish_task(unit_test_generation_config["queue_name"], rabbitmq_payload)
        )

        return {
            "success": True,
            "task_id": task_id,
            "message": message,
        }
    except Exception as ex:
        logging.error(f"Failed checking for existing unit tests. {ex}")


# MongoDB Repo Metadata Manager

def build_component_refinement_map(
    component_names: List[str],
    llm_refinement: int,
) -> Dict[str, List[int]]:
    """
    Convert API input into internal storage format:
    ["A", "B"], 3  ->  {"A": [1, 2, 3], "B": [1, 2, 3]}
    """
    return {component: list(range(1, llm_refinement + 1)) for component in component_names}


class RepoMetadataManager:
    """
    MongoDB manager for tracking unit test generation results per
    repo / branch / commit / component / llm refinement.
    """

    def __init__(
        self,
        collection_name: str = "unit_test_generation_results_tracking",
    ):
        self.collection: Collection = MongoDB.get_collection(collection_name)

    # GET RECORD
    async def get_record(
        self,
        repo_url: str,
        branch: str,
        component_names: Optional[List[str]] = None,
        llm_refinement: Optional[int] = None,
        token: Optional[str] = None,
        latest_commit: Optional[str] = None,
    ) -> Dict:

        repo_name = extract_repo_name(repo_url)

        if latest_commit:
            latest_commit = normalize_commit_hash(latest_commit)
        else:
            if not token:
                raise ValueError("SSO token is required when commit_hash is not provided")
            full_hash = await get_latest_commit_hash(repo_url, branch, token)
            latest_commit = normalize_commit_hash(full_hash)

        existing = await asyncio.to_thread(
            self.collection.find_one,
            {
                "repo_name": repo_name,
                "branch": branch,
                "latest_commit": {"$regex": f"^{latest_commit}"},
            },
        )

        if not existing:
            return {
                "status": "NOT_FOUND",
                "latest_commit": latest_commit,
                "data": None,
            }

        stored_components: Dict[str, List[int]] = existing.get("component_names", {})
        missing: Dict[str, List[int]] = {}

        if component_names and llm_refinement is not None:
            for component in component_names:
                stored_refs = set(stored_components.get(component, []))
                if llm_refinement not in stored_refs:
                    missing[component] = [llm_refinement]

        if missing:
            return {
                "status": "PARTIAL",
                "latest_commit": latest_commit,
                "missing_components": missing,
                "storage_path": existing.get("storage_path"),
                "data": existing,
            }

        return {
            "status": "EXISTS",
            "latest_commit": latest_commit,
            "storage_path": existing.get("storage_path"),
            "data": existing,
        }

    # CREATE OR UPDATE RECORD
    async def create_or_update_record(
        self,
        repo_url: str,
        branch: str,
        component_names: List[str],
        llm_refinement: int,
        storage_path: str,
        token: Optional[str] = None,
        latest_commit: Optional[str] = None,
    ) -> Dict:

        repo_name = extract_repo_name(repo_url)

        component_ref_map = build_component_refinement_map(
            component_names,
            llm_refinement,
        )

        lookup = await self.get_record(
            repo_url=repo_url,
            branch=branch,
            component_names=component_names,
            llm_refinement=llm_refinement,
            token=token,
            latest_commit=latest_commit,
        )

        latest_commit = lookup["latest_commit"]

        # ---------------- CREATE ----------------
        if lookup["status"] == "NOT_FOUND":
            doc = {
                "repo_name": repo_name,
                "branch": branch,
                "latest_commit": latest_commit,
                "component_names": component_ref_map,
                "storage_path": storage_path,
            }

            result = await asyncio.to_thread(self.collection.insert_one, doc)
            doc["_id"] = str(result.inserted_id)

            return {"status": "CREATED", "data": doc}

        # ---------------- PARTIAL UPDATE ----------------
        if lookup["status"] == "PARTIAL":
            await self.update_components(
                repo_url=repo_url,
                branch=branch,
                latest_commit=latest_commit,
                components=lookup["missing_components"],
            )

            return {
                "status": "UPDATED",
                "added_components": lookup["missing_components"],
                "storage_path": lookup["storage_path"],
            }

        return lookup

    # UPDATE COMPONENT REFINEMENTS
    async def update_components(
        self,
        repo_url: str,
        branch: str,
        latest_commit: str,
        components: Dict[str, List[int]],
    ) -> bool:

        repo_name = extract_repo_name(repo_url)
        latest_commit = short_hash(latest_commit)

        update_ops = {
            f"component_names.{component}": {"$each": refinements}
            for component, refinements in components.items()
        }

        result = await asyncio.to_thread(
            self.collection.update_one,
            {
                "repo_name": repo_name,
                "branch": branch,
                "latest_commit": {"$regex": f"^{latest_commit}"},
            },
            {"$addToSet": update_ops},
        )

        return result.modified_count > 0

    # UPDATE STORAGE PATH
    async def update_storage_path(
        self,
        repo_url: str,
        branch: str,
        latest_commit: str,
        new_storage_path: str,
    ) -> bool:

        repo_name = extract_repo_name(repo_url)
        latest_commit = short_hash(latest_commit)

        result = await asyncio.to_thread(
            self.collection.update_one,
            {
                "repo_name": repo_name,
                "branch": branch,
                "latest_commit": {"$regex": f"^{latest_commit}"},
            },
            {"$set": {"storage_path": new_storage_path}},
        )

        return result.modified_count > 0

    # DELETE RECORD
    async def delete_record(
        self,
        repo_url: str,
        branch: str,
        latest_commit: str,
    ) -> bool:

        repo_name = extract_repo_name(repo_url)
        latest_commit = short_hash(latest_commit)

        result = await asyncio.to_thread(
            self.collection.delete_one,
            {
                "repo_name": repo_name,
                "branch": branch,
                "latest_commit": {"$regex": f"^{latest_commit}"},
            },
        )

        return result.deleted_count > 0

    # FIND BY BRANCH
    async def find_by_branch(
        self,
        repo_url: str,
        branch: str,
    ) -> Optional[Dict]:

        repo_name = extract_repo_name(repo_url)

        return await asyncio.to_thread(
            self.collection.find_one,
            {"repo_name": repo_name, "branch": branch},
        )
