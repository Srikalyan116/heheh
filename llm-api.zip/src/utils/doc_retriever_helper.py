"""Preprocess and postprocess data."""

import os
from io import BytesIO

import pandas as pd

from src.config.config import document_retriever_config
from src.utils.mongo_db import MongoDB
from src.utils.utils_enum import FileType


def preprocess_input_file(file, id_col):
    """Preprocess input data.

    Args:
        file (_type_): input file
        id_col (_type_): ID column name

    Raises:
        TypeError: if file fileformat is not excel or csv

    Returns:
        file: processed file
    """
    file_extension = os.path.splitext(file.filename)[-1]
    if file_extension == FileType.CSV.value:
        file_dataframe = pd.read_csv(BytesIO(file.file.read()))
    elif file_extension == FileType.EXCEL.value:
        file_dataframe = pd.read_excel(BytesIO(file.file.read()))
    else:
        raise TypeError("File format is not supported, it must be csv or excel")
    file_dataframe.dropna(subset=[id_col], inplace=True)
    towrite = BytesIO()
    if file_extension == FileType.CSV.value:
        file_dataframe.to_csv(towrite)
    elif file_extension == FileType.EXCEL.value:
        file_dataframe.to_excel(towrite)
    # write to BytesIO buffer
    return towrite


def postprocess_result_file(data: pd.DataFrame, id_col, des_col):
    """Postprocess output Data.

    Args:
        data (pd.DataFrame): data
        id_col (_type_): ID column name
        des_col (_type_): description col name

    Returns:
        data: processed data
    """
    columns: list = data.columns.tolist()
    drop_col = [col for col in columns if col not in [id_col, des_col]]
    if any(data[des_col].astype("str") == "nan"):
        data.loc[data[des_col].astype("str") == "nan", drop_col] = ""
    return data


def get_project_by_user_id(project_name: str, user_id: str):
    """Get unique project details from mongodb based on project name and user id.

    Args:
        project_name (str): Name of the project
        user_id (str): User ID

    Returns:
        dict: metadata of the project
    """
    project_collection_name = document_retriever_config.get("project_manage_collection_name")
    project_collection = MongoDB.get_collection(project_collection_name)
    project = project_collection.find_one({"project_name": project_name, "admin.id": user_id})
    return project
