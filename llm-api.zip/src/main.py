"""Main module for the FastAPI application setup and routing."""

import os
import sys
from contextlib import asynccontextmanager
from fastapi import Request
from dotenv import load_dotenv
from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.controllers.agentic_controller import routeragentic
from src.controllers.case_test_generation_controller import routertestcase
from src.controllers.code_beamer_controller import router_code_beamer
from src.controllers.code_search_controller import routercodesearch
from src.controllers.design_requirement_controller import design_requirement_router
from src.controllers.document_retriever_controller import router as doc_router
from src.controllers.regulation_comparision_controller import routerreg
from src.controllers.requirement_classification_controller import router
from src.controllers.requirement_classification_generic_xmc import router as router_xmc
from src.controllers.requirement_classification_generic_pecos import router as router_pecos
from src.controllers.delta_comparator_controller import delta_router as delta_router

from src.controllers.requirement_comparision_tracer_controller import routertracer
from src.controllers.requirement_completeness_checker_controller import (
    req_completeness_router,
)
from src.controllers.test_coverage_controller import test_coverage_router
from src.controllers.incose_controller import router as incose_router
from src.controllers.iso_controller import router as iso_router
from src.controllers.comstack_controller import router as comstack_router
from src.controllers.unit_test_generation_controller import router as unit_test_gen_router
from src.controllers.artifacts_controller import artifacts_router

from src.rabbitMQ_manager import RabbitMQManager
from src.utils.auth import AuthValidation
from src.utils.documentation import readme_description
from src.utils.mongo_db import MongoDB
from src.utils.common.logger import log as logging
from src.utils.common.logger import set_job_context,set_trace_context_from_headers,clear_context
from prometheus_fastapi_instrumentator import Instrumentator
sys.path.append("../")



from src.utils.mongo_db import MongoDB


load_dotenv()


user_auth = AuthValidation()
rabbitmq = RabbitMQManager()

queue_names = os.getenv("RABBITMQ_QUEUE_NAMES").split(",")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manages the RabbitMQ lifecycle."""
    if not getattr(app.state, "rabbitmq_initialized", False):

        MongoDB.initialize()
        await rabbitmq.initialize()
        await rabbitmq.initialize_queues(queue_names)

        app.state.rabbitmq = rabbitmq
        app.state.rabbitmq_initialized = True

    yield

    # Cleanup (if needed)
    await app.state.rabbitmq.close_connection()


app = FastAPI(
    lifespan=lifespan,
    title="Gen AI for Software development",
    description=readme_description,
    version="0.0.1-Beta",
)
Instrumentator().instrument(app).expose(app, endpoint="/metrics")
app.include_router(artifacts_router)
app.include_router(incose_router)
app.include_router(iso_router)
app.include_router(delta_router)
app.include_router(router_xmc)
app.include_router(router_pecos)
app.include_router(router)
app.include_router(routerreg)
app.include_router(doc_router)
app.include_router(routertracer)
app.include_router(routertestcase)
app.include_router(routeragentic)
app.include_router(router_code_beamer)
app.include_router(routercodesearch)
app.include_router(req_completeness_router)
app.include_router(design_requirement_router)
app.include_router(test_coverage_router)
app.include_router(comstack_router)
app.include_router(unit_test_gen_router)

# Fetch the ORIGINS environment variable
origins_env = os.getenv("ORIGINS")

if origins_env is None:
    logging.error("The ORIGINS environment variable is not set.")
    # Here, you handle the case where ORIGINS is not set
    raise EnvironmentError("The ORIGINS environment variable is not set.")
else:
    # If ORIGINS is set, split and strip each origin URL
    origins = [origin.strip() for origin in origins_env.split(",")]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_trace_context(request: Request, call_next):
    set_trace_context_from_headers(request)
    response = await call_next(request)
    clear_context()
    return response
