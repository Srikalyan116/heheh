"""RabbitMQ Manager file."""

import json
import os

from src.utils.common.logger import log as logging
from aio_pika import Message, connect_robust
from dotenv import load_dotenv

# load_dotenv()


class RabbitMQManager:
    """RabbitMQ Class."""

    def __init__(self, host="localhost"):
        """Initializes the RabbitMQ manager with the specified host and default credentials.

        Args:
            host (str, optional): The hostname of the RabbitMQ server. Defaults to "localhost".

        """
        self.host = os.getenv("RABBITMQ_HOST")
        self.rabbitmq_port = int(os.getenv("RABBITMQ_PORT"))
        self.rabbitmq_user = os.getenv("RABBITMQ_USER")
        self.rabbitmq_password = os.getenv("RABBITMQ_PASSWORD")
        self.connection = None
        self.channel = None
        self.message = None

    async def initialize_queues(self, queue_names):
        """Declare queues for the application."""
        for queue in queue_names:
            try:
                if queue == "heartbeat_queue":
                    await self.channel.declare_queue(
                        queue, durable=True, arguments={"x-message-ttl": 1000}
                    )
                else:
                    await self.channel.declare_queue(queue, durable=True)
            except Exception as e:
                logging.error(f"Error initializing queue {queue}: {e}")

    async def initialize(self):
        """Initialize connection and channel."""
        try:
            self.connection = await connect_robust(
                host=self.host,
                port=self.rabbitmq_port,
                login=self.rabbitmq_user,
                password=self.rabbitmq_password,
                heartbeat=30,
                timeout=30,
            )
            self.channel = await self.connection.channel()
        except Exception as e:
            logging.error(f"Error initializing RabbitMQ connection: {e}")

    async def publish_task(self, queue_name, task):
        """Publish a task to the specified queue."""
        try:
            if not self.channel:
                await self.initialize()
            await self.channel.default_exchange.publish(
                Message(json.dumps(task, default=str).encode()),
                routing_key=queue_name,
            )
        except Exception as e:
            logging.error(f"Error publishing task to {queue_name}: {e}")

    async def consume_queue(self, queue_name, callback):
        """Consume messages from a queue."""

        async def process_message(message):
            async with message.process():
                try:
                    task = json.loads(message.body.decode())
                    callback(task)
                except Exception as e:
                    logging.error(f"Error processing message from {queue_name}: {e}")

        try:
            queue = await self.channel.get_queue(queue_name)
            await queue.consume(process_message)
        except Exception as e:
            logging.error(f"Error consuming queue {queue_name}: {e}")

    async def close_connection(self):
        """Close RabbitMQ connection."""
        try:
            if self.connection:
                await self.connection.close()
        except Exception as e:
            logging.error(f"Error closing RabbitMQ connection: {e}")

    async def get_channel(self):
        """Function to initialize the channel if not active."""
        try:
            if not self.channel:
                await self.initialize()
            return self.channel
        except Exception as e:
            logging.error(f"Error getting RabbitMQ channel: {e}")
            return None
