"""Rabbit MQ Consumer helper."""

# consumer.py
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))  # Ensure current directory is in path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import asyncio

from datetime import datetime, timezone

from bson import ObjectId
from dotenv import load_dotenv


from src.rabbitMQ_manager import RabbitMQManager
from src.utils.mongo_db import MongoDB
from src.utils.unit_test_generation_utils import RepoMetadataManager
from src.utils.utils_enum import TaskStatus
from src.utils.common.logger import log as logging
from src.utils.common.logger import set_trace_context,set_job_context,set_trace_context_consumer

# Load environment variables
load_dotenv()

from fastapi import HTTPException


async def handle_completion_update(message, repo_metadata_manager: RepoMetadataManager):
    """Handles the completion update for a task.

    This function updates the status of a task in the MongoDB collection based on the
    provided message. If the status code is not 200, it raises an HTTPException.

    Args:
        message (dict): A dictionary containing the task update information. It should
                        include the following keys:
                        - "task_id": The ID of the task.
                        - "status_code": The status code of the task.
                        - "status_message": The status update message.
                        - "output_file_url": The URL of the output file.
                        - "collection_name": The name of the MongoDB collection.

    Raises:
        HTTPException: If there is an error updating the task status in the MongoDB collection.
    """
    task_id = message["task_id"]
    status_code = int(message["status_code"])
    status_update_message = message["status_message"]
    output_file_url_excel = message.get("output_file_url", "")
    output_file_url_json = message.get("output_file_url_json", "")
    output_filename = message.get("output_filename", "")
    testcase_output_filename = message.get("testcase_output_filename", None)
    collection_name = message["collection_name"]

    set_trace_context_consumer(message.get("trace_id"), message.get("parent_span_id"))
    set_job_context(message.get("task_id"))

    try:
        collection = MongoDB.get_collection(collection_name)
        task = collection.find_one({"_id": ObjectId(task_id)})

        if not task:
            logging.error(f"Task not found {task_id}")
            raise Exception(f"No task found for task_id={task_id}")

        old_msg = task.get("status_update_message", {})
        if not isinstance(old_msg, dict):
            old_msg = {}

        timestamp = datetime.now(timezone.utc).isoformat()
        new_entry = {timestamp: status_update_message}

        # merge previous status
        new_update_msg = {**old_msg, **new_entry}

        logging.info(f"Task {task_id} status {status_update_message}.")

        # Skip the status code 202
        if status_code == 202:
            collection.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$set": {
                        "status": message.get("status", TaskStatus.PROCESSING.value),
                        "status_code": 200,
                        "status_update_message": new_update_msg,
                        "lastupdated_timestamp": datetime.now(timezone.utc),
                        }
                },
            )

        elif status_code == 102:
            # Remove fields not needed in DB
            msg_copy = dict(message)
            msg_copy.pop("task_id", None)
            msg_copy.pop("collection_name", None)
            msg_copy.pop("status_code", None)
            msg_copy.pop("_id", None)

            msg_copy["status_update_message"] = new_update_msg
            print(msg_copy)
            collection.update_one(
                {"_id": ObjectId(task_id)},
                {"$set": msg_copy},
            )

        elif status_code != 200:
            # FAILURE CASE
            collection.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$set": {
                        "status": message.get("status", TaskStatus.FAILED.value),
                        "overall_status": message.get("overall_status", TaskStatus.FAILED.value),
                        "status_code": status_code,
                        "status_update_message": new_update_msg,
                        "lastupdated_timestamp": datetime.now(timezone.utc),
                        "output_filename": output_file_url_excel,
                        "match_json_file": output_file_url_json,
                        "error": message.get("error", "Not Available"),
                    }
                },
            )

        else:
            # SUCCESS OR PROCESSING CASE
            update_data = {
                "status_code": 200,
                "status_update_message": new_update_msg,
                "lastupdated_timestamp": datetime.now(timezone.utc),
                "output_filename": output_file_url_excel,
                "match_json_file": output_file_url_json,
            }

            if output_file_url_excel is None:
                update_data["status"] = TaskStatus.PROCESSING.value
                update_data["overall_status"] = TaskStatus.PROCESSING.value
            else:
                update_data["status"] = TaskStatus.SUCCESS.value
                update_data["overall_status"] = TaskStatus.SUCCESS.value
                if output_filename:
                    update_data["output_filename"] = output_filename
                if testcase_output_filename:
                    update_data["testcase_output_filename"] = testcase_output_filename
                logging.info(f"the json file is {output_file_url_json}")

            collection.update_one(
                {"_id": ObjectId(task_id)},
                {"$set": update_data},
            )

            # unit test generation results update
            repo_url = message.get("repo_url", None)
            branch = message.get("branch", None)
            latest_commit = message.get("latest_commit", None)
            component_names = message.get("component_names", [])
            storage_path = message.get("output_filename", "")
            llm_refinements = message.get("llm_refinements", None)
            if repo_url and branch and latest_commit and component_names and llm_refinements:
                await repo_metadata_manager.create_or_update_record(
                    repo_url=repo_url,
                    branch=branch,
                    latest_commit=latest_commit,
                    component_names=component_names,
                    storage_path=storage_path,
                    llm_refinement=llm_refinements
                )
                logging.info(f"Updated unit test metadata to 'unit_test_generation_results_tracking' collection")
            else:
                logging.info(f"Failed updating unit test metadata  to 'unit_test_generation_results_tracking' collection")

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to update task status after processing: {e}",
        )


async def initialize_services():
    """Initialize MongoDB and RabbitMQ connections."""
    try:
        # Initialize MongoDB
        MongoDB.initialize()
        logging.info("MongoDB connection established")

        # Repo metadata manager (separate collection)
        repo_metadata_manager = RepoMetadataManager(
            collection_name="unit_test_generation_results_tracking"
        )
        # Initialize RabbitMQ
        rabbitmq = RabbitMQManager()
        await rabbitmq.initialize()

        # Declare queues from environment config
        queue_names = ["completion_queue"]
        await rabbitmq.initialize_queues(queue_names)

        return rabbitmq, repo_metadata_manager

    except Exception as e:
        logging.error(f"Service initialization failed: {str(e)}")
        raise


async def start_consumer():
    """Start consuming messages from RabbitMQ."""
    try:
        rabbitmq, repo_metadata_manager = await initialize_services()
        # await rabbitmq.channel(prefetch_count=1)
        logging.info("Starting RabbitMQ consumer...")

        loop = asyncio.get_running_loop()

        def callback(message):
            loop.create_task(
                handle_completion_update(
                    message=message,
                    repo_metadata_manager=repo_metadata_manager
                )
            )
        await rabbitmq.consume_queue(
            queue_name="completion_queue", callback=callback
        )
        # Keep the consumer running
        await asyncio.Future()

    except asyncio.CancelledError:
        logging.info("Consumer shutdown requested")
    except Exception as e:
        logging.critical(f"Consumer crashed: {str(e)}")
    finally:
        logging.info("Closing connections...")
        if rabbitmq and getattr(rabbitmq, "channel", None):
            await rabbitmq.channel.close()

        if rabbitmq and getattr(rabbitmq, "connection", None):
            await rabbitmq.connection.close()


if __name__ == "__main__":
    try:
        asyncio.run(start_consumer())
    except KeyboardInterrupt:
        logging.info("Consumer stopped by user")
