import argparse
import json
import os
import sys

import loguru
from pymongo import MongoClient

# Parse command-line arguments
parser = argparse.ArgumentParser(description="MongoDB Schema Extractor")
parser.add_argument("--uri", required=True, help="MongoDB connection URI")
parser.add_argument(
    "--schema_version_folder", default="schema_version", help="Folder where schemas will be saved"
)
args = parser.parse_args()

# Use the URI and schema folder from arguments
uri = args.uri
SCHEMA_FOLDER = args.schema_version_folder

try:
    client = MongoClient(uri, serverSelectionTimeoutMS=10000)
    client.admin.command("ping")
    loguru.logger.info("Connected successfully")
except Exception as e:
    loguru.logger.error(f"Connection error: {e}")
    sys.exit(1)
db = client[os.getenv("DB_NAME", "llmsd-dev")]  # Replace with your actual database name

# Ensure that the schema folder exists
os.makedirs(SCHEMA_FOLDER, exist_ok=True)


def infer_field_type(value):
    """
    Infers the type of a field's value. Replaces 'NoneType' with 'str'.
    """
    field_type = type(value).__name__
    return "str" if field_type == "NoneType" else field_type


def infer_schema(document):
    """
    Infers the schema of a single document.
    """
    schema = {key: infer_field_type(value) for key, value in document.items()}
    return schema


def load_existing_schema(file_path):
    """
    Loads the existing schema file if it exists.
    """
    if os.path.exists(file_path):
        with open(file_path, "r") as f:
            return json.load(f)
    return None


def save_schema_to_file(collection_name, schema, version):
    """
    Saves the schema to a JSON file with versioning (v_x.x.x format).
    """
    file_name = f"{collection_name}_v_{version}.json"
    file_path = os.path.join(SCHEMA_FOLDER, file_name)

    with open(file_path, "w") as f:
        json.dump(schema, f, indent=4)

    loguru.logger.info(
        f"Schema version v_{version} for collection '{collection_name}' saved to {file_path}"
    )
    return file_path


def schema_changed(new_schema, existing_schema):
    """
    Compares two schemas and checks if there is a difference.
    """
    return new_schema != existing_schema


def get_latest_version(collection_name):
    """
    Checks the existing files in the schema folder and retrieves the latest version in the format x.x.x.
    Returns '0.0.0' if no schema file is found.
    """
    version = "0.9.9"  # Default initial version

    # Check for files in the folder matching the collection name
    for file_name in os.listdir(SCHEMA_FOLDER):
        if file_name.startswith(f"{collection_name}_v_") and file_name.endswith(".json"):
            # Extract version number from the filename (e.g., collection_v_0.0.1.json)
            version_str = file_name.split("_v_")[1].split(".json")[0]
            version = max(version, version_str)  # Get the maximum version string

    return version  # Start from 0.0.0 if no schema files exist


def increment_version(version):
    """
    Increments the version following semantic versioning:
    - 0.0.9 -> 0.1.0
    - 0.9.9 -> 1.0.0
    """
    major, minor, patch = map(int, version.split("."))

    # First, increment the patch
    patch += 1

    # If the patch exceeds 9, reset patch to 0 and increment minor
    if patch > 9:
        patch = 0
        minor += 1

    # If the minor exceeds 9, reset minor to 0 and increment major
    if minor > 9:
        minor = 0
        major += 1

    return f"{major}.{minor}.{patch}"


def schema_exists(collection_name, current_schema):
    """
    Check if the current schema already exists in the schema file for the collection.
    If it exists, return True, otherwise return False.
    """
    # Find the latest schema file for this collection
    latest_version = get_latest_version(collection_name)
    if latest_version != "0.0.0":
        file_name = f"{collection_name}_v_{latest_version}.json"
        file_path = os.path.join(SCHEMA_FOLDER, file_name)
        existing_schema = load_existing_schema(file_path)
        if not schema_changed(current_schema, existing_schema):
            return True
    return False


def main():
    # Get a list of all collections in the database
    collection_names = db.list_collection_names()

    for collection_name in collection_names:
        loguru.logger.info(f"Processing schema for collection: {collection_name}")

        # Get the last document from the collection to infer its schema
        last_document = db[collection_name].find().sort([("$natural", -1)]).limit(1)

        documents = list(last_document)

        if not documents:
            loguru.logger.info(f"No documents found in collection '{collection_name}'. Skipping...")
            continue

        # Infer the schema from the last document
        current_schema = infer_schema(documents[0])

        # Check if this schema already exists in any previous schemas for this collection
        if schema_exists(collection_name, current_schema):
            loguru.logger.info(
                f"Schema already exists for collection '{collection_name}'. No version update needed."
            )
            continue

        # Get the latest schema type for the collection
        latest_schema_type = get_latest_version(collection_name)
        new_schema_type = increment_version(latest_schema_type)

        # Save the new schema as a separate schema type
        save_schema_to_file(collection_name, current_schema, new_schema_type)


if __name__ == "__main__":
    main()
